export class Course {
    courseName:string;
    coursePrice:number;
    courseRating?:number;
}
