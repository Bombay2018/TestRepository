
export const QUOTES = [
        {"quoteBy":"Harry","quote":"Be Unique, not Perfect"},
        {"quoteBy":"Sally","quote":"Life , has different perspectives"},
        {"quoteBy":"Jeff","quote":"Cartoons, depicts Sarcassim to its best"},
        {"quoteBy":"Pam","quote":"Happy, in space"},
        {"quoteBy":"Carol","quote":"Play, the strings, to tap in the right moments of life!"},
]

