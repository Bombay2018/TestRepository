export interface Quote {
    quoteBy:string;
    quote:string;
}
