import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['../assets/red.css']
})
export class AppComponent {
  title:string = 'app';
  imgPath:string;
  flag:boolean;

  constructor() {
    this.imgPath = '../assets/buddha-04.jpg'
    this.flag=true;
  }

  remove() {
    alert("I am leaving----");
    this.flag = false;
  }
}
