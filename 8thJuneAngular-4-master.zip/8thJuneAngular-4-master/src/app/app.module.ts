import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';

// custom module
import {SharedModule} from './shared/shared.module';
import {RoutingModule} from './routing/routing.module';

import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { EmployeeComponent } from './employee/employee.component';
import {EmployeeService} from './employee.service';
import { DateconvertorPipe } from './dateconvertor.pipe';
import { SortPipe } from './sort.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChilsComponent } from './chils/chils.component';
import { WebComponent } from './web/web.component';
import { StudentComponent } from './student/student.component';
import { CustomerComponent } from './customer/customer.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { EmployeeDetailComponent } from './employee-detail/employee-detail.component';
import {XXXService} from './xxx.service';

@NgModule({
  // components , pipes , directives
  declarations: [
    AppComponent,
    UserComponent,
    EmployeeComponent,
    DateconvertorPipe,
    SortPipe,
    ParentComponent,
    ChilsComponent,
    WebComponent,
    StudentComponent,
    CustomerComponent,
    NotFoundComponent,
    EmployeeDetailComponent,
    
  ],
  // dependent modules
  imports: [
    BrowserModule,
    FormsModule,
    SharedModule,
    HttpModule,
    ReactiveFormsModule,
    RoutingModule
  ],
  // services = global to module
  providers: [EmployeeService,XXXService],
  // Root component
  bootstrap: [AppComponent]
})
export class AppModule { }
