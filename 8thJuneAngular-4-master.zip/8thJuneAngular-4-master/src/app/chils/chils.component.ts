import { Component, OnInit,Input,OnChanges,SimpleChanges,Output,EventEmitter } from '@angular/core';
import {Pricequoter} from '../pricequoter';

@Component({
  selector: 'child',
  templateUrl: './chils.component.html',
  styleUrls: ['./chils.component.css']
})
export class ChilsComponent implements OnInit,OnChanges {
  @Input() sampleText:string; // receive from the parent

  // Generating an EventEmitter of Pricequpter Type. To emit events(publish)
  @Output() emitter:EventEmitter<Pricequoter> = new EventEmitter<Pricequoter>();

   stkSym:string;
   lstPrice:number;

  curr:string;

  constructor() { }

  ngOnInit() {
    setInterval(()=>{
      // initializing prizequoter object
      let sharePrice:Pricequoter = {
        stockSymbol:"TechM",
        lastPrice:100 * Math.random() 
      }
      // initializing instance members
      this.stkSym = sharePrice.stockSymbol;
      this.lstPrice = sharePrice.lastPrice;

      // emit an event
      this.emitter.emit(sharePrice); // priceQuoter object

    },1000);
  }

  ngOnChanges(changes:SimpleChanges) {
    let prev = changes.sampleText.previousValue;
    this.curr = changes.sampleText.currentValue;
    console.log("Previous value::" + JSON.stringify(prev) + "  Current Value::" + JSON.stringify(this.curr));

  }
}
