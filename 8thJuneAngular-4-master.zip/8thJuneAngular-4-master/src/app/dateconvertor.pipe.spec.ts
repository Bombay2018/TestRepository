import { DateconvertorPipe } from './dateconvertor.pipe';

describe('DateconvertorPipe', () => {
  it('create an instance', () => {
    const pipe = new DateconvertorPipe();
    expect(pipe).toBeTruthy();
  });
});
