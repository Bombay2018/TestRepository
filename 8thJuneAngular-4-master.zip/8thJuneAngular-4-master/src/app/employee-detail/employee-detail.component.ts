import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from  '@angular/router';
import {EmployeeService} from '../employee.service';
import {Employee} from '../employee';

@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.css']
})
export class EmployeeDetailComponent implements OnInit {
  
  employee:Employee;

  constructor(private _route:ActivatedRoute,private _service:EmployeeService) { }

  ngOnInit() {
    this._route.paramMap.subscribe(params=>{
      let ename = params.get('ename');
      this.employee = this._service.getEmployeeByName(ename);
    })
  }

}
