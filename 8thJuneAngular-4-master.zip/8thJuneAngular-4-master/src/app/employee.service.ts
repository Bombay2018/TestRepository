import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable()
export class EmployeeService {
  employees: Employee[];

  constructor() {
    this.employees = [
      { "empId": 1001, "empName": "Jack", "empPhone": 5678903456, "empPhoto": "../assets/buddha-04.jpg", empSalary: 56000, "empDoB": "1994-12-9" },
      { "empId": 1002, "empName": "Jill", "empPhone": 7890124537, "empPhoto": "../assets/buddha-04.jpg", empSalary: 67000, "empDoB": "1991-10-8" },
      { "empId": 1003, "empName": "Jessica", "empPhone": 4747567467, "empPhoto": "../assets/buddha-04.jpg", empSalary: 25000, "empDoB": "1990-10-10" },
      { "empId": 1004, "empName": "Robert", "empPhone": 1423423423, "empPhoto": "../assets/buddha-04.jpg", empSalary: 78000, "empDoB": "1984-12-11" },
      { "empId": 1005, "empName": "Harry", "empPhone": 78979789789, "empPhoto": "../assets/buddha-04.jpg", empSalary: 35000, "empDoB": "1993-6-9" },
      { "empId": 1006, "empName": "Sebastian", "empPhone": 2325346346, "empPhoto": "../assets/buddha-04.jpg", empSalary: 45000, "empDoB": "1989-1-9" }
    ]
  }

  getEmployees(): Employee[] {
    return this.employees;
  }

  getEmployeeByName(ename: string): Employee {
    for (let i = 0; i < this.employees.length; i++) {
      if (ename == this.employees[i].empName) {
        return this.employees[i];
      }
    }
  }

}
