export interface Employee {
    empId:number;
    empName:string;
    empPhone:number;
    empPhoto:string;
    empSalary:number;
    empDoB:string;

}
