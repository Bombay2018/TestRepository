import { Component, OnInit, OnDestroy} from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: []
})

export class EmployeeComponent implements OnInit, OnDestroy {
  public employees: Employee[];

  // DI via construtor - injecting the service object
  constructor(private _empService: EmployeeService) { }

  ngOnInit() {
    // acess data from service
    this.employees = this._empService.getEmployees();
  }

  ngOnDestroy() {

  }
}
