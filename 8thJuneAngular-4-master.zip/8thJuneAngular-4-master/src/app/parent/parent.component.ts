import { Component, OnInit } from '@angular/core';
import {Pricequoter} from '../pricequoter';

@Component({
  selector: 'parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  userText:string;
  stockSymbol:string;
  finalPrice:number;

  constructor() { 
    this.userText = "Google";
  }

  ngOnInit() {
  }

// Event Handler for the child emitted Event
  priceQuoteHandler(event:Pricequoter) {
    this.stockSymbol = event.stockSymbol;
    this.finalPrice = event.lastPrice;
  }
}
