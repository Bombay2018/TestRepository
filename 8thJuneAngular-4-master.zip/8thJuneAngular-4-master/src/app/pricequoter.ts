export interface Pricequoter {
    stockSymbol:string;
    lastPrice:number;
}
