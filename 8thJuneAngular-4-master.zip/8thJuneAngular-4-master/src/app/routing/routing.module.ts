import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import {CustomerComponent} from '../customer/customer.component';
import {EmployeeComponent} from '../employee/employee.component';
import {StudentComponent} from '../student/student.component';
import {UserComponent} from '../user/user.component';
import {ParentComponent} from '../parent/parent.component';
import {WebComponent} from '../web/web.component';
import {NotFoundComponent} from '../not-found/not-found.component';
import {EmployeeDetailComponent} from '../employee-detail/employee-detail.component';
import {XXXService} from '../xxx.service';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot([
      {path:'',redirectTo:'/customer',pathMatch:'full'},
      {path:'customer',component:CustomerComponent,canActivate:[XXXService]},
      {path:'employeeDetails/:ename',component:EmployeeDetailComponent},
      {path:'employee',component:EmployeeComponent},
      {path:'parent',component:ParentComponent},
      {path:'student',component:StudentComponent},
      {path:'user',component:UserComponent},
      {path:'web',component:WebComponent},
      // generic : when no path matches
      {path:'**',component:NotFoundComponent},
    ])
  ],
  declarations: [],
  exports:[RouterModule] // exporting the entire Router Module
})
export class RoutingModule { }
