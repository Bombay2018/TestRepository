import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hello',
  templateUrl: './hello.component.html',
  styleUrls: ['./hello.component.css']
})
export class HelloComponent implements OnInit {
  name:string;
  flag: boolean;

  constructor() { 
    this.flag = false;
  }

  ngOnInit() {
  }

  getName() {
    this.name = "Shirley Clinton";
    this.flag = true;
  }
}
