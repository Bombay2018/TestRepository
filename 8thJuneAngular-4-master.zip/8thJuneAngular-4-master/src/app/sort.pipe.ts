import { Pipe, PipeTransform } from '@angular/core';
import { Employee } from './employee';
@Pipe({
  name: 'sortByName'
})
export class SortPipe implements PipeTransform {

  transform(array: Array<Employee>): Array<Employee> {
    array.sort((a, b) => {
      var a1 = a.empName.toUpperCase();
      var b1 = b.empName.toUpperCase();

      if (a1 < b1) {
        return -1;
      } else if (a1 > b1) {
        return 1;
      } else {
        return 0;
      }
    });
    return array;
  }

}
