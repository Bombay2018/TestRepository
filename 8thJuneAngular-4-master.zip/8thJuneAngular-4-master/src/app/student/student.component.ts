import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  firstName:string; // text box
  secret:string; // pASSword
  gender:string; // radio
  isTNC:boolean; // checkbox
  qualification:string; // drop down
  
  // array to populate the drop down list
  education:string[]; 
  
  constructor() {
    this.education = ["MSc","MBA","Phd","MCA"];
   }

  ngOnInit() {
  }

  validate(studForm) {
    console.log(studForm);
  }

}
