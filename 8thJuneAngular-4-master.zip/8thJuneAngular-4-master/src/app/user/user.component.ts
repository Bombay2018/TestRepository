import { Component, OnInit } from '@angular/core';
import {Address} from '../address';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['../../assets/red.css']
})
export class UserComponent implements OnInit {
  email:string;
  address1: Address;
  address2: Address;
  hobbies: string[];
  flag:boolean;

  constructor() { 
    this.email = "animalhag@gmail.com";
    this.address1 = {
      city : 'San Diego',
      state : 'California',
      country : 'USA'
    },
    this.hobbies = ['Painting','Photography','New Aged Delivery','Browsing'];
    this.flag = false;
  }

  ngOnInit() {
  }

  playHobbies() {
    this.flag = !this.flag;
  }

  addHobby(hob:string) {
    this.hobbies.push(hob);
  }

  deleteHobby(j:number) {
    this.hobbies.splice(j,1);
  }
} 

