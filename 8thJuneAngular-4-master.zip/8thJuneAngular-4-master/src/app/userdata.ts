export interface Userdata {
    id:number;
    first_name:string;
    last_name:string;
    avatar:string;
}
