import { Injectable } from '@angular/core';
import {Http,Response} from '@angular/http';
import {Observable} from 'rxjs/Observable';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import {Userdata} from './userdata';

@Injectable() // inject the Http object into my Web service
export class WebService {

  // DI
  constructor(private _http: Http) { 
  }

  getData():Observable<any>{
    return this._http.get("https://reqres.in/api/users")
    .map(this.extractData)
    .catch(this.handleError);
  }

  getDataById(id:number):Observable<any>   {
    return this._http.get("https://reqres.in/api/users/"+id)
    .map(this.extractData)
  }

  // HTTP Response
  extractData(res:Response) {
    let body = res.json().data; // part of the response object
    return body;
  }

  // HTTP error
  handleError(error:any) {
    return Observable.throw(error); //re throwing exceptions
  }
}
