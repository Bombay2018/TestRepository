import { Component, OnInit } from '@angular/core';
import {WebService} from '../web.service';
import {Userdata} from '../userdata';

@Component({
  selector: 'web',
  templateUrl: './web.component.html',
  styleUrls: ['./web.component.css'],
  providers:[WebService] // service is availble to WebComponent and children
})
export class WebComponent implements OnInit {
  users:Userdata[];
  userObject:Userdata; // fetching object by ID
  flag;flag1:boolean;
  errorMessage:string;

  constructor(private _web:WebService) { }

  ngOnInit() {
     //result  is the object that will receive data from service (map operator)
    this._web.getData()
    .subscribe(result=>this.users=result);
  }

  getById(id:number) {
    this._web.getDataById(id)
    .subscribe(result=>{
      if(result!=undefined){
         this.flag = true;
        this.userObject=result,
        error=>this.errorMessage=error
      }else{
        this.flag1 = true;
      }
     
    });
    
  }


}
