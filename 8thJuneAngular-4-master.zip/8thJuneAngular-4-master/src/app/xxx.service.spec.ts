import { TestBed, inject } from '@angular/core/testing';

import { XXXService } from './xxx.service';

describe('XXXService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [XXXService]
    });
  });

  it('should be created', inject([XXXService], (service: XXXService) => {
    expect(service).toBeTruthy();
  }));
});
