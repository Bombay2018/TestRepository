using Microsoft.Extensions.DependencyInjection;
using ServiceLocator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Angular6
{
  public static class ServiceExtension
  {
    public static IServiceCollection RegisterServices(this IServiceCollection services)
    {
      services.AddSingleton((ctx) =>
      {
        return ServiceFactory.GetLogger();
      });

      services.AddScoped((ctx) =>
      {
        return ServiceFactory.GetEmailProxy();
      });

      return services;
    }
  }
}
