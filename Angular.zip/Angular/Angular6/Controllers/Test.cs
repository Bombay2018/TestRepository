using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Angular6
{
  public static class FactoryManager1
  {
    public static IEntityServiceProvider GetEntityServiceProvider()
    {
      string option = "SQL";
      switch (option)
      {
        case "SQL":
          return new SQLServerEntityService();
        case "COSMOS":
          return new CosmosEntityService();
        default:
          throw new ArgumentException("Unsupported ESignEngine", option);
      }
    }

  }
}


namespace Angular6
{

  public interface IEntityServiceProvider
  {
    string Greeting();
  }

  public class CosmosEntityService : IEntityServiceProvider
  {
    public string Greeting()
    {
      return "CosmosEntityService";
    }
  }

  public class SQLServerEntityService : IEntityServiceProvider
  {
    public string Greeting()
    {
      return "SQLServerEntityService";
    }
  }
}
