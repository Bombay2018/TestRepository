using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Angular6.Models;
using Logger.Abstractions;
using MailProxy.Abstraction.Proxy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Angular6.Controllers
{
  [Route("api/[controller]")]
  public class ValuesController : Controller
  {
    public ILogger Logger { get; set; }
    public IMailProxy MailProxy { get; set; }
    public ValuesController(ILogger logger,IMailProxy mailProxy) // Constructor Injection
    {
      Logger = logger;
      MailProxy = mailProxy;
    }

    // GET api/values
    [HttpGet]
    [Authorize]
    public IEnumerable<string> Get()
    {
      try
      {

        string sMessage = null;
        if(sMessage==null)
        {
          throw new DivideByZeroException("Invalid Data");
        }
        if (sMessage.Length > 0)
        {
          var sResult = sMessage.Substring(0);
        }

        UserRegistration.SendMail(MailProxy); // Method Injection

        var quote = new Quote();
        quote.MailService = MailProxy; //Propert Injection
        quote.SendMail();

        Logger.Warn(new Exception("Getting values"));

        return new string[] { "value1", "value2" };
      }
      catch (ArgumentException ex)
      {
        Logger.Error(ex);
        throw new ApiException(ex, 500);
      }
      catch (DivideByZeroException ex)
      {
        Logger.Error(ex);
        throw new ApiException(ex,500);
      }
      catch (Exception ex)
      {
        Logger.Error(ex);
        throw ex;
      }
    }

    // GET api/values/5
    [HttpGet("{id}")]
    public static string Get(int id)
    {
      return "value";
    }

    // POST api/values
    [HttpPost]
    public static void Post([FromBody]string value)
    {
    }

    // PUT api/values/5
    [HttpPut("{id}")]
    public static void Put(int id, [FromBody]string value)
    {
    }

    // DELETE api/values/5
    [HttpDelete("{id}")]
    public static void Delete(int id)
    {
    }
  }
}
