using MailProxy.Abstraction.Model;
using MailProxy.Abstraction.Proxy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;

namespace Angular6.Models
{
  public static class UserRegistration
  {
    public static void SendMail(IMailProxy mailProxy)
    {
      IMailMessage message = new MailMessage();
      mailProxy.SendMailAsync(message);
    }
  }

  public class Quote
  {
    private IMailProxy _mailService;

    public IMailProxy MailService

    {
      set
      {
        this._mailService = value;
      }

      get
      {
        return this._mailService;
      }
    }

    public void SendMail()
    {
      IMailMessage message = new MailMessage();
      this._mailService.SendMailAsync(message);
    }
  }


  public class MailMessage : IMailMessage
  {
    public MailAddress Sender { get; set; }
    public ICollection<MailAddress> Recipients { get; set; }
    public string Subject { get; set; }
    public string PlainTextBody { get; set; }
    public string HtmlBody { get; set; }

    public IPrototype Clone()
    {
      throw new NotImplementedException();
    }
  }

}
