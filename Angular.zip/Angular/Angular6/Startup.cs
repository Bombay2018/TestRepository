using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ServiceLocator;

namespace Angular6
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public static void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();

            //var policy = new AuthorizationPolicyBuilder()
            //.RequireAuthenticatedUser()
            //.RequireRole("Admin", "SuperUser")
            //.Build();


            services.AddMvc(options =>
            {
             // options.Filters.Add(new CustomActionFilter());
              options.Filters.Add(new ApiExceptionFilter());
              
                 
                 //options.Filters.Add(typeof(CustomActionFilter));

                //options.Filters.Add(new CustomAuthorizationFilter());

                //options.Filters.Add(new AuthorizeFilter(policy));
            });
            services.RegisterServices();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public static void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            //if (!env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}
            //else
            //{
            //    app.UseExceptionHandler(
            //        options =>
            //        {
            //          options.Run(
            //          async context =>
            //          {
            //            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            //            context.Response.ContentType = "text/html";
            //            var ex = context.Features.Get<IExceptionHandlerFeature>();
            //            if (ex != null)
            //            {
            //              var err = $"<h1>Error: {ex.Error.Message}</h1>{ex.Error.StackTrace }";
            //              await context.Response.WriteAsync(err).ConfigureAwait(false);
            //            }
            //          });
            //        });


            //} 

            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseMvc();
        }
    }
}
