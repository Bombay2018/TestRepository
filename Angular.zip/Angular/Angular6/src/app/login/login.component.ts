import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { IUSER_MASTER } from './../shared/interfaces/entities.interface';
import { UserService } from './../services/user.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[UserService]
})


export class LoginComponent implements OnInit {

  public user:IUSER_MASTER = {user_name:'', password:''} as IUSER_MASTER;

    constructor(private _routes: Router,private _userSev:UserService<IUSER_MASTER>) { 

  }

  ngOnInit() {  


    };

    onUserNameKeyPress(event: any) { // without type info
        this.user.user_name = this.user.user_name.trim();
    }

    onPasswordKeyPress(event: any) { // without type info
        this.user.password = this.user.password.trim();
    }

  doLogin() {
    this.isValidUser(this.user as IUSER_MASTER)
     // this._userSev.getUser(this.user).subscribe(
     // resdata => this.isValidUser(resdata as IUSER_MASTER)
     //);
    };

    showRegister() {
        alert('register');
        this._routes.navigate(['/register']);
    };


  isValidUser(user: IUSER_MASTER) {
    debugger;
    alert('Success');
    return;

    //if (this.user != undefined) {
    //    if (this.user.user_name == 'Ajith' && this.user.password == 'a1234567') {
    //    localStorage.setItem('currentUser', JSON.stringify(user));
    //    /* the global event manger to show the nav bar */
    //    //this._globalEventsManagerSev.showNavBar(true);
    //    // this._globalEventsManagerSev.showNavBar.emit(true);
    //    //this._routes.navigate(['/home']);
    //    } else {
    //    this.invalidUser();
    //    }
    //} else {
    //    this.invalidUser();
    //}
  }

  invalidUser() {
    alert('Invalid User');
  }
}

