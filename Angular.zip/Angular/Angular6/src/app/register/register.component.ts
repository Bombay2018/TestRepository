import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { IUSER_MASTER } from './../shared/interfaces/entities.interface';
import { UserService } from './../services/user.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
    styleUrls: ['./register.component.css'],
  providers:[UserService]
})


export class RegisterComponent implements OnInit {

  public user:IUSER_MASTER = {user_name:'', password:''} as IUSER_MASTER;

  

  ngOnInit() {  
    
  }

    doRegister() {
    
  }

}

