import { NgModule,ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';


import { LoginComponent } from '../login/login.component';
import { RegisterComponent } from '../register/register.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot([
      // Configure the routes...Routes are objects. Default patterns  
      { path: '', component: LoginComponent },
      //{path:'',redirectTo:'/login',pathMatch:'full'},  
      {path:'login',component:LoginComponent},
      {path:'register',component:RegisterComponent},  
    ])
  ],
  declarations: [],
  exports:[RouterModule]
})
export class RoutingModule { }
