import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
//import { Subject } from 'rxjs/Rx';

@Injectable()
export class ConfigService {

    _apiURI: string;
    _header: any;

    constructor() {
        this._apiURI = '<<>>/services/';
    }

    getApiURI() {
        return this._apiURI;
    }

    getApiHost() {
        return this._apiURI.replace('api/', '');
    }

    getHTTPHeader() {
        this._header = new Headers({
           // 'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization',
            //'Access-Control-Allow-Origin': '*',
           // 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Content-Type': 'application/json'
        });

        return this._header;

    }
    
}
