import { Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, Subject } from 'rxjs';
import { map, take, tap, catchError} from 'rxjs/operators';


import { IUSER_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';





@Injectable()
export class UserService<T> {

  private _baseUrl: string = '';
    private _headers: any;

    public user: IUSER_MASTER; 

    constructor(private http: HttpClient) {
       //this._baseUrl = configsvc.getApiURI();
    }

    getUser(Iuser: IUSER_MASTER): Observable<any> {
        debugger;
        return this.http.get<IUSER_MASTER>(this._baseUrl + "/assets/user.json");
      //let data = {
      //    "uname": Iuser.user_name,
      //    "pwd": Iuser.password
      //};
      //let options = new RequestOptions({ headers: this._headers });
      //let body = JSON.stringify(data);

      //return this.http.get<any>('user.json')
      //  .pipe(map((response: any) => { return <any>response.json() }));

  
      //(tap((data: any) => { console.log(JSON.stringify(data)) }))

      //return this.http.get("../shared/mockdata/user.json")
      //  .pipe(map((response: any) => { <IUSER_MASTER>response.json().Result[1] }),
      //    (tap((data: any) => { console.log(JSON.stringify(data)) })));   
  
            
  }
 
}



