export interface IUSER_MASTER{
    user_id: number;
    user_name: string;
    password: string;
    firstName: string;
    lastName: string;
   
}
