﻿using System.Collections.Specialized;

namespace ConfigReader.Abstraction
{
    public interface IConfigReader
    {
        NameValueCollection AppSettings { get; }
    }
}