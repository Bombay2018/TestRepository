﻿using Logger.Abstractions;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Logger.Abstractions
{
    public interface ILogger
    {
        Task Configure(ILoggingServer loggingServer);

        Task Debug(Exception exception);
        Task Debug(Exception exception, string format);
        Task Debug(Exception exception, string format, params object[] args);

        Task Error(Exception exception);
        Task Error(Exception exception, string format);
        Task Error(Exception exception, string format, params object[] args);

        Task Info(Exception exception);
        Task Info(Exception exception, string format);
        Task Info(Exception exception, string format, params object[] args);

        Task Warn(Exception exception);
        Task Warn(Exception exception, string format);
        Task Warn(Exception exception, string format, params object[] args);
    }
}
