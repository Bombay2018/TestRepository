﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Logger.Abstractions
{
    public interface ILoggingServer 
    {
        Uri Url { get; set; }
        NetworkCredential Credential { get; set; }
        string ApiKey { get; set; }
    }
}
