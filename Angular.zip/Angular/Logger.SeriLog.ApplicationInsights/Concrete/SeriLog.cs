﻿using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using Logger.Abstractions;
using Serilog;
using System.Collections.Generic;
using System.Text;
using ILoggerService = Logger.Abstractions.ILogger;


namespace Logger.SeriLog.ApplicationInsights.Concrete
{
    public class SeriLog : ILoggerService
    {
        public async Task Configure(ILoggingServer loggingServer)
        {
            await Task.Run(() => Serilog.Log.Logger = new Serilog.LoggerConfiguration()
               .MinimumLevel.Verbose() // Minimum severity to log
               .WriteTo
               .ApplicationInsightsEvents(loggingServer.ApiKey)
               .CreateLogger());
        }

        public async Task Debug(Exception exception)
        {
            await Task.Run(() => Serilog.Log.Debug(exception.Message));
        }

        public Task Debug(Exception exception, string format)
        {
            throw new NotImplementedException();
        }

        public Task Debug(Exception exception, string format, params object[] args)
        {
            throw new NotImplementedException();
        }

        public async Task Error(Exception exception)
        {
            await Task.Run(() => Serilog.Log.Error(exception.Message));
        }

        public Task Error(Exception exception, string format)
        {
            throw new NotImplementedException();
        }

        public Task Error(Exception exception, string format, params object[] args)
        {
            throw new NotImplementedException();
        }

        public  async Task Info(Exception exception)
        {
            await Task.Run(() => Serilog.Log.Information(exception.Message));
        }

        public Task Info(Exception exception, string format)
        {
            throw new NotImplementedException();
        }

        public Task Info(Exception exception, string format, params object[] args)
        {
            throw new NotImplementedException();
        }

        public async Task Warn(Exception exception)
        {
            await Task.Run(() => Serilog.Log.Warning(exception.Message));
        }

        public async Task Warn(Exception exception, string format)
        {
            await Task.Run(() => Serilog.Log.Warning(exception.Message));
        }

        public Task Warn(Exception exception, string format, params object[] args)
        {
            throw new NotImplementedException();
        }

    }
}
