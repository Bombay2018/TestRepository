﻿using MailProxy.Abstraction.Proxy;

namespace MailProxy.Abstraction.Factory
{
    public interface IMailProxyFactory
    {
        ITempatedMailProxy GetTemplatedMailProxy();

        IExtandedMailProxy GetExtendedMailProxy();
    }
}
