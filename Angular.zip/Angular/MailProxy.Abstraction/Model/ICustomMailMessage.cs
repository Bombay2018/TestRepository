﻿namespace MailProxy.Abstraction.Model
{
    public interface ICustomMailMessage : IMailMessageExtended
    {
        CustomArguments CustomArgs { get; set; }

    }

    public class CustomArguments
    {
        public string MessageId { get; set; }
    }
}
