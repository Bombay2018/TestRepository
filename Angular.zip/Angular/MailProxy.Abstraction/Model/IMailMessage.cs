﻿using System.Collections.Generic;
using System.Net.Mail;

namespace MailProxy.Abstraction.Model
{
    public interface IPrototype
    {
        IPrototype Clone();
    }

    public interface IMailMessage : IPrototype
    {
        MailAddress Sender { get; set; }

        ICollection<MailAddress> Recipients { get; set; }

        string Subject { get; set; }

        string PlainTextBody { get; set; }

        string HtmlBody { get; set; }
    }

    public interface IMailMessageExtended : IMailMessage
    {
        MailAddress ReplyTo { get; set; }

        ICollection<MailAddress> Cc { get; }

        ICollection<MailAddress> Bcc { get; }

        ICollection<Attachment> Attachements { get; }
    }
}
