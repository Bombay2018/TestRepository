﻿using System.Collections.Generic;

namespace MailProxy.Abstraction.Model
{
    public interface ITemplatedMailMessage : IMailMessage
    {
        int EmailTemplateId { get; set; }

        ICollection<string> Category { get; set; }

        Dictionary<string, string> Substitutions { get; }

        string AccessToken { get; set; }

        string UniqueId { get; set; }

        bool IsTrack { get; set; }
    }
}
