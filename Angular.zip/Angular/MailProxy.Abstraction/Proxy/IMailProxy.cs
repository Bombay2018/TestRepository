﻿using MailProxy.Abstraction.Model;
using System.Threading.Tasks;

namespace MailProxy.Abstraction.Proxy
{
    public interface IMailProxy
    {
        Task SendMailAsync(IMailMessage message);
    }

    public interface ITempatedMailProxy : IMailProxy
    {
        ITemplatedMailMessage GetBlankTemplatedMessage();
    }

    public interface IExtandedMailProxy : IMailProxy
    {
        IMailMessageExtended GetBlankMessage();
    }
}
