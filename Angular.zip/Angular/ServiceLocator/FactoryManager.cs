﻿using Logger.Abstractions;
using System;
using System.Collections.Specialized;
using Logger.SeriLog.ApplicationInsights.Concrete;
using MailProxy.Abstraction.Proxy;
using MailProxy.Abstraction.Model;
using System.Threading.Tasks;

namespace ServiceLocator
{
    public static class ServiceFactory
    {
        public static ILogger GetLogger()
        {
            string logger = "SeriLog";
            switch (logger)
            {
                case "SeriLog":
                    var serilog = new SeriLog();
                    Task.Run(() => serilog.Configure(GetLoggingServer()));
                    return serilog;
                case "NLog":
                    throw new NotImplementedException();
                default:
                    throw new NotImplementedException();

            }
        }

        private static ILoggingServer GetLoggingServer()
        {
            string Service = "Seq";

            switch (Service)
            {
                case "Seq":

                    return LoggingServer.Create(new Uri("http://localhost:5321/"), null, null);

                case "ApplicationInsights":

                    return LoggingServer.Create(null, null, "9af8b854-f846-47a0-809e-e12b81a29380");

                default:

                    throw new NotImplementedException();

            }

        }

        public static IMailProxy GetEmailProxy()
        {
            string logger = "SendGrid";
            switch (logger)
            {
                case "SendGrid":
                    return new MailProxy();
                case "Amazon":
                    throw new NotImplementedException();
                default:
                    throw new NotImplementedException();

            }
        }
    }
}

namespace ServiceLocator
{
    public class MailProxy : IMailProxy
    {
#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
        public async Task SendMailAsync(IMailMessage message)
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously
        {
            System.Diagnostics.Debug.Print("");
        }
    }
}

