﻿using Logger.Abstractions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace ServiceLocator
{
    public class LoggingServer : ILoggingServer
    {
        public Uri Url { get; set; }
        public NetworkCredential Credential { get; set; }
        public string ApiKey { get; set; }

        public static LoggingServer Create(Uri url, NetworkCredential credential, string apiKey)
        {
            return new LoggingServer { Url = url, Credential = credential, ApiKey = apiKey };
        }
    }
}
