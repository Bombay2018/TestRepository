import { Component } from '@angular/core';
import {Address} from './address';
@Component({
  selector: 'home-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:string ;
  email:string ;
  address:Address;
  imgPath:string;
  check:boolean;

  constructor() {
    this.title='Welcome to Angular';
    this.email='justinbeiber@animalhack.com';
    this.address ={
      city:'Agra',
      state:'Uttar Pradesh'
    };
    this.imgPath='../assets/image2.jpg';
    this.check = true;
  }

  remove() {
    this.check = false;
  }
}

