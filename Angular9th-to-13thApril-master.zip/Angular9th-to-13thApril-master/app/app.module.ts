import { BrowserModule } from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import { NgModule } from '@angular/core';
import {BsDatepickerModule} from 'ngx-bootstrap/datepicker';
// custom module
import {RoutingModule} from './routing/routing.module';

import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { EmployeeComponent } from './employee/employee.component';
import {EmployeeService} from './employee.service';
import { RatingComponent } from './rating/rating.component';
import { DateconvertorPipe } from './dateconvertor.pipe';
import { SortPipe } from './sort.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { EmployeeChildComponent } from './employee-child/employee-child.component';
import { ShadowDirective } from './shadow.directive';
import { PostComponent } from './post/post.component';
import { StudentComponent } from './student/student.component';
import { CustomerComponent } from './customer/customer.component';
import { NotFoundComponent } from './not-found/not-found.component';



@NgModule({
  declarations: [
    // Components , Directives , Pipes
    AppComponent,
    UserComponent,
    EmployeeComponent,
    RatingComponent,
    DateconvertorPipe,
    SortPipe,
    ParentComponent,
    ChildComponent,
    EmployeeChildComponent,
    ShadowDirective,
    PostComponent,
    StudentComponent,
    CustomerComponent,
    NotFoundComponent,

      
  ],
  imports: [
    // other modules you are dependent on
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    RoutingModule
  ],
  // services : Global
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
