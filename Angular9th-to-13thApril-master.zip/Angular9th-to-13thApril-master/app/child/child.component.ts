import { Component, OnInit,Input,OnChanges,SimpleChanges,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'home-child',
  template: `
    Inside Child : {{outTxt}}
    <br/>
    <button class="btn btn-primary" (click)='callNotify()'>Click Me</button>

  `,
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit,OnChanges {

  @Input() outTxt:string;

  @Output() notify = new EventEmitter;
  counter = 0;

  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    let prevValue = changes.outTxt.previousValue;
    let currValue = changes.outTxt.currentValue;
    console.log("Previous value::" + JSON.stringify(prevValue) + " Current Value::" + JSON.stringify(currValue));
  }

  callNotify() {
    this.counter = this.counter + 1;// change

    this.notify.emit(this.counter); // raise an event and it will propogate to Parent
  }
}
