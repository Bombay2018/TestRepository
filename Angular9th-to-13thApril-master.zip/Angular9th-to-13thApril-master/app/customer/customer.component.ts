import { Component, OnInit } from '@angular/core';
import  {FormGroup, FormBuilder,Validators} from '@angular/forms';

@Component({
  selector: 'home-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customerForm : FormGroup;
  pwdPattern : string;
  emailPattern : string;
  qualification : string[];

  constructor(private fb:FormBuilder) {
    this.pwdPattern = '^[A-Za-z0-9]{8,15}$';
    this.emailPattern = '^[a-z0-9$]+[@][a-z]+[.][a-z]{3}$';
    this.qualification = ['M.Sc','B.Sc','PHd'];
    // construct form
    this.customerForm = fb.group({
      // individual form controls
      'firstName':['',Validators.required],
      'password':['',[Validators.required,Validators.pattern(this.pwdPattern)]],
      'gender':['',Validators.required],
      'education':['',Validators.required],
      'email':['',[Validators.required,Validators.pattern(this.emailPattern)]],
          // nested Form group:
       'address':this.fb.group({
            'city':['',Validators.required],
            'state':['',Validators.required]
          })
    })

   }

  ngOnInit() {
  }

  saveCustomer(customerForm){
    console.log(customerForm);
  }
}
