import { Component, OnInit,Input } from '@angular/core';
import {ActivatedRoute}  from '@angular/router';
import {Employee} from '../employee';
import {EmployeeService} from '../employee.service';

@Component({
  selector: 'employee-child',
  templateUrl: './employee-child.component.html',
  styleUrls: ['./employee-child.component.css']
})
export class EmployeeChildComponent implements OnInit {
  
  employee: Employee;

  constructor(private route:ActivatedRoute,private empService:EmployeeService) { 

  }

  ngOnInit() {
      this.route.paramMap.subscribe(params=> {
        let ename = params.get('ename');
        this.employee = this.empService.getEmployeeByName(ename);
      })
  }

}
 