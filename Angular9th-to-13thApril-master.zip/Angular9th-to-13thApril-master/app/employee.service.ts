import { Injectable } from '@angular/core';
import {Employee} from './employee';

@Injectable()
export class EmployeeService {
  employees:Employee[]

  constructor() {
    this.employees = [
      {"empId":1001,"empName":"Jack","email":"jack@gmail.com",
      "photo":"../assets/images/cake1.jpg","phone":8989898989,"salary":5000,"dob":"1994-9-12"},
      {"empId":1002,"empName":"Jill","email":"jill@gmail.com","photo":"../assets/images/cake2.jpg", "phone":3534543535,"salary":23000,"dob":"1993-8-10"},
      {"empId":1003,"empName":"Sebastian","email":"seb@gmail.com","photo":"../assets/images/cake3.jpg", "phone":435345344545,"salary":15000,"dob":"1992-10-12"},
      {"empId":1004,"empName":"Harry","email":"harry@gmail.com","photo":"../assets/images/cake4.jpg", "phone":3345345444,"salary":5000,"dob":"1990-9-12"},
      {"empId":1005,"empName":"Emma","email":"emma@gmail.com", "photo":"../assets/images/cake5.jpg","phone":9090909009,"salary":5000,"dob":"1989-6-24"}
    ]
   }

   fetchEmployees():Employee[]{
    return this.employees;
   }

   getEmployeeByName(ename:string) : Employee {
     for(let i=0;i<this.employees.length;i++){
        if(this.employees[i].empName==ename){
          console.log("In service::" +this.employees[i]);
          return this.employees[i];
        }
     }
   }
   assignRating(ename) :number{
     console.log("********" + ename);
     for(let i=0;i<this.employees.length;i++) {
      if('Jack'==ename) {
        return this.employees[i].appraisalRating=5;
      } else if('Sebastian'==ename) {
        return this.employees[i].appraisalRating=4;
      }  else if('Jill'==ename) {
        return this.employees[i].appraisalRating=3;
      }  else if('Sebastian'==ename) {
        return this.employees[i].appraisalRating=3.5;
      }  else if('Harry'==ename) {
        return this.employees[i].appraisalRating=4.5;
      } else if('Emma'==ename) {
        return this.employees[i].appraisalRating=4.25;
      }

     }
   }
}
