export interface Employee {
    empId:number;
    empName:string;
    email:string;
    photo:string;
    phone:number;
    salary:number;
    appraisalRating?:number;
    dob:string;
}
