import { Component, OnInit } from '@angular/core';
import {Employee} from '../employee';
import {EmployeeService} from '../employee.service';

@Component({
  selector: 'home-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employees:Employee[];
  bday:Date;
// DI = loose coupling
  constructor(private _empService:EmployeeService) { 
    
    this.bday=new Date();
  }

  ngOnInit() {
    this.employees = this._empService.fetchEmployees();
    //console.log("****" + this.employees);
  }

}
