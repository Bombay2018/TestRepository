import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home-parent',
  template: `
    {{txtValue}}<br/>
    Change Now: <input type='text' [(ngModel)]=txtValue/><br/>

    <home-child [outTxt]=txtValue (notify)='displayCounter($event)'></home-child>
    <hr/>
    <br/>
    Parent Gets : {{counterValue}}
  `,
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  
  txtValue:string;
  counterValue : number;

  constructor() { }

  ngOnInit() {
    this.txtValue = "Parent Test";
  }

  displayCounter(counter) {
    this.counterValue = counter;

  }
}
