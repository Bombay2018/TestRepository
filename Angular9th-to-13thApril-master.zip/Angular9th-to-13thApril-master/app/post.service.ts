import { Injectable } from '@angular/core';
import {Response,Http} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import {Post} from './post';

@Injectable() // decorator inject object of HTTP [DI]
export class PostService {

  constructor(private _http:Http) { }

  getAllPosts():Observable<any> {
    return this._http.get("https://jsonplaceholder.typicode.com/posts")
    .map(this.extractData) // observable operator to convet to json format
    .catch(this.handleError); // observable operator to handle errors

  }

  getPostById(postId:number):Observable<any>{
     return this._http.get("https://jsonplaceholder.typicode.com/posts/"+postId)
    .map(this.extractData) // observable operator to convet to json format 
    .catch(this.handleError); // observable operator to handle errors

  }

  

// res: HTTP Response Object = Observable
  extractData(res:Response) {
    let body = res.json();
    return body || {};
  }

  // handle errors:
  handleError(error:any) {
    // throwing errors back to the component
    return Observable.throw(error);
  }
}
