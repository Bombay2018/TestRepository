import { Component, OnInit } from '@angular/core';
import {Post} from '../post';
import {PostService} from '../post.service';

@Component({
  selector: 'home-post',
  templateUrl: './post.component.html',
  styleUrls: ['../../assets/green.css'],
  providers:[PostService] 
})

// PostService is available for Post Component and its childern
export class PostComponent implements OnInit {
  posts:Post[];
  postObject:Post;
  errorMessage:any;

  constructor(private _postServ:PostService) { }

  ngOnInit() {
    // subscribe where the component is fetching data asynchronously
    /*this._postServ.getAllPosts().
    c*/
  }

  getPostById(postId:number) {
    this._postServ.getPostById(postId).
    subscribe(result => this.postObject=result,
    error => this.errorMessage=error); 
  }

}
