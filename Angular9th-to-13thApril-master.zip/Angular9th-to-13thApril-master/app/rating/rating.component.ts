import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../employee.service';

@Component({
  selector: 'home-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class RatingComponent implements OnInit {
  empRating:number;
  flag:boolean;
  constructor(private _empService:EmployeeService) { }

  ngOnInit() {
  }

  getRating(ename:string) {
    this.empRating=this._empService.assignRating(ename);
    if(this.empRating > 0){
      this.flag=true;
    } else {
      this.flag=false;
    }

    
  }
}
