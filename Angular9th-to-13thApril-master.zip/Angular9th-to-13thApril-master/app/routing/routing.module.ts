import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';

import { UserComponent } from '../user/user.component';
import { EmployeeComponent } from '../employee/employee.component';
import { RatingComponent } from '../rating/rating.component';
import { EmployeeChildComponent } from '../employee-child/employee-child.component';
import { ParentComponent } from '../parent/parent.component';
import { ChildComponent } from '../child/child.component';
import { PostComponent } from '../post/post.component';
import { StudentComponent } from '../student/student.component';
import { CustomerComponent } from '../customer/customer.component';
import { NotFoundComponent } from '../not-found/not-found.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot([
      // Configure the routes...Routes are objects. Default patterns
      {path:'',redirectTo:'/user',pathMatch:'full'},
      {path:'user',component:UserComponent},
      {path:'customer',component:CustomerComponent},
      {path:'employeeDetails/:ename',component:EmployeeChildComponent},
      {path:'employee',component:EmployeeComponent},
      {path:'parent',component:ParentComponent},
      {path:'post',component:PostComponent},
      {path:'student',component:StudentComponent},
      {path:'rating',component:RatingComponent},
      {path:'**',component:NotFoundComponent}
    ])
  ],
  declarations: [],
  exports:[RouterModule]
})
export class RoutingModule { }
