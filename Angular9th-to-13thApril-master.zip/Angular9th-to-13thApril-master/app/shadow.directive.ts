import { Directive,ElementRef,Renderer2 } from '@angular/core';

@Directive({
  selector: '[homeShadow]'
})
export class ShadowDirective {

  constructor(ele:ElementRef,ren:Renderer2) { 
    ren.setStyle(ele.nativeElement,'box-shadow','5px 5px 1px');
    ren.setStyle(ele.nativeElement,'background-color','yellow');
  }

}
