import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  studName:string;
  studPwd:string;
  gender:string;
  education:string[];

  constructor() { 
    this.education = ['M.Sc','B.Sc','PH.d','MBA','MCA'];
  }

  ngOnInit() {
  }

  saveStudent(studentFom:any) {
    alert(studentFom);

  }
}
