import { Injectable } from '@angular/core';
import {Response,Http} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class TestService {

  constructor(private _http:Http) { }

   getData():Observable<any> {
    return this._http.get("https://jsonplaceholder.typicode.com/posts").
    map(res=>{
      let id = res.json()[0].id;
       return this._http.get('https://jsonplaceholder.typicode.com/posts/'+id).
        map(res1=>{
        console.log("*******" + res1);
        res1.json()
      });
    })

  }

}
