import { Component, OnInit,OnDestroy } from '@angular/core';
import {Address} from '../address';

@Component({
  selector: 'home-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit,OnDestroy {

  hobbies:string[];
  status:boolean;
  username:string;
  useraddress:Address;

  constructor() { 
    this.hobbies=['Surfing','Photography','Chess'];
    this.status=false;
    this.username="John";
    this.useraddress = {
      city:'Pune',
      state:'MH'
    }
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    alert("I am leaving!!");
    console.log("I have been destroyed......");
  }
  
  toggleHobbies():void {
    this.status = !this.status;
  }

  addHobby(hob:string):void {
    this.hobbies.push(hob);
  }

  deleteHobby(i:number):void {
    this.hobbies.splice(i,1);
    // i = index and 1 : the number of elements to be deleted
  }
}
