import { Component, OnInit } from '@angular/core';
import {GlobalEventsManager} from "./../../services/shared/globaleventsmanager.service";

@Component({
  selector: 'app-hcpcinfocodecrosswalk',
  templateUrl: './hcpcinfocodecrosswalk.component.html'
})
export class HcpcInfoCodeCrosswalkComponent implements OnInit {

  constructor(private _globalEventsManagerSev: GlobalEventsManager)
  {
      this._globalEventsManagerSev.showNavBar.emit(true);
  }

  ngOnInit() {
  }

}
