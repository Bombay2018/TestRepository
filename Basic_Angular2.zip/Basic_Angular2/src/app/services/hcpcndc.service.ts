//getHTTPHeader
import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { INDC_ATTRIBUTES } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class HCPCNDCService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public ndc: INDC_ATTRIBUTES;

    constructor(private http: Http, private configSvc: ConfigService, private repository: Repository<INDC_ATTRIBUTES>, ) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getNdcByCode(ndcCode: string) {
        this.repository.getByCode('app/shared/mockdata/mockNDCMaster.json', ndcCode)
            .subscribe((ndc: INDC_ATTRIBUTES) => {
                user => this.ndc;
            });
    }

    getMockNdcFailureInit(): Observable<INDC_ATTRIBUTES> {
        return this.http
            .get("app/shared/mockdata/mockdataNDCFailureInit.json")
            .map(resp => resp.json() as INDC_ATTRIBUTES)
            .catch(this.handleError);
    }

    getMockNdcFailureByCode(): Observable<INDC_ATTRIBUTES[]> {
        return this.http
            .get("app/shared/mockdata/mockdataNDCFailure.json")
            .map(resp => resp.json() as INDC_ATTRIBUTES[])
            .catch(this.handleError);
    }

    getMockNdc(): Observable<INDC_ATTRIBUTES[]> {
        return this.http
            .get("app/shared/mockdata/mockNDCMaster.json")
            .map(resp => resp.json() as INDC_ATTRIBUTES[])
            .catch(this.handleError);
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}