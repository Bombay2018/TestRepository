import { Injectable } from '@angular/core';

@Injectable()
export class ndcInput{
    ndc:string
}