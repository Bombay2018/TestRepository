import { Injectable } from '@angular/core';

@Injectable()
export class UtilitiesService {

    getlastRecord(arrObj: any): any {
        return arrObj.reduce(function (prev, current) {
            return (prev.y > current.y) ? current : prev
        })
    }

    sortByDescending(arrObj: any, sortOn: string) {
        arrObj.sort(function (val1, val2) {
            if (val1.sortOn > val2.sortOn) {
                return -1;
            } else if (val1.sortOn < val2.sortOn) {
                return 1;
            } else {
                return 0;
            }
        });
    }
}