export interface Predicate<T> {
    (item: T): boolean
}

//example:
//removeItems<T>(array: Array<T>, predicate: Predicate<T>) {
   // _.remove(array, predicate);
//}

//this.itemsService.removeItems<IUser>(this.users, x => x.id < 0);