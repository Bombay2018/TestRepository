import { BrowserModule } from '@angular/platform-browser';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { HttpModule } from '@angular/http';
import { NgModule, ErrorHandler } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { routing } from './app.routes';

import { ContextMenuDirective } from './directives/contextmenu.directive';
import { AllowNumberDirective } from './directives/allownumber.directive';
import { OnlyNumber } from './directives/onlynumber.directive';
import { OnlyAlphanumeric } from './directives/OnlyAlphanumeric.directive';
import { onlyalphanumericDecimal } from './directives/onlyalphanumericDecimal.directive';
import { NDCValidatorDirective } from './directives/NDCValidator.directive';
import { AllowSpecificCharDirective } from './directives/allowspecificchar.directive';
import { DiscripancyStatusDirective } from './directives/discrepancystatus.dierctive';
import { DraggableDirective} from './directives/draggable.directive';

import { menuAccess } from './pipes/menu.pipe';
import { dropdownSortBy } from './pipes/dropdownsortby.pipe';
import { viewfilter } from './pipes/view.pipe';
import { ObjectFilter } from './pipes/objectfilter.pipe';
import { OrderBy } from './pipes/orderby.pipe';
//import { SafeHTMLPipe } from './pipes/safehtmltag.pipe';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { NdcResolutionComponent } from './components/ndcresolution/ndcresolution.component';
import { NdcResolutionOnlyComponent } from './components/ndcresolution/ndcresolutionReadOnly.component';
import { NdcconversionmappingComponent } from './components/ndcconversionmapping/ndcconversionmapping.component';
import { HcpcNdcCrosswalkComponent } from './components/hcpcndccrosswalk/hcpcndccrosswalk.component';
import { IndicationIdcCrosswalkComponent } from './components/indicationidccrosswalk/indicationidccrosswalk.component';
import { InfoCodeMasterComponent } from './components/infocodemaster/infocodemaster.component';
import { NarrativeMasterComponent } from './components/narrativemaster/narrativemaster.component';
import { UploadMasterComponent } from './components/uploadmaster/uploadmaster.component';
import { PIMasterComponent } from './components/pimaster/pimaster.component';
import { PriceSpecMasterComponent } from './components/pricespecmaster/pricespecmaster.component';
import { ReimbMasterComponent } from './components/reimbmaster/reimbmaster.component';
import { PartBvsDCrossWalkComponent } from './components/partbvsdcrosswalk/partbvsdcrosswalk.component';
import { HcpcInfoCodeCrosswalkComponent } from './components/hcpcinfocodecrosswalk/hcpcinfocodecrosswalk.component';
import { IndicationAdminCrosswalkComponent } from './components/indicationadmincrosswalk/indicationadmincrosswalk.component';
import { IndicationMinMaxCrosswalkComponent } from './components/indicationminmaxcrosswalk/indicationminmaxcrosswalk.component';

import { TopNavbarComponent } from './components/shared/topnavbar/topnavbar.component';
import { ContextMenuHolderComponent } from './components/shared/contextmenuholder.component';
import { ModalComponent } from './components/shared/modalpopup.component';
import { ConfirmationComponent } from './components/shared/confirmation/confirmation.component';
import { AutocompleteComponent } from './components/shared/autocomplete.component';


import { AuthGuard } from './services/shared/auth.guard';
import { LoggerService } from './services/shared/logger.service';

import { ConfigService } from './services/shared/config.service';
import { GlobalErrorHandler } from './services/shared/exceptionhandler.service';
import { ContextMenuService } from './services/shared/contextmenu.service';
import { ConfirmationService } from "./services/shared/confirmation.service";

import { GlobalService } from './services/shared/global.service';
import { UtilitiesService } from "./services/shared/utilities.service";
import { UserService } from './services/user.service';
import { DataService } from './services/data.service';
import { DropDown } from './shared/common';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NdcResolutionComponent,
    NdcResolutionOnlyComponent,
    NdcconversionmappingComponent,
    HcpcNdcCrosswalkComponent,
    IndicationIdcCrosswalkComponent,
    InfoCodeMasterComponent,
    NarrativeMasterComponent,
    UploadMasterComponent,
    PIMasterComponent,
    PriceSpecMasterComponent,
    PartBvsDCrossWalkComponent,
    HcpcInfoCodeCrosswalkComponent,
    
    TopNavbarComponent,
    ContextMenuHolderComponent,
    ModalComponent,
    ConfirmationComponent,
    AutocompleteComponent,
    
    dropdownSortBy,
    menuAccess,
    viewfilter,
    OrderBy,
    ObjectFilter,
    
    ContextMenuDirective,
    AllowNumberDirective,
    NDCValidatorDirective,
    AllowSpecificCharDirective,
    DiscripancyStatusDirective,
    DraggableDirective,
    ReimbMasterComponent,
    IndicationAdminCrosswalkComponent,
    IndicationMinMaxCrosswalkComponent,
    OnlyNumber,
    OnlyAlphanumeric,
    onlyalphanumericDecimal    
    
  ],
  imports: [
    BrowserModule, HttpModule, FormsModule, routing
  ],

  providers: [AuthGuard,
    DataService,
    UserService,
    ConfigService,
    ContextMenuService,
    ConfirmationService,
    GlobalService,
    LoggerService,
  {		
      provide: ErrorHandler,		
      useClass: GlobalErrorHandler		
    },
    {
      provide: LocationStrategy, 
      useClass: HashLocationStrategy
    },
    UtilitiesService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }