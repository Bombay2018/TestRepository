
import { Component, OnInit, AfterViewInit, ViewChild, Compiler } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { GlobalService } from "./../../services/shared/global.service";
import { HCPCNDCService } from "./../../services/hcpcndc.service";
import { DataService } from '../../services/data.service';
import { IUSER_MASTER, INDC_ATTRIBUTES, IADMIN_CODE, IHCPC_MASTER } from '../../shared/interfaces/entities.interface';
import { DropDown } from '../../shared/common';
import { ModalComponent } from '../shared/modalpopup.component';
import { ConfigService } from '../../services/shared/config.service';
import { PriceDesc, Sections } from '../../services/shared/config.const';

declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'app-hcpcndccrosswalk',
    templateUrl: './hcpcndccrosswalk.component.html?v=${new Date().getTime()}',
    providers: [HCPCNDCService, DataService]
})
export class HcpcNdcCrosswalkComponent implements OnInit, AfterViewInit {

    sectionList: any[];
    PriceDesc = PriceDesc;
    hcpcData: any;
    contexMenu;
    user: IUSER_MASTER;
    selectedHcpcCode: string = "";
    rc_id: number;
    dump_code: string;
    units: number;
    desc: string = "";
    calcPriceDropDown: DropDown[];
    sortDropDown: DropDown[];
    reasonNoteDropDown: any;
    workQueueTypeDropDown: DropDown[];
    workQueueDropDown: DropDown[];
    attributeNameDropDown: any;
    userDropDown: any;
    ruleFailureDropDown: any;
    hcpcSuperSixData: any;
    hcpcSuperSixFilterData: any;
    hcpcSuperSixDataBackup: any;
    hcpcSuperSixInitialBackup: any;
    recalBackup: any;
    hcpcRuleFailureBackup: any;
    hcpcDeleted: any;
    adminCodeData: IADMIN_CODE[];
    addAdminCode: IADMIN_CODE[] = {} as IADMIN_CODE[];
    hcpcPriceData: any;
    popupPriceData: any;
    popupHistoryPriceData: any;
    addHcpcSuperSix: any;
    hcpcSearchData: IHCPC_MASTER[];
    hcpcSearchFilterData: IHCPC_MASTER[];
    s6_wildcard_hcpcs_id: number;
    reasonNotesList: String[];
    pushReasonNote: any[] = new Array();
    newReasonNote = {
        reasonCode: 0,
        reasonNote: "",
        attributeId: 0,
    }
    RoutingNotes: any;
    otherInfo: Object;
    newAdminCode: boolean = false;
    filterparam: Object = {};

    pushAdminDelCode: any[] = new Array();
    pushAdminAddCode: any[] = new Array();

    columnSelected: Object = {};
    column: string = 'generic_name';
    direction: number;
    isDesc: boolean;
    isAddHcpcRow: boolean = false;
    isSearch: boolean = false;
    isRecCal: boolean = false;
    hcpcRuleFailure: any[] = new Array();
    statusProp: string = '';
    isNocCode: string = '';
    isAdminCode: string = '';
    otherHcpc: any;

    isPublishAllowed: boolean = false;
    isPublishRequestAllowed: boolean = false;
    hcpcRowIndex: number;
    s6_wc_hcpcs_ndc_id: number;
    hcpc_temp_id: number;
    hcpc_id: number;
    wt_id: number;
    pushNdcStatus: any[] = new Array();
    preSearch: any = [{ "searchOn": 1, "data": [] }, { "searchOn": 2, "data": [] }, { "searchOn": 3, "data": [] }, { "searchOn": 4, "data": [] }];
    newData: any[] = new Array();

    hcpcList: any[] = new Array();
    hcpcDescList: any[] = new Array();
    ndcList: any[] = new Array();
    adminCodeList: any[] = new Array();
    priceDetails: any;

    searchPram = {
        hcpc_code: '',
        hcpc_desc: '',
        ndc: '',
    }

    activeTab: number = 0;
    selView: string = 'Z';

    @ViewChild('modalHCPCSearchList') modalHCPCSearchList: ModalComponent;
    @ViewChild('modalPricing') modalPricing: ModalComponent;
    @ViewChild('modalAdminCodes') modalAdminCodes: ModalComponent;
    @ViewChild('modalReasonNotes') modalReasonNotes: ModalComponent;
    @ViewChild('modalDelete') modalDelete: ModalComponent;

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private _globalSev: GlobalService,
        private _hcpcSvc: HCPCNDCService<IADMIN_CODE>,
        private _datasvc: DataService,
        private _configsvc: ConfigService, private _compiler: Compiler) {
        this.user = JSON.parse(localStorage.getItem('currentUser'));
        this._globalSev.showNavBar(true, this.user.user_name);
        this._compiler.clearCache();

    }

    ngOnInit() {
        this.rc_id = this.route.snapshot.params['rc_id'];
        this.selectedHcpcCode = this.route.snapshot.params['hcpc_code'];

        this.contexMenu = this._configsvc.getcontexMenu();
        this.contexMenu.forEach(cm => cm.subject.subscribe(val => this.setStatus(val)));

        this.sectionList = Sections;
        this.filterparam = {
            genericName: "",
            brandName: "",
            strength: "",
            roa: "",
            DoseForm: "",
            calcPrice: "0",
            rxOtc: "",
            pendingTask: false,
            roFilter: false
        }

        this._datasvc.getDropdownData().subscribe((res: any) => {
            this.calcPriceDropDown = res.CalcPriceDropDown;
            this.sortDropDown = res.HcpcNdcSortDropdown;
            this.columnSelected = this.sortDropDown[0].id;
            this.reasonNoteDropDown = res.HcpcNdcReasonCode;
            this.otherInfo['reason_notes'] = this.reasonNoteDropDown[0].id;
            this.ruleFailureDropDown = res.mockRuleFailureUpdate;
            this.otherInfo['rule_failure'] = this.ruleFailureDropDown[0].Id;
            this.workQueueTypeDropDown = res.mockWorkQueueType;
        });

        this._datasvc.getAllAttribute().subscribe((res: any) => {
            this.attributeNameDropDown = res['Result'];
        });

        this._datasvc.getWorkQueueName().subscribe((res: any) => {
            this.workQueueDropDown = res;
        });

        switch (this.user.role_name) {
            case "L1-Initial":
            case "L1-Change": {
                this.isPublishAllowed = false;
                this.isPublishRequestAllowed = true;
                break;
            }
            case "L2-Initial":
            case "L2-Change":
            case "L2-Second level":
            case "L2-Publish": {
                this.isPublishAllowed = true;
                this.isPublishRequestAllowed = false;
                break;
            }
            default: {
                this.isPublishAllowed = false;
                this.isPublishRequestAllowed = false;
                break;
            }
        }

        this.setHcpcNdcOtherDetails();
        this.hcpcData = {
            "hcpcMap": [{
                "ndcMap": []
            }],
            "followUpDetails": {
                "followUpDate": ""
            },
            "ruleFailuer": [],
            "furtherRouting": {}
        }

        if (this.rc_id != null && this.selectedHcpcCode != null) {
            this._hcpcSvc.getHCPCByRcId(this.rc_id).subscribe(res => {
                if (res != null) {
                    var data = { "rc_id": this.rc_id, "hcpc_code": res['hcpc_code'], "cms_desc": "", "rj_addl_desc": res['hcpc_desc'], "hcpc_status": "", "is_admin_code": res['is_admin_code'], "is_noc_code": res['is_noc_code'], "ndc": null, "units": res['units'], "dump_code": res['dump_code'] }
                    this.showHCPCSuperSix(data);
                }
            });
        }
    }

    ngAfterViewInit() {
        $('#awpDate').datepicker({
            format: 'mm/dd/yyyy',
            autoclose: true
        }).on('change', (event: any) => {
            this.PriceDesc['awpDate'] = event.target.value;
        });
        $('#wacDate').datepicker({
            format: 'mm/dd/yyyy',
            autoclose: true
        }).on('change', (event: any) => {
            this.PriceDesc['wacDate'] = event.target.value;
        });
        $('#aspDate').datepicker({
            format: 'mm/dd/yyyy',
            autoclose: true
        }).on('change', (event: any) => {
            this.PriceDesc['aspDate'] = event.target.value;
        });
        $('#apcDate').datepicker({
            format: 'mm/dd/yyyy',
            autoclose: true
        }).on('change', (event: any) => {
            this.PriceDesc['apcDate'] = event.target.value;
        });
        $('#cmacDate').datepicker({
            format: 'mm/dd/yyyy',
            autoclose: true
        }).on('change', (event: any) => {
            this.PriceDesc['cmacDate'] = event.target.value;
        });
        $('#followupDate').datepicker({
            format: 'mm/dd/yyyy',
            autoclose: true
        }).on('change', (event: any) => {
            this.otherInfo['follow_up_date'] = event.target.value;
        });
    }

    private setHcpcNdcOtherDetails() {
        this.otherInfo = {
            reason_notes: "",
            attribute_status: "",
            follow_up_date: "",
            reason_code: "",
            work_queue: 0,
            work_queue_type: 0,
            route_user_id: 0,
            routing_notes: '',
            publish_note: '',
            req_to_publish_note: '',
            reason_attribute_id: ''
        }
    }

    private searchPramChange(event, searchOn: number) {
        var self = this;
        var eventLen = event.length;
        this.newData = new Array();

        self.hcpcList = [];
        self.hcpcDescList = [];
        self.ndcList = [];
        self.adminCodeList = [];

        if (eventLen < 3) {
            return;
        }

        var getExists = this.preSearch.filter(obj => (obj.searchOn == searchOn));
        var existingData = getExists[0].data || [];
        getExists[0].data.forEach(function (val) {
            if (val.length > 0) {
                var isExit = val.startsWith(event)
                if (isExit == true) {
                    self.newData.push(val);
                }
            }
        });

        switch (searchOn) {
            case 1: //hcpc_code
                if (this.newData.length > 0) {
                    self.hcpcList = this.newData;
                } else {
                    this._hcpcSvc.getHCPCByCode(event).subscribe((hcpcList) => {
                        if (hcpcList != null) {
                            hcpcList.forEach(function (hcpc) {
                                existingData.push(hcpc.hcpc_code);
                                self.hcpcList.push(hcpc.hcpc_code);
                            });
                            self.preSearch.push({ "searchOn": 1, "data": existingData });
                        } else {
                            self.hcpcList = new Array();
                        }
                    });
                }
                break;
            case 2: //hcpc_desc
                if (this.newData.length > 0) {
                    self.hcpcDescList = this.newData;
                } else {
                    this._hcpcSvc.getHCPCByDescription(event).subscribe((hcpcDescList) => {
                        if (hcpcDescList != null) {
                            hcpcDescList.forEach(function (desc) {
                                var hcpcDesc = desc['rj_addl_desc'] != null ? desc['rj_addl_desc'] : desc['cms_desc'];
                                existingData.push( hcpcDesc);
                                self.hcpcDescList.push( hcpcDesc);
                            });
                            self.preSearch.push({ "searchOn": 2, "data": existingData });
                        } else {
                            self.hcpcDescList = new Array();
                        }
                    });
                }
                break;
            case 3: //ndc
                if (this.newData.length > 0) {
                    self.ndcList = this.newData;
                } else {
                    this._datasvc.getDistinctNDC(event).subscribe((ndcList) => {
                        if (ndcList.Result.length > 0) {
                            ndcList.Result.forEach(function (ndc) {
                                existingData.push(ndc.ndc);
                                self.ndcList.push(ndc.ndc);
                            });
                            self.preSearch.push({ "searchOn": 3, "data": existingData });
                        } else {
                            self.ndcList = new Array();
                        }
                    });
                }
                break;
            case 4: //ndc
                if (this.newData.length > 0) {
                    self.adminCodeList = this.newData;
                } else {
                    this._hcpcSvc.getdistictAdminCode(event).subscribe((adminCodeList) => {
                        if (adminCodeList.Result.length > 0) {
                            adminCodeList.Result.forEach(function (hcpc_code) {
                                existingData.push(hcpc_code.hcpc_code);
                                self.adminCodeList.push(hcpc_code.hcpc_code);
                            });
                            self.preSearch.push({ "searchOn": 4, "data": existingData });
                        } else {
                            self.adminCodeList = new Array();
                        }
                    });
                }
                break;
        }
    }

    private selectedPram(value: string, selectedFor: number) {
        switch (selectedFor) {
            case 1: //hcpc_code
                this.searchPram.hcpc_code = value;
                this.hcpcList = new Array();
                break;
            case 2: //hcpc_desc
                this.searchPram.hcpc_desc = value;
                this.hcpcDescList = new Array();
                break;
            case 3: //ndc
                this.searchPram.ndc = value;
                this.ndcList = new Array();
                break;
            case 4: //admin code
                this.addAdminCode['admin_code'] = value;
                this._hcpcSvc.getAdminCode(value).subscribe((adminCode: IADMIN_CODE[]) => {
                    this.addAdminCode['description'] = adminCode[0].description;
                });
                this.adminCodeList = new Array();
                break;
        }
    }

    //Call on search button click
    private searchHCPC() {
        this.activeTab = 0;
        this.selView = 'Z';
        this.clearCommands();
        var propCount = 0;
        for (var prop in this.searchPram) {
            if (this.searchPram[prop] == "") {
                // this.searchPram[prop] = null
                propCount++;
            }
        }
        if (propCount == 3) {
            toastr.error('Enter searching criteria');
        } else {
            this._hcpcSvc.getHCPCDetails(this.searchPram).subscribe((hcpcDetails) => {
                if (hcpcDetails != null) {
                    this.hcpcSearchData = hcpcDetails;
                    this.modalHCPCSearchList.show();
                } else {
                    toastr.info('Record Not Found');
                }
            });
        }
    }

    //Call on popup search result row click
    private showHCPCSuperSix(data) {

        this.isRecCal = false;
        this.clearCommands();
        var self = this;
        var hcpc_code = data['hcpc_code'];
        var desc = data['cms_desc'] + data['rj_addl_desc'];
        this.isAdminCode = data['is_admin_code'];
        this.isNocCode = data['is_noc_code'];
        this.rc_id = data['rc_id'];
        this.dump_code = data['dump_code'];
        this.units = data['units'];
        if (hcpc_code != undefined && hcpc_code.length > 0) {
            this.adminCodeData = undefined;
            this.selectedHcpcCode = hcpc_code;
            this.desc = desc;
            this.searchPram.hcpc_code = hcpc_code;

            this._hcpcSvc.getHCPCSuperSix(this.rc_id).subscribe(superSix => {

                this.hcpcSuperSixData = [];
                this.hcpcSuperSixFilterData = [];
                this.hcpcSuperSixDataBackup = [];
                if (superSix != null && superSix.length > 0) {
                    superSix.forEach(function (obj) {
                        obj['isShowNDCDetails'] = false;
                        obj['generic_name_status'] = 0;
                        obj['brand_name_status'] = 0;
                        obj['strength_status'] = 0;
                        obj['dosage_form_status'] = 0;
                        obj['route_of_administration_status'] = 0;
                        obj['rx_otc_ind_status'] = 0;
                        obj['billable_unit_status'] = 0;
                        obj['calc_flag_status'] = 0;
                        if (obj['ndcMap'] != undefined) {
                            obj['ndcMap'].forEach(function (ndc) {
                                ndc['view'] = true;
                            });
                        }

                    });

                    self.hcpcSuperSixData = superSix;
                    self.hcpcSuperSixFilterData = superSix;
                    self.hcpcSuperSixDataBackup = JSON.parse(JSON.stringify(superSix));
                    self.hcpcSuperSixInitialBackup = JSON.parse(JSON.stringify(superSix));
                    self.recalBackup = JSON.parse(JSON.stringify(superSix));
                    self.setHcpcStatus();
                    this.showRoutingNotes(hcpc_code);
                    this.showRuleFailure(hcpc_code);
                }
                this.modalHCPCSearchList.hide();
            });

            this.showHcpcPrice(hcpc_code);
        }
    }

    private setHcpcStatus() {
        //attribute status not added in backup

        this._hcpcSvc.getHcpcStatus(this.selectedHcpcCode).subscribe(res => {
            if (res != undefined) {
                var hcpcStatus = res;
                if (this.hcpcSuperSixFilterData != undefined && this.hcpcSuperSixFilterData.length > 0) {
                    var hcpcProps = Object.getOwnPropertyNames(this.hcpcSuperSixFilterData[0]);
                    this.hcpcSuperSixFilterData.forEach(function (hcpc) {
                        var hcpcRecord = hcpcStatus.filter(obj => obj['t_s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id']);
                        if (hcpcRecord.length > 0) {
                            for (var i = 0; i < hcpcProps.length; i++) {
                                var hcpcPropName = hcpcProps[i];
                                switch (hcpcPropName) {
                                    case 'generic_name':
                                    case 'brand_name':
                                    case 'strength':
                                    case 'dosage_form':
                                    case 'route_of_administration':
                                    case 'rx_otc_ind':
                                    case 'billable_unit':
                                    case 'calc_flag':
                                        if (hcpcRecord[0][hcpcPropName + '_status'] == 'Y') {
                                            hcpc[hcpcPropName + '_status'] = 2;
                                        }
                                        break;
                                    default: break;
                                }
                            }
                        }
                    });
                }
            }
        });
        if (this.hcpcSuperSixFilterData != undefined && this.hcpcSuperSixFilterData.length > 0) {
            this.hcpcSuperSixFilterData.forEach(function (obj) {
                if (obj['isTemp'] == 'Y' && obj['s6_wildcard_hcpcs_id'] == null) {
                    obj['generic_name_status'] = 2;
                    obj['brand_name_status'] = 2;
                    obj['strength_status'] = 2;
                    obj['dosage_form_status'] = 2;
                    obj['route_of_administration_status'] = 2;
                    obj['rx_otc_ind_status'] = 2;
                    obj['billable_unit_status'] = 2;
                    obj['calc_flag_status'] = 2;
                }
            });
        }
    }

    private showView(selTab: number) {
        if (this.selectedHcpcCode == undefined || this.selectedHcpcCode.length == 0) {
            return;
        }
        debugger;
        var self = this;
        this.activeTab = selTab;

        // self.hcpcSuperSixFilterData.forEach(item => {
        //     item['view'] = true;
        //     if (item['ndcMap'] != undefined) {
        //         item['ndcMap'].forEach(function (ndc) {
        //             ndc['view'] = true;
        //         });
        //     }
        // });
        switch (selTab) {
            case 1: //
            case 2: //AWP View
                debugger;
                this.selView = 'Z';
                self.hcpcSuperSixFilterData.forEach(item => {
                    if (item["isShowNDCDetails"])
                        item["isShowNDCDetails"] = !(item["isShowNDCDetails"]);
                    if (item['ndcMap'] != undefined) {
                        var awpClone = item['ndcMap'].sort((a, b) => {
                            if (parseFloat(b.awpPrice) < parseFloat(a.awpPrice))
                                return -1;
                            if (parseFloat(b.awpPrice) > parseFloat(a.awpPrice))
                                return 1;
                            return 0;
                        });
                        item['ndcMap'] = awpClone;
                    }
                });
                this.selView = 'N';
                break;
            case 3: //WAC View
                debugger;
                this.selView = 'Z';
                self.hcpcSuperSixFilterData.forEach(item => {
                    if (item["isShowNDCDetails"])
                        item["isShowNDCDetails"] = !(item["isShowNDCDetails"]);
                    if (item['ndcMap'] != undefined) {
                        var wacClone = item['ndcMap'].sort((a, b) => {
                            if (parseFloat(b.wacPrice) < parseFloat(a.wacPrice))
                                return -1;
                            if (parseFloat(b.wacPrice) > parseFloat(a.wacPrice))
                                return 1;
                            return 0;
                        });
                        item['ndcMap'] = wacClone;
                    }
                });
                this.selView = 'N';
                break;
            default:
                self.hcpcSuperSixFilterData.forEach(item => {
                    if (item["isShowNDCDetails"])
                        item["isShowNDCDetails"] = !(item["isShowNDCDetails"]);
                });
                this.selView = 'Z';
                break;
        }
        debugger;
    }

    private showHcpcPrice(hcpc_code: string) {
        this._hcpcSvc.getHcpcPrice(hcpc_code).subscribe(hcpcPrice => {
            if (hcpcPrice != null)
                this.hcpcPriceData = hcpcPrice.splice(0, 2);
        });
    }

    private showReasonNotes(s6_wildcard_hcpcs_id: number, isTemp: string) {
        this.s6_wildcard_hcpcs_id = s6_wildcard_hcpcs_id;
        if (this.searchPram.hcpc_code != "") {
            this._hcpcSvc.getReasonNotes(s6_wildcard_hcpcs_id, isTemp).subscribe((reason_notes: string[]) => {
                this.reasonNotesList = reason_notes;
                this.modalReasonNotes.show();
            });
        }
    }

    //Get data on grid + click 
    private showHcpcNdcsData(isTemp, s6_wildcard_hcpcs_id, s6_wildcard_hcpcs_temp_id) {
        var mainHcpc = this.hcpcSuperSixFilterData.filter(obj => obj['isTemp'] == isTemp && obj['s6_wildcard_hcpcs_id'] == s6_wildcard_hcpcs_id && obj['s6_wildcard_hcpcs_temp_id'] == s6_wildcard_hcpcs_temp_id);
        if (mainHcpc.length > 0) {
            mainHcpc[0]['isShowNDCDetails'] = !mainHcpc[0]['isShowNDCDetails'];
        }
    }

    private showRoutingNotes(hcpc_code: string) {
        this._hcpcSvc.getRoutingNotes(hcpc_code).subscribe((RoutingNotes) => {
            this.RoutingNotes = RoutingNotes;
        });
    }

    private showRuleFailure(data) {
        var self = this;
        this._hcpcSvc.getHCPCRuleFailure(data).subscribe((ndcrulefailure) => {
            ndcrulefailure.forEach(function (rf) {
                var existRF = self.hcpcRuleFailure.filter(ex => ex['workqueue_id'] == rf['workqueue_id'])
                if (existRF.length == 0) {
                    self.hcpcRuleFailure.push(rf);
                    self.hcpcRuleFailureBackup = JSON.parse(JSON.stringify(self.hcpcRuleFailure));
                }
            });
        });
    }

    private userDropdown() {
        var queue_id = this.otherInfo['work_queue'];
        var work_queue_type = this.otherInfo['work_queue_type'];
        if (queue_id > 0 && work_queue_type > 0) {
            var role_type = work_queue_type == 1 ? "Initial" : "Second";
            this._datasvc.getUserByQueueId(queue_id, role_type).subscribe((res: any) => {
                this.userDropDown = res;
            });
        }
    }

    private contexMenuClick(prop) {

        this.statusProp = prop;
    }

    private setStatus(id) {
        var prop = this.statusProp.slice(0, -7);
        var updatedData = this.hcpcSuperSixFilterData[this.hcpcRowIndex]['ndcMap'].filter(obj => obj.s6_wc_hcpcs_ndc_id == this.s6_wc_hcpcs_ndc_id);
        var backup = this.hcpcSuperSixDataBackup[this.hcpcRowIndex]['ndcMap'].filter(obj => obj.s6_wc_hcpcs_ndc_id == this.s6_wc_hcpcs_ndc_id);

        if (updatedData[0][prop] == backup[0][prop]) {
            toastr.error('Status not allowed to <br> change on old value');
            return;
        }
        // switch case not required directly assin id
        switch (id) {
            case 0: //Failure Resolved
                updatedData[0][this.statusProp] = 0;
                break;
            case 3: //override value
                updatedData[0][this.statusProp] = 3;
                var oNdcStatus = {
                    's6_wildcard_hcpcs_id': this.hcpc_id,
                    's6_wildcard_hcpcs_temp_id': this.hcpc_temp_id,
                    'wt_id': this.wt_id,
                    'ndc_status': this.statusProp,
                    'ndc_status_value': 3
                }
                this.pushNdcStatus.push(oNdcStatus);
                break;
            case 4: //Change Review
                updatedData[0][this.statusProp] = 4;
                var oNdcStatus = {
                    's6_wildcard_hcpcs_id': this.hcpc_id,
                    's6_wildcard_hcpcs_temp_id': this.hcpc_temp_id,
                    'wt_id': this.wt_id,
                    'ndc_status': this.statusProp,
                    'ndc_status_value': 4
                }
                this.pushNdcStatus.push(oNdcStatus);
                break;
            default:
                toastr.info('Invalid selection');
                break;
        }

        this.statusProp = '';
    }

    private getHcpcIndex(index, s6_wc_hcpcs_ndc_id, wt_id, prop) {
        this.statusProp = prop;
        this.hcpcRowIndex = index;
        this.s6_wc_hcpcs_ndc_id = s6_wc_hcpcs_ndc_id;
        this.wt_id = wt_id;
        this.hcpc_temp_id = this.hcpcSuperSixFilterData[this.hcpcRowIndex]['s6_wildcard_hcpcs_temp_id'];
        this.hcpc_id = this.hcpcSuperSixFilterData[this.hcpcRowIndex]['s6_wildcard_hcpcs_id'];
    }

    private modelChange(s6_id, status, event) {
        debugger;
        var prop = status.slice(0, -7);
        var editHcpc = this.hcpcSuperSixFilterData.filter(obj => obj['s6_wildcard_hcpcs_id'] == s6_id);
        var bkHcpc = this.hcpcSuperSixDataBackup.filter(obj => obj['s6_wildcard_hcpcs_id'] == s6_id);
        if (status != '') {
            if (bkHcpc[prop] != event) {
                editHcpc[0][status] = 1;
            } else {
                bkHcpc[status] = bkHcpc[status];
            }
        }
    }

    private modelChangeNdc(index, s6_wc_hcpcs_ndc_id, status, event) {
        var prop = status.slice(0, -7);
        if (this.hcpcSuperSixFilterData != undefined && this.hcpcSuperSixFilterData[index]['ndcMap'] != undefined) {
            var editHcpc = this.hcpcSuperSixFilterData[index]['ndcMap'].filter(obj => obj['s6_wc_hcpcs_ndc_id'] == s6_wc_hcpcs_ndc_id);
            if (this.hcpcSuperSixDataBackup != undefined && this.hcpcSuperSixDataBackup[index]['ndcMap'] != undefined) {
                var bkHcpc = this.hcpcSuperSixDataBackup[index]['ndcMap'].filter(obj => obj['s6_wc_hcpcs_ndc_id'] == s6_wc_hcpcs_ndc_id);
                if (status != '') {
                    if (bkHcpc[prop] != event) {
                        editHcpc[0][status] = 1;
                    } else {
                        bkHcpc[status] = bkHcpc[status];
                    }
                }
            }
        }
    }

    private ndcStatusWorkqueue(ndc) {

        var rjworkqueues = [];
        if (ndc['calc_flag_status'] != undefined) {
            if (ndc['calc_flag_status'] == 4 && ndc['calc_flag_status'] == 3) {
                var orjworkqueue = {
                    "data_source_id": ndc['data_source_id'] != undefined ? ndc['data_source_id'] : 6,
                    "wt_id": ndc['wt_id'],
                    "attribute_id": 22,
                    "is_manual_review": ndc['calc_flag_status'] == 4 ? "Y" : "N",
                    "is_overide": ndc['calc_flag_status'] == 3 ? "Y" : "N"
                }
                rjworkqueues.push(orjworkqueue);
            }
        }
        if (ndc['billableUnit_status'] != undefined) {
            if (ndc['billableUnit_status'] == 4 && ndc['billableUnit_status'] == 3) {
                var orjworkqueue = {
                    "data_source_id": ndc['data_source_id'] != undefined ? ndc['data_source_id'] : 6,
                    "wt_id": ndc['wt_id'],
                    "attribute_id": 23,
                    "is_manual_review": ndc['billableUnit_status'] == 4 ? "Y" : "N",
                    "is_overide": ndc['billableUnit_status'] == 3 ? "Y" : "N"
                }
                rjworkqueues.push(orjworkqueue);
            }
        }
        return rjworkqueues;
    }

    private addHcpcRow() {

        this.addHcpcSuperSix = [{ 'generic_name': '', 'brand_name': '', 'strength': '', 'dosage_form': '', 'route_of_administration': '', 'rx_otc_ind': '', 'billable_unit': '', 'calc_flag': '' }];
        if (this.searchPram.hcpc_code != "") {
            this.isAddHcpcRow = true;
        } else {
            toastr.info("Please select a HCPC code");
        }
    }

    private checkDeleteToHcpc() {

        if (this.hcpcSuperSixFilterData != undefined) {
            var selectedHcpc = this.hcpcSuperSixFilterData.filter(obj => obj['isDeleteSelect'] == true);
            if (selectedHcpc.length != 0) {
                this.modalDelete.show();
            } else {
                toastr.info("Please select a HCPC code");
            }
        } else {
            toastr.info("Please select a HCPC code");
        }
    }

    private deleteHcpc() {
        if (this.searchPram.hcpc_code != "") {
            this.hcpcDeleted = (this.hcpcDeleted == undefined) ? [] : this.hcpcDeleted;
            var markDelet = this.hcpcSuperSixFilterData.filter(obj => obj['isDeleteSelect'] == true);
            markDelet.forEach(item => {
                this.hcpcDeleted.push(item);
                item['status'] = 'deleted';
            });
            //this.hcpcSuperSixFilterData  =  this.hcpcSuperSixFilterData.filter(obj  =>  obj['isDeleteSelect']  !=  true);
        } else {
            toastr.info("Please select a HCPC code");
        }
    }

    private keepHcpc() {
        var markDelet = this.hcpcSuperSixFilterData.filter(obj => obj['isDeleteSelect'] == true);
        markDelet.forEach(function (obj) { obj['isDeleteSelect'] = false });
    }

    private showAdminCode() {
        if (this.searchPram.hcpc_code != "") {
            this._hcpcSvc.getAdminCode(this.searchPram.hcpc_code).subscribe((adminCode: IADMIN_CODE[]) => {
                this.adminCodeData = adminCode;
            });
            this.modalAdminCodes.show();
        } else {
            toastr.info("Insert HCPC code");
        }
    }

    private addAdminCodeRow() {
        this.newAdminCode = true;
        this.addAdminCode['admin_code'] = "";
        this.addAdminCode['description'] = "";
    }

    private deleteAdminCodeRow() {

        this.newAdminCode = false;
        var arrLenght = this.adminCodeData.length - 1;
        var deleteJson = {};
        deleteJson['rc_id'] = this.rc_id;
        deleteJson['adminCodesXwalk'] = [];
        deleteJson['deleteIndex'] = [];
        for (let i = arrLenght; i >= 0; i--) {
            if (this.adminCodeData[i]['is_selected'] == true) {
                var index = this.adminCodeData.indexOf(this.adminCodeData[i]);
                //push deleted admin code to pushAdminDelCode json and det splice from main json                
                var obj = {
                    "adminCode": this.adminCodeData[index]['admin_code'],
                    "description": this.adminCodeData[index]['description'],
                    "isDelete": true,
                    "adminCodeHcpcId": this.adminCodeData[index]['admin_codes_hcpc_id'],
                }
                deleteJson['adminCodesXwalk'].push(obj);
                //this.pushAdminDelCode.push(obj);
                deleteJson['deleteIndex'].push(index);
                //this.adminCodeData.splice(index, 1);
            }
        }
        this._hcpcSvc.deleteAdminCode(deleteJson).subscribe((response: any) => {
            if (response == "success") {
                toastr.success("Admin Codes Deleted successfully");
                deleteJson['deleteIndex'].forEach(del => {
                    this.adminCodeData.splice(del, 1)
                });
            }
        })
    }

    private saveAdminCodeRow() {
        var addJson = {};
        addJson['rc_id'] = this.rc_id;
        addJson['adminCodesXwalk'] = [];

        if (this.addAdminCode['admin_codes_hcpc_id'] != undefined) {
            var obj = {
                "adminCode": this.addAdminCode['admin_code'],
                "description": this.addAdminCode['description'],
                "isDelete": false,
                "adminCodeHcpcId": 0,
                "toBeDelete": null,
                "toBeAdded": true
            }
            this.pushAdminAddCode.push(obj);
        }

        if (this.addAdminCode['admin_code'] == "" || this.addAdminCode['description'] == "") {
            toastr.warning("Please fill up all details before save");
            return;
        }

        var isAdminCodeAdded = this.adminCodeData.filter(item => item.admin_code == this.addAdminCode['admin_code']);
        if (isAdminCodeAdded != null && isAdminCodeAdded.length > 0) {
            toastr.warning(this.addAdminCode['admin_code'] + "already associted with,Please try with new admin code");
            return;
        }

        this._hcpcSvc.IsValidAdminCode(this.addAdminCode['admin_code']).subscribe((response: any) => {
            if (response) {
                this.adminCodeData = this.adminCodeData || [];

                var obj = {
                    "adminCode": this.addAdminCode['admin_code'],
                    "description": this.addAdminCode['description'],
                    "isDelete": false,
                    "adminCodeHcpcId": null
                }
                addJson['adminCodesXwalk'].push(obj);
                this._hcpcSvc.saveAdminCode(addJson).subscribe((response: any) => {
                    if (response == "success") {
                        this.addAdminCode['admin_code'] = "";
                        this.addAdminCode['description'] = "";
                        this.newAdminCode = false;
                        toastr.success("Admin Codes saved successfully");
                        this._hcpcSvc.getAdminCode(this.searchPram.hcpc_code).subscribe((adminCode: IADMIN_CODE[]) => {
                            this.adminCodeData = adminCode;
                        });
                    }
                });
                // this.adminCodeData.push({
                //     admin_codes_hcpc_id: this.addAdminCode['admin_codes_hcpc_id'],
                //     admin_code: this.addAdminCode['admin_code'],
                //     description: this.addAdminCode['description'],
                //     is_selected: false
                // });
                this.modalAdminCodes.hide();
            }
            else {
                toastr.error("Admin code already exists.Try with new Admin Code");
                return;
            }
        });
        //push deleted admin code in final jason on save admin
        this.pushAdminDelCode.forEach(each => {
            if (each["toBeDelete"]) {
                each["toBeDelete"] = false;
                var obj = {
                    "adminCode": each['adminCode'],
                    "description": each['description'],
                    "isDelete": false,
                    "adminCodeHcpcId": each['adminCodeHcpcId']
                }
                this.hcpcData['adminCodesXwalk'].push(obj);
            }
        })
    }

    private closeAdminCodeRow() {
        //push the deleted admin code in final json
        this.newAdminCode = false;
        this.pushAdminDelCode.forEach(each => {
            if (each["toBeDelete"]) {
                each["toBeDelete"] = false;
                this.adminCodeData.push({
                    admin_codes_hcpc_id: each['adminCodeHcpcId'],
                    admin_code: each['adminCode'],
                    description: each['description'],
                    is_selected: false
                });
            }
        });
        this.modalAdminCodes.hide();
    }

    private isRecalRequired(): boolean {

        var self = this;
        var isRecalRequired = false;

        this.hcpcSuperSixFilterData.forEach(function (hcpc) {
            var hcpcProps = Object.getOwnPropertyNames(self.hcpcSuperSixFilterData[0]);
            if (self.recalBackup != undefined) {
                var recalValues = self.recalBackup.filter(bk => bk['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id']);
                if (recalValues.length > 0) {
                    var indxHcpc = 0;
                    for (var i = 0; i < hcpcProps.length; i++) {
                        var hcpcPropName = hcpcProps[i];
                        switch (hcpcPropName) {
                            case 'generic_name':
                            case 'brand_name':
                            case 'strength':
                            case 'dosage_form':
                            case 'route_of_administration':
                            case 'rx_otc_ind':
                                if (hcpc[hcpcPropName] != null && recalValues[indxHcpc][hcpcPropName] != null && hcpc[hcpcPropName].toLowerCase().trim() != recalValues[indxHcpc][hcpcPropName].toLowerCase().trim()) {
                                    isRecalRequired = true;
                                    self.isRecCal = false;
                                    return isRecalRequired;
                                }
                                break;
                            default:
                                break;
                        }
                    }

                    if (hcpc['ndcMap'] != undefined && recalValues[0]['ndcMap'] != undefined) {
                        var ndcIdx = 0;
                        hcpc['ndcMap'].forEach(function (ndc) {
                            if (recalValues[0]['ndcMap'][ndcIdx] != undefined) {
                                if ((ndc['calc_flag'] != null && recalValues[0]['ndcMap'][ndcIdx]['calc_flag'] != null
                                    && ndc['calc_flag'].toLowerCase().trim() != recalValues[0]['ndcMap'][ndcIdx]['calc_flag'].toLowerCase().trim())
                                    ||
                                    (ndc['billableUnit'] != null && recalValues[0]['ndcMap'][ndcIdx]['billableUnit'] != null
                                        && ndc['billableUnit'] != recalValues[0]['ndcMap'][ndcIdx]['billableUnit'])) {

                                    isRecalRequired = true;
                                    self.isRecCal = false;
                                }
                            }
                            ndcIdx++;
                        });
                    }
                }
            }
        });
        return isRecalRequired;
    }

    private reCalcHcpc() {

        if (this.selectedHcpcCode.length == 0) {
            toastr.info("Please select a HCPC");
            return;
        }
        var self = this;

        self.hcpcData.hcpcMap = [];
        self.hcpcData['user_id'] = this.user['user_id'];

        self.hcpcData['rc_id'] = this.rc_id;
        self.hcpcData['dump_code'] = this.dump_code;
        self.hcpcData['units'] = this.units;
        self.hcpcData['queue_id'] = 2;
        self.hcpcData['note_description'] = "";

        var workqueues = [];

        //Only Add hcpc
        if (this.isAddHcpcRow == true) {
            if ((this.addHcpcSuperSix['generic_name'] == "" || this.addHcpcSuperSix['generic_name'] == undefined) ||
                (this.addHcpcSuperSix['brand_name'] == "" || this.addHcpcSuperSix['brand_name'] == undefined) ||
                (this.addHcpcSuperSix['strength'] == "" || this.addHcpcSuperSix['strength'] == undefined) ||
                (this.addHcpcSuperSix['dosage_form'] == "" || this.addHcpcSuperSix['dosage_form'] == undefined) ||
                (this.addHcpcSuperSix['route_of_administration'] == "" || this.addHcpcSuperSix['route_of_administration'] == undefined) ||
                (this.addHcpcSuperSix['rx_otc_ind'] == "" || this.addHcpcSuperSix['rx_otc_ind'] == undefined) ||
                (this.addHcpcSuperSix['calc_flag'] == "" || this.addHcpcSuperSix['calc_flag'] == undefined) ||
                (this.addHcpcSuperSix['billable_unit'] == "" || this.addHcpcSuperSix['billable_unit'] == undefined)) {
                toastr.warning("Please fill all values in new HCPC combination");
                return;
            } else {
                debugger;
                var isDuplicate = false;
                self.hcpcSuperSixFilterData.forEach(function (oldHcpc) {
                    if ((oldHcpc['generic_name'].toLowerCase().trim() == self.addHcpcSuperSix['generic_name'].toLowerCase().trim()
                        || oldHcpc['generic_name'] == '*' || self.addHcpcSuperSix['generic_name'] == '*')
                        && (oldHcpc['brand_name'].toLowerCase().trim() == self.addHcpcSuperSix['brand_name'].toLowerCase().trim()
                            || oldHcpc['brand_name'] == '*' || self.addHcpcSuperSix['brand_name'] == '*')
                        && (oldHcpc['strength'].toLowerCase().trim() == self.addHcpcSuperSix['strength'].toLowerCase().trim()
                            || oldHcpc['strength'] == '*' || self.addHcpcSuperSix['strength'] == '*')
                        && (oldHcpc['dosage_form'].toLowerCase().trim() == self.addHcpcSuperSix['dosage_form'].toLowerCase().trim()
                            || oldHcpc['dosage_form'] == '*' || self.addHcpcSuperSix['dosage_form'] == '*')
                        && (oldHcpc['route_of_administration'].toLowerCase().trim() == self.addHcpcSuperSix['route_of_administration'].toLowerCase().trim()
                            || oldHcpc['route_of_administration'] == '*' || self.addHcpcSuperSix['route_of_administration'] == '*')
                        && (oldHcpc['rx_otc_ind'].toLowerCase().trim() == self.addHcpcSuperSix['rx_otc_ind'].toLowerCase().trim()
                            || oldHcpc['rx_otc_ind'] == '*' || self.addHcpcSuperSix['rx_otc_ind'] == '*')
                        && (oldHcpc['calc_flag'].toLowerCase().trim() == self.addHcpcSuperSix['calc_flag'].toLowerCase().trim()
                            || oldHcpc['calc_flag'] == '*' || self.addHcpcSuperSix['calc_flag'] == '*')
                        && (oldHcpc['billable_unit'].toLowerCase().trim() == self.addHcpcSuperSix['billable_unit'].toLowerCase().trim()
                            || oldHcpc['billable_unit'] == '*' || self.addHcpcSuperSix['billable_unit'] == '*')) {
                        isDuplicate = true;
                    }
                });
                if (isDuplicate == false) {
                    var objNewHcpc = {
                        s6_wildcard_hcpcs_id: null,
                        s6_wildcard_hcpcs_temp_id: null,
                        s6_wildcard_id: null,
                        isShowNDCDetails: false,
                        generic_name: this.addHcpcSuperSix['generic_name'],
                        brand_name: this.addHcpcSuperSix['brand_name'],
                        strength: this.addHcpcSuperSix['strength'],
                        dosage_form: this.addHcpcSuperSix['dosage_form'],
                        route_of_administration: this.addHcpcSuperSix['route_of_administration'],
                        rx_otc_ind: this.addHcpcSuperSix['rx_otc_ind'],
                        billable_unit: this.addHcpcSuperSix['billable_unit'],
                        calc_flag: this.addHcpcSuperSix['calc_flag'],
                        reasonCode: "",
                        reasonNote: "",
                        attributeId: null,
                        status: "adding",
                        isActive: "Y"
                    }
                    self.hcpcData.hcpcMap.push(objNewHcpc);
                }
                else {
                    toastr.info("This combination is already present");
                    return;
                }
            }
        }

        self.hcpcSuperSixFilterData = self.hcpcSuperSixFilterData || [];
        if (self.hcpcSuperSixFilterData.length > 0) {
            var hcpcProps = Object.getOwnPropertyNames(self.hcpcSuperSixFilterData[0]);
            self.hcpcSuperSixFilterData.forEach(function (hcpc) {
                if (self.hcpcSuperSixDataBackup != undefined && self.hcpcSuperSixDataBackup.length > 0) {
                    var backupHcpc = self.hcpcSuperSixDataBackup.filter(bk => bk['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id']);
                }
                var workqueues = [];
                var oWorkqueue = {};
                var hcpcPropName = '';

                var oHcpc = {
                    s6_wildcard_hcpcs_id: hcpc['s6_wildcard_hcpcs_id'],
                    s6_wildcard_hcpcs_temp_id: hcpc['s6_wildcard_hcpcs_temp_id'],
                    s6_wildcard_id: hcpc['s6_wildcard_id'],
                    reasonCode: "",
                    reasonNote: "",
                    attributeId: null,
                    status: "nochanged",
                    isActive: hcpc['is_active'],
                    stage_id: hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2,
                    workqueues: [],
                    ndcMap: []
                }

                // Those hcpc property values are not equal
                for (var i = 0; i < hcpcProps.length; i++) {
                    hcpcPropName = hcpcProps[i];
                    switch (hcpcPropName) {
                        case 'generic_name':
                        case 'brand_name':
                        case 'strength':
                        case 'dosage_form':
                        case 'route_of_administration':
                        case 'rx_otc_ind':
                        case 'billable_unit':
                        case 'calc_flag':
                            hcpc[hcpcPropName] = (hcpc[hcpcPropName] == null) ? "" : hcpc[hcpcPropName];
                            oHcpc[hcpcPropName] = hcpc[hcpcPropName];
                            if ((hcpc['s6_wildcard_hcpcs_id'] != null || hcpc['s6_wildcard_hcpcs_temp_id'] != null) && hcpc['status'] != 'deleted') {
                                if (backupHcpc != undefined && backupHcpc.length > 0) {
                                    backupHcpc[0][hcpcPropName] = (backupHcpc[0][hcpcPropName] == null) ? "" : backupHcpc[0][hcpcPropName];
                                    if (hcpc[hcpcPropName].toString().toLowerCase().trim() != backupHcpc[0][hcpcPropName].toString().toLowerCase().trim()) {
                                        oWorkqueue = {
                                            "queue_id": 2,
                                            "stage_id": hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2,
                                            "attribute_name": hcpcPropName,
                                            "attribute_value": hcpc[hcpcPropName]
                                        }
                                        oHcpc.workqueues.push(oWorkqueue);
                                        oHcpc['status'] = "editing";
                                    }
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
                if (hcpc['status'] == 'deleted') {
                    oWorkqueue = {
                        "queue_id": 2,
                        "stage_id": hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2,
                    }
                    oHcpc.workqueues.push(oWorkqueue);
                    oHcpc['status'] = "deleted";
                    oHcpc['isActive'] = 'N';
                }

                if (hcpc['ndcMap'] != undefined) {
                    var backNdcs = [];
                    var ndcIdx = 0;

                    hcpc['ndcMap'].forEach(function (ndc) {
                        var oNdc = {};
                        var workqueues = [];
                        var oWorkqueue = {};
                        debugger;
                        if (hcpc['s6_wildcard_hcpcs_id'] != null) {
                            if (backupHcpc != undefined && backupHcpc.length > 0) {
                                if (backupHcpc[0]['ndcMap'] != undefined && backupHcpc[0]['ndcMap'][ndcIdx] != undefined) {
                                    var changeCalPrice = (ndc['calc_flag'] == null) ? '' : ndc['calc_flag'];
                                    var orgCalPrice = (backupHcpc[0]['ndcMap'] == undefined || backupHcpc[0]['ndcMap'][ndcIdx]['calc_flag'] == null) ? '' : backupHcpc[0]['ndcMap'][ndcIdx]['calc_flag'];
                                    if (changeCalPrice.toLowerCase().trim() != orgCalPrice.toLowerCase().trim()) {
                                        oWorkqueue = {
                                            'queue_id': 1,
                                            'stage_id': 1,
                                            "attribute_id": 22,
                                            'attribute_name': 'calc_flag',
                                            'attribute_value': ndc['calc_flag']
                                        }
                                        workqueues.push(oWorkqueue);
                                    }

                                    var changeBillUnit = (ndc['billableUnit'] == null) ? '' : ndc['billableUnit'];
                                    var orgBillUnit = (backupHcpc[0]['ndcMap'] == undefined || backupHcpc[0]['ndcMap'][ndcIdx]['billableUnit'] == null) ? '' : backupHcpc[0]['ndcMap'][ndcIdx]['billableUnit'];
                                    if (changeBillUnit.toLowerCase().trim() != orgBillUnit.toLowerCase().trim()) {
                                        oWorkqueue = {
                                            'queue_id': 1,
                                            'stage_id': 1,
                                            "attribute_id": 23,
                                            'attribute_name': "billableUnit",
                                            'attribute_value': ndc['billableUnit']
                                        }
                                        workqueues.push(oWorkqueue);
                                    }
                                }
                            }
                            if (workqueues.length > 0) {
                                oNdc['s6_wc_hcpcs_ndc_id'] = ndc['s6_wc_hcpcs_ndc_id'] == undefined ? null : ndc['s6_wc_hcpcs_ndc_id'];
                                oNdc['s6_wc_hcpcs_ndc_temp_id'] = (ndc['s6_wc_hcpcs_ndc_temp_id'] == undefined) ? null : ndc['s6_wc_hcpcs_ndc_temp_id'];
                                oNdc['ndc'] = ndc['ndc'];
                                oNdc["generic_name"] = ndc['generic_name'] == undefined ? null : ndc['generic_name'];
                                oNdc["brand_name"] = ndc['brand_name'] == undefined ? null : ndc['brand_name'];
                                oNdc["strength"] = ndc['strength'] == undefined ? null : ndc['strength'];
                                oNdc["dosage_form"] = ndc['dosage_form'] == undefined ? null : ndc['dosage_form'];
                                oNdc["route_of_administration"] = ndc['route_of_administration'] == undefined ? null : ndc['route_of_administration'];
                                oNdc["rx_otc_ind"] = ndc['rx_otc_ind'] == undefined ? null : ndc['rx_otc_ind'];
                                oNdc["package_size"] = ndc['package_size'] == undefined ? null : ndc['package_size'];
                                oNdc["brandGenericIndicator"] = ndc['brandGenericIndicator'] == undefined ? null : ndc['brandGenericIndicator'];
                                oNdc["repackager_ind"] = ndc['repackager_ind'] == undefined ? null : ndc['repackager_ind'];
                                oNdc["inner_outer_package_indicator"] = ndc['inner_outer_package_indicator'] == undefined ? null : ndc['inner_outer_package_indicator'];
                                oNdc["ndc_status"] = ndc['ndc_status'] == undefined ? null : ndc['ndc_status'];
                                oNdc["awpPrice"] = ndc['awpPrice'] == undefined ? null : ndc['awpPrice'];
                                oNdc["wacPrice"] = ndc['wacPrice'] == undefined ? null : ndc['wacPrice'];
                                oNdc["calc_flag"] = ndc['calc_flag'] == undefined ? null : ndc['calc_flag'];
                                oNdc['billableUnit'] = ndc['billableUnit'] == undefined ? null : ndc['billableUnit'];
                                oNdc['isActive'] = (ndc['isActive'] == undefined) ? null : ndc['isActive'];
                                oNdc['wt_id'] = ndc['wt_id'];
                                oNdc['status'] = "editing";
                                ndc['calc_flag'] = ndc['calc_flag'] == undefined || ndc['calc_flag'] == null ? '' : ndc['calc_flag'];
                                oNdc['workqueues'] = workqueues;
                                oHcpc['ndcMap'].push(oNdc);
                            }
                            ndcIdx++;
                        }
                    });
                }
                self.hcpcData.hcpcMap.push(oHcpc);
            });
        }
        //only deleted hcpc
        // if (this.hcpcDeleted != null) {
        //     
        //     this.hcpcDeleted.forEach(function (hcpc) {
        //         var oHcpc = {};
        //         oHcpc = {
        //             status: "deleted",
        //             s6_wildcard_hcpcs_id: hcpc['s6_wildcard_hcpcs_id'],
        //             s6_wildcard_hcpcs_temp_id: hcpc['s6_wildcard_hcpcs_temp_id'],
        //             s6_wildcard_id: hcpc['s6_wildcard_id'],
        //             attributeId: null,
        //             reasonCode: null,
        //             reasonNote: "",
        //             generic_name: hcpc['generic_name'],
        //             brand_name: hcpc['brand_name'],
        //             strength: hcpc['strength'],
        //             dosage_form: hcpc['dosage_form'],
        //             route_of_administration: hcpc['route_of_administration'],
        //             rx_otc_ind: hcpc['rx_otc_ind'],
        //             billable_unit: hcpc['billable_unit'],
        //             calc_flag: hcpc['calc_flag'],
        //             isActive: "N",
        //         }
        //         self.hcpcData.hcpcMap.push(oHcpc);
        //     });
        // }

        if (self.hcpcData.hcpcMap.length != 0) {
            var recalIndex = 0;
            self.otherHcpc = [];
            this._hcpcSvc.recalHcpc(self.hcpcData).subscribe(recalhcpc => {
                debugger;
                var retType = typeof recalhcpc;
                if (retType == 'object') {
                    self.recalBackup = [];
                    self.recalBackup = JSON.parse(JSON.stringify(recalhcpc['hcpcMap']));
                    self.hcpcSuperSixData = recalhcpc['hcpcMap'];
                    self.hcpcSuperSixFilterData = recalhcpc['hcpcMap'];

                    var hcpcRecalFilter = recalhcpc['hcpcMap'].filter(obj => obj['s6_wildcard_hcpcs_temp_id'] == null && obj['s6_wildcard_hcpcs_id'] == null)
                    if (hcpcRecalFilter != undefined && hcpcRecalFilter.length > 0) {
                        self.otherHcpc.push(hcpcRecalFilter[0]['hcpc_codes']);
                        if (this.otherHcpc != undefined && this.otherHcpc.length > 0) {
                            var hcpcList = '';
                            this.otherHcpc.forEach(element => {
                                console.log(element.hcpc_code);
                                hcpcList = hcpcList + element.hcpc_code + ', ';
                            });
                            toastr.info("Newly added combination already exists in other HCPC " + hcpcList.substring(0, hcpcList.length - 2));
                        }
                    }

                    this.priceDetails = recalhcpc['priceDetails'];

                    if (self.pushNdcStatus != undefined) {
                        self.pushNdcStatus.forEach(status => {
                            var hcpcStatus = self.hcpcSuperSixFilterData.filter(obj => obj['s6_wildcard_hcpcs_id'] == status['s6_wildcard_hcpcs_id']
                                && obj['s6_wildcard_hcpcs_temp_id'] == status['s6_wildcard_hcpcs_temp_id']);
                            if (hcpcStatus.length > 0 && hcpcStatus[0]['ndcMap'] != undefined) {
                                var ndcStatus = hcpcStatus[0]['ndcMap'].filter(obj => obj['wt_id'] == status['wt_id']);
                                if (ndcStatus.length > 0) {
                                    var propStatus = status['ndc_status'];
                                    ndcStatus[0][propStatus] = status['ndc_status_value'];
                                }
                            }
                        });
                    }
                    // var addNewHcpc = recalhcpc['hcpcMap'].filter(h => h['s6_wildcard_hcpcs_id'] == null);
                    // addNewHcpc.forEach(newhcpc => {
                    //     var flag = false;
                    //     self.hcpcSuperSixFilterData.forEach(addhcpc => {
                    //         if (addhcpc['s6_wildcard_id'] == newhcpc['s6_wildcard_id']) {
                    //             flag = true;
                    //         }
                    //     });
                    //     if (!flag) {
                    //         self.hcpcSuperSixFilterData.push(newhcpc);
                    //     }
                    // });

                    //replace old awp/wac price
                    var content = "";
                    if (this.priceDetails['awpPriceChanged'] && this.priceDetails['wacPriceChanged']) {
                        content += "AWP Price : " + this.priceDetails['awpPrice'] + " ";
                        content += "WAC Price : " + this.priceDetails['wacPrice'];
                        if (this.hcpcPriceData != undefined && this.hcpcPriceData.length > 0) {
                            var tempPrice = JSON.parse(JSON.stringify(this.hcpcPriceData[0]));
                            this.hcpcPriceData[0]['awp_price'] = this.priceDetails['awpPrice'];
                            this.hcpcPriceData[0]['wac_price'] = this.priceDetails['wacPrice'];
                            this.hcpcPriceData[1] = tempPrice;
                        }
                    }
                    else if (this.priceDetails['awpPriceChanged']) {
                        content += "AWP Price : " + this.priceDetails['awpPrice'] + " ";
                        if (this.hcpcPriceData != undefined && this.hcpcPriceData.length > 0) {
                            var tempPrice = JSON.parse(JSON.stringify(this.hcpcPriceData[0]));
                            this.hcpcPriceData[0]['awp_price'] = this.priceDetails['awpPrice'];
                            this.hcpcPriceData[1] = tempPrice;
                        }
                    }
                    else if (this.priceDetails['wacPriceChanged']) {
                        content += "WAC Price : " + this.priceDetails['wacPrice'];
                        if (this.hcpcPriceData != undefined && this.hcpcPriceData.length > 0) {
                            var tempPrice = JSON.parse(JSON.stringify(this.hcpcPriceData[0]));
                            this.hcpcPriceData[0]['wac_price'] = this.priceDetails['wacPrice'];
                            this.hcpcPriceData[1] = tempPrice;
                        }
                    }
                    if (this.priceDetails['awpPriceChanged'] || this.priceDetails['wacPriceChanged']) {
                        toastr.success(content, "Recalc completed </br>  Affected price");
                    }
                    else {
                        toastr.success("Recalc completed");
                    }
                    recalhcpc['hcpcMap'].forEach(function (hcpc) {
                        if (hcpc['s6_wildcard_hcpcs_id'] != null && hcpc['s6_wildcard_hcpcs_temp_id'] != null && hcpc['ndcMap'] != undefined) {
                            hcpc['ndcMap'].forEach(function (ndc) {

                                if (self.hcpcSuperSixDataBackup != undefined && self.hcpcSuperSixDataBackup.length > 0) {
                                    var exHcpc = self.hcpcSuperSixDataBackup.filter(h => h['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id'] && h['s6_wildcard_hcpcs_temp_id'] == hcpc['s6_wildcard_hcpcs_temp_id']);
                                    if (exHcpc.length > 0 && exHcpc[0]['ndcMap'] != undefined) {
                                        var exNdc = exHcpc[0]['ndcMap'].filter(n => n['wt_id'] == ndc['wt_id']);
                                        if (exNdc.length == 0) {
                                            exHcpc[0]['ndcMap'].push(JSON.parse(JSON.stringify(ndc)));
                                        }
                                    }
                                    if (exHcpc.length > 0 && exHcpc[0]['ndcMap'] == undefined) {
                                        exHcpc[0]['ndcMap'] = exHcpc[0]['ndcMap'] != undefined ? exHcpc[0]['ndcMap'] : [];
                                        exHcpc[0]['ndcMap'].push(JSON.parse(JSON.stringify(ndc)));
                                    }
                                }
                            });
                        }
                    });
                    // self.hcpcSuperSixDataBackup.forEach(function (hcpc) {
                    //     if (hcpc['ndcMap'] != undefined) {
                    //         hcpc['ndcMap'].forEach(function (ndc) {
                    //             var exHcpc = self.recalBackup.filter(h => h['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id'] && h['s6_wildcard_hcpcs_temp_id'] == hcpc['s6_wildcard_hcpcs_temp_id']);
                    //             if (exHcpc.length > 0 && exHcpc[0]['ndcMap'] != undefined) {
                    //                 var exNdc = exHcpc[0]['ndcMap'].filter(n => n['wt_id'] != ndc['wt_id']);                                   
                    //                 if (exNdc.length != 0) {
                    //                     var idx = hcpc['ndcMap'].indexOf(ndc);
                    //                     hcpc['ndcMap'].splice(idx, 1);
                    //                 }
                    //             }
                    //         });
                    //     }
                    // });
                }
                this.isAddHcpcRow = false;
                this.isRecCal = true;
                recalIndex++;
            });

        } else {
            toastr.info("No HCPC attriubute changes found");
        }
    }

    private save() {
        var saveData = this.requestJson();

        this._hcpcSvc.saveHcpc(saveData).subscribe(savehcpc => {
            this.isAddHcpcRow = false;
            if (savehcpc.toLowerCase() == "success") {
                toastr.success("saved successfully");
                this.router.navigate(['home']);
            }
        });
    }

    private requestToPublish() {
        var requestToPublishData = this.requestJson();
        requestToPublishData['note_description'] = this.otherInfo['req_to_publish_note'];

        this._hcpcSvc.requestToPublishHcpc(requestToPublishData).subscribe(reqPublish => {
            this.isAddHcpcRow = false;
            if (reqPublish.toLowerCase() == "success") {
                toastr.success("Request to publish successfull");
                this.router.navigate(['home']);
            }
        });
    }

    private publish() {
        var publishData = this.requestJson();
        publishData['note_description'] = this.otherInfo['publish_note'];

        if (this.priceDetails != undefined) {
            this.priceDetails['awpPrice'] = this.priceDetails['awpPrice'] == null ? 0 : this.priceDetails['awpPrice'];
            this.priceDetails['wacPrice'] = this.priceDetails['wacPrice'] == null ? 0 : this.priceDetails['wacPrice'];

            publishData['priceDetails'] = {
                "awpPrice": this.priceDetails['awpPrice'],
                "wacPrice": this.priceDetails['wacPrice'],
                "awpPriceChanged": this.priceDetails['awpPriceChanged'],
                "wacPriceChanged": this.priceDetails['wacPriceChanged']
            }
        }

        this._hcpcSvc.publishHcpc(publishData).subscribe(publish => {
            this.isAddHcpcRow = false;
            if (publish.toLowerCase() == "success") {
                toastr.success("Publish successfull");
                this.router.navigate(['home']);
            }
        });
    }

    private requestJson() {

        if (this.selectedHcpcCode.length == 0) {
            toastr.info("Please select a HCPC");
            return;
        }
        if (this.isAddHcpcRow == true) {
            if ((this.addHcpcSuperSix['generic_name'] == "" || this.addHcpcSuperSix['generic_name'] == undefined) ||
                (this.addHcpcSuperSix['brand_name'] == "" || this.addHcpcSuperSix['brand_name'] == undefined) ||
                (this.addHcpcSuperSix['strength'] == "" || this.addHcpcSuperSix['strength'] == undefined) ||
                (this.addHcpcSuperSix['dosage_form'] == "" || this.addHcpcSuperSix['dosage_form'] == undefined) ||
                (this.addHcpcSuperSix['route_of_administration'] == "" || this.addHcpcSuperSix['route_of_administration'] == undefined) ||
                (this.addHcpcSuperSix['rx_otc_ind'] == "" || this.addHcpcSuperSix['rx_otc_ind'] == undefined) ||
                (this.addHcpcSuperSix['calc_flag'] == "" || this.addHcpcSuperSix['calc_flag'] == undefined) ||
                (this.addHcpcSuperSix['billable_unit'] == "" || this.addHcpcSuperSix['billable_unit'] == undefined)) {
                toastr.warning("Please fill all values in new HCPC combination");
                return;
            }
            else {
                toastr.warning("Please recalc before save,request to publish and publish");
                return;
            }
        }
        // if (this.hcpcDeleted == null || this.hcpcDeleted == undefined || this.isAddHcpcRow == true) {
        //     toastr.info("Please Recalc before save,request to publish and publish");
        //     return;
        // }
        // if (this.isRecalRequired() == true) {
        //     toastr.warning("Data mis-match, please re-cal for further process");
        //     return;
        // }
        var self = this;

        self.hcpcData.hcpcMap = [];
        self.hcpcData['user_id'] = this.user['user_id'];
        self.hcpcData['rc_id'] = this.rc_id;
        self.hcpcData['dump_code'] = this.dump_code;
        self.hcpcData['units'] = this.units;
        self.hcpcData['queue_id'] = 2;   // 2 or 3
        self.hcpcData['note_description'] = "";

        //changes hcpc & changes ndc
        this.hcpcSuperSixFilterData.forEach(function (hcpc) {
            var hcpcProps = Object.getOwnPropertyNames(self.hcpcSuperSixFilterData[0]);

            if (self.hcpcSuperSixDataBackup != undefined && self.hcpcSuperSixDataBackup.length > 0) {
                var backupHcpc = self.hcpcSuperSixDataBackup.filter(bk => bk['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id']);
            }
            var oHcpc = {};
            var workqueues = [];
            var oWorkqueue = {};

            oHcpc['isActive'] = hcpc['isActive'] == null || hcpc['isActive'] == undefined ? 'Y' : hcpc['isActive'];
            //----------------------- 17Nov2017----------------------
            if (self.hcpcDeleted != undefined && self.hcpcDeleted.length > 0) {
                var deletedHcpc = self.hcpcDeleted.filter(dc => dc['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id'] && dc['s6_wildcard_hcpcs_temp_id'] == hcpc['s6_wildcard_hcpcs_temp_id']);
                if (deletedHcpc.length > 0) {
                    oHcpc['isActive'] = 'N';
                }
            }
            //-------------------------------------------------------

            oHcpc['s6_wildcard_hcpcs_id'] = hcpc['s6_wildcard_hcpcs_id'];
            oHcpc['s6_wildcard_hcpcs_temp_id'] = hcpc['s6_wildcard_hcpcs_temp_id'];
            oHcpc['s6_wildcard_id'] = hcpc['s6_wildcard_id'] == undefined ? null : hcpc['s6_wildcard_id'];;
            oHcpc['stage_id'] = hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2;
            oHcpc['attributeId'] = null;
            oHcpc['reasonCode'] = null;
            oHcpc['reasonNote'] = "";
            oHcpc['status'] = hcpc['status'];
            oHcpc['ndcMap'] = [];
            oHcpc['workqueues'] = [];

            // Those hcpc property values are not equal
            for (var i = 0; i < hcpcProps.length; i++) {
                var hcpcPropName = hcpcProps[i];
                switch (hcpcPropName) {
                    case 'generic_name':
                    case 'brand_name':
                    case 'strength':
                    case 'dosage_form':
                    case 'route_of_administration':
                    case 'rx_otc_ind':
                    case 'billable_unit':
                    case 'calc_flag':
                        hcpc[hcpcPropName] = (hcpc[hcpcPropName] == null) ? "" : hcpc[hcpcPropName];
                        oHcpc[hcpcPropName] = hcpc[hcpcPropName];
                        if ((hcpc['s6_wildcard_hcpcs_id'] != null || hcpc['s6_wildcard_hcpcs_temp_id'] != null) && hcpc['status'] != "deleted") {
                            if (backupHcpc != undefined && backupHcpc.length > 0) {
                                backupHcpc[0][hcpcPropName] = (backupHcpc[0][hcpcPropName] == null) ? "" : backupHcpc[0][hcpcPropName];
                                if (backupHcpc[0][hcpcPropName].toString().toLowerCase().trim() != hcpc[hcpcPropName].toString().toLowerCase().trim()) {
                                    oWorkqueue = {
                                        "queue_id": 2,
                                        "stage_id": hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2,
                                        "attribute_name": hcpcPropName,
                                        "attribute_value": hcpc[hcpcPropName]
                                    }
                                    oHcpc['workqueues'].push(oWorkqueue);
                                    oHcpc['status'] = "editing";
                                }
                            }
                            // workqueues.push(oWorkqueue);
                        }
                        break;
                    default:
                        break;
                }
            }
            if (hcpc['s6_wildcard_hcpcs_id'] == null && hcpc['s6_wildcard_hcpcs_temp_id'] == null) {
                oWorkqueue = {
                    "queue_id": 2,
                    "stage_id": hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2
                }
                oHcpc['workqueues'].push(oWorkqueue);
            }
            if (hcpc['status'] == "deleted") {
                oWorkqueue = {
                    "queue_id": 2,
                    "stage_id": hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2
                }
                oHcpc['workqueues'].push(oWorkqueue);
            }

            //get reson notes
            if (self.pushReasonNote.length > 0) {

                var filterReasonNotes = self.pushReasonNote.filter(r => r['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id']);
                if (filterReasonNotes.length > 0) {
                    oHcpc['attributeId'] = filterReasonNotes[0]['attributeId'];
                    oHcpc['reasonCode'] = filterReasonNotes[0]['reasonCode'];
                    oHcpc['reasonNote'] = filterReasonNotes[0]['reasonNote'];
                }
            }

            if (hcpc['ndcMap'] != undefined) {
                var backNdcs = [];
                var ndcIdx = 0;
                hcpc['ndcMap'].forEach(function (ndc) {

                    var oNdc = {};
                    var workqueues = [];
                    var oWorkqueue = {};
                    oNdc['rjworkqueues'] = self.ndcStatusWorkqueue(ndc);
                    oNdc['s6_wc_hcpcs_ndc_id'] = ndc['s6_wc_hcpcs_ndc_id'] == undefined ? null : ndc['s6_wc_hcpcs_ndc_id'];
                    oNdc['s6_wc_hcpcs_ndc_temp_id'] = (ndc['s6_wc_hcpcs_ndc_temp_id'] == undefined) ? null : ndc['s6_wc_hcpcs_ndc_temp_id'];
                    oNdc['ndc'] = ndc['ndc'];
                    oNdc["calc_flag"] = ndc['calc_flag'] == undefined ? null : ndc['calc_flag'];
                    oNdc['billableUnit'] = ndc['billableUnit'] == undefined ? null : ndc['billableUnit'];
                    oNdc['isActive'] = (ndc['isActive'] == undefined) ? null : ndc['isActive'];
                    oNdc['wt_id'] = ndc['wt_id'];
                    oNdc['status'] = "nochanged";
                    ndc['calc_flag'] = ndc['calc_flag'] == undefined || ndc['calc_flag'] == null ? '' : ndc['calc_flag'];

                    if (hcpc['s6_wildcard_hcpcs_id'] != null || hcpc['s6_wc_hcpcs_ndc_temp_id'] != null) {
                        if (backupHcpc != undefined && backupHcpc.length > 0) {
                            if (backupHcpc[0]['ndcMap'] != undefined && backupHcpc[0]['ndcMap'][ndcIdx] != undefined) {
                                var changeCalPrice = (ndc['calc_flag'] == null) ? '' : ndc['calc_flag'];
                                var orgCalPrice = (backupHcpc[0]['ndcMap'] == undefined || backupHcpc[0]['ndcMap'][ndcIdx]['calc_flag'] == null) ? '' : backupHcpc[0]['ndcMap'][ndcIdx]['calc_flag'];
                                if (changeCalPrice.toLowerCase().trim() != orgCalPrice.toLowerCase().trim()) {
                                    oWorkqueue = {
                                        'queue_id': 1,
                                        'stage_id': 1,
                                        "attribute_id": 22,
                                        'attribute_name': 'calc_flag',
                                        'attribute_value': ndc['calc_flag']
                                    }
                                    workqueues.push(oWorkqueue);
                                }

                                var changeBillUnit = (ndc['billableUnit'] == null) ? '' : ndc['billableUnit'];
                                var orgBillUnit = (backupHcpc[0]['ndcMap'] == undefined || backupHcpc[0]['ndcMap'][ndcIdx]['billableUnit'] == null) ? '' : backupHcpc[0]['ndcMap'][ndcIdx]['billableUnit'];
                                if (changeBillUnit.toLowerCase().trim() != orgBillUnit.toLowerCase().trim()) {
                                    oWorkqueue = {
                                        'queue_id': 1,
                                        'stage_id': 1,
                                        "attribute_id": 23,
                                        'attribute_name': "billableUnit",
                                        'attribute_value': ndc['billableUnit']
                                    }
                                    workqueues.push(oWorkqueue);
                                }
                            }
                        }
                    }
                    else {
                        self.recalBackup.forEach(function (rhcpc) {
                            if (rhcpc['ndcMap'] !== undefined) {
                                var recNdc = rhcpc['ndcMap'].filter(n => n['wt_id'] == ndc['wt_id']);
                                if (recNdc.length > 0) {
                                    var recalChangeCalPrice = (ndc['calc_flag'] == null) ? '' : ndc['calc_flag'];
                                    var recalOrgCalPrice = (recNdc[0]['calc_flag'] == null) ? '' : recNdc[0]['calc_flag'];
                                    if (recalChangeCalPrice.toLowerCase().trim() != recalOrgCalPrice.toLowerCase().trim()) {
                                        oWorkqueue = {
                                            'queue_id': 1,
                                            'stage_id': 1,
                                            "attribute_id": 22,
                                            'attribute_name': 'calc_flag',
                                            'attribute_value': ndc['calc_flag']
                                        }
                                        oNdc['status'] = "editing";
                                        workqueues.push(oWorkqueue);
                                    }
                                    var recalChangeBillUnit = (ndc['billableUnit'] == null) ? '' : ndc['billableUnit'];
                                    var recalOrgBillUnit = (recNdc[0]['billableUnit'] == null) ? '' : recNdc[0]['billableUnit'];
                                    if (recalChangeBillUnit.toLowerCase().trim() != recalOrgBillUnit.toLowerCase().trim()) {
                                        oWorkqueue = {
                                            'queue_id': 1,
                                            'stage_id': 1,
                                            "attribute_id": 23,
                                            'attribute_name': "billableUnit",
                                            'attribute_value': ndc['billableUnit']
                                        }
                                        oNdc['status'] = "editing";
                                        workqueues.push(oWorkqueue);
                                    }
                                }
                            }
                        });
                    }

                    if (workqueues.length > 0) {
                        oNdc['workqueues'] = workqueues;
                        oNdc['status'] = "editing";
                        oHcpc['status'] = "editing";
                    }

                    if (self.hcpcSuperSixInitialBackup != undefined) {
                        var initialHcpc = self.hcpcSuperSixInitialBackup.filter(h => h['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id'] && h['s6_wildcard_hcpcs_temp_id'] == hcpc['s6_wildcard_hcpcs_temp_id']);
                        if (initialHcpc.length > 0 && initialHcpc[0]['ndcMap'] != undefined) {
                            var initialNdc = initialHcpc[0]['ndcMap'].filter(n => n['wt_id'] == ndc['wt_id']);
                            if (initialNdc.length == 0) {
                                oHcpc['status'] = "editing";
                                oWorkqueue = {
                                    "queue_id": 2,
                                    "stage_id": hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2
                                }
                                oHcpc['workqueues'].push(oWorkqueue);
                            }
                        }
                    }
                    oHcpc['ndcMap'].push(oNdc);
                    ndcIdx++;
                });
                // for privious NDC which is discarded
                if (oHcpc['workqueues'].length == 0) {
                    var orgHcpc = self.hcpcSuperSixInitialBackup.filter(h => h['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id'] && h['s6_wildcard_hcpcs_temp_id'] == hcpc['s6_wildcard_hcpcs_temp_id']);
                    var orgNdc = orgHcpc[0]['ndcMap'];
                    var newNdc = hcpc['ndcMap'];
                    var bool = false;
                    orgNdc.forEach(function (ndc) {
                        var ifFoundNdc = newNdc.filter(X => X['wt_id'] == ndc['wt_id']);
                        if (!bool && ifFoundNdc.length == 0) {
                            oHcpc['status'] = "editing";
                            oWorkqueue = {
                                "queue_id": 2,
                                "stage_id": hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2
                            }
                            oHcpc['workqueues'].push(oWorkqueue);
                            bool = true;
                        }
                    });
                }
            }
            else {
                var orgHcpc = self.hcpcSuperSixInitialBackup.filter(h => h['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id'] && h['s6_wildcard_hcpcs_temp_id'] == hcpc['s6_wildcard_hcpcs_temp_id']);
                if (orgHcpc.length > 0 && orgHcpc[0]["ndcMap"].length > 0) {
                    oHcpc['status'] = "editing";
                    oWorkqueue = {
                        "queue_id": 2,
                        "stage_id": hcpc['stage_id'] != undefined || hcpc['stage_id'] != null ? hcpc['stage_id'] : 2
                    }
                    oHcpc['workqueues'].push(oWorkqueue);
                }

                ndcIdx++;
            }
            //check if no changes in hcpc and ndcs
            // if (oHcpc['ndcMap'].length == 0 && oHcpc['workqueues'].length == 0) {

            //     var noChangeMade = self.hcpcData.hcpcMap.filter(bk => bk['s6_wildcard_hcpcs_id'] == hcpc['s6_wildcard_hcpcs_id']);
            //     if (noChangeMade.length > 0) {
            //         var idx = self.hcpcData.hcpcMap.indexOf(noChangeMade);
            //         self.hcpcData.hcpcMap.splice(idx, 1);
            //     }
            // }
            self.hcpcData.hcpcMap.push(oHcpc);
        });
        self.hcpcData['followUpDetails'] = { "followUpDate": this.otherInfo['follow_up_date'] };
        self.hcpcData['furtherRouting'] = {
            "queueName": this.otherInfo['work_queue'],
            "queueType": this.otherInfo['work_queue_type'],
            "routingUserId": this.otherInfo['route_user_id'],
            "notes": this.otherInfo['routing_notes']
        };

        if (self.hcpcRuleFailure != undefined) {
            self.hcpcRuleFailure.forEach(item => {
                var rf = self.hcpcRuleFailureBackup.filter(bk => bk['workqueue_id'] == item['workqueue_id'] && bk['attribute_status'] != item['attribute_status']);
                if (rf.length != 0) {
                    self.hcpcData['ruleFailuer'].push({ "attributeid": rf['attribute_id'], "rcId": self.rc_id, "description": rf['description'], "workqueueId": rf['workqueueId'] });
                }
            });
        }
        return self.hcpcData;
    }

    private sort(columnSelected) {
        this.column = this.columnSelected.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    private filterPendingTask($event) {
        this.filterparam['pendingTask'] = $event.target.checked;
        this.filterHCPCSuperSix();
    }

    private filterRxOtc($event, rxotcValue) {
        if ($event.target.checked) {
            this.filterparam['rxOtc'] = rxotcValue;
        }
        this.filterHCPCSuperSix();
    }

    private filterHCPCSuperSix(): void {

        if ((this.filterparam['genericName'] || this.filterparam['brandName'] || this.filterparam['strength'] ||
            this.filterparam['roa'] || this.filterparam['DoseForm'] || this.filterparam['calcPrice'] || this.filterparam['rxOtc'] ||
            this.filterparam['pendingTask']) && this.hcpcSuperSixData != undefined) {

            this.hcpcSuperSixFilterData = this.hcpcSuperSixData.filter
                (item =>
                    ((this.filterparam['genericName']) ? (item.generic_name.toLowerCase().indexOf(this.filterparam['genericName'].toLowerCase()) > -1) : 1)
                    &&
                    ((this.filterparam['brandName']) ? (item.brand_name.toLowerCase().indexOf(this.filterparam['brandName'].toLowerCase()) > -1) : 1)
                    &&
                    ((this.filterparam['strength']) ? (item['strength'].toLowerCase().indexOf(this.filterparam['strength'].toLowerCase()) > -1) : 1)
                    &&
                    ((this.filterparam['roa']) ? (item.route_of_administration.toLowerCase().indexOf(this.filterparam['roa'].toLowerCase()) > -1) : 1)
                    &&
                    ((this.filterparam['DoseForm']) ? (item.dosage_form.toLowerCase().indexOf(this.filterparam['DoseForm'].toLowerCase()) > -1) : 1)
                    &&
                    ((this.filterparam['calcPrice'] && item.calc_flag != null) ? (item.calc_flag.toLowerCase().indexOf(this.filterparam['calcPrice'].toLowerCase()) > -1) : 1)
                    &&
                    ((this.filterparam['rxOtc']) ? (item.rx_otc_ind.toLowerCase().indexOf(this.filterparam['rxOtc'].toLowerCase()) > -1) : 1)
                    &&
                    ((this.filterparam['pendingTask']) ? item.is_active == true : 1)
                );
        }
        else {
            this.hcpcSuperSixFilterData = this.hcpcSuperSixData;
        }
    }

    private clear() {
        this.filterparam = {
            genericName: "",
            brandName: "",
            strength: "",
            roa: "",
            DoseForm: "",
            calcPrice: "0",
            rxOtc: "",
            pendingTask: false,
            roFilter: false
        }

        this.hcpcSuperSixFilterData = this.hcpcSuperSixData;
    }

    private saveReasonNotes() {
        this.pushReasonNote.push({
            "s6_wildcard_hcpcs_id": this.s6_wildcard_hcpcs_id,
            "reasonCode": this.newReasonNote.reasonCode,
            "reasonNote": this.newReasonNote.reasonNote,
            "attributeId": this.newReasonNote.attributeId
        });
        this.newReasonNote = {
            reasonCode: 0,
            reasonNote: "",
            attributeId: 0,
        }
    }

    private cancel() {
        this.router.navigate(['home']);
    }

    private clearCommands() {
        this.isAddHcpcRow = false;
        this.hcpcDeleted = new Array();
        this.hcpcList = new Array();
        this.hcpcDescList = new Array();
        this.ndcList = new Array();
        this.otherInfo['req_to_publish_note'] = "";
        this.otherInfo['publish_note'] = "";
    }

    private showIDSymbol(price_type) {
        if (this.hcpcPriceData != undefined) {
            if (this.hcpcPriceData.length == 1) {
                return "glyphicon text-danger glyphicon-triangle-top";
            } else if (this.hcpcPriceData.length > 1 && this.hcpcPriceData[1][price_type] != undefined) {
                if (this.hcpcPriceData[0][price_type] > this.hcpcPriceData[1][price_type]) {
                    return "glyphicon text-danger glyphicon-triangle-top";
                }
                else if (this.hcpcPriceData[0][price_type] < this.hcpcPriceData[1][price_type]) {
                    return "glyphicon text-success glyphicon-triangle-bottom";
                }
            }
        } else {
            return "glyphicon";
        }
    }

    private showPopupPricingData(hcpc_code: string) {
        if (this.hcpcSuperSixFilterData) {
            this._hcpcSvc.getPopupPricingData(hcpc_code).subscribe(hcpcPrice => {
                this.popupPriceData = hcpcPrice[0];
            });
            this._hcpcSvc.getPopupPricingHistoryData(hcpc_code).subscribe(hcpcPricehistory => {
                this.popupHistoryPriceData = hcpcPricehistory;
            });
            this.modalPricing.show();
        }
    }

    private selectChange(value, tabName, currentPrice, HistoryPrice) {

        var IncreaseOrDecrease;
        currentPrice > HistoryPrice ? IncreaseOrDecrease = 'Increase' : IncreaseOrDecrease = 'Decrease';

        var a = this.reasonNoteDropDown.filter(obj => (obj.value == value));
        var desc = tabName + a[0]['desc'];
        var arr = desc.split('|');
        var length = arr.length;

        switch (tabName) {
            case 'AWP':
                if (length == 2) {
                    this.PriceDesc.awpFirst = arr[0];
                    this.PriceDesc.awpSecond = arr[1];
                } else {
                    this.PriceDesc.awpFirst = desc;
                    this.PriceDesc.awpSecond = "";
                }
                this.PriceDesc.awpFirst = this.PriceDesc.awpFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                this.PriceDesc.awpFirst = this.PriceDesc.awpFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                break;
            case 'WAC':
                if (length == 2) {
                    this.PriceDesc.wacFirst = arr[0];
                    this.PriceDesc.wacSecond = arr[1];
                } else {
                    this.PriceDesc.wacFirst = desc;
                    this.PriceDesc.wacSecond = "";
                }
                this.PriceDesc.wacFirst = this.PriceDesc.wacFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                this.PriceDesc.wacFirst = this.PriceDesc.wacFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                break;
            case 'ASP':
                if (length == 2) {
                    this.PriceDesc.aspFirst = arr[0];
                    this.PriceDesc.aspSecond = arr[1];
                } else {
                    this.PriceDesc.aspFirst = desc;
                    this.PriceDesc.aspSecond = "";
                }
                this.PriceDesc.aspFirst = this.PriceDesc.aspFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                this.PriceDesc.aspFirst = this.PriceDesc.aspFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                break;
            case 'APC':
                if (length == 2) {
                    this.PriceDesc.apcFirst = arr[0];
                    this.PriceDesc.apcSecond = arr[1];
                } else {
                    this.PriceDesc.apcFirst = desc;
                    this.PriceDesc.apcSecond = "";
                }
                this.PriceDesc.apcFirst = this.PriceDesc.apcFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                this.PriceDesc.apcFirst = this.PriceDesc.apcFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                break;
            case 'CMAC':
                if (length == 2) {
                    this.PriceDesc.cmacFirst = arr[0];
                    this.PriceDesc.cmacSecond = arr[1];
                } else {
                    this.PriceDesc.cmacFirst = desc;
                    this.PriceDesc.cmacSecond = "";
                }
                this.PriceDesc.cmacFirst = this.PriceDesc.cmacFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                this.PriceDesc.cmacFirst = this.PriceDesc.cmacFirst.replace("(increase/decrease)", IncreaseOrDecrease);
                break;
            default:
                break;
        }
    }

    private savePrice() {
        var priceType = ['awp', 'wac', 'asp', 'apc', 'cmac'];
        var finalSaveData = [];
        priceType.forEach(obj => {
            if (this.popupPriceData[obj + '_price_type_id'] != null) {
                var savePriceData = {
                    "rcId": this.rc_id,
                    "priceTypeId": this.popupPriceData[obj + '_price_type_id'],
                    "effectiveDate": this.popupPriceData[obj + '_effective_date'],
                    "unitPrice": this.popupPriceData[obj + '_price'],
                    "description": this.PriceDesc[obj + 'Date'] + this.PriceDesc[obj + 'First'] + this.PriceDesc[obj + 'Note'] + this.PriceDesc[obj + 'Second'] != "" ? this.PriceDesc[obj + 'First'] + this.PriceDesc[obj + 'Note'] + this.PriceDesc[obj + 'Second'] : "",
                    "notes": this.popupPriceData[obj + '_note_description'] != null ? this.popupPriceData[obj + '_note_description'] : ""
                }
                finalSaveData.push(savePriceData);
            }
        });
        this._hcpcSvc.savePricing(finalSaveData).subscribe(pricedata => {
            if (pricedata == "success") {
                toastr.success("Pricing Data Saved Successfully");
                priceType.forEach(obj => {
                    this.PriceDesc[obj + 'Date'] = "";
                    this.PriceDesc[obj + 'First'] = "";
                    this.PriceDesc[obj + 'Note'] = "";
                    this.PriceDesc[obj + 'Second'] = "";
                });
            }
        });
    }

    private showSection(section) {
        this.sectionList[section]['show'] = !this.sectionList[section]['show'];
    }

    private clearNotes() {
        this.otherInfo['req_to_publish_note'] = "";
        this.otherInfo['publish_note'] = "";
    }
}
