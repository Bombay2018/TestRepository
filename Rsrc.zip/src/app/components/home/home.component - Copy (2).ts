/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, Directive } from '@angular/core';
import { Router } from '@angular/router';

import { HomeService } from "./../../services/home.service";
import { DataService } from '../../services/data.service';
import { IUSER_MASTER, IWorkQueue, IFOLLOWUP_MASTER } from '../../shared/interfaces/entities.interface';
import { GlobalService } from '../..//services/shared/global.service';
import { PopoverConfig, HomeGridDropdown } from '../../services/shared/config.const';
import { DropDown } from '../../shared/common';

import { ModalComponent } from '../shared/modalpopup.component';

import * as _ from "lodash";
declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'app-home',
    templateUrl: './home.component.html?v=${new Date().getTime()}',
    providers: [HomeService, DataService]
})

export class HomeComponent implements OnInit, AfterViewInit {
    user: IUSER_MASTER;
    functionsMenu: any[] = new Array();
    isDesc: boolean = false;
    column: string = 'Date_Added';
    direction: number;
    selectedColumn: Object = {};
    dropDown: DropDown[];
    workqueuedata: IWorkQueue[];
    workqueuedataFilter: IWorkQueue[];
    calendarFollowUp: IFOLLOWUP_MASTER[];
    calendarFollowUpFilter: IFOLLOWUP_MASTER[];
    el: HTMLElement;
    todayDate: any;
    differenceInDate: any;
    differenceInMonth: any;
    differenceInYear: any;
    ImpactedElement: string;
    WorkQueueType: string;
    stage_id: number;
    RuleFailure: string;
    AttributeFailed: string;
    Status: string;
    statusFilter: string;
    switchResult: any;
    newfollowup: IFOLLOWUP_MASTER = {} as IFOLLOWUP_MASTER;
    selectedCode: string;
    selectedRuleFailure: string;
    seldate: Date;
    grFilter: boolean;


    @ViewChild('taskDate') div: ElementRef;
    @ViewChild('modalLockExist') modalLockExist: ModalComponent;

    constructor(
        private homeSvc: HomeService<IWorkQueue>,
        private dataSvc: DataService,
        private _router: Router,
        private elementRef: ElementRef,
        private _globalSev: GlobalService) {
        this.user = JSON.parse(localStorage.getItem('currentUser'));
        toastr.options = { positionClass: 'toast-top-center' };
        if (this.user == undefined) {
            this._router.navigate(['/login']);
            return;
        }
        this._globalSev.showNavBar(true, this.user.user_name);
    }

    ngOnInit() {
        if (this.user == undefined) {
            this._router.navigate(['/login']);
            return;
        }
        this.showFunctionMenu();

        this.workqueuedataFilter = [] as IWorkQueue[];
        localStorage.removeItem('followupdates');
        this.todayDate = new Date().getDate();
        //this.showWorkQueueData();
        this.showFollowup();
        this.dropDown = HomeGridDropdown;
        this.selectedColumn = this.dropDown[0].id;
        this.sortDefault();
    }

    private sortDefault() {
        this.column = 'Date_Added';
        this.direction = this.isDesc == false ? 1 : -1;
    }

    private showWorkQueueData() {
        this.homeSvc.getWorkqueue(this.user.user_id).subscribe((WorkQueue: IWorkQueue[]) => {
            if (Array.isArray(WorkQueue['Result']) == true) {
                if (WorkQueue['Result'] != null && WorkQueue['Result'].length > 0) {
                    var Attribute_Failed = WorkQueue['Result'].filter(obj => obj['Attribute_Failed'] == 'ndc_status');
                    Attribute_Failed.forEach(ndc_Status => {
                        ndc_Status["Attribute_Failed"] = "status";
                    });
                    this.workqueuedata = WorkQueue['Result'];
                    this.workqueuedataFilter = WorkQueue['Result'];

                    var orderByWq = _.orderBy(this.workqueuedata, ['Date_Added', 'workqueue_id', 'Impacted_Element'], ['desc']);
                    var grouped = _.groupBy(orderByWq, function (obj) {
                        return obj.Impacted_Element;
                    });

                    //====================================
                    /* var props = Object.getOwnPropertyNames(grouped);
                     var workQueueList = [];
                     props.forEach(prop => {
                         workQueueList.push(grouped[prop][0]);
                         //var other = workQueueList.filter(obj=>obj['Impacted_Element']==grouped[prop][0]['Impacted_Element']);
                         //other[0]['others']=[];
                         if (grouped[prop].length > 1) {
                             grouped[prop].slice(1).forEach(rec => {
                                 rec['Impacted_Element']=null;
                                 rec['is_routed']=false;
                                 rec['is_gt_30']=false;
                                 other[0]['others'].push(
                                 workQueueList.push(
                                     {
                                         "Impacted_Element": null,
                                         "Work_Queue_Type": rec['Work_Queue_Type'],
                                         "recRule_Failure": rec['recRule_Failure'],
                                         "recAttribute_Failed": rec['recAttribute_Failed'],
                                         "Status": rec['Status'],
                                         "Date_Added": rec['Date_Added'],
                                         "is_routed": false,
                                         "is_gt_30":false
                                     }
                                 )
                                 );
                             });
                         }
                     })*/

                    //====================================
                }
                else {
                    toastr.error("Work Queue Does Not Exists");
                }
            }
        })
    }

    private showFollowup() {
        this.homeSvc.getCalendarFollowUp(this.user.user_id).subscribe((calendarData: IFOLLOWUP_MASTER[]) => {
            this.calendarFollowUp = calendarData['result'];
            this.calendarFollowUpFilter = this.calendarFollowUp.filter(obj => ((new Date(obj.follow_up_date)).getDate() == (new Date()).getDate()) && ((new Date(obj.follow_up_date)).getMonth() == (new Date()).getMonth()));
            // this.calendarFollowUp = calendarData['result'];
            var followupdates = [];
            calendarData['result'].forEach(function (obj) {
                followupdates.push(obj.follow_up_date);
                // $(".datepicker td:contains(" + new Date(obj.follow_up_date).getDate() + ")").addClass('danger');
            });
            localStorage.setItem('followupdates', JSON.stringify(followupdates));
            //this.ShowHiglightedFolloupDates();

        });
    }

    private ShowHiglightedFolloupDatesonSelect(date) {

        var followupdates = [];
        this.calendarFollowUp.forEach(function (obj) {
            followupdates.push(obj.follow_up_date);
            // $(".datepicker td:contains(" + new Date(obj.follow_up_date).getDate() + ")").addClass('danger');
        });

        let selMonth = ((date).getMonth());
        let selDate = (date).getDate();
        let selYear = (date).getFullYear();
        // if((new Date()).getMonth()>selMonth){

        //     $(".datepicker-days td.old.day").filter(function () {
        //         return $(this).text() != "";
        //     }).removeClass('success').removeClass('danger').removeClass('old.day').addClass('day');
        //     $(".datepicker-days td.day").filter(function () {
        //         return $(this).text() == "";
        //     }).removeClass('success').removeClass('danger').removeClass('day').addClass('new.day');           
        // }
        // else if((new Date()).getMonth()<selMonth){{
        //     $(".datepicker-days td.old.day").filter(function () {
        //         return $(this).text() != "";
        //     }).removeClass('td.old.day').removeClass('danger');
        //     $(".datepicker-days td.old.day").filter(function () {
        //         return $(this).text() !="";
        //     }).removeClass('success').removeClass('danger');
        //     $(".datepicker-days td.old.day").filter(function () {
        //         return $(this).text() == "";
        //     }).removeClass('success').removeClass('danger');
        // }

        var followupdates = [];
        this.calendarFollowUp.forEach(function (obj) {
            followupdates.push(obj.follow_up_date);
            // $(".datepicker td:contains(" + new Date(obj.follow_up_date).getDate() + ")").addClass('danger');
        });
        if (followupdates != null && followupdates.length > 0) {
            // var followupDates = JSON.parse(localStorage.getItem('followupdates'));           
            followupdates.forEach(function (followupdate) {

                //old years
                // if (((new Date(followupdate)).getFullYear() < (new Date()).getFullYear())) {
                //     $(".datepicker-days td.old.day").filter(function () {
                //         return $(this).text() == (new Date(followupdate)).getDate();
                //     }).removeClass('success').addClass('danger');
                // }
                //same year but month older
                if (((new Date(followupdate)).getMonth() < (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() == (new Date()).getFullYear())) {
                    //$(".datepicker td:eq(" + (new Date(followupdate)).getDate() + ")").removeClass('success');                           
                    if((new Date()).getMonth()>selMonth){
                        $(".datepicker td.day").filter(function () {
                            return $(this).text() == (new Date(followupdate)).getDate();
                        }).removeClass('success').addClass('danger');
                    }
                    else if((new Date()).getMonth()== selMonth){                        
                    $(".datepicker td.old.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('success').addClass('danger');
                }
                } else if (((new Date(followupdate)).getDate() >= (new Date()).getDate()) && ((new Date(followupdate)).getMonth() == (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() == (new Date()).getFullYear())) {
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('danger');  
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('today').addClass('success');  
                    $(".datepicker td.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('danger').addClass('success');
                } else if (((new Date(followupdate)).getDate() < (new Date()).getDate()) && ((new Date(followupdate)).getMonth() == (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() == (new Date()).getFullYear())) {
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('danger');  
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('today').addClass('success');  
                    $(".datepicker td.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('success').addClass('danger');
                } else if (((new Date(followupdate)).getMonth() > (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() == (new Date()).getFullYear())) {
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('danger');  
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('today').addClass('success');  
                    if((new Date()).getMonth()<selMonth){
                    $(".datepicker td.new.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('danger').addClass('success');
                }else if((new Date()).getMonth()==selMonth){
                }

                }

                //new years greater than current year
                // if (((new Date(followupdate)).getFullYear() > (new Date()).getFullYear())) {
                //     $(".datepicker-days td.new.day").filter(function () {
                //         return $(this).text() == (new Date(followupdate)).getDate();
                //     }).removeClass('danger').addClass('success');
                // }
            });
        }

       
    }
   



    private ShowHiglightedFolloupDates() {

        var followupdates = [];
        this.calendarFollowUp.forEach(function (obj) {
            followupdates.push(obj.follow_up_date);
            // $(".datepicker td:contains(" + new Date(obj.follow_up_date).getDate() + ")").addClass('danger');
        });
        if (followupdates != null && followupdates.length > 0) {
            // var followupDates = JSON.parse(localStorage.getItem('followupdates'));
            $(".datepicker-days td.old.day").removeClass('success').removeClass('danger');
            $(".datepicker-days td.day").removeClass('success').removeClass('danger');
            $(".datepicker-days td.new.day").removeClass('success').removeClass('danger');
            followupdates.forEach(function (followupdate) {

                //old years
                if (((new Date(followupdate)).getFullYear() < (new Date()).getFullYear())) {
                    $(".datepicker-days td.old.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('success').addClass('danger');
                }
                //same year but month older
                if (((new Date(followupdate)).getMonth() < (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() == (new Date()).getFullYear())) {
                    //$(".datepicker td:eq(" + (new Date(followupdate)).getDate() + ")").removeClass('success');                           

                    $(".datepicker td.old.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('success').addClass('danger');
                } else if (((new Date(followupdate)).getDate() >= (new Date()).getDate()) && ((new Date(followupdate)).getMonth() == (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() == (new Date()).getFullYear())) {
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('danger');  
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('today').addClass('success');  
                    $(".datepicker td.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('danger').addClass('success');
                } else if (((new Date(followupdate)).getDate() < (new Date()).getDate()) && ((new Date(followupdate)).getMonth() == (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() == (new Date()).getFullYear())) {
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('danger');  
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('today').addClass('success');  
                    $(".datepicker td.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('success').addClass('danger');
                } else if (((new Date(followupdate)).getMonth() > (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() == (new Date()).getFullYear())) {
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('danger');  
                    //$(".datepicker td:contains(" + (new Date(followupdate)).getDate() + ")").removeClass('today').addClass('success');  
                    $(".datepicker td.new.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('danger').addClass('success');
                }

                //new years greater than current year
                if (((new Date(followupdate)).getFullYear() > (new Date()).getFullYear())) {
                    $(".datepicker-days td.new.day").filter(function () {
                        return $(this).text() == (new Date(followupdate)).getDate();
                    }).removeClass('danger').addClass('success');
                }
            });
        }
    }

    ngAfterViewInit() {

        var self = this;
        $('.date').datepicker({
            format: 'mm/dd/yyyy',
            startDate: new Date(),
            autoclose: true
        }).on('change', (event: any) => {
            this.newfollowup.follow_up_date = event.target.value;
        });
        
        var datesArray=['7/12/2017','11/26/2017']

        $('.inlineDate div').datepicker({
            // multidate: false,
            // multidateSeparator: ",",
            // todayHighlight: true,
            format: 'mm/dd/yyyy',
           
            onSelect: function(date, datepicker) {
                // if (datepicker.id == "beginDate") {
                //     $('#endDate').datepicker("setDate", date)
                // }   
                alert(123);                   
            },
            onChangeMonthYear: function(year, month, datepicker) {
                // if (datepicker.id == "beginDate") {
                //     var newDate = new Date();
                //     newDate.setMonth(month -1);
                //     newDate.setFullYear(year);
                //     $('#endDate').datepicker("setDate", newDate);
                // }   
                alert(12);                 
            },
            beforeShowDay: function (date) {
				var theday = (date.getMonth()+1) +'/'+ 
							date.getDate()+ '/' + 
							date.getFullYear();
					return [true,$.inArray(theday, datesArray) >=0?"specialDate":''];
				},
            // beforeShowDay: function (date) {
            //     var count=1;
            //     if (localStorage.getItem('followupdates') != null && localStorage.getItem('followupdates') != '') {
            //         var followupDates = JSON.parse(localStorage.getItem('followupdates'));                    
            //         if(followupDates!=null && followupDates.length>0){
            //             if(count==1){
            //             self.ShowHiglightedFolloupDates();
            //             count++;
            //             }
            //         // followupDates.forEach(function (followupdate) {
            //         //     if (new Date(followupdate).getMonth() == date.getMonth() && new Date(followupdate).getDate() == date.getDate()) {
            //         //         if (date.getDate() < (new Date()).getDate()) {
            //         //             $(".datepicker td:contains(" + date.getDate() + ")").addClass('danger');
            //         //         } else if (date.getDate() >= (new Date()).getDate()) {
            //         //             $(".datepicker td:contains(" + date.getDate() + ")").removeClass('today').addClass('success');
            //         //         }
            //         //     }
            //         // })
            //         }
            //     }
            // }.bind(this), //.apply(this),    

        }).on("changeDate", function (e) {
            this.seldate = new Date(e.date)
            self.calendarFollowUpFilter = self.calendarFollowUp.filter(obj => ((new Date(obj.follow_up_date)).getDate() == (new Date(this.seldate)).getDate()) && ((new Date(obj.follow_up_date)).getMonth() == (new Date(this.seldate)).getMonth()));
            //self.ShowHiglightedFolloupDatesonSelect((e.date)); 
            //self.ShowHiglightedFolloupDates();

            // if (localStorage.getItem('followupdates') != null && localStorage.getItem('followupdates') != '') {
            //     var followupDates = JSON.parse(localStorage.getItem('followupdates'));
            //     //var selMonthDate = new Date((e.date).getFullYear(), (e.date).getMonth(), 1);
            //     var selMonth = ((e.date).getMonth());
            //     var selDate = (e.date).getDate();
            //     var selYear = (e.date).getFullYear();
            //     followupDates.forEach(function (followupdate) {
            //         if (new Date(followupdate).getMonth() == selMonth && new Date(followupdate).getFullYear() == selYear) {
            //             if (((new Date(followupdate)).getDate() < (new Date()).getDate()) && ((new Date(followupdate)).getMonth() <= (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() <= (new Date()).getFullYear())) {
            //                 $(".datepicker-days td.old day").filter(function () {
            //                     return $(this).text() == (new Date(followupdate)).getDate();
            //                 }).addClass('danger');
            //                 $(".datepicker-days td").filter(function () {
            //                     return $(this).text() == (new Date(followupdate)).getDate();
            //                 }).addClass('danger');
            //             } else if (((new Date(followupdate)).getDate() >= (new Date()).getDate()) && ((new Date(followupdate)).getMonth() >= (new Date()).getMonth()) && ((new Date(followupdate)).getFullYear() <= (new Date()).getFullYear())) {
            //                 $(".datepicker-days td.new day").filter(function () {
            //                     return $(this).text() == (new Date(followupdate)).getDate();
            //                 }).removeClass('today').addClass('success');
            //                 $(".datepicker-days td.old day").filter(function () {
            //                     return $(this).text() == (new Date(followupdate)).getDate();
            //                 }).removeClass('today').addClass('success');
            //             }
            //             //old years
            //             if (((new Date(followupdate)).getFullYear() < (new Date()).getFullYear())) {
            //                 $(".datepicker-days td.old.day").filter(function () {
            //                     return $(this).text() == (new Date(followupdate)).getDate();
            //                 }).addClass('danger');
            //             }
            //             //new years
            //             if (((new Date(followupdate)).getFullYear() > (new Date()).getFullYear())) {
            //                 $(".datepicker-days td.new.day").filter(function () {
            //                     return $(this).text() == (new Date(followupdate)).getDate();
            //                 }).removeClass('today').addClass('success');
            //             }

            //         }
            //     })
            //     //selMonthDate.setDate(selMonthDate.getDate() + 1);

            //}

        });  //.bind(this));   
        
        $('.datepicker-days th.prev').click(function(){
           // alert(1);
           // self.ShowHiglightedFolloupDates();
        });

        $('.datepicker-days th.next').click(function(){
            // alert(1);
             //self.ShowHiglightedFolloupDates();
         });

    }



    private sort() {
        this.column = this.selectedColumn.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    private filterStatus($event, statusValue) {
        if ($event.target.checked) {
            this.statusFilter = statusValue;
        }
        this.filterWorkQueueData();
    }

    private filterWorkQueueData(): void {
        if (this.workqueuedataFilter.length > 0) {
            if (this.ImpactedElement || this.WorkQueueType || this.RuleFailure || this.AttributeFailed || this.Status || this.statusFilter) {
                this.workqueuedataFilter = this.workqueuedata.filter
                    (item =>
                        ((this.RuleFailure) ? (item.Rule_Failure.toLowerCase().indexOf(this.RuleFailure.toLowerCase()) > -1) : 1)
                        &&
                        ((this.ImpactedElement) ? (item.Impacted_Element.indexOf(this.ImpactedElement.toLowerCase()) > -1) : 1)
                        &&
                        ((this.WorkQueueType) ? (item.Work_Queue_Type.toLowerCase().indexOf(this.WorkQueueType.toLowerCase()) > -1) : 1)
                        &&
                        ((this.AttributeFailed) ? (item.Attribute_Failed.toLowerCase().indexOf(this.AttributeFailed.toLowerCase()) > -1) : 1)
                        &&
                        ((this.Status) ? (item.Status.toLowerCase().indexOf(this.Status.toLowerCase()) > -1) : 1)
                        &&
                        ((this.statusFilter) ? (item.Status.toLowerCase().indexOf(this.statusFilter.toLowerCase()) > -1) : 1)
                    );
            }
            else {
                this.workqueuedataFilter = this.workqueuedata;
            }
        }
    }

    private clear() {
        this.ImpactedElement = "";
        this.RuleFailure = "";
        this.AttributeFailed = "";
        this.Status = "";
        this.WorkQueueType = "";
        this.grFilter = false;
        this.workqueuedataFilter = this.workqueuedata;
    }

    private parseDate(dateString: string): Date {
        if (dateString) {
            return new Date(dateString);
        } else {
            return null;
        }
    }

    private saveFollowUp() {
        if (this.newfollowup.ndc && this.newfollowup.hcpc && this.newfollowup.drug_name &&
            this.newfollowup.follow_up_date && this.newfollowup.notes) {
            this.newfollowup.user_id = this.user.user_id;
            // newfollowup.is_ndc_followup=false;
            this.homeSvc.saveFollowUp(this.newfollowup).subscribe(
                resdata => this.showFollowup()
            );
        }
        else {
            toastr.warning("None of the field should be empty while adding follow-up");
        }
        this.newfollowup.ndc = "";
        this.newfollowup.hcpc = "";
        this.newfollowup.drug_name = "";
        this.newfollowup.follow_up_date = undefined;
        this.newfollowup.notes = "";
    }

    private deleteFollowUpTask(followUpId) {
        if (confirm("Are you sure you want to delete this Task?")) {
            this.homeSvc.deleteFollowUp(followUpId).subscribe(
                resdata => this.showFollowup()
            );
        }
        else {
            return false;
        }
    }

    private lockWorkQueueByUser(row: any) {
        if (this.user == null || this.user == undefined) {
            this._router.navigate(['/login']);
            return;
        }
        this.selectedCode = row['Impacted_Element'];
        this.selectedRuleFailure = row['Rule_Failure'];
        var users = JSON.parse(localStorage.getItem('currentUser'));
        let objData = { "ndc_hcpc_id": row["Impacted_Element"], "user_id": users.user_id };
        var wq = this.workqueuedata.filter(obj => obj.Impacted_Element === this.selectedCode && obj.Rule_Failure === this.selectedRuleFailure)[0];
        if (wq.Rule_Failure == "NDC" || wq.Rule_Failure == "Conversion/Translation") {
            var isNdcAllow = this.user['role'].filter(mnu => mnu.name == 'NDC_RESOLUTION');
            if (isNdcAllow.length != 0) {
                this.dataSvc.lockWorkQueueNdc(objData).subscribe((res: any) => {
                    if (res == "Already locked by user") {
                        this.modalLockExist.show();
                    }
                    else {
                        this._router.navigate(['/NDC_RESOLUTION', { workqueue: this.selectedCode, id: row["Impacted_Element"], uId: users.user_id }]);
                    }
                    localStorage.removeItem('followupdates');
                });
            } else {
                toastr.info("Access Denied for NDC Resolution Page");
            }
        } else if (wq.Rule_Failure == "HCPC") {
            var isHcpcAllow = this.user['role'].filter(mnu => mnu.name == 'HCPC_NDC');
            if (isHcpcAllow.length != 0) {
                if (row["rc_id"] != null) {
                    this._router.navigate(['/HCPC_NDC', { rc_id: row["rc_id"], hcpc_code: row['hcpc_code'] }]);
                    return;
                }
                else {
                    toastr.info("Combination not found");
                    this._router.navigate(['/HCPC_NDC']);
                    return;
                }
            } else {
                toastr.info("Access Denied for HCPC NDC crosswalk");
                return;
            }
        }
        else if (wq.Rule_Failure == "Part B vs Part D") {
            var isBvsDAllow = this.user['role'].filter(mnu => mnu.name == 'PART_BVSD_CROSSWALK');
            if (isBvsDAllow.length != 0) {
                if (row["bvsdId"] != null && row["bvsdName"] != null) {
                    this._router.navigate(['/PART_BVSD_CROSSWALK', { bvsdId: row["bvsdId"], bvsdName: row['bvsdName'] }]);
                    return;
                }
                else {
                    toastr.info("Combination not found");
                    this._router.navigate(['/PART_BVSD_CROSSWALK']);
                    return;
                }
            }
            else {
                toastr.info("Access Denied for Part B vs D");
                return;
            }
        }
    }
    private viewNdcFailure() {
        var isNdcAllow = this.user['role'].filter(mnu => mnu.name == 'NDC_RESOLUTION');
        if (isNdcAllow.length > 0) {
            var code = this.selectedCode;
            var wq = this.workqueuedata.filter(obj => obj.Impacted_Element === code && obj.Rule_Failure === this.selectedRuleFailure)[0];

            if (wq.Rule_Failure == "NDC") {
                this._router.navigate(['/ndcfailureReadOnly', code]);
            }
            else if (wq.Rule_Failure == "Conversion/Translation") {
                this._router.navigate(['/ndcfailureReadOnly', code]);
            }
            localStorage.removeItem('followupdates');
        }
    }

    private deleteFollowUp(followUpId): void {
        this.homeSvc.deleteFollowUp(followUpId).subscribe(
            resdata => this.showFollowup()
        );
    }

    private showFunctionMenu() {
        if (this.user != null) {
            this.user['role'].forEach((menu: any) => {
                switch (menu.name) {
                    case "REIMB_CODE":
                        this.functionsMenu.push({ "seq": 1, "menu": "Code Maintenance", "name": menu.name });
                        break;
                    case "NDC_RESOLUTION":
                        this.functionsMenu.push({ "seq": 2, "menu": "NDC Maintenance", "name": menu.name });
                        break;
                    case "CONVERSION_TRANSLATION":
                        this.functionsMenu.push({ "seq": 3, "menu": "Conversion/Translation Screen", "name": menu.name });
                        break;
                    case "PART_BVSD_CROSSWALK":
                        break;
                    case "HCPC_NDC":
                        break;
                    case "INFO_CODE_CROSSWALK":
                        break;
                    case "DDC10_CROSSWALK":
                        break;
                    case "FILE_UPLOAD":
                        break;
                    case "INFO_CODES":
                        break;
                    case "PRICE_SPECS":
                        break;
                    case "NARRATIVES":
                        break;
                }
            });

            this.functionsMenu.sort(function (val1, val2) {
                if (val1.seq < val2.seq) {
                    return -1;
                } else if (val1.seq > val2.seq) {
                    return 1;
                } else {
                    return 0;
                }
            });
        } else {
            if (this.user == undefined) {
                this._router.navigate(['/login']);
                return;
            }
        }
    }

    private openPopover(src, pmId: number) {
        var self = this;
        var source = src.srcElement;
        var pm = PopoverConfig.filter(obj => obj.id == pmId);
        var ndclink = document.getElementById(source.id);
        $(source)['popover']({
            placement: 'top',
            html: true,
            //trigger: 'click',
            title: pm[0].title + ' <a href="#" class="close" data-dismiss="alert" onclick="$(&quot;#' + source.id + '&quot;).popover(&quot;destroy&quot;);">&times;</a>',
            content: `<div class="  ">
          <div class="media-body">
            <h4 class="media-heading">` + pm[0].message + `</h4>
            <p class="text-center">
              <button id="btnYes`+ source.id + `" class="btn btn-danger" onclick="$(&quot;#` + source.id + `&quot;).popover(&quot;destroy&quot;);">` + pm[0].YesCaption + `</button>
              <button id="btnNo`+ source.id + `" class="btn btn-default" onclick="$(&quot;#` + source.id + `&quot;).popover(&quot;destroy&quot;);"> ` + pm[0].NoCaption + `</button>
            </p>
          </div>
        </div>`
        });

        $('#' + source.id)['popover']('show');
        var btnYes = document.getElementById("btnYes" + source.id);
        if (btnYes != null) {
            eval('btnYes.addEventListener("click", () => self.' + pm[0].YesMethod + '(' + source.id + '))');
        }
    }

}