/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, Directive } from '@angular/core';
import { Router } from '@angular/router';

import { HomeService } from "./../../services/home.service";
import { DataService } from '../../services/data.service';
import { IUSER_MASTER, IWorkQueue, IFOLLOWUP_MASTER } from '../../shared/interfaces/entities.interface';
import { GlobalService } from '../..//services/shared/global.service';
import { PopoverConfig } from '../../services/shared/config.const';
import { DropDown } from '../../shared/common';

import { ModalComponent } from '../shared/modalpopup.component';

declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'app-home',
    templateUrl: './home.component.html?v=${new Date().getTime()}',
    providers: [HomeService, DataService]
})

export class HomeComponent implements AfterViewInit {
    user: IUSER_MASTER;
    isDesc: boolean = false;
    column: string = 'Date_Added';
    direction: number;
    selectedColumn: Object = {};
    dropDown: DropDown[];
    workqueuedata: IWorkQueue[];
    workqueuedataFilter: IWorkQueue[];
    calendarFollowUp: IFOLLOWUP_MASTER[];
    calendarFollowUpFilter: IFOLLOWUP_MASTER[];
    el: HTMLElement;
    todayDate: any;
    differenceInDate: any;
    differenceInMonth: any;
    differenceInYear: any;
    ImpactedElement: string;
    WorkQueueType: string;
    stage_id: number;
    RuleFailure: string;
    AttributeFailed: string;
    Status: string;
    statusFilter: string;
    switchResult: any;
    newfollowup: IFOLLOWUP_MASTER = {} as IFOLLOWUP_MASTER;
    selectedCode: string;
    selectedRuleFailure: string;
    seldate: Date;

    @ViewChild('taskDate') div: ElementRef;
    @ViewChild('modalLockExist') modalLockExist: ModalComponent;

    constructor(
        private homeSvc: HomeService<IWorkQueue>,
        private dataSvc: DataService,
        private router: Router,
        private elementRef: ElementRef,
        private _globalSev: GlobalService) {
        this.user = JSON.parse(localStorage.getItem('currentUser'));
        toastr.options = { positionClass: 'toast-top-center' };
        if (this.user == undefined) {
            this.router.navigate(['/login']);
            return;
        }
        this._globalSev.showNavBar(true, this.user.user_name);
    }

    ngOnInit() {
        if (this.user == undefined) {
            this.router.navigate(['/login']);
            return;
        }

        this.workqueuedataFilter = [] as IWorkQueue[];
        localStorage.removeItem('followupdates');
        this.todayDate = new Date().getDate();
        this.showWorkQueueData();
        this.showFollowup();
        this.dataSvc.getDropdownData().subscribe((res: any) => {
            this.dropDown = res.HomeGridDropdown;
            this.selectedColumn = this.dropDown[0].id;
        });
        this.sortDefault();
        // this._globalSev.getLoggedUser(this.user.user_name);

    }

    private sortDefault() {
        this.column = 'Date_Added';
        this.direction = this.isDesc == false ? 1 : -1;
    }
    
    private showWorkQueueData() {
        this.homeSvc.getWorkqueue(this.user.user_id).subscribe((WorkQueue: IWorkQueue[]) => {
            if (Array.isArray(WorkQueue['Result']) == true) {
                if (WorkQueue['Result'] != null && WorkQueue['Result'].length > 0) {
                    var Attribute_Failed = WorkQueue['Result'].filter(obj => obj['Attribute_Failed'] == 'ndc_status');
                    Attribute_Failed.forEach(ndc_Status => {
                        ndc_Status["Attribute_Failed"] = "status";
                    });
                    this.workqueuedata = WorkQueue['Result'];
                    this.workqueuedataFilter = WorkQueue['Result'];
                }
            }
            else {
                toastr.error("Record Not found");
            }
        });
    }

    private showFollowup() {
        this.homeSvc.getCalendarFollowUp(this.user.user_id).subscribe((calendarData: IFOLLOWUP_MASTER[]) => {
            this.calendarFollowUp = calendarData['result'];
            this.calendarFollowUpFilter = this.calendarFollowUp.filter(obj => ((new Date(obj.follow_up_date)).getDate() == (new Date()).getDate()) && ((new Date(obj.follow_up_date)).getMonth() == (new Date()).getMonth()));
            this.calendarFollowUp = calendarData['result'];
            var followupdates = [];
            calendarData['result'].forEach(function (obj) {
                followupdates.push(obj.follow_up_date);
                // $(".datepicker td:contains(" + new Date(obj.follow_up_date).getDate() + ")").addClass('danger');
            });
            localStorage.setItem('followupdates', JSON.stringify(followupdates));
        });
    }

    ngAfterViewInit() {
        $('.date').datepicker({
            format: 'mm/dd/yyyy',
            startDate: new Date(),
            autoclose: true
        }).on('change', (event: any) => {
            this.newfollowup.follow_up_date = event.target.value;
        });

        $('.inlineDate div').datepicker({
            multidate: false,
            multidateSeparator: ",",
            todayHighlight: true,
            beforeShowDay: function (date) {
                if (localStorage.getItem('followupdates') != null && localStorage.getItem('followupdates') != '') {
                    var followupDates = JSON.parse(localStorage.getItem('followupdates'));
                    followupDates.forEach(function (followupdate) {
                        if (new Date(followupdate).getMonth() == date.getMonth() && new Date(followupdate).getDate() == date.getDate()) {
                            if (date.getDate() < (new Date()).getDate()) {
                                $(".datepicker td:contains(" + date.getDate() + ")").addClass('danger');
                            } else if (date.getDate() >= (new Date()).getDate()) {
                                $(".datepicker td:contains(" + date.getDate() + ")").removeClass('today').addClass('success');
                            }
                        }
                    })
                }
            }.bind(this), //.apply(this),               
        }).on("changeDate", function (e) {
            this.seldate = new Date(e.date)
            if (localStorage.getItem('followupdates') != null && localStorage.getItem('followupdates') != '') {
                var followupDates = JSON.parse(localStorage.getItem('followupdates'));
                var selMonthDate = new Date((e.date).getFullYear(), (e.date).getMonth(), 1);
                while (selMonthDate.getMonth() === (e.date).getMonth()) {
                    followupDates.forEach(function (followupdate) {
                        if (new Date(followupdate).getMonth() == e.date.getMonth() && new Date(followupdate).getDate() == selMonthDate.getDate()) {
                            if (selMonthDate.getDate() < (new Date()).getDate()) {
                                $(".datepicker td:contains(" + selMonthDate.getDate() + ")").addClass('danger');
                            } else if (selMonthDate.getDate() >= (new Date()).getDate()) {
                                $(".datepicker td:contains(" + selMonthDate.getDate() + ")").removeClass('today').addClass('success');
                            }
                        }
                    })
                    selMonthDate.setDate(selMonthDate.getDate() + 1);
                }
            }
            this.calendarFollowUpFilter = this.calendarFollowUp.filter(obj => ((new Date(obj.follow_up_date)).getDate() == (new Date(this.seldate)).getDate()) && ((new Date(obj.follow_up_date)).getMonth() == (new Date(this.seldate)).getMonth()));
        }.bind(this));
    }

    private sort() {
        this.column = this.selectedColumn.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    private filterStatus($event, statusValue) {
        if ($event.target.checked) {
            this.statusFilter = statusValue;
        }
        this.filterWorkQueueData();
    }

    private filterWorkQueueData(): void {
        if (this.workqueuedataFilter.length > 0) {
            if (this.ImpactedElement || this.WorkQueueType || this.RuleFailure || this.AttributeFailed || this.Status || this.statusFilter) {
                this.workqueuedataFilter = this.workqueuedata.filter
                    (item =>
                        ((this.RuleFailure) ? (item.Rule_Failure.toLowerCase().indexOf(this.RuleFailure.toLowerCase()) > -1) : 1)
                        &&
                        ((this.ImpactedElement) ? (item.Impacted_Element.indexOf(this.ImpactedElement.toLowerCase()) > -1) : 1)
                        &&
                        ((this.WorkQueueType) ? (item.Work_Queue_Type.toLowerCase().indexOf(this.WorkQueueType.toLowerCase()) > -1) : 1)
                        &&
                        ((this.AttributeFailed) ? (item.Attribute_Failed.toLowerCase().indexOf(this.AttributeFailed.toLowerCase()) > -1) : 1)
                        &&
                        ((this.Status) ? (item.Status.toLowerCase().indexOf(this.Status.toLowerCase()) > -1) : 1)
                        &&
                        ((this.statusFilter) ? (item.Status.toLowerCase().indexOf(this.statusFilter.toLowerCase()) > -1) : 1)
                    );
            }
            else {
                this.workqueuedataFilter = this.workqueuedata;
            }
        }
    }

    private clear() {
        this.ImpactedElement = "";
        this.RuleFailure = "";
        this.AttributeFailed = "";
        this.Status = "";
        this.workqueuedataFilter = this.workqueuedata;
    }

    private parseDate(dateString: string): Date {
        if (dateString) {
            return new Date(dateString);
        } else {
            return null;
        }
    }

    private saveFollowUp() {
        if (this.newfollowup.ndc && this.newfollowup.hcpc && this.newfollowup.drug_name &&
            this.newfollowup.follow_up_date && this.newfollowup.notes) {
            this.newfollowup.user_id = this.user.user_id;
            // newfollowup.is_ndc_followup=false;
            this.homeSvc.saveFollowUp(this.newfollowup).subscribe(
                resdata => this.showFollowup()
            );
        }
        else {
            toastr.warning("None of the field should be empty while adding follow-up");
        }
        this.newfollowup.ndc = "";
        this.newfollowup.hcpc = "";
        this.newfollowup.drug_name = "";
        this.newfollowup.follow_up_date = undefined;
        this.newfollowup.notes = "";
    }

    private deleteFollowUpTask(followUpId) {
        if (confirm("Are you sure you want to delete this Task?")) {
            this.homeSvc.deleteFollowUp(followUpId).subscribe(
                resdata => this.showFollowup()
            );
        }
        else {
            return false;
        }
    }

    private lockWorkQueueByUser(row: any) {
        this.selectedCode = row['Impacted_Element'];
        this.selectedRuleFailure = row['Rule_Failure'];
        var users = JSON.parse(localStorage.getItem('currentUser'));
        localStorage.setItem('userId', users.user_id);
        let objData = { "ndc_hcpc_id": row["Impacted_Element"], "queue_id": row["Impacted queue_id"], "user_id": users.user_id };
        var wq = this.workqueuedata.filter(obj => obj.Impacted_Element === this.selectedCode && obj.Rule_Failure === this.selectedRuleFailure)[0];

        if (wq.Rule_Failure == "HCPC") {
            if (row["rc_id"] != null) {
                this.router.navigate(['/hcpcndccrosswalk', { rc_id: row["rc_id"], hcpc_code: row['hcpc_code'] }]);
                return;
            }
            else {
                toastr.info("HCPC not found");
                return;
            }
        }

        // if (wq.Rule_Failure == "Part B vs Part D") {
        //     if (row["bvsdId"] != null) {
        //         this.router.navigate(['/hcpcndccrosswalk', { bvsdId: row["bvsdId"], bvsdName: row['bvsdName'] }]);
        //         return;
        //     }
        //     else {
        //         toastr.info("Part B vs Part D data not found");
        //         return;
        //     }
        // }

        this.dataSvc.lockWorkQueueNdc(objData).subscribe((res: any) => {
            var result = res.Result;
            if (result == "Already locked by user") {
                this.modalLockExist.show();
            }
            else {
                this._globalSev.queue_id = wq["Impacted queue_id"];
                this._globalSev.stage_id = wq["stage_id"];

                if (wq.Rule_Failure == "NDC") {
                    this.router.navigate(['/ndcresolution', { workqueue: this.selectedCode, id: row["Impacted_Element"], qId: row["Impacted queue_id"], uId: users.user_id }]);
                }
                else if ("Conversion/Translation") {
                    this.router.navigate(['/ndcresolution', { workqueue: this.selectedCode, id: row["Impacted_Element"], qId: row["Impacted queue_id"], uId: users.user_id }]);
                }
                localStorage.removeItem('followupdates');
            }
        })
    }
    private viewNdcFailure() {
        var code = this.selectedCode;
        var wq = this.workqueuedata.filter(obj => obj.Impacted_Element === code && obj.Rule_Failure === this.selectedRuleFailure)[0];
        if (wq.Work_Queue_Type == "Initial") {
            this._globalSev.stage_id = 1;
        }

        if (wq.Rule_Failure == "NDC") {
            this.router.navigate(['/ndcfailureReadOnly', code]);
        }
        else if (wq.Rule_Failure == "HCPC") {
            this.router.navigate(['/hcpcndccrosswalk']);
        } else if (wq.Rule_Failure == "Conversion/Translation") {
            this.router.navigate(['/ndcfailureReadOnly', code]);
        }
        localStorage.removeItem('followupdates');
    }

    private openPopover(src, pmId: number) {
        var self = this;
        var source = src.srcElement;
        var pm = PopoverConfig.filter(obj => obj.id == pmId);
        var ndclink = document.getElementById(source.id);
        $(source)['popover']({
            placement: 'top',
            html: true,
            //trigger: 'click',
            title: pm[0].title + ' <a href="#" class="close" data-dismiss="alert" onclick="$(&quot;#' + source.id + '&quot;).popover(&quot;destroy&quot;);">&times;</a>',
            content: `<div class="media">
          <div class="media-body">
            <h4 class="media-heading">` + pm[0].message + `</h4>
            <p class="text-center">
              <button id="btnYes`+ source.id + `" class="btn btn-danger" onclick="$(&quot;#` + source.id + `&quot;).popover(&quot;destroy&quot;);">` + pm[0].YesCaption + `</button>
              <button id="btnNo`+ source.id + `" class="btn btn-default" onclick="$(&quot;#` + source.id + `&quot;).popover(&quot;destroy&quot;);"> ` + pm[0].NoCaption + `</button>
            </p>
          </div>
        </div>`
        });

        $('#' + source.id)['popover']('show');
        var btnYes = document.getElementById("btnYes" + source.id);
        if (btnYes != null) {
            eval('btnYes.addEventListener("click", () => self.' + pm[0].YesMethod + '(' + source.id + '))');
        }
    }

    private showViewMode(id): void {
        alert('show' + id);
    }

    private deleteFollowUp(followUpId): void {
        this.homeSvc.deleteFollowUp(followUpId).subscribe(
            resdata => this.showFollowup()
        );
    }
}