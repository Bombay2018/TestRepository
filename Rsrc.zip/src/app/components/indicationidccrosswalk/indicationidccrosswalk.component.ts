import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { GlobalService } from "./../../services/shared/global.service";
import { ConfigService } from '../../services/shared/config.service';
import { ModalComponent } from '../shared/modalpopup.component';
import { DropDown } from '../../shared/common';
import { IUSER_MASTER, IDDC10_ATTRIBUTES, IDDC10_SAVE_ATTRIBUTES, ICD_CODE_MASTER } from '../../shared/interfaces/entities.interface';
import { DDC10Service } from '../../services/DDC10.service';
import { DataService } from '../../services/data.service';

declare var $: any;

@Component({
  selector: 'app-indicationidccrosswalk',
  templateUrl: './indicationidccrosswalk.component.html?v=${new Date().getTime()}',
  providers: [DDC10Service, DataService]
})

export class IndicationIdcCrosswalkComponent implements OnInit {

  user: IUSER_MASTER;
  ddc10Details: IDDC10_ATTRIBUTES[];
  ddc10DeleteDetails: IDDC10_ATTRIBUTES[];
  ddc10MasterDetails: IDDC10_ATTRIBUTES[];
  ddc10FilterDetails: IDDC10_ATTRIBUTES[] = [] as IDDC10_ATTRIBUTES[];;
  ddc10SaveDetails: IDDC10_SAVE_ATTRIBUTES[] = [] as IDDC10_SAVE_ATTRIBUTES[];
  icdCodeDataList: ICD_CODE_MASTER[];
  icdCodeFilterDataList: ICD_CODE_MASTER[]= [] as ICD_CODE_MASTER[];
  ddc10IcdCodeList: any;
  dropDown: DropDown[];
  columnSelected: any;
  hcpc_code: string = "";
  icd10: string = "";
  selected_rc_id: Number = 0;
  selected_hcpc_code: string;
  short_title: string = "";
  effective_date: string = "";
  searchParam = {
    IndicationSearch: "",
    ICD10Search: "",
    ICD10DescSearch: "",
  };
  popSearchParam = {
    ICD10Code: "",
    ICD10Desc: ""
  }
  column: string = 'hcpc_code';
  direction: number;
  isDesc: boolean = false;
  searchICD10Result: any;
  isAssocitedICDCode: Boolean = false;

  preSearch: any = [{ "searchOn": 1, "data": [] }, { "searchOn": 2, "data": [] }, { "searchOn": 3, "data": [] }];
  newData: any[] = new Array();
  indicationCodeList: any[] = new Array();
  ICD10CodeList: any[] = new Array();
  ICD10CodeDescList: any[] = new Array();


  @ViewChild('modalSearchICD10List') modalSearchICD10List: ModalComponent;
  @ViewChild('modalDelete') modalDelete: ModalComponent;
  @ViewChild('modalAddHCPCIDC') modalAddHCPCIDC: ModalComponent;


  constructor(private _globalSev: GlobalService,
    private _DDC10svc: DDC10Service<IDDC10_ATTRIBUTES>,
    private _router: Router,
    private _datasvc: DataService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {

    this.setSortDropdown();
  }

  AfterViewInit() {
    //this.ngAfterViewInit();
  }

  setNewEffDate() {

    $('#effectiveDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {

      this.effective_date = event.target.value;
      // var eff_date= this.ddc10FilterDetails.filter(item=>item['hcpc_icd10_xwalk_id']==id);
      // if(eff_date.length>0){
      //   eff_date[0]['effective_date'] = event.target.value;
      // }
    });
  }

  setEffDate(id) {
    $('#' + id).datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {

      var eff_date = this.ddc10FilterDetails.filter(item => item['icd10'] == id);
      if (eff_date.length > 0) {
        eff_date[0]['effective_date'] = event.target.value;
      }
    });
  }

  setTermDate(id) {

    $('#' + id + '_1').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      var term_date = this.ddc10FilterDetails.filter(item => item['icd10'] == id);
      if (term_date.length > 0) {
        term_date[0]['term_date'] = event.target.value;
      }
    });

  }

  setSortDropdown() {
    this._datasvc.getDropdownData().subscribe((res: any) => {
      this.dropDown = res.DDC10SortDropdown;
      this.columnSelected = this.dropDown[0].id;
    });

  }

  sort() {
    
    this.column = this.columnSelected.toString();
    this.direction = this.isDesc == false ? 1 : -1;
  }

  filterDD10Data(): void {
    if (this.ddc10Details && (this.hcpc_code || this.icd10 || this.short_title)) {
      this.ddc10FilterDetails = this.ddc10Details.filter(item =>
        // ((this.hcpc_code) ? (item.hcpc_code.toLowerCase().indexOf(this.hcpc_code.toLowerCase()) > -1) : 1)
        // &&
        ((this.icd10) ? (item.icd10.toLowerCase().indexOf(this.icd10.toLowerCase()) > -1) : 1)
        &&
        ((this.short_title) ? (item.short_title.toLowerCase().indexOf(this.short_title.toLowerCase()) > -1) : 1)
      );
    }
    else {
      this.ddc10FilterDetails = this.ddc10MasterDetails;
    }
  }

  clear() {

    this.hcpc_code = "";
    this.icd10 = "";
    this.short_title = "";
    this.ddc10FilterDetails = this.ddc10MasterDetails;
  }


  //Handle search autocomplete Fields
  searchPramChange(event, searchOn: number) {
    var self = this;
    var eventLen = event.length;
    this.newData = new Array(); 
    
    self.indicationCodeList=[];
    self.ICD10CodeList=[];
    self.ICD10CodeDescList=[];   

    if (eventLen ==0) { 
            
      return;
    }
    var getExists = this.preSearch.filter(obj => (obj.searchOn == searchOn));
    var existingData = getExists[0].data || [];

    if (existingData.length > 0) {
      switch (searchOn) {
        case 1:
          getExists[0].data.forEach(function (val) {
            if (val.length > 0) {
              var isExit = val.hcpc_code.startsWith(event)
              if (isExit == true) {
                self.newData.push(val);
              }
            }
          });
          break;
        case 2:
        case 3:
          getExists[0].data.forEach(function (val) {
            if (val.length > 0) {
              var isExit = val.startsWith(event)
              if (isExit == true) {
                self.newData.push(val);
              }
            }
          });
          break;
      }
    }
    switch (searchOn) {
      case 1: //indicationCode ==hcpc code

        self.selected_rc_id = 0;
        if (this.newData.length > 0) {
          self.indicationCodeList = this.newData;
        } else {
          this._datasvc.getDistinctHCPC(event).subscribe((indicationCodeList) => {
            if (indicationCodeList['Result'] != null && indicationCodeList['Result'].length > 0) {
              indicationCodeList.Result.forEach(function (hcpc) {
                getExists[0].data.push(hcpc);
                self.indicationCodeList.push(hcpc);
              });
            } else {
              self.indicationCodeList = new Array();
            }
          });
        }
        break;
      case 2: //ICD 10 Code
        if (this.newData.length > 0) {
          self.ICD10CodeList = this.newData;
        } else {
          this._DDC10svc.getDistinctICDCodes(event).subscribe((ICD10CodeList) => {
            if (ICD10CodeList['Result'] != null && ICD10CodeList['Result'].length > 0) {
              // var arrHcpcDesc = hcpcDescList.map(function (prop) { return prop["hcpc_desc"]; })
              ICD10CodeList.Result.forEach(function (ICD10Code) {
                getExists[0].data.push(ICD10Code.icd10);
                self.ICD10CodeList.push(ICD10Code.icd10);
              });
            } else {
              self.ICD10CodeList = new Array();
            }
          });
        }
        break;
      case 3: //ICD 10 Desc
        if (this.newData.length > 0) {
          self.ICD10CodeDescList = this.newData;
        } else {
          this._DDC10svc.getDistinctICDCodesDesc(event).subscribe((ICD10CodeDescList) => {
            if (ICD10CodeDescList['Result'] != null && ICD10CodeDescList['Result'].length > 0) {
              ICD10CodeDescList.Result.forEach(function (ICD10Desc) {
                getExists[0].data.push(ICD10Desc.short_title);
                self.ICD10CodeDescList.push(ICD10Desc.short_title);
              });
            } else {
              self.ICD10CodeDescList = new Array();
            }
          });
        }
        break;
    }
  }


  selectedPram(value: any, selectedFor: number) {
    switch (selectedFor) {
      case 1: //hcpc_code
        this.searchParam.IndicationSearch = value.hcpc_code;
        this.selected_hcpc_code = value.hcpc_code;
        this.selected_rc_id = value.rc_id;
        this.indicationCodeList = new Array();
        this.clearGridControls();
        break;
      case 2: //ICD 10
        this.searchParam.ICD10Search = value;
        this.ICD10CodeList = new Array();
        this.clearGridControls();
        break;
      case 3: //ICD 10 Desc
        this.searchParam.ICD10DescSearch = value;
        this.ICD10CodeDescList = new Array();
        this.clearGridControls();
        break;
    }
  }

  //End of Search AutoComplete Fields

  //Perform Search

  search() {

    this.clearGridControls();
    if (this.searchParam.IndicationSearch == "" && this.searchParam.ICD10Search == "" && this.searchParam.ICD10DescSearch == "") {
      toastr.error('Enter atleast one search criteria');
      return;
    }

    //{
    this._DDC10svc.getDDC10Search(this.searchParam.IndicationSearch, this.searchParam.ICD10Search, this.searchParam.ICD10DescSearch).subscribe((res: any) => {
      this.searchICD10Result = res;
      if (this.searchICD10Result != null && this.searchICD10Result.length > 0) {
        this.modalSearchICD10List.show();
      }
      else {
        toastr.error("Record not found.Either there is no mapping ICD code or serach creteria is not correct.\nPlease perform search using valid search criteria");
      }
    });
    //this.clearAntocompleate();
    //}
  }

  getDDC10DetailsByDDCCode(searchData) {
    this._DDC10svc.getDDC10DetailsByDDCCode(searchData.rc_id).subscribe((ddc10Details: IDDC10_ATTRIBUTES[]) => {

      this.ddc10Details = ddc10Details;
      //this.ddc10MasterDetails=ddc10Details;
      this.ddc10MasterDetails = JSON.parse(JSON.stringify(ddc10Details));
      this.ddc10FilterDetails = ddc10Details;
      this.selected_rc_id = searchData.rc_id;
      this.selected_hcpc_code = searchData.hcpc_code;
      this.ddc10FilterDetails.forEach(function (ddc10Detail) {
        ddc10Detail['showDetails'] = false;
        ddc10Detail['icdHistory'] = [];
      });
      //this.ngAfterViewInit();

    });


    this.modalSearchICD10List.hide();
  }

  getChildICDList(data) {
    var self = this;
    
    if (data.icdHistory.length == 0) {
      this._DDC10svc.getChildICDDetails(data.icd10).subscribe((ddc10IcdCodeListDetails: IDDC10_ATTRIBUTES[]) => {
        var xyz = this.ddc10FilterDetails.filter(item => item.icd10_id == data.icd10_id && item.hcpc_icd10_xwalk_id == data.hcpc_icd10_xwalk_id);
        xyz.forEach(function (abc) {
          abc['icdHistory'] = ddc10IcdCodeListDetails.slice(1);
        });
      });




      // this.ddc10IcdCodeList = ddc10IcdCodeListDetails;


    }
    data.showDetails = !data.showDetails;

    this.modalSearchICD10List.hide();
  }

  checkDeleteForHcpc_ICD() {

    if (this.ddc10FilterDetails != undefined && this.ddc10FilterDetails.length > 0) {
      var selectedICD = this.ddc10FilterDetails.filter(obj => obj['chkstatus'] == true);
      if (selectedICD.length != 0) {
        this.modalDelete.show();
      } else if (this.ddc10FilterDetails != undefined) {
        toastr.error("Please select a ICD code");
        return;
      }

    } else {
      toastr.error("There is no ICD available to delete.Please search ICD first.");
      return;
    }


  }




  private deleteHcpc_ICD() {

    this.ddc10Details = this.ddc10FilterDetails.filter(obj => obj['chkstatus'] == true);
    this.ddc10DeleteDetails= this.ddc10FilterDetails.filter(obj => obj['chkstatus'] == true);
    this.ddc10FilterDetails = this.ddc10FilterDetails.filter(obj => obj['chkstatus'] != true);

    if (this.ddc10Details != null && this.ddc10Details.length > 0) {
      for (let i = 0; i < this.ddc10Details.length; i++) {

        // var index=this.ddc10SaveDetails.findIndex(item=>item.hcpc_icd10_xwalk_id==this.ddc10Details[i]['hcpc_icd10_xwalk_id']);
        // if(index>0){
        //   this.ddc10SaveDetails[index]['status']=-1;
        // }
        // else{

        var obj = {
          "hcpc_icd10_xwalk_id": this.ddc10Details[i]['hcpc_icd10_xwalk_id'],
          "hcpc_code": this.selected_hcpc_code,
          "icd10": this.ddc10Details[i]['icd10'],
          "icd10_id": this.ddc10Details[i]['icd10_id'],
          "short_title": this.ddc10Details[i]['short_title'],
          "effective_date": this.ddc10Details[i]['effective_date'],
          "term_date": this.ddc10Details[i]['term_date'],
          // "date": (new Date()).toDateString(),
          // "user": this.user.user_name,
          "status": -1  //deleted
        }


        this.ddc10SaveDetails.push(obj);
      }
      //}
    }

  }
  AddHCPCICD() {
    var self = this;
    if (self.selected_rc_id == 0) {
      toastr.error("To add new icd code against indication code,\nplease choose and select indication code to setup indication code and perform search first.");
      return;
    }

    if(this.ddc10FilterDetails !=null && this.ddc10FilterDetails.length==0){

    this._DDC10svc.getDDC10DetailsByDDCCode(self.selected_rc_id).subscribe((ddc10Details: IDDC10_ATTRIBUTES[]) => {

      if (ddc10Details != null && ddc10Details.length > 0) {
        this.ddc10Details = ddc10Details;
        //this.ddc10MasterDetails=ddc10Details;
        this.ddc10MasterDetails = JSON.parse(JSON.stringify(ddc10Details));
        this.ddc10FilterDetails = ddc10Details;
        // this.selected_rc_id=this.selected_rc_id;
        this.selected_hcpc_code = ddc10Details[0].hcpc_code;
        this.ddc10FilterDetails.forEach(function (ddc10Detail) {
          ddc10Detail['showDetails'] = false;
          ddc10Detail['icdHistory'] = [];
        });


        this.icdCodeDataList = [];
        this.effective_date = "";
        this.modalAddHCPCIDC.show();
      }
      else {


        this.icdCodeDataList = [];
        this.effective_date = "";
        this.modalAddHCPCIDC.show();
      }

    });
  }
  else {
   
    this.icdCodeDataList = [];
    this.effective_date = "";
    this.modalAddHCPCIDC.show();
  }


  }

  searchAddHCPCICD() {

    if (this.popSearchParam.ICD10Code.trim() == '' && this.popSearchParam.ICD10Desc.trim() == '') {
      toastr.error("Please enter valid ICD Code or ICD Description");
      return;
    } else {
      this.populateICDCodeList();
    }

  }

  populateICDCodeList() {
    this._DDC10svc.getDistinctICDCodesDetails(this.popSearchParam.ICD10Code.trim(), this.popSearchParam.ICD10Desc.trim()).subscribe((icdCodeList: ICD_CODE_MASTER[]) => {
      this.icdCodeDataList = icdCodeList;
      if (this.icdCodeDataList == null || this.icdCodeDataList.length == 0) {
        toastr.warning("No ICD code found.Please try with another search critetia ");
        this.popSearchParam.ICD10Code = "";
        this.popSearchParam.ICD10Desc = "";
        return;
      }
      else {
        var index;
        this.icdCodeFilterDataList = this.icdCodeDataList;

        this.icdCodeFilterDataList.forEach(function (icd10MasterCodeList) {
          icd10MasterCodeList['is_selected'] = false;
        });


        // only show those info code which are not present at right side
        if(this.ddc10FilterDetails !=null  && this.ddc10FilterDetails.length>0){
        var result = this.icdCodeFilterDataList.filter(item => this.ddc10FilterDetails.some(infocode => infocode.icd10.trim() == item.icd10.trim()));
        var count = this.icdCodeFilterDataList.length;
        for (var i = 0; i < count; i++) {
          index = this.icdCodeFilterDataList.indexOf(result[i]);
          if (index > -1) {
            this.icdCodeFilterDataList.splice(index, 1);
            this.isAssocitedICDCode = true;
          }
        }
      }
        if(this.ddc10DeleteDetails !=null  && this.ddc10DeleteDetails.length>0){
        var resultDelete = this.icdCodeFilterDataList.filter(item =>this.ddc10DeleteDetails.some(infocode => infocode.icd10.trim() == item.icd10.trim()));
        var count = this.icdCodeFilterDataList.length;
        for (var i = 0; i < count; i++) {
          index = this.icdCodeFilterDataList.indexOf(resultDelete[i]);
          if (index > -1) {
            this.icdCodeFilterDataList.splice(index, 1);
            this.isAssocitedICDCode = true;
          }
        }
      }

     

        if (this.icdCodeFilterDataList != null && this.icdCodeFilterDataList.length == 0)
          toastr.error("Infocode searched already associted with   " + this.selected_hcpc_code + "    .Please search new Info code");

      }
    });

  }

  clearPopup() {
    this.icdCodeFilterDataList = [];
    this.popSearchParam.ICD10Code = "";
    this.popSearchParam.ICD10Desc = "";
    this.modalAddHCPCIDC.hide();
  }

  RemoveICDCode() {

    var index;
    var isItemSelected: boolean = false;
    var hcpcICDCodeRemoveFromLeft = [];

    if (this.ddc10FilterDetails == null) {
      toastr.error("Please select atleast 1 info code to remove");
      return;
    }

    for (let i = 0; i < this.ddc10FilterDetails.length; i++) {
      if (this.ddc10FilterDetails[i]['is_selected'] == true) {
        var icdCodeMovedDataLtoR = {
          icd10_id: 0,
          icd10: "",
          short_title: "",
          is_selected: false
        };
        var hcpcIcdCodeMovedDataLtoR = {
          hcpc_icd10_xwalk_id: 0,
          hcpc_code: "",
          icd10: "",
          icd10_id: 0,
          short_title: "",
          effective_date: "",
          term_date: "",
          status: 0
        };
        icdCodeMovedDataLtoR.icd10 = this.ddc10FilterDetails[i].icd10;
        icdCodeMovedDataLtoR.icd10_id = this.ddc10FilterDetails[i].icd10_id;
        icdCodeMovedDataLtoR.short_title = this.ddc10FilterDetails[i].short_title;

        var result1 = this.ddc10SaveDetails.filter(item => item.icd10 == this.ddc10FilterDetails[i].icd10);
        if (result1 != null && result1.length > 0) {
          var count = this.ddc10SaveDetails.length;
          for (var m = 0; m < count; m++) {
            index = this.ddc10SaveDetails.indexOf(result1[m]);
            if (index > -1) {
              this.ddc10SaveDetails.splice(index, 1);
            }
          }
        }
        else {
          hcpcIcdCodeMovedDataLtoR.hcpc_icd10_xwalk_id = this.ddc10FilterDetails[i].hcpc_icd10_xwalk_id;
          hcpcIcdCodeMovedDataLtoR.icd10_id = this.ddc10FilterDetails[i].icd10_id;
          //hcpcIcdCodeMovedDataLtoR. = this.hcpcInfoCodeDataList[i].info_code_id;
          //hcpcIcdCodeMovedDataLtoR.info_code = this.hcpcInfoCodeDataList[i].info_code;
          hcpcIcdCodeMovedDataLtoR.status = -1;
          //Add deleted item to save list
          this.ddc10SaveDetails.push(hcpcIcdCodeMovedDataLtoR);

        }
        //Add icd code to right list
        this.icdCodeFilterDataList.push(icdCodeMovedDataLtoR);
        
        //Remove item from left list
        hcpcICDCodeRemoveFromLeft.push(this.ddc10FilterDetails[i]);

        isItemSelected = true;
      }

    }
    if (!isItemSelected) {
      toastr.error("Please select atleast 1 info code to remove");
      return;
    }

    var result = this.ddc10FilterDetails.filter(item => hcpcICDCodeRemoveFromLeft.some(icdCode => icdCode.icd10 == item.icd10));
    var count = this.ddc10FilterDetails.length;
    for (var i = 0; i < count; i++) {
      index = this.ddc10FilterDetails.indexOf(result[i]);
      if (index > -1) {
        this.ddc10FilterDetails.splice(index, 1);
      }
    }

  }

  AddICDCode() {

    var isItemSelected: boolean = false;
    var self = this;
    var index;
    var icdCodeMovedDataRtoL = [];

    if (this.icdCodeFilterDataList == null) {

      var selectedICDList = self.icdCodeFilterDataList.filter(item => (item['is_selected'] == true));
      if (selectedICDList.length == 0) {
        toastr.error("Please select atleast 1 ICD code to add");
        return;
      }
    } else {

      if (self.effective_date == "") {
        toastr.error("Please set effective date before addine new ICD code");
        return;
      }
      for (let i = 0; i < this.icdCodeFilterDataList.length; i++) {
        if (this.icdCodeFilterDataList[i]['is_selected'] == true) {
          icdCodeMovedDataRtoL.push(this.icdCodeFilterDataList[i]);
          var hcpcIcdCodeMovedDataRtoL = {
            hcpc_icd10_xwalk_id: 0,
            hcpc_code: "",
            icd10: "",
            icd10_id: 0,
            short_title: "",
            effective_date: this.effective_date,
            term_date: "",
            status: 0
          };

          //Check if data already in savestructure or otherwise push

          var result1 = this.ddc10SaveDetails.filter(item => item.icd10 == this.icdCodeFilterDataList[i].icd10);
          if (result1 != null && result1.length > 0) {
            for (var j = 0; j < this.ddc10SaveDetails.length; j++) {
              index = this.ddc10SaveDetails.indexOf(result1[j]);
              if (index > -1) {
                this.ddc10SaveDetails.splice(index, 1);

                this.ddc10FilterDetails.push(result1[j]);
              }
            }

          }
          else {

            hcpcIcdCodeMovedDataRtoL.hcpc_icd10_xwalk_id = 0;
            hcpcIcdCodeMovedDataRtoL.hcpc_code = this.selected_hcpc_code;
            hcpcIcdCodeMovedDataRtoL.icd10 = this.icdCodeFilterDataList[i].icd10;
            hcpcIcdCodeMovedDataRtoL.icd10_id = this.icdCodeFilterDataList[i].icd10_id;
            hcpcIcdCodeMovedDataRtoL.short_title = this.icdCodeFilterDataList[i].short_title;
            this.ddc10FilterDetails.push(hcpcIcdCodeMovedDataRtoL);
          }

          this.ddc10SaveDetails.push(hcpcIcdCodeMovedDataRtoL);
          isItemSelected = true;

        }
      }
    }

    if (!isItemSelected) {
      toastr.error("Please select atleast 1 info code to add");
      return;
    }

    //Remove ICD code from right side and show it n left side
    var result = this.icdCodeFilterDataList.filter(item => icdCodeMovedDataRtoL.some(icd => icd.icd10 == item.icd10));
    var count = this.icdCodeFilterDataList.length;
    for (var j = 0; j < count; j++) {
      index = this.icdCodeFilterDataList.indexOf(result[j]);
      if (index > -1) {
        this.icdCodeFilterDataList.splice(index, 1);
      }
    }

  }





  save() {
    // this.infoCodeData.push({
    //   "info_code_id": this.info_code_id,
    //   "info_code": this.info_code,
    //   "note_description": this.info_note
    // });

    // this._DDC10svc.hcpcICDCodeMappinSave(this.hcpcIcdCodeMappingDetails).subscribe((infoCode: IINFO_CODE_MASTER[]) => {
    //   var saveResp = infoCode['Result'];
    //   if (saveResp == "success") {
    //     toastr.success("Info code saved successfully");
    //     //
    //     this.cancelInfoCode();
    //   }
    //   else {
    //     toastr.error("Error while saving Info Code");
    //   }
    // });

    // var hcpcICDCode = [];
    // this.hcpcInfoCodeSaveData.forEach(function (obj) {
    //   var objHcpcInfoCode = {
    //     info_code_id: 0,
    //     hcpc_info_code_map_id: 0,
    //     status: -2
    //   }
    //   objHcpcInfoCode.hcpc_info_code_map_id = obj.hcpc_info_code_map_id;
    //   objHcpcInfoCode.info_code_id = obj.info_code_id;
    //   objHcpcInfoCode.status = obj.status;
    //   //hcpcInfoCode.push(objHcpcInfoCode);

    // });

    // this.ddc10SaveDetails=

    //Preapare Save Data
    var self = this;
    this.ddc10MasterDetails.forEach(function (hcpc_icd_item) {
      var matchedhcpcicdList = self.ddc10FilterDetails.filter(item => (item['hcpc_icd10_xwalk_id'] == hcpc_icd_item['hcpc_icd10_xwalk_id']) && ((item['effective_date'] != hcpc_icd_item['effective_date']) || (item['term_date'] != hcpc_icd_item['term_date'])));
      if (matchedhcpcicdList.length > 0) {
        var obj = {
          "hcpc_icd10_xwalk_id": matchedhcpcicdList[0]['hcpc_icd10_xwalk_id'],
          "hcpc_code": self.selected_hcpc_code,
          "icd10": matchedhcpcicdList[0]['icd10'],
          "icd10_id": matchedhcpcicdList[0]['icd10_id'],
          "short_title": matchedhcpcicdList[0]['short_title'],
          "effective_date": matchedhcpcicdList[0]['effective_date'],
          "term_date": matchedhcpcicdList[0]['term_date'],
          // "date": (new Date()).toDateString(),
          // "user": this.user.user_name,
          "status": 1  //update,edit
        }
        self.ddc10SaveDetails.push(obj);
      }

    });

    if (this.ddc10SaveDetails.length == 0) {
      toastr.info("There is no changes to save");
      return;
    }
    var savedata = {
      "user_id":this.user.user_id,
      "rc_id": this.selected_rc_id,
      "icd_code_list": this.ddc10SaveDetails
    }

    this._DDC10svc.HcpcIcdCodeMappingSave(savedata).subscribe((response: any) => {
      var saveResp = response['Result'];
      if (saveResp == "success") {
        toastr.success("Hcpc -ICD mapping saved successfully");
        this.clearControls();
      }
      else {
        toastr.error("Error while saving Hcpc -ICD mapping");
        this.clearControls();
      }
      this.clearControls();
    });

  }

  clearControls() {
    this.ddc10MasterDetails = [];
    this.ddc10FilterDetails = [];
    this.ddc10SaveDetails = [];
    this.ddc10Details = [];
    this.searchParam.ICD10DescSearch = "";
    this.searchParam.ICD10Search = "";
    this.searchParam.IndicationSearch = "";
    this.selected_hcpc_code = "";
    this.selected_rc_id = 0;
    this.ddc10DeleteDetails=[];

  }


  clearGridControls() {
    this.ddc10MasterDetails = [];
    this.ddc10FilterDetails = [];
    this.ddc10SaveDetails = [];
    this.ddc10Details = [];
    //this.selected_hcpc_code="";
    //this.selected_rc_id=0;

  }

  cancel() {
    this._router.navigate(['home']);

  }


}

