import { Component, OnInit } from '@angular/core';

import { IUSER_MASTER } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-indicationminmaxcrosswalk',
  templateUrl: './indicationminmaxcrosswalk.component.html?v=${new Date().getTime()}'
})
export class IndicationMinMaxCrosswalkComponent implements OnInit {

  user: IUSER_MASTER;
  searchPram = {
    ndc: ""
  }

  preSearch: any = [{ "searchOn": 1, "data": [] }, { "searchOn": 2, "data": [] }, { "searchOn": 3, "data": [] }];
  newData: any[] = new Array();

  ndcList: any[] = new Array();

  constructor(private _globalSev: GlobalService, private _datasvc: DataService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {
  }

  selectedPram(value: string, selectedFor: number) {
    switch (selectedFor) {
      case 1: //Indication
        // this.searchPram.hcpc_code = value;
        // this.hcpcList = new Array();
        break;
      case 2: //Generic name

        break;
      case 3: //ndc
        this.searchPram.ndc = value;
        this.ndcList = new Array();
        break;
      case 4: //Brand name
        this.searchPram.ndc = value;
        this.ndcList = new Array();
        break;
    }
  }

  searchPramChange(event, searchOn: number) {
    var self = this;
    var eventLen = event.length;
    this.newData = new Array();

    if (eventLen < 3) {
      return;
    }
    var getExists = this.preSearch.filter(obj => (obj.searchOn == searchOn));
    var existingData = getExists[0].data || [];

    if (existingData.length > 0) {
      getExists[0].data.forEach(function (val) {
        if (val.length > 0) {
          var isExit = val.startsWith(event)
          if (isExit == true) {
            self.newData.push(val);
          }
        }
      });
    }
    switch (searchOn) {
      case 1: //B vs D Part Name
        if (this.newData.length > 0) {
          // self.hcpcList = this.newData;
        } else {
          // this._reimbMasterSvc.getHCPCByCode(event).subscribe((hcpcList) => {
          //   if (hcpcList != null && hcpcList.length > 0) {
          //     hcpcList.forEach(function (hcpc) {
          //       //existingData.push(hcpc.hcpc_code);
          //       getExists[0].data.push(hcpc.hcpc_code);
          //       self.hcpcList.push(hcpc.hcpc_code);
          //     });
          //   } else {
          //     self.hcpcList = new Array();
          //   }
          // });
        }
        break;
      case 2: //Generic Name
        if (this.newData.length > 0) {
          //self.hcpcDescList = this.newData;
        } else {
          // this._reimbMasterSvc.getHCPCByDescription(event).subscribe((hcpcDescList) => {
          //   if (hcpcDescList != null && hcpcDescList.length > 0) {
          //     // var arrHcpcDesc = hcpcDescList.map(function (prop) { return prop["hcpc_desc"]; })
          //     hcpcDescList.forEach(function (desc) {
          //       getExists[0].data.push(desc.hcpc_desc);
          //       self.hcpcDescList.push(desc.hcpc_desc);
          //     });
          //   } else {
          //     self.hcpcDescList = new Array();
          //   }
          // });
        }
        break;
      case 3: //ndc
        if (this.newData.length > 0) {
          self.ndcList = this.newData;
        } else {
          this._datasvc.getDistinctNDC(event).subscribe((ndcList) => {
            if (ndcList['Result'] != null && ndcList['Result'].length > 0) {
              ndcList.Result.forEach(function (ndc) {
                getExists[0].data.push(ndc.ndc);
                self.ndcList.push(ndc.ndc);
              });
            } else {
              self.ndcList = new Array();
            }
          });
        }
        break;
      // case 4: //brand name
      // if (this.newData.length > 0) {
      //   self.ndcList = this.newData;
      // } else {
      //   this._datasvc.getDistinctNDC(event).subscribe((ndcList) => {
      //     if (ndcList['Result'] != null && ndcList['Result'].length > 0) {
      //       ndcList.Result.forEach(function (ndc) {
      //         getExists[0].data.push(ndc.ndc);
      //         self.ndcList.push(ndc.ndc);
      //       });
      //     } else {
      //       self.ndcList = new Array();
      //     }
      //   });
      // }
      // break;
    }
  }


}
