import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { GlobalService } from "./../../services/shared/global.service";
import { InfoCodeService } from '../../services/infocode.service';
import { IUSER_MASTER, IBD_SPEC, IINFO_CODE_MASTER } from '../../shared/interfaces/entities.interface';
import { ModalComponent } from '../shared/modalpopup.component';

@Component({
  selector: 'app-infocodemaster',
  templateUrl: './infocodemaster.component.html?v=${new Date().getTime()}',
  providers: [InfoCodeService]
})
export class InfoCodeMasterComponent {
  user: IUSER_MASTER;
  infoCodeData: IINFO_CODE_MASTER[];
  infoCodeFilterData: IINFO_CODE_MASTER[];
  infoCodeSearch: string = "";
  info_code_id: number = 0;
  info_code: string = "";
  info_note: string = "";
  isNewInfoCode: boolean = false;

  preSearch: any[] = new Array();
  infoCodeList: any[] = new Array();

  constructor(private _infoCodeSev: InfoCodeService<IINFO_CODE_MASTER>,
    private _globalSev: GlobalService,
    private _router: Router) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  searchPramChange(event) {
    var self = this;
    self.infoCodeList = new Array();
    var eventLen = event.length;
    if (eventLen == 0) {
      //self.infoCodeList = new Array();
      return;
    } //else if (eventLen < 3) {
    //return;
    //}

    this.preSearch.forEach(function (val) {
      var isExit = val['info_code'].startsWith(event)
      if (isExit == true) {
        self.infoCodeList.push(val);
      }
    });

    if (self.infoCodeList.length == 0) {
      this._infoCodeSev.getInfoCode(event).subscribe((infoCode: IINFO_CODE_MASTER[]) => {
        this.infoCodeData = infoCode;
        if (infoCode != null && infoCode.length > 0) {
          infoCode.forEach(function (info_code) {
            var info = self.preSearch.filter(ic => ic.info_code == info_code.info_code && ic.info_code_id == info_code.info_code_id);
            if (info.length == 0) {
              self.preSearch.push(info_code);
              self.infoCodeList.push(info_code);
            }
          });
        } else {
          self.infoCodeList = new Array();
          this.info_code_id = 0;
          this.info_code = '';
          this.info_note = '';
        }
      });
    }
    //self.infoCodeList = self.infoCodeList.filter((info, index, me) => me.findIndex((t) => { return t.info_code === info.info_code && t.info_code_id === info.info_code_id; }) === index);
    //self.preSearch = self.preSearch.filter((info, index, me) => me.findIndex((t) => { return t.info_code === info.info_code && t.info_code_id === info.info_code_id; }) === index);    
  }
  selectedPram(value: string) {

    this.infoCodeSearch = value;
    this.infoCodeList = new Array();
    this.info_code = "";
    this.info_note = "";
  }
  onBlur(val) {
    this.infoCodeSearch = "";
    this.infoCodeList = [];

  }
  search() {
    if (this.infoCodeSearch.trim() == '') {
      toastr.error("Please enter Info Code");
      return;
    } else {
      this.exactInfoCodeMatch();
    }
  }

  exactInfoCodeMatch() {
    // var self = this;
    // if (this.infoCodeSearch.trim() == "") {
    //   toastr.info("Record Not Found");
    //   return;
    // }
    // else{
    // if (self.infoCodeList.length == 1) {
    this.getInfoByCode(this.infoCodeSearch.trim());
    //   self.infoCodeList = [];
    //}
  }

  getInfoByCode(code: string): any {
    this._infoCodeSev.getInfoByCode(code).subscribe((infoCode: IINFO_CODE_MASTER[]) => {

      if (infoCode != null) {
        this.infoCodeFilterData = infoCode;
        this.infoCodeList = new Array();
        this.info_code_id = infoCode['info_code_id'];
        this.info_code = infoCode['info_code'];
        this.info_note = infoCode['note_description'];
      }
      else {
        toastr.info("Record Not Found");
      }
    });
  }

  addInfoCode() {
    this.info_code_id = 0;
    this.info_code = this.infoCodeSearch;
    this.info_note = "";
    this.isNewInfoCode = true;
  }

  saveInfoCode() {
    this.infoCodeData = [];
    this.infoCodeSearch = "";
    if (this.info_code == "" || this.info_note == "") {
      toastr.warning("None of the field should be empty");
      return;
    }
    if(this.info_code.indexOf("*")!=-1)
    {
      toastr.warning("Special character not allowed in info code.");
      return;
    }
    if (this.isNewInfoCode) {
      this._infoCodeSev.getInfoCode(this.info_code).subscribe((infoCodes: IINFO_CODE_MASTER[]) => {
        var matchedInfoCodes = infoCodes.filter(infoCode => infoCode.info_code === this.info_code);
        if (matchedInfoCodes.length != 0) {
          toastr.error("Entered info Code already exist! Please try wth new code");
          return;
        } else {
          this.save();
        }
      })
    } else {
      this.save();
    }
  }
  save() {
    this.infoCodeData.push({
      "info_code_id": this.info_code_id,
      "info_code": this.info_code,
      "note_description": this.info_note
    });

    this._infoCodeSev.saveInfoCode(this.infoCodeData).subscribe((infoCode: IINFO_CODE_MASTER[]) => {
      var saveResp = infoCode['Result'];
      if (saveResp == "success") {
        toastr.success("Info code saved successfully");
        this.cancelInfoCode();
      }
      else {
        toastr.error("Error while saving Info Code");
      }
    });
  }

  cancelInfoCode() {
    this.infoCodeSearch = "";
    this.infoCodeFilterData = [];
    this.infoCodeData = [];
    this.info_code_id = 0;
    this.info_code = "";
    this.info_note = "";
    this.isNewInfoCode = false;
  }
  navigateToHome() {
    this._router.navigate(['home']);
  }

  private uniqueInfoCode() {
    this.infoCodeList = this.infoCodeList.filter((info, index, self) => self.findIndex((t) => { return t.info_code === info.info_code && t.info_code_id === info.info_code_id; }) === index);
    this.preSearch = this.preSearch.filter((info, index, self) => self.findIndex((t) => { return t.info_code === info.info_code && t.info_code_id === info.info_code_id; }) === index);
  }

}

