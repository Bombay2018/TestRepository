import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';

import { IUSER_MASTER, INARRATIVE_MASTER, INARRATIVE_SAVE_MASTER } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";
import { NarrativeService } from '../../services/narrative.service';
import { ModalComponent } from '../shared/modalpopup.component';
import { DropDown } from '../../shared/common';
import { ConfigService } from '../../services/shared/config.service';

declare var $: any;

@Component({
  selector: 'app-narrativemaster',
  templateUrl: './narrativemaster.component.html?v=${new Date().getTime()}',
  providers: [NarrativeService]
})
export class NarrativeMasterComponent implements OnInit, AfterViewInit {

  user: IUSER_MASTER;
  narrativeType: DropDown[];
  searchResultList: INARRATIVE_MASTER[];
  searchResultDetails: INARRATIVE_MASTER = {} as INARRATIVE_MASTER;
  narrativeData: INARRATIVE_SAVE_MASTER = {} as INARRATIVE_SAVE_MASTER;
  narrativeMasterDetails = {
    narrativesNameSearch: "",
    narrativesTypeSearch: ""
  };
  narrative_file_exists:string;
  isSearch: boolean = false;
  isSaveDisable: boolean = true;
  preSearch: any[] = new Array();
  narrativeNameList: any[] = new Array();
  requestData: FormData = new FormData();

  uploadFile: any;
  _baseUrl : string;

  @ViewChild('modalNarrativeList') modalNarrativeList: ModalComponent;

  constructor(private narrativeService: NarrativeService<INARRATIVE_MASTER>,
    private _globalSev: GlobalService,
    private _router: Router,
    private configSvc: ConfigService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
    this._baseUrl = configSvc.getApiURI();
  }

  ngOnInit() {
    this.narrativeService.getDistinctNarrativesType().subscribe((res: any) => {
      this.narrativeType = res['Result'];
      this.narrativeMasterDetails.narrativesTypeSearch = "0";
      this.searchResultDetails.narratives_type = "0";
      this.searchResultDetails.bvsd_status = "0";
      this.searchResultDetails['filename'] = null;
      this.narrative_file_exists="";
      //this.columnSelected = this.sortDropDown[0].id;
    });
  }

  ngAfterViewInit() {
    $('#narrativeDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    })
    .on('change', (event: any) => {
      this.searchResultDetails['eff_date'] = event.target.value;
    });
  }

  searchPramChange(event) {

    var self = this;
    self.narrativeNameList = new Array();
    if (event.length == 0) {     
      return;
    }    
    
    this.preSearch.forEach(function (val) {
      var isExit = val['bvsd_name'].startsWith(event)
      if (isExit == true) {
        self.narrativeNameList.push(val);
      }
    });

    if (self.narrativeNameList.length == 0) {
      this.narrativeService.getDistinctNarrativesName(event).subscribe((narrativeName: INARRATIVE_MASTER[]) => {
       //this.narrativeNameList = narrativeName['Result'];
        if (narrativeName['Result'] != null && narrativeName['Result'].length > 0) {
          narrativeName['Result'].forEach(function (narrative_name) {
            var bvsd_name = self.preSearch.filter(nm => nm.bvsd_name == narrative_name.bvsd_name && nm.part_bvsd_id==narrative_name.part_bvsd_id);
            if (bvsd_name.length == 0) {
              self.preSearch.push(narrative_name);
              self.narrativeNameList.push(narrative_name);
            }
          });
        } else {
          self.narrativeNameList = new Array();         
        }
      });
    }
  }

  selectedPram(value: string) {

    this.narrativeMasterDetails.narrativesNameSearch = value;
    this.narrativeNameList = new Array();
  }

  search() {

    this.isSearch = true;
    if (this.narrativeMasterDetails.narrativesNameSearch.trim() == '' || this.narrativeMasterDetails.narrativesTypeSearch == "0") {
      toastr.error("Please enter NarrativeName and NarrativeTpe for search");
      return;
    }
    else if (this.narrativeMasterDetails.narrativesNameSearch.trim() != '' || this.narrativeMasterDetails.narrativesTypeSearch.trim() != "0") {
      this.narrativeService.getNarrativesNameAndTypeList(this.narrativeMasterDetails.narrativesNameSearch.trim(), this.narrativeMasterDetails.narrativesTypeSearch.trim()).subscribe((res: any) => {
        
        this.searchResultList = res['Result'];        
        if (this.searchResultList != null && this.searchResultList.length == 0) {
          toastr.info("Record Not Found");
          return;
        }
        if (this.searchResultList != null && this.searchResultList.length > 1) {
          this.modalNarrativeList.show();
        }
        else {
          this.narrativeService.getNarrativesMasterDetails(this.narrativeMasterDetails.narrativesNameSearch.trim(), this.narrativeMasterDetails.narrativesTypeSearch.trim()).subscribe((res: any) => {
            this.searchResultDetails = res['Result'][0];
            this.getUploadFile();
            if (this.searchResultDetails.filename !=null)
             this.narrative_file_exists="file Exists";
          });
          this.isSaveDisable = false;
        }
      });
    }
  }

  getNarrativeList(bvsd_name, narratives_type) {

    this.narrativeService.getNarrativesMasterDetails(bvsd_name, narratives_type).subscribe((res: any) => {
      this.searchResultDetails = res['Result'][0];
      this.modalNarrativeList.hide();
    });
    this.isSaveDisable = false;
  }

  getUploadFile() {
    
    var servicePath = "getNdcAttributeFile?partbvsdId=";
    var part_bvsd_id = this.searchResultDetails['part_bvsd_id'];
    this.uploadFile = this._baseUrl + servicePath + part_bvsd_id;
    
  }

  addnewNarrative() {
    if (this.narrativeMasterDetails.narrativesNameSearch == "")
      toastr.error("Please enter valid narrative name before clciking Add New Narrative");
    else {      
      var narrativesName=this.narrativeMasterDetails.narrativesNameSearch;
      this.clearControls();
      this.searchResultDetails.bvsd_name = narrativesName
      this.isSearch = false;
      this.isSaveDisable = false;  
      this.narrative_file_exists="";    
    }
  }

  saveNarrativeDetails() {
    if (this.searchResultDetails.narratives_type == "0" || this.searchResultDetails.bvsd_name == "" || this.searchResultDetails.bvsd_status == "0" || this.searchResultDetails.b_reason == "" || this.searchResultDetails.d_reason == "" ) {
      toastr.warning("Please fill up all details before save");
      return;
    }

    if(this.searchResultDetails.bvsd_name.indexOf("*")!=-1)
    {
      toastr.warning("Special character not allowed in narrative name.");
      return;
    }
    if (!this.isSearch) {
      // this.narrativeService.getNarrativesMasterDetails(this.searchResultDetails.bvsd_name.trim(), this.searchResultDetails.narratives_type.trim()).subscribe((res: any) => {
      //   if (res['Result'].length > 0 && res['Result'][0].part_bvsd_id > 0)
     
      this.narrativeService.checkIfNarrativeNameAlreadyExists(this.searchResultDetails.bvsd_name.trim()).subscribe((response: any) => {
        if (response)
          toastr.error("Narrative details already exists.Try with new Narratvie Name");
        else {
          this.save();
        }
      })
    } else {
      this.save();
    }
  }
  save() {

    if (this.isSearch == false) {
      this.narrativeData.partBvsdId = 0;
    }
    else {
      this.narrativeData.partBvsdId = this.searchResultDetails.part_bvsd_id;
    }
    this.narrativeData.narrativeType = this.searchResultDetails.narratives_type;
    this.narrativeData.narrativeName = this.searchResultDetails.bvsd_name;
    this.narrativeData.bvsdStatus = this.searchResultDetails.bvsd_status;
    this.narrativeData.bReason = this.searchResultDetails.b_reason;
    this.narrativeData.dReason = this.searchResultDetails.d_reason;    
    this.narrativeData.eff_date = this.searchResultDetails.eff_date;
 

    //set data to facilate upload file
    this.requestData.append("partBvsdId", this.narrativeData.partBvsdId.toString());
    this.requestData.append('narrativeType', this.narrativeData.narrativeType);
    this.requestData.append('narrativeName', this.narrativeData.narrativeName);
    this.requestData.append('bvsdStatus', this.narrativeData.bvsdStatus);
    this.requestData.append('bReason', this.narrativeData.bReason);
    this.requestData.append('dReason', this.narrativeData.dReason);
    this.requestData.append('eff_date', this.narrativeData.eff_date);  
       
    this.searchResultDetails['filename']=null; //Writing here to clear this field as this is not get clear after ajax post back
    this.narrative_file_exists="";
    this.narrativeService.saveNarrativesMasterDetails(this.requestData);
    //  {
    //   if (narrativeResponse['Result'] == "success") {
    //     toastr.success("Narrative Details saved successfully");
    //     this.narrativeMasterDetails.narrativesTypeSearch = "0";
    //     this.narrativeMasterDetails.narrativesNameSearch = "";
    //     this.searchResultDetails = {} as INARRATIVE_MASTER;
    //   }
    //   else {
    //     toastr.error("Error while saving Info Code");
    //   }
    // });
    this.clearControls();
  }
  onClick(e){
    e.target.value=null;
  }
  onFileChange(e) {
    let fileList: FileList = e.target.files;
    if (fileList.length > 0) {
      let file: File = fileList[0];

      if ((file.name.split(".").pop()).toLowerCase() !="html" && (file.name.split(".").pop()).toLowerCase() !="htm") {
        e.target.value=null; 
        toastr.warning("The chosen file should be in htm or html format.");      
        
      }
      else{
      //this.uploadFileMaster.bvsd_status=file.name;
      this.requestData.append('file', file, file.name);
      this.searchResultDetails['filename']=file.name; 
      this.narrative_file_exists="";

      }
    }
  }

  cancel() {   
    this._router.navigate(['home']);
  }

  clearControls(){

    this.narrativeMasterDetails.narrativesTypeSearch = "0";
    this.narrativeMasterDetails.narrativesNameSearch = "";
    this.searchResultDetails.narratives_type = "0";
    this.searchResultDetails.bvsd_status = "0";
    this.searchResultDetails.bvsd_name = "";
    this.searchResultDetails.b_reason = "";
    this.searchResultDetails.d_reason = "";
    this.searchResultDetails.eff_date = "";
    this.searchResultDetails['filename']=null; 
    this.isSaveDisable=true;
    this.requestData=new FormData();
    this._router.navigate(['narrativemaster']);
    
  }
}