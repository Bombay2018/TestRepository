import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { IUSER_MASTER, IDS_RJ_MAP } from '../../shared/interfaces/entities.interface';
import { DataService } from '../../services/data.service';
import { ConversionService } from '../../services/conversion.service';
import { DropDown } from '../../shared/common';
import { GlobalService } from "./../../services/shared/global.service";
import { ModalComponent } from '../shared/modalpopup.component';

declare var $: any;

@Component({
    selector: 'app-ndcconversionmapping',
    moduleId: module.id,
    templateUrl: './ndcconversionmapping.component.html?v=${new Date().getTime()}',
    providers: [ConversionService, DataService]
})
export class NdcconversionmappingComponent implements OnInit {

    logInUser: IUSER_MASTER;
    dropDown: DropDown[];
    allDS: any;
    addRowCT: DropDown[];
    ndcSuperSixData: IDS_RJ_MAP[];
    ndcSuperSixDataFilter: IDS_RJ_MAP[];
    masterNdcSuperSixData: IDS_RJ_MAP[];

    superSix: any;
    isDesc: boolean = false;
    column: string = 'data_source_name';
    direction: number;
    columnSelected: any;
    data_source_name: string;
    ds_value: string;
    user: string;
    isAddRow: boolean = false;
    addSuperSix: IDS_RJ_MAP = {} as IDS_RJ_MAP;
    isEditRow: boolean = false;
    editIds: number[] = new Array();
    editRowId: number;
    showRowSelectedError: boolean = false;
    ct_filter: string;
    activeTab: string = '';
    attributeId: number = 2;
    selectedDS: any;
    grFilter:boolean;

    @ViewChild('modalDelete') modalDelete: ModalComponent;

    constructor(private datasvc: DataService,
        private router: Router,
        private conversionSvc: ConversionService<IDS_RJ_MAP>,
        private _globalSev: GlobalService) {
        this.logInUser = JSON.parse(localStorage.getItem('currentUser'));
        this._globalSev.showNavBar(true, this.logInUser.user_name);
    }

    ngOnInit() {

        this.datasvc.getDataSource().subscribe((res: any) => {
            this.allDS = res['Result'];
        });
        //  this.datasvc.getAllAttribute().subscribe((res: any) => {
        //      
        //      this.superSix = res['Result'].filter(obj  =>  obj.attribute_id>1 && obj.attribute_id < 8);
        //      //this.superSix = res['Result'];
        //  });

        this.datasvc.getDropdownData().subscribe((res: any) => {
            this.dropDown = res.CTGridDropdown;
            this.addRowCT = res.ConversionTranslation;
            this.columnSelected = this.dropDown[0].id;
        })
        this.showNdcSuperSixData(2);
    }

    showNdcSuperSixData(attributeId: number) {
        
        this.ndcSuperSixData = [] as IDS_RJ_MAP[];
        this.ndcSuperSixDataFilter = [] as IDS_RJ_MAP[];
        this.masterNdcSuperSixData = [] as IDS_RJ_MAP[];

        this.data_source_name = "";
        this.ds_value = "";
        this.user = "";
        this.ct_filter = "";
        this.clear();

        this.attributeId = attributeId;
        switch (attributeId) {
            case 3:
                this.activeTab = 'brand_name';
                break;
            case 4:
                this.activeTab = 'strength';
                break;
            case 5:
                this.activeTab = 'dosage_form';
                break;
            case 6:
                this.activeTab = 'rx_otc_ind';
                break;
            case 7:
                this.activeTab = 'route_of_administration';
                break;
            case 8:
                this.activeTab = 'br_generic_indicator';
                break;
            case 9:
                this.activeTab = 'therapeutic_class';
                break;
            case 10:
                this.activeTab = 'manufacturer_name';
                break;
            case 11:
                this.activeTab = 'package_description';
                break;
            case 12:
                this.activeTab = 'package_size';
                break;
            case 14:
                this.activeTab = 'package_unit_dose';
                break;
            case 16:
                this.activeTab = 'repackager_ind';
                break;
            case 17:
                this.activeTab = 'sd_md';
                break;
            case 18:
                this.activeTab = 'tee_code';
                break;
            case 19:
                this.activeTab = 'inner_outer_package_indicator';
                break;
            default:
                this.activeTab = 'generic_name';
        }
        this.conversionSvc.getConversionTranslation(this.activeTab).subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
            this.masterNdcSuperSixData = Object.assign([], ndcSuperSix['Result']);
            this.ndcSuperSixData = ndcSuperSix['Result'];
            this.ndcSuperSixDataFilter = ndcSuperSix['Result']; // user updated data to be stored
        });

    }

    showcalender() {
        // $('#addDate').created_datepicker({
        //     format: 'mm/dd/yyyy',
        //     autoclose: true
        // }).on('change', (event: any) => {
        //     this.new_created_date = event.target.value;
        // });
    }
    sort() {
        //this.isDesc = !this.isDesc;
        this.column = this.columnSelected.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    filterCT($event, ctValue) {
        if ($event.target.checked) {
            this.ct_filter = ctValue;
        }
        this.filterNdcSuperSixData();
    }

    filterNdcSuperSixData(): void {
        // this.ndcSuperSixData = this.masterNdcSuperSixData.filter(obj  =>  obj.super_six_name == this.activeTab);
        
        if (this.ndcSuperSixData.length > 0) {
            if (this.data_source_name || this.ds_value || this.user || this.ct_filter) {
                this.ndcSuperSixDataFilter = this.ndcSuperSixData.filter(item =>
                    ((this.data_source_name) ? (item.data_source_name.toLowerCase().indexOf(this.data_source_name.toLowerCase()) > -1) : 1)
                    &&
                    ((this.ds_value) ? (item.ds_value.toLowerCase().indexOf(this.ds_value.toLowerCase()) > -1) : 1)
                    &&
                    ((this.user) ? (item.modified_by.toLowerCase().indexOf(this.user.toLowerCase()) > -1) : 1)
                    &&
                    ((this.ct_filter) ? (item.map_type.toLowerCase().indexOf(this.ct_filter.toLowerCase()) > -1) : 1)
                );
            }
            else {
                this.ndcSuperSixDataFilter = this.masterNdcSuperSixData;
            }
        }
    }

    clear() {
        this.data_source_name = "";
        this.ds_value = "";
        this.user = "";
        this.ct_filter = "";
        this.grFilter=false;
        this.ndcSuperSixDataFilter = this.masterNdcSuperSixData;
    }

    checkAll(event) {
        if (event == true) {
            for (let data of this.ndcSuperSixDataFilter) {
                data.is_selected = true;
            }
        }
        else {
            for (let data of this.ndcSuperSixDataFilter) {
                data.is_selected = false;
            }
        }
    }

    addRow() {
        this.addSuperSix.data_source_name = "";
        this.addSuperSix.ds_value = "";
        this.addSuperSix.rj_value = "";
        this.addSuperSix.map_type = "";
        this.isAddRow = true;
        this.isEditRow = false;
    }

    DeleteConfirmationPopup() {

        var isChekedItem: boolean = false;
        for (let i = 0; i < this.ndcSuperSixDataFilter.length; i++) {
            if (this.ndcSuperSixDataFilter[i]['is_selected'] == true) {

                isChekedItem = true;
                this.modalDelete.show();
            }
        }
        if (!isChekedItem) {
            toastr.error("Please select atleast one item to delete");
            return;
        }

    }

    deleteRow() {
        var convTranId = [];
        for (let i = 0; i < this.ndcSuperSixDataFilter.length; i++) {
            if (this.ndcSuperSixDataFilter[i]['is_selected'] == true) {
                convTranId.push(this.ndcSuperSixDataFilter[i].ds_rj_id);
            }
        }
        if (convTranId.length > 0) {
            this.conversionSvc.deleteConversionTranslation(convTranId).subscribe((res: JSON) => {

                if (res['Result'].toLowerCase() == 'success') {
                    toastr.success("Successfully Deleted");
                    this.showNdcSuperSixData(this.attributeId);
                } else {
                    toastr.error("failed to delete /n internal sever error");
                }
            });
        } else {
            toastr.error("You must select atleast 1 row to delete");
        }
    }

    edit(Id) {
        
        this.isAddRow = false;
        this.isEditRow = true;
        this.editRowId = Id;
        this.editIds.push(Id);
    }

    changeDatasource(ds: number) {
        this.selectedDS = this.allDS.filter(obj => obj.data_source_name == ds);
    }

    saveNdcSuperSixData() {
        
        if (this.isEditRow == true) {
            var matchedData = this.ndcSuperSixDataFilter.filter(obj => obj.ds_rj_id == this.editRowId);
            var changedAttr = this.masterNdcSuperSixData.filter(obj => obj.ds_rj_id == matchedData[0]['ds_rj_id'] && obj.rj_value != matchedData[0]['rj_value']);
            if (changedAttr.length == 0) {
                var isRjValueEdited = 'Y';
            }
        }
        var updatedSuperSix: IDS_RJ_MAP[] = [];
        this.editIds.forEach(element => {

            var modifiedSuperSixTC: IDS_RJ_MAP = {} as IDS_RJ_MAP;
            modifiedSuperSixTC = this.ndcSuperSixDataFilter.filter(obj => obj.ds_rj_id == element)[0];
            modifiedSuperSixTC.attribute_id = this.attributeId;
            modifiedSuperSixTC.modified_by = this.logInUser.user_name;
            this.selectedDS = this.allDS.filter(obj => obj.data_source_name == modifiedSuperSixTC.data_source_name);
            modifiedSuperSixTC.data_source_id = this.selectedDS[0]['data_source_id'];
            modifiedSuperSixTC.isRjValueEdited = isRjValueEdited;
            delete modifiedSuperSixTC.data_source_name;
            delete modifiedSuperSixTC.modified_date;
            updatedSuperSix.push(modifiedSuperSixTC);
        });

        if (this.isAddRow == true) {
            if (this.addSuperSix.data_source_name && this.addSuperSix.ds_value && this.addSuperSix.rj_value && this.addSuperSix.map_type) {
                this.addSuperSix.ds_rj_id = 0;
                this.addSuperSix.data_source_id = this.selectedDS[0]['data_source_id'];
                this.addSuperSix.attribute_id = this.attributeId;
                this.addSuperSix.modified_by = this.logInUser.user_name;
                this.addSuperSix.isRjValueEdited = 'N';
                updatedSuperSix.push(this.addSuperSix);
            }
            else if (this.addSuperSix.data_source_name && this.addSuperSix.ds_value && this.addSuperSix.map_type.toLowerCase() == 'c') {
                this.addSuperSix.ds_rj_id = 0;
                this.addSuperSix.attribute_id = this.attributeId;
                this.addSuperSix.modified_by = this.logInUser.user_name;
                this.addSuperSix.isRjValueEdited = 'N';
                updatedSuperSix.push(this.addSuperSix);
            }
            else {
                toastr.error("Please enter all the fields");
            }
        }

        var count = 0;
        if (updatedSuperSix.length > 0) {
            
            updatedSuperSix.forEach(superSix => {
                
                if ((superSix['attribute_id'] <= 0 || superSix['attribute_id'] == undefined) || (superSix['data_source_id'] <= 0 || superSix['data_source_id'] == undefined)
                    || (superSix['ds_rj_id'] < 0 || superSix['ds_rj_id'] == undefined) || (superSix['ds_value'] == "" || superSix['ds_value'] == undefined)
                    || (superSix['map_type'] == "")) {
                    toastr.error("No field should be empty");
                    return;
                }
                else {
                    this.conversionSvc.saveConversionTranslation(superSix).subscribe((res: JSON) => {
                        count++;
                        if (res['Result'].toLowerCase() == 'success') {
                            if (count == updatedSuperSix.length) {
                                this.showNdcSuperSixData(this.attributeId);
                                toastr.success("Saved Successfully");
                                this.editIds = [];
                            }
                        }
                        else {
                            toastr.error(res['Result']);
                        }
                    });
                }
            });
        }
        this.isAddRow = false;
        this.isEditRow = false;
    }

    cancel() {
        // this.showNdcSuperSixData(this.attributeId);
        // this.isAddRow = false;
        // this.isEditRow = false;
        // this.showRowSelectedError = false;
        this.router.navigate(['home']);
    }
}
