/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, HostListener, Renderer, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs/Rx';

import { ConfigService } from '../../services/shared/config.service';
import { NDCFailureGridHead, NDCFailureMessage, WorkQueueType, DataSources, Sections } from '../../services/shared/config.const';
import { INDC_ATTRIBUTES, INDC_ATTRIBUTES_STATUS, INDC_PRICE_HISTORY, IUSER_MASTER, IDS_RJ_MAP, IWORKQUEUE_MAPPING } from '../../shared/interfaces/entities.interface';
import { GlobalService } from '../../services/shared/global.service';
import { DataService } from '../../services/data.service';
import { NdcResolutionService } from '../../services/ndcresolution.service';
import { PriceHistoryService } from '../../services/pricehistory.service';
import { ConversionService } from '../../services/conversion.service';
import { UtilitiesService } from "./../../services/shared/utilities.service";

import { DropDown } from '../../shared/common';

import { ModalComponent } from '../shared/modalpopup.component';

declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'app-ndc-resolution',
  templateUrl: './ndcresolution.component.html?v=${new Date().getTime()}',
  providers: [NdcResolutionService, DataService, PriceHistoryService, ConversionService]
})

export class NdcResolutionComponent implements OnInit, AfterViewInit, OnDestroy {
  user: IUSER_MASTER;
  mockRuleFailureUpdate: any;
  mockWorkQueue: DropDown[];
  reasonCodeDropDown: DropDown[];
  attributeNameDropDown: any;
  workQueueType: any;
  ndc_hcpc_id: any;
  queueId: any;
  users: any;
  workQueueRow: any;
  selectedCode: any;
  userId: any;

  viewMode: boolean = false;
  ndcSearchResult: any[] = new Array();
  ndcSearchCode: string = '';
  ndcNumber: string = '';
  ndcStatus: string = '';
  ndcWtId: number = 0;
  //prescribinginformation: Object;
  ndcDSAttributes: any;
  ndcSDDLAttributes: any;
  ndcSDDLAttributesBackup: any;
  ndcDiscrepancyAttributes: any;
  ndcChangedAttr: Object;
  ndcOtherDetails: Object;
  ndcRuleFailure: any[] = new Array();
  attrubutStatus: INDC_ATTRIBUTES_STATUS = {} as INDC_ATTRIBUTES_STATUS;

  msView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  fdbView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  rjView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  gsView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  rbView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];

  addNewNDC: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  msshow: boolean = true;
  fdbshow: boolean = true;
  rjshow: boolean = true;
  gsShow: boolean = true;
  rbshow: boolean = true;
  activeHistoryTab: number = 0;

  conversionTranslate: any; //IDS_RJ_MAP = {} as IDS_RJ_MAP;
  selectedSuperSix: string = '';
  statusProp: string = '';

  isSearch: boolean = false;
  isNewNDC: boolean = false;
  isAddNDC: boolean = false;
  newNDC: boolean = false;

  priceHistoryshow: boolean = false;
  activePricing: string;
  ndcAWPWACHistoryBackup: INDC_PRICE_HISTORY[] = [] as INDC_PRICE_HISTORY[];
  ndcAWPWACHistory: INDC_PRICE_HISTORY[] = [] as INDC_PRICE_HISTORY[];

  sectionList: any[];
  datasources: any;
  pricespecification: any;
  saveQueueId: number = 1;
  contexMenu;
  message;
  gridhead: any;
  isL1User: boolean = false;
  isAdminUser: boolean = true;
  isL2User: boolean = false;

  preSearch: any[] = new Array();
  ndcList: any[] = new Array();

  @ViewChild('modalNDCList') modalNDCList: ModalComponent;
  @ViewChild('modalRequestPublish') modalRequestPublish: ModalComponent;
  @ViewChild('modalPublish') modalPublish: ModalComponent;
  @ViewChild('modalLockExist') modalLockExist: ModalComponent;
  @ViewChild('fdbTab') div: ElementRef;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private configsvc: ConfigService,
    private elementRef: ElementRef,
    private ndcSvc: NdcResolutionService<INDC_ATTRIBUTES>,
    private _datasvc: DataService,
    private pricehistorySvc: PriceHistoryService<INDC_PRICE_HISTORY>,
    private conversionSvc: ConversionService<IDS_RJ_MAP>,
    private _globalSev: GlobalService,
    private _utilService: UtilitiesService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {

    this.isAddNDC = false;
    this.ndcNumber = this.route.snapshot.params['workqueue'];
    this.ndc_hcpc_id = this.route.snapshot.params['id'];
    this.queueId = this.route.snapshot.params['qId'];
    this.saveQueueId = this.queueId;
    this.userId = this.route.snapshot.params['uId'];
    this.gridhead = NDCFailureGridHead;
    this.getNDCByCode(this.ndcNumber);
    this.message = NDCFailureMessage;
    this.sectionList = Sections;
    this.contexMenu = this.configsvc.getcontexMenu();
    this.contexMenu.forEach(cm => cm.subject.subscribe(val => this.setStatus(val)));

    if ((this.user.role_name == "L1-Initial") || (this.user.role_name == "L1-Change")) {
      this.isL1User = true;
      this.isAdminUser = false;
      this.isL2User = false;
    }
    else if ((this.user.role_name == "L2-Initial") || (this.user.role_name == "L2-Change") ||
      (this.user.role_name == "L2-Second level") || (this.user.role_name == "L2-Publish")) {
      this.isL1User = false;
      this.isAdminUser = false;
      this.isL2User = true;
    }
    this._datasvc.getDropdownData().subscribe((res: any) => {
      this.mockRuleFailureUpdate = res.mockRuleFailureUpdate;
      this.workQueueType = WorkQueueType;
      this.reasonCodeDropDown = res.HcpcNdcReasonCode;
      this.ndcOtherDetails['reason_notes'] = this.reasonCodeDropDown[0].id;
    })
    // this._datasvc.getStageName().subscribe((res: any) => {
    //   this.workQueueType = res;
    // })
    this._datasvc.getAllAttribute().subscribe((res: any) => {
      this.attributeNameDropDown = res['Result'];
    });
    this._datasvc.getWorkQueueName().subscribe((res: any) => {
      this.mockWorkQueue = res;
    });
    this._datasvc.getDataSource().subscribe((res: any) => {
      this.datasources = res['Result'];
    });
    this.setndcOtherDetails();
  }

  ngAfterViewInit() {
    $('#followDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.ndcOtherDetails['follow_up_date'] = event.target.value;
    });

    $('#piDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.ndcOtherDetails['pi_status_date'] = event.target.value;
    });

    // $('#rjDate').datepicker({
    //   format: 'mm/dd/yyyy',
    //   startDate: new Date(),
    //   autoclose: true
    // }).on('change', (event: any) => {
    //   this.ndcSDDLAttributes[0]['ndc_status_date'] = event.target.value;
    // });

    // $('#rjDate').datepicker({
    //   format: 'mm/dd/yyyy',
    //   startDate: new Date(),
    //   autoclose: true
    // }).on('change', (event: any) => {
    //   this.ndcSDDLAttributes[0]['ndc_status_date'] = event.target.value;
    // });

    // $('#rjDate').datepicker({
    //   format: 'mm/dd/yyyy',
    //   startDate: new Date(),
    //   autoclose: true
    // }).on('change', (event: any) => {
    //   this.ndcSDDLAttributes[0]['ndc_status_date'] = event.target.value;
    // });

  }
  ngOnDestroy() {
    this.releaseWorkQueueNdc();
  }

  private searchPramChange(event) {
    var self = this;
    this.ndcList = new Array();
    var eventLen = event.length;
    if (eventLen < 3) {
      return;
    }
    this.ndcList = new Array();
    this.preSearch.forEach(function (val) {
      if (val.length > 0) {
        var isExit = val['ndc'].startsWith(event)
        if (isExit == true) {
          self.ndcList.push(val);
        }
      }
    });
    if (self.ndcList.length == 0) {
      self._datasvc.getDistinctNDC(event).subscribe((ndcList) => {
        if (ndcList.Result != null && ndcList.Result.length > 0) {
          ndcList.Result.forEach(function (ndc) {
            var existNdc = self.ndcList.filter(n => n['ndc'] == ndc['ndc']);
            if (existNdc.length == 0) {
              self.preSearch.push(ndc);
              self.ndcList.push(ndc);
            }
          });
        } else {
          self.ndcList = new Array();
        }
      });
    }
  }

  private exactNdcMatch() {

    var self = this;
    if (self.ndcList.length == 0) {
      toastr.info("Record Not Found");
      return;
    }
    if (self.ndcList.length == 1) {
      this.getNDCByCode(self.ndcList[0]['ndc']);
      this.ndcStatus = self.ndcList[0]['ndc_status'];
      this.ndcSearchCode = "";
      self.ndcList = new Array();
    }
  }

  private search() {
    this.isSearch = true;
    this.isAddNDC = false;
    this.clearControls();
    if (this.ndcSearchCode.trim() == '') {
      toastr.error("Please enter NDC Code");
      return;
    } else {
      this.exactNdcMatch();
    }
  }

  private userDropdown() {

    var queue_id = this.ndcOtherDetails['work_queue'];   // on the same page hardcoded send that page dropdown value
    var work_queue_type = this.ndcOtherDetails['work_queue_type'];
    if (queue_id > 0 && work_queue_type > 0) {
      var role_type = work_queue_type == 1 ? "Initial" : "Second"; // send L1 or L2
      this._datasvc.getUserByQueueId(queue_id, role_type).subscribe((res: any) => {
        this.users = res;
      });
    }
    else {
      this.users = null;
    }
  }

  private getNDCByCode(code: string): any {

    this.ndcNumber = code;
    var ndcAttributesNew = [];
    if (this.ndcSearchResult.length > 0) {
      this.ndcWtId = this.ndcSearchResult.filter(obj => obj.ndc == code)[0]['wt_id'];
    }

    if (code != undefined) {
      this.ndcSvc.getNDCByNDC(code).subscribe((ndcattributes: INDC_ATTRIBUTES[]) => {
        if (ndcattributes != null) {
          ndcattributes.forEach(obj => {
            switch (obj.data_source_id) {
              case 1:
              case 2:
              case 3:
              case 4:
                var ifExist = ndcAttributesNew.filter(item => item.data_source_id == obj.data_source_id);
                if (ifExist.length == 0) {
                  if (obj['history'] == undefined) {
                    var historyToAdd = [];
                    var history = ndcattributes.filter(item => item.data_source_id == obj.data_source_id);
                    if (history.length > 1) {
                      for (var i = 1; i < history.length; i++) {
                        historyToAdd.push(history[i]);
                      }
                    }
                    obj['history'] = historyToAdd;
                    obj['showHistory'] = false;
                  }
                  ndcAttributesNew.push(obj);
                }
                break;
              case 6:
                var ifExist = ndcAttributesNew.filter(item => item.data_source_id == obj.data_source_id);
                if (ifExist.length == 0) {
                  var historyToAdd = [];
                  var history = ndcattributes.filter(item => item.data_source_id == obj.data_source_id);
                  if (history.length > 1) {
                    for (var i = 0; i < history.length; i++) {
                      ndcAttributesNew.push(history[i]);
                      break;
                    }
                  }
                }
                break;
              default:
                obj['history'] = [];
                obj['showHistory'] = false;
                ndcAttributesNew.push(obj);
                break;
            }
          });
        }
        this.ndcDSAttributes = ndcAttributesNew;
        this.ndcSDDLAttributes = ndcattributes.filter(obj => obj.data_source_id == 6);
        if (this.ndcSDDLAttributes != null && this.ndcSDDLAttributes.length != 0) {
          this.ndcWtId = this.ndcSDDLAttributes[0].wt_id;

          this.ndcSvc.getNDCPrescribingInformation(this.ndcWtId).subscribe((ndcprescribinginformation) => {
            if (ndcprescribinginformation != null) {
              this.ndcOtherDetails['pi_name'] = ndcprescribinginformation[0]['pi_name'];
              this.ndcOtherDetails['pi_link'] = ndcprescribinginformation[0]['pi_link'];
              this.ndcOtherDetails['pi_status_date'] = ndcprescribinginformation[0]['pi_status_date'];
            }
          });

          this.ndcSvc.getNDCPriceSpecificationNDCDetail(this.ndcWtId).subscribe((ndcPriceSpecification) => {
            if (ndcPriceSpecification != null && ndcPriceSpecification.length > 0) {
              this.ndcOtherDetails['price_spec_id'] = ndcPriceSpecification[0]['price_spec_id'];
              this.ndcOtherDetails['price_spec_notes'] = ndcPriceSpecification[0]['note_description'];
            }
          });
        }
        else {
          this.ndcWtId = 0;
        }
        this.InitStatus();

        var statusProps = Object.getOwnPropertyNames(this.attrubutStatus);
        if (this.ndcSDDLAttributes.length <= 0) {
          this.ndcSDDLAttributes[0] = this.attrubutStatus;
        }
        statusProps.forEach(prop => {
          this.ndcSDDLAttributes[0][prop] = 0
        });

        this.ndcSvc.getNDCRuleFailure(code).subscribe((ndcrulefailure) => {
          if (ndcrulefailure.length > 0) {
            this.ndcRuleFailure = ndcrulefailure;
            if (ndcrulefailure['queue_name'] == "NDC_Discrepancy") {
              this.saveQueueId = 1;
            }
            else {
              this.saveQueueId = 5;
            }
            this._globalSev.stage_id = ndcrulefailure["stage_id"];
            if (this.ndcRuleFailure.length > 0) {
              this.ndcSvc.getDiscrepancyAttributes(code).subscribe((workqueitems: IWORKQUEUE_MAPPING[]) => {
                this.ndcDiscrepancyAttributes = workqueitems;
                if (this.ndcDiscrepancyAttributes != null && this.ndcSDDLAttributes[0] != null) {
                  this.ndcDiscrepancyAttributes.forEach(obj => {

                    switch (obj["attribute_name"].toLowerCase()) {
                      case "generic_name": this.ndcSDDLAttributes[0]['generic_name'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['generic_name_status'] = 2; break;
                      case "brand_name": this.ndcSDDLAttributes[0]['brand_name'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['brand_name_status'] = 2; break;
                      case "strength": this.ndcSDDLAttributes[0]['strength'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['strength_status'] = 2; break;
                      case "route_of_administration": this.ndcSDDLAttributes[0]['route_of_administration'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['route_of_administration_status'] = 2; break;
                      case "dosage_form": this.ndcSDDLAttributes[0]['dosage_form'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['dosage_form_status'] = 2; break;
                      case "rx_otc_ind": this.ndcSDDLAttributes[0]['rx_otc_ind'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['rx_otc_ind_status'] = 2; break;
                      case "awp": this.ndcSDDLAttributes[0]['awp'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['awp_status'] = 2; break;
                      case "wac": this.ndcSDDLAttributes[0]['wac'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['wac_status'] = 2; break;
                      case "ndc_status": this.ndcSDDLAttributes[0]['ndc_status'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['ndc_status_status'] = 2; break;
                      case "ndc_status_date": this.ndcSDDLAttributes[0]['ndc_status_date'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['ndc_status_date_status'] = 2; break;
                      case "br_generic_indicator": this.ndcSDDLAttributes[0]['br_generic_indicator'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['br_generic_indicator_status'] = 2; break;
                      case "package_size":

                        this.ndcSDDLAttributes[0]['package_size'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_size_status'] = 2;
                        if (this.ndcSDDLAttributes[0]['package_size'] != null) {
                          // this.ndcSDDLAttributes[0]['package_size']=this.ndcSDDLAttributes[0]['package_size'] +'|'+ this.ndcSDDLAttributes[0]['package_size_uom'];
                          var pkgUOM = this.ndcSDDLAttributes[0]['package_size'].split("|");
                          if (pkgUOM.length > 0) {
                            this.ndcSDDLAttributes[0]['package_size'] = pkgUOM[0];
                            this.ndcSDDLAttributes[0]['package_size_uom'] = pkgUOM[1] == undefined ? "" : pkgUOM[1];
                          }
                        }
                        break;

                      case "package_description": this.ndcSDDLAttributes[0]['package_description'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_description_status'] = 2; break;
                      case "package_unit_dose": this.ndcSDDLAttributes[0]['package_unit_dose'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_unit_dose_status'] = 2; break;
                      case "package_quantity": this.ndcSDDLAttributes[0]['package_quantity'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_quantit_status'] = 2; break;
                      case "repackager_ind": this.ndcSDDLAttributes[0]['repackager_ind'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['repackager_ind_status'] = 2; break;
                      case "sd_md": this.ndcSDDLAttributes[0]['sd_md'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['sd_md_status'] = 2; break;
                      case "tee_code": this.ndcSDDLAttributes[0]['tee_code'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['tee_code_status'] = 2; break;
                      case "inner_outer_package_indicator": this.ndcSDDLAttributes[0]['inner_outer_package_indicator'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['inner_outer_package_indicator_status'] = 2; break;
                      case "manufacturer_name": this.ndcSDDLAttributes[0]['manufacturer_name'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['manufacturer_name_status'] = 2; break;
                      case "cms_rebate": this.ndcSDDLAttributes[0]['cms_rebate'] = obj["attribute_value"]; break;
                      case "created_date": this.ndcSDDLAttributes[0]['created_date'] = obj["attribute_value"]; break;
                    }
                  });
                }

                //this.ndcSDDLAttributesBackup = Object.assign({}, this.ndcSDDLAttributes[0]);
                this.ndcSDDLAttributesBackup = JSON.parse(JSON.stringify(this.ndcSDDLAttributes[0]));

                //check ndcRuleFailure to change status and create link
                var self = this;
                var ths = Array.prototype.slice.call(document.getElementById("grid").getElementsByTagName("th"));
                this.ndcRuleFailure.forEach(function (obj) {

                  var isStructured = self.attributeNameDropDown.filter(us => us['attribute_name'].toLowerCase().trim() == obj['attribute_name'].toLowerCase().trim());
                  var status = obj['attribute_name'];
                  // self.ndcSDDLAttributes[0][status.toLowerCase() + '_status'] = 2;
                  // self.ndcSDDLAttributesBackup[status.toLowerCase() + '_status'] = 2;
                  if (isStructured.length > 0 && isStructured[0]['is_structured'].toUpperCase().trim() == 'N') {
                    if (obj['attribute_name'].toLowerCase() != 'awp' && obj['attribute_name'].toLowerCase() != 'wac' && obj['attribute_name'].toLowerCase() != 'ndc_status') {
                      var link = document.createElement("a");
                      link.setAttribute('href', "javascript:void(0)");
                      link.innerHTML = self.gridhead[status.toLowerCase()];
                      ths.forEach((th) => {
                        if (th.innerHTML.trim() == link.innerHTML.trim()) {
                          link.addEventListener("click", self.showCTpopup.bind(self));
                          th.innerHTML = '';
                          th.appendChild(link);
                        }
                      });
                    }
                  }
                  else {
                    debugger;
                    //console.log(self.gridhead[status.toLowerCase()]);
                    //console.log(ths[3]);
                    // console.log(ths);
                    //var th = '<th class="text-org">'+self.gridhead[status]+'</th>';
                    ths.forEach((th) => {
                      if (th.innerHTML.trim() == (self.gridhead[status.toLowerCase()]).trim()) {
                        // th.innerHTML = '';
                        // th.appendChild('<th class="text-org">'+self.gridhead[status.toLowerCase()]+'</th>'
                        th.style.color = 'orange';
                      }
                    });
                    // var test =ths.indexOf(th);
                    // console.log(test);
                    //var isNonStructured = ths.filter(nus => console.log(nus));
                    //console.log(isNonStructured);
                    //console.log('isNonStructured');
                  }
                });
              });

            }
          }
          else {
            // this.ndcSDDLAttributesBackup = Object.assign({}, this.ndcSDDLAttributes[0]);
            this.ndcSDDLAttributesBackup = JSON.parse(JSON.stringify(this.ndcSDDLAttributes[0]));
          }

          var prop = status.slice(0, -7);
          if (prop.trim().length > 0) {
            if (this.ndcSDDLAttributesBackup[prop] != event) {
              this.ndcSDDLAttributes[0][status] = 1;
            } else {
              this.ndcSDDLAttributes[0][status] = this.ndcSDDLAttributesBackup[status];
            }
          }

        });
        this.ndcSvc.getNDCPriceSpecificationDropDown().subscribe((pricespecification) => {
          this.pricespecification = pricespecification;
        });
      });
    }
    this.ndcSearchCode = '';
  }

  private modelChange(status, event) {

    var prop = status.slice(0, -7);
    if (status != '') {
      if (this.ndcSDDLAttributesBackup[prop] != event) {
        this.ndcSDDLAttributes[0][status] = 1;
      } else {
        this.ndcSDDLAttributes[0][status] = this.ndcSDDLAttributesBackup[status];
      }
    }
  }

  private showhide(dsId: number, dsName: string) {
    if (this.isNewNDC == false) {
      switch (dsName.toUpperCase()) {
        case 'MS':
          this.msshow = !this.msshow;
          if (this.msView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, dsId).subscribe((msView: INDC_ATTRIBUTES[]) => {
              this.msView = msView;
            })
          }
          break;
        case 'FDB':
          this.fdbshow = !this.fdbshow;
          if (this.fdbView.length == 0) {
            this.fdbView = this.ndcDSAttributes.filter(X => X.data_source_id == dsId)[0]['history'];
          }
          break;
        case 'RB':
          this.rbshow = !this.rbshow;
          if (this.rbView.length == 0) {
            this.rbView = this.ndcDSAttributes.filter(X => X.data_source_id == dsId)[0]['history'];
          }
          break;
        case 'GS':
          this.gsShow = !this.gsShow;
          if (this.gsView.length == 0) {
            this.gsView = this.ndcDSAttributes.filter(X => X.data_source_id == dsId)[0]['history'];
          }
          break;
        case 'SDDL':
          this.rjshow = !this.rjshow;
          if (this.rjView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, dsId).subscribe((rjView: INDC_ATTRIBUTES[]) => {
              this.rjView = rjView;
            })
          }
          break;
      }
    }
  }

  private showCTpopup(e) {
    if (e.srcElement.innerHTML != 'AWP Pr' && e.srcElement.innerHTML != 'WAC Pr' && e.srcElement.innerHTML != "Status") {
      this.selectedSuperSix = e.srcElement.innerHTML;
      var key = Object.keys(NDCFailureGridHead).find(key => NDCFailureGridHead[key] === e.srcElement.innerHTML);
      // this.conversionSvc.getConversionTranslation(key).subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
      //   this.conversionTranslate = ndcSuperSix['Result'];
      //   var x = document.getElementById("CTPopup");
      //   x.style.position = "relative";
      //   x.style.left = '550.5px';
      //   x.style.top = '-1926px';
      //   x.style.display = 'block';
      // });

      //==RUM-417=====      
      var attributesValues = this.ndcDSAttributes.map(a => a[key]);
      var uniqueattributValues = attributesValues.filter((x, i, a) => a.indexOf(x) == i);
      var rjDetails = [];
      if (uniqueattributValues != null && uniqueattributValues.length > 0) {
        uniqueattributValues.forEach(element => {
          var result = this.ndcDSAttributes.filter(item => item[key] == element);
          if (result != null && result.length > 1) {
            result.forEach(item => {
              var objRJDetails = {
                "wt_id": item.wt_id,
                "source_value": element,
                "data_source": item.data_source_name
              }
              rjDetails.push(objRJDetails);
            });
          }

          if (result != null && result.length == 1) {
            var objRJDetails = {
              "wt_id": result[0].wt_id,
              "source_value": element,
              "data_source": result[0].data_source_name
            }
            rjDetails.push(objRJDetails);
          }
        });

        var pullconversionTranslationMappingDataForNDC = {
          "attribute_name": key,
          "rjDetails": rjDetails
        }

        this.ndcSvc.getconversionTranslationMappingDataForNDC(pullconversionTranslationMappingDataForNDC).subscribe((conversionTranslationMap: INDC_ATTRIBUTES[]) => {

          this.conversionTranslate = conversionTranslationMap;
          var x = document.getElementById("CTPopup");
          x.style.position = "relative";
          x.style.left = '550.5px';
          x.style.top = '-1026px';
          x.style.display = 'block';

        });
      }
    }

    // var wt_id  = this.ndcDSAttributes.map(a => a[wt_id]);      
    //var uniqueattributValues=result.filter((x, i, a) => a.indexOf(x) == i);
    // if(uniqueattributValues!=null && uniqueattributValues.length>0)
    // for (var m = 0; m < uniqueattributValues.length; m++) {
    // this.conversionTranslate=this.conversionTranslate.filter(sc=>sc.ds_value==uniqueattributValues[m]); 
    //}

  }

  private filter_array(test_array) {
    var index = -1,
      arr_length = test_array ? test_array.length : 0,
      resIndex = -1,
      result = [];

    while (++index < arr_length) {
      var value = test_array[index];

      if (value) {
        result[++resIndex] = value;
      }
    }

    return result;
  }

  private closeCTpopup() {
    var x = document.getElementById("CTPopup");
    x.style.display = 'none';
  }

  private showhistory(ds, data_source_id, attribute_name) {
    this.activeHistoryTab = ds;
    this.activePricing = attribute_name;
    this.pricehistorySvc.getPriceHistory(this.ndcNumber, attribute_name).subscribe((pricehistory: INDC_PRICE_HISTORY[]) => {
      pricehistory.forEach((obj) => {
        this.ndcAWPWACHistoryBackup.push(obj);
      });
      this.ndcAWPWACHistory = this.ndcAWPWACHistoryBackup.filter(obj => obj.data_source_id === data_source_id && obj['attribute_name'] === attribute_name);
      this.priceHistoryshow = true;
    });
    this.ndcAWPWACHistoryBackup = [] as INDC_PRICE_HISTORY[];
  }

  private closePriceHistory() {
    this.priceHistoryshow = false;
  }

  private showSection(section) {
    this.sectionList[section]['show'] = !this.sectionList[section]['show'];
  }

  private contexMenuClick(prop) {
    this.statusProp = prop;
  }

  private setndcOtherDetails() {
    this.ndcOtherDetails = {
      reason_notes: "",
      reason_code: "",
      pi_name: "",
      pi_link: "",
      pi_status_date: "",
      price_spec_id: 0,
      price_spec_notes: '',
      follow_up_date: "",
      work_queue: 0,
      work_queue_type: 0,
      route_user_id: 0,
      routing_notes: '',
      req_to_publish_note: '',
      publish_note: '',
      reason_attribute_id: ''
    }
  }

  private setStatus(id) {
    var prop = this.statusProp.slice(0, -7);
    //var maxId: number = Math.max.apply(Math, this.ndcDSAttributes.DataSource.RJ.map(function (o) { return o.Id; }))
    var updatedData = Object.assign({}, this.ndcSDDLAttributes[0]);
    if (updatedData[prop] === this.ndcSDDLAttributesBackup[prop]) {
      toastr.error('Status not allowed to <br> change on old value');
      return;
    }

    // switch case not required directly assin id
    switch (id) {
      case 0: //Failure Resolved
        this.ndcSDDLAttributes[0][this.statusProp] = 0;
        this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        break;
      case 3: //override value
        this.ndcSDDLAttributes[0][this.statusProp] = 3;
        if (this.ndcSDDLAttributesBackup[status] == undefined) {
          this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        }
        break;
      case 4: //Change Review
        this.ndcSDDLAttributes[0][this.statusProp] = 4;
        if (this.ndcSDDLAttributesBackup[status] == undefined) {
          this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        }
        break;
      default:
        toastr.info('Invalid selection');
        break;
    }
    this.statusProp = '';
  }

  private addNDC() {
    this.isAddNDC = true;
    if (this.newNDC == false) {
      this.newNDC = true;
      this.gridhead = NDCFailureGridHead;
    }
    else {
      toastr.error("Add Multiple NDC Not Allow");
    }
  }

  private saveNewNDC(serviceType, ndc) {

    if (this.addNewNDC['generic_name'] && this.addNewNDC['brand_name'] && this.addNewNDC['strength'] && this.addNewNDC['route_of_administration']
      && this.addNewNDC['dosage_form'] && this.addNewNDC['rx_otc_ind'] && this.addNewNDC['awp'] && this.addNewNDC['wac'] && this.addNewNDC['ndc_status']
      && this.addNewNDC['ndc_status_date'] && this.addNewNDC['br_generic_indicator'] && this.addNewNDC['package_size'] && this.addNewNDC['package_size_uom']
      && this.addNewNDC['package_description'] && this.addNewNDC['package_unit_dose'] && this.addNewNDC['package_quantity'] && this.addNewNDC['repackager_ind']
      && this.addNewNDC['sd_md'] && this.addNewNDC['tee_code'] && this.addNewNDC['inner_outer_package_indicator'] && this.addNewNDC['manufacturer_name']
      && this.addNewNDC['cms_rebate']) {
      var workqueues = [];
      this.attributeNameDropDown.forEach(element => {
        for (var prop in this.addNewNDC) {
          if (prop == element['attribute_name']) {
            workqueues.push({
              workqueue_id: 0,
              attribute_id: element['attribute_id'],
              attribute_name: element['attribute_name'],
              attribute_value: this.addNewNDC[prop]
            });
          }
        }
      });
      if (this.ndcOtherDetails['route_user_id'] == 0) {
        this.ndcOtherDetails['route_user_id'] = this.user['user_id'];
      }
      if (this.ndcOtherDetails['reason_code'] == "" || this.ndcOtherDetails['reason_code'] == undefined) {
        this.ndcOtherDetails['reason_code'] = 0;
      }
      //if (this.ndcOtherDetails['follow_up_date'] == undefined) { this.ndcOtherDetails['follow_up_date'] = ""; }
      if (this.ndcOtherDetails['reason_attribute_name'] == undefined) { this.ndcOtherDetails['reason_attribute_name'] = ""; }
      if (this.ndcOtherDetails['price_spec_id'] == undefined) { this.ndcOtherDetails['price_spec_id'] = 0; }
      if (this.ndcOtherDetails['pi_name'] == undefined) { this.ndcOtherDetails['pi_name'] = ""; }
      if (this.ndcOtherDetails['pi_link'] == undefined) { this.ndcOtherDetails['pi_link'] = ""; }
      if (this.ndcOtherDetails['price_spec_notes'] == undefined) { this.ndcOtherDetails['price_spec_notes'] = ""; }
      if (this.ndcOtherDetails['pi_status_date'] == undefined) { this.ndcOtherDetails['pi_status_date'] = ""; }
      if (this.ndcOtherDetails['reason_notes'] == undefined) { this.ndcOtherDetails['reason_notes'] = ""; }
      if (this.ndcOtherDetails['routing_notes'] == undefined) { this.ndcOtherDetails['routing_notes'] = ""; }

      var savedata = {
        "pi_name": this.ndcOtherDetails['pi_name'],
        "pi_link": this.ndcOtherDetails['pi_link'],
        "pi_status_date": this.ndcOtherDetails['pi_status_date'],
        "price_spec_id": this.ndcOtherDetails['price_spec_id'],
        "price_spec_notes": this.ndcOtherDetails['price_spec_notes'],
        "publish_notes": this.ndcOtherDetails['publish_note'],
        "req_to_publish_notes": this.ndcOtherDetails['req_to_publish_note'],
        "loggedin_userid": this.user['user_id'],
        "wq_list": {
          "ndc": ndc,
          "user_id": this.ndcOtherDetails['route_user_id'],
          "wq_notes": this.ndcOtherDetails['reason_notes'],
          "reason_code": this.ndcOtherDetails['reason_code'],
          "reason_attribute_id": this.ndcOtherDetails['reason_attribute_name'],
          "routing_notes": this.ndcOtherDetails['routing_notes'],
          "workqueues": workqueues
        }
      }
      this.ndcSvc.saveNewNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
        if (ndcData['status'] != null || ndcData['status'] == "Success") {
          toastr.success("New NDC Data Saved Successfully");
          //this.releaseWorkQueueNdc();
          this.router.navigate(['home']);
        }
      });
    }
    else {
      toastr.warning("All the RJ fields should be filled");
    }
  }

  private save(serviceType) {
    var errorList = [];
    this.isAddNDC = false;
    var props = Object.getOwnPropertyNames(this.gridhead);
    props.forEach(prop => {
      if (this.ndcSDDLAttributes[0][prop] == "") {
        errorList.push(this.gridhead[prop] + '<br/>');
      }
    });
    if (errorList.length > 0) {
      errorList.splice(0, 0, 'Following are the error(s):<br/>')
      toastr.error(errorList.toString().replace(",", ""));
      return;
    }
    if (this.ndcSDDLAttributes[0] == undefined) {
      toastr.error("Any attribute updates not made");
      return;
    }
    if (this._utilService.urlValidation(this.ndcOtherDetails['pi_link'])) {
      toastr.error("PI link is nt in valid format.It should be in web url format.");
      return;
    }
    else {
      this.getChangedAttr(this.ndcSDDLAttributesBackup, this.ndcSDDLAttributes[0]);

      var self = this;
      var workqueues = [];
      for (var prop in self.ndcChangedAttr) {
        var wq_id = [];
        var attr = self.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase() == prop && obj['attribute_name'].toLowerCase() != this.attrubutStatus['attribute_name']);
        if (self.ndcDiscrepancyAttributes != null) {
          wq_id = self.ndcDiscrepancyAttributes.filter(obj => obj['attribute_name'].toLowerCase() == prop);
        }
        if (attr.length > 0) {
          if (wq_id.length > 0) {
            workqueues.push({
              workqueue_id: wq_id[0]['workqueue_id'],
              wq_queue_id: wq_id[0]['queue_id'],
              attribute_id: attr[0]['attribute_id'],
              attribute_name: attr[0]['attribute_name'],
              attribute_value: this.ndcChangedAttr[prop]
            });
          } else {
            workqueues.push({
              workqueue_id: 0,
              wq_queue_id: 1,
              attribute_id: attr[0]['attribute_id'],
              attribute_name: attr[0]['attribute_name'],
              attribute_value: this.ndcChangedAttr[prop]
            });
          }
        }
      }
      var rule_failures = [];
      this.ndcRuleFailure.forEach(existing => {
        var attr = self.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase() == existing['attribute_name'].toLowerCase());
        if (attr.length > 0 && existing['attribute_status'] != null) {
          rule_failures.push(existing);
        }
      });

      if (this.ndcOtherDetails['route_user_id'] == 0) {
        this.ndcOtherDetails['route_user_id'] = this.user['user_id'];
      }
      if (this.ndcOtherDetails['reason_code'] == "" || this.ndcOtherDetails['reason_code'] == undefined) {
        this.ndcOtherDetails['reason_code'] = 0;
      }
      if (this.ndcOtherDetails['follow_up_date'] == undefined) { this.ndcOtherDetails['follow_up_date'] = ""; }
      if (this.ndcOtherDetails['reason_attribute_name'] == undefined) { this.ndcOtherDetails['reason_attribute_name'] = ""; }
      if (this.ndcOtherDetails['price_spec_id'] == undefined) { this.ndcOtherDetails['price_spec_id'] = 0; }
      if (this.ndcOtherDetails['pi_name'] == undefined) { this.ndcOtherDetails['pi_name'] = ""; }
      if (this.ndcOtherDetails['pi_link'] == undefined) { this.ndcOtherDetails['pi_link'] = ""; }
      if (this.ndcOtherDetails['price_spec_notes'] == undefined) { this.ndcOtherDetails['price_spec_notes'] = ""; }
      if (this.ndcOtherDetails['pi_status_date'] == undefined) { this.ndcOtherDetails['pi_status_date'] = ""; }
      if (this.ndcOtherDetails['reason_notes'] == undefined) { this.ndcOtherDetails['reason_notes'] = ""; }
      if (this.ndcOtherDetails['routing_notes'] == undefined) { this.ndcOtherDetails['routing_notes'] = ""; }
      debugger;
      workqueues.forEach(obj => {
        if (obj["attribute_name"] == "package_size_uom") {
          var size = workqueues.filter(obj => obj['attribute_name'] == 'package_size');
          var package_size_id = self.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase() == 'package_size')[0];
          if (size.length > 0) {
            obj["attribute_id"] = package_size_id['attribute_id'];
            obj["attribute_value"] = size[0]['attribute_value'] + '|' + obj["attribute_value"];
            obj["attribute_name"] = "package_size";
            var wqIndex = workqueues.findIndex(obj => obj['attribute_name'] == 'package_size_uom');
            if (wqIndex > 0) {
              workqueues.splice(wqIndex, 1);
            }
          } else {
            obj["attribute_value"] = (this.ndcSDDLAttributesBackup['package_size_uom'] == undefined ? "" : this.ndcSDDLAttributesBackup['package_size_uom']) + '|' + obj["attribute_value"];
            obj["attribute_name"] = "package_size";
            var wqIndex = workqueues.findIndex(obj => obj['attribute_name'] == 'package_size_uom');
            if (wqIndex > 0) {
              workqueues.splice(wqIndex, 1);
            }
          }
        }

        else if (obj["attribute_name"] == "package_size") {
          var uom = workqueues.filter(obj => obj['attribute_name'] == 'package_size_uom');
          var pkgsizNuom = obj["attribute_value"].split('|');
          if (pkgsizNuom > 0) {
            obj["attribute_value"] = pkgsizNuom[0];
          }
          if (uom.length > 0) {
            obj["attribute_value"] = obj["attribute_value"] + '|' + uom[0]['attribute_value'];
            var wqIndex = workqueues.findIndex(obj => obj['attribute_name'] == 'package_size_uom');
            if (wqIndex > 0) {
              workqueues.splice(wqIndex, 1);
            }
          } else {
            obj["attribute_value"] = obj["attribute_value"] + '|' + (this.ndcSDDLAttributesBackup['package_size_uom'] == undefined ? "" : this.ndcSDDLAttributesBackup['package_size_uom']);
          }
        }
      });

      var savedata = {
        "wt_id": this.ndcWtId,
        "pi_name": this.ndcOtherDetails['pi_name'],
        "pi_link": this.ndcOtherDetails['pi_link'],
        "pi_status_date": this.ndcOtherDetails['pi_status_date'],
        "price_spec_id": this.ndcOtherDetails['price_spec_id'],
        "price_spec_notes": this.ndcOtherDetails['price_spec_notes'],
        "publish_notes": this.ndcOtherDetails['publish_note'],
        "req_to_publish_notes": this.ndcOtherDetails['req_to_publish_note'],
        "follow_up_date": this.ndcOtherDetails['follow_up_date'],
        "loggedin_userid": this.user['user_id'],
        "wq_list": {
          "ndc": this.ndcNumber,
          "wt_id": this.ndcWtId,
          "user_id": this.ndcOtherDetails['route_user_id'],
          "wq_notes": this.ndcOtherDetails['reason_notes'],
          "reason_code": this.ndcOtherDetails['reason_code'],
          "queue_id": this.saveQueueId,
          "routing_queue_id ": this.saveQueueId,
          //this.ndcOtherDetails['work_queue'],
          "reason_attribute_id": this.ndcOtherDetails['reason_attribute_name'],
          "routing_notes": this.ndcOtherDetails['routing_notes'],
          "stage_id": 1,
          "workqueues": workqueues,
          "rule_failures": rule_failures
        }
      }
    }
    if (serviceType == "RequestPublish") {

      savedata['wq_list']['rjworkqueues'] = this.changedAttributeStatus();
      this.requestPublishServiceCall(savedata);
    } else if (serviceType == "Save") {
      savedata['wq_list']['rjworkqueues'] = this.changedAttributeStatus();
      this.saveServiceCall(savedata);
    } else {
      savedata['wq_list']['rjworkqueues'] = [];
      this.publish(savedata)
    }
    this.newNDC = false;
    this.setndcOtherDetails();
  }

  private changedAttributeStatus() {
    var allAttributes = this.attributeNameDropDown;
    var changedAttributes = this.ndcSDDLAttributes;
    var rjworkqueues = [];
    allAttributes.forEach(attr => {
      if (changedAttributes[0][attr.attribute_name.toLowerCase() + '_status'] != undefined && (changedAttributes[0][attr.attribute_name.toLowerCase() + '_status'] == 3 || changedAttributes[0][attr.attribute_name.toLowerCase() + '_status'] == 4)) {
        var obj = {};
        if (changedAttributes[0][attr.attribute_name.toLowerCase() + '_status'] == 3) {
          obj = {
            "data_source_id": changedAttributes[0]['data_source_id'],
            "wt_id": this.ndcWtId,
            "attribute_id": attr.attribute_id,
            "is_manual_review": null,
            "is_overide": "Y"
          }
        } else if (changedAttributes[0][attr.attribute_name.toLowerCase() + '_status'] == 4) {
          obj = {
            "data_source_id": changedAttributes[0]['data_source_id'],
            "wt_id": this.ndcWtId,
            "attribute_id": attr.attribute_id,
            "is_manual_review": "Y",
            "is_overide": null
          }
        }
        rjworkqueues.push(obj);
      }
    });
    return rjworkqueues;
  }

  private saveServiceCall(savedata) {
    this.ndcSvc.saveNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
      if (ndcData['Result'] != null || ndcData['Result'] == "Success") {
        toastr.success("NDC Resolution Page Data Saved Successfully");
        //this.releaseWorkQueueNdc();
        this.router.navigate(['home']);
      }
      else {
        toastr.error(ndcData['Result']);
      }
    });
  }

  private requestPublishServiceCall(savedata) {
    this.ndcSvc.requestPublishNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
      if (ndcData['Result'] != null || ndcData['Result'] == "Success") {
        toastr.success("NDC Resolution Page Data Saved and Requested for Publish Successfully");
        //this.releaseWorkQueueNdc();
        this.router.navigate(['home']);
      }
    });
  }

  private publish(savedata) {
    this.ndcSvc.publishNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
      if (ndcData['Result'] != null || ndcData['Result'] == "Success") {
        toastr.success("NDC Resolution Page Data Saved and Published Successfully");
        //this.releaseWorkQueueNdc();
        this.router.navigate(['home']);
      }
    });
  }

  private savePublish() {
    if (this.ndcOtherDetails['req_to_publish_note'] == '') {
      toastr.error("Request to publish Note cannot be empty");
    } else {
      this.save("RequestPublish");
      this.modalRequestPublish.hide();
      this.ndcOtherDetails['req_to_publish_note'] == '';
    }
  }

  private actualPublish() {

    if (this.ndcOtherDetails['publish_note'] == '') {
      toastr.error("publish Note cannot be empty");
    } else {
      this.modalPublish.hide();
      // this.ndcOtherDetails['publish_note'] == '';
      var errorList = [];
      var props = Object.getOwnPropertyNames(this.gridhead);
      props.forEach(prop => {
        if (this.ndcSDDLAttributes[0][prop] == "") {
          errorList.push(this.gridhead[prop] + '<br/>');
        }
      });
      if (errorList.length > 0) {
        errorList.splice(0, 0, 'Following are the error(s):<br/>')
        toastr.error(errorList.toString().replace(",", ""));
        return;
      }

      this.getChangedAttr(this.ndcSDDLAttributesBackup, this.ndcSDDLAttributes[0]);
      var self = this;
      var workqueues = [];

      for (var prop in this.ndcChangedAttr) {
        var attr = self.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase() == prop && obj['attribute_name'].toLowerCase() != this.attrubutStatus['attribute_name']);
        if (attr.length > 0) {
          workqueues.push({
            workqueue_id: 0,
            wq_queue_id: 1,
            attribute_id: attr[0]['attribute_id'],
            attribute_name: attr[0]['attribute_name'],
            attribute_value: this.ndcChangedAttr[prop]
          });
        }
      }
      if (this.ndcDiscrepancyAttributes != null) {
        this.ndcDiscrepancyAttributes.forEach(existing => {
          attr = self.attributeNameDropDown.filter(obj => obj['attribute_name'] == existing['attribute_name'] && obj['attribute_name'] != this.attrubutStatus['attribute_name']);
          if (attr.length > 0) {
            var wqIndex = workqueues.findIndex(obj => obj['attribute_name'] == attr[0]['attribute_name']);
            if (wqIndex != -1) {
              workqueues[wqIndex].workqueue_id = existing['workqueue_id'];
              workqueues[wqIndex].queue_id = existing['queue_id'];
              workqueues[wqIndex].attribute_id = attr[0]['attribute_id'];
            }
            else {
              workqueues.push({
                workqueue_id: existing['workqueue_id'],
                wq_queue_id: existing['queue_id'],
                attribute_id: existing['attribute_id'],
                attribute_name: existing['attribute_name'],
                attribute_value: existing['attribute_value']
              });
            }
          }
        });
      }
      var rule_failures = [];
      this.ndcRuleFailure.forEach(existing => {
        var attr = self.attributeNameDropDown.filter(obj => obj['attribute_name'] == existing['attribute_name']);
        if (attr.length > 0 && existing['attribute_status'] != null) {
          rule_failures.push(existing);
        }
      });

      if (this.ndcOtherDetails['route_user_id'] == 0) {
        this.ndcOtherDetails['route_user_id'] = this.user['user_id'];
      }
      if (this.ndcOtherDetails['reason_code'] == "" || this.ndcOtherDetails['reason_code'] == undefined) {
        this.ndcOtherDetails['reason_code'] = 0;
      }
      if (this.ndcOtherDetails['follow_up_date'] == undefined) { this.ndcOtherDetails['follow_up_date'] = ""; }
      if (this.ndcOtherDetails['reason_attribute_name'] == undefined) { this.ndcOtherDetails['reason_attribute_name'] = ""; }
      if (this.ndcOtherDetails['price_spec_id'] == undefined) { this.ndcOtherDetails['price_spec_id'] = 0; }
      if (this.ndcOtherDetails['pi_name'] == undefined) { this.ndcOtherDetails['pi_name'] = ""; }
      if (this.ndcOtherDetails['pi_link'] == undefined) { this.ndcOtherDetails['pi_link'] = ""; }
      if (this.ndcOtherDetails['price_spec_notes'] == undefined) { this.ndcOtherDetails['price_spec_notes'] = ""; }
      if (this.ndcOtherDetails['pi_status_date'] == undefined) { this.ndcOtherDetails['pi_status_date'] = ""; }
      if (this.ndcOtherDetails['reason_notes'] == undefined) { this.ndcOtherDetails['reason_notes'] = ""; }
      if (this.ndcOtherDetails['routing_notes'] == undefined) { this.ndcOtherDetails['routing_notes'] = ""; }

      workqueues.forEach(obj => {
        if (obj["attribute_name"] == "package_size_uom") {
          var size = workqueues.filter(obj => obj['attribute_name'] == 'package_size');
          var package_size_id = self.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase() == 'package_size')[0];
          if (size.length > 0) {
            obj["attribute_id"] = package_size_id['attribute_id'];
            obj["attribute_value"] = size[0]['attribute_value'] + '|' + obj["attribute_value"];
            obj["attribute_name"] = "package_size";
          } else {
            obj["attribute_id"] = package_size_id['attribute_id'];
            obj["attribute_value"] = (this.ndcSDDLAttributesBackup['package_size_uom'] == undefined ? "" : this.ndcSDDLAttributesBackup['package_size_uom']) + '|' + obj["attribute_value"];
            obj["attribute_name"] = "package_size";
          }
        } else if (obj["attribute_name"] == "package_size") {
          var uom = workqueues.filter(obj => obj['attribute_name'] == 'package_size_uom');
          var pkgsizNuom = obj["attribute_value"].split('|');
          if (pkgsizNuom > 0) {
            obj["attribute_value"] = pkgsizNuom[0];
          }
          if (uom.length > 0) {
            obj["attribute_value"] = obj["attribute_value"] + '|' + uom[0]['attribute_value'];
            var wqIndex = workqueues.findIndex(obj => obj['attribute_name'] == 'package_size_uom');
            if (wqIndex > 0) {
              workqueues.splice(wqIndex, 1);
            }
          } else {
            obj["attribute_value"] = obj["attribute_value"] + '|' + (this.ndcSDDLAttributesBackup['package_size_uom'] == undefined ? "" : this.ndcSDDLAttributesBackup['package_size_uom']);
          }
        }
      });
      //=========RJHSFOUN-766
      var newsddl = self.ndcSDDLAttributes[0];
      var sddl = self.ndcSDDLAttributesBackup;
      debugger;
      var finalNDC = {
        'sddlFinalWtId': this.ndcWtId,
        'genericName': (newsddl['generic_name'] != null || newsddl['generic_name'] != 'null') ? newsddl['generic_name'] : null,
        'brandName': (newsddl['brand_name'] != null || newsddl['brand_name'] != 'null') ? newsddl['brand_name'] : null,
        'strength': (newsddl['strength'] != null || newsddl['strength'] != 'null') ? newsddl['strength'] : null,
        'routeOfAdministration': (newsddl['route_of_administration'] != null || newsddl['route_of_administration'] != 'null') ? newsddl['route_of_administration'] : null,
        'dosageForm': (newsddl['dosage_form'] != null || newsddl['dosage_form'] != 'null') ? newsddl['dosage_form'] : null,
        'rxOTCIndicator': (newsddl['rx_otc_ind'] != null || newsddl['rx_otc_ind'] != 'null') ? newsddl['rx_otc_ind'] : null,
        'brandGenericIndicator': (newsddl['br_generic_indicator'] != null || newsddl['br_generic_indicator'] != 'null') ? newsddl['br_generic_indicator'] : null,
        'awpPrice': (newsddl['awp'] != null || newsddl['awp'] != 'null') ? newsddl['awp'] : null,
        'awpType': (newsddl['awp_lk_price_sub_type_id'] != null || newsddl['awp_lk_price_sub_type_id'] != 'null') ? newsddl['awp_lk_price_sub_type_id'] : null,
        'awpEffectiveDate': (newsddl['awp_price_effective_date'] != null || newsddl['awp_price_effective_date'] != 'null') ? newsddl['awp_price_effective_date'] : null,
        'wacPrice': (newsddl['wac'] != null || newsddl['wac'] != 'null') ? newsddl['wac'] : null,
        'wacType': (newsddl['wac_lk_price_sub_type_id'] != null || newsddl['wac_lk_price_sub_type_id'] != 'null') ? newsddl['wac_lk_price_sub_type_id'] : null,
        'wacEffectiveDate': (newsddl['wac_price_effective_date'] != null || newsddl['wac_price_effective_date'] != 'null') ? newsddl['wac_price_effective_date'] : null,
        'ndcStatus': (newsddl['ndc_status'] != null || newsddl['ndc_status'] != 'null') ? newsddl['ndc_status'] : null,
        'wtId': this.ndcWtId,
        's6Id': null,
        'sddlGenericName': (sddl['generic_name'] != null || sddl['generic_name'] != 'null') ? sddl['generic_name'] : null,
        'sddlBrandName': (sddl['brand_name'] != null || sddl['brand_name'] != 'null') ? sddl['brand_name'] : null,
        'sddlStrength': (sddl['strength'] != null || sddl['strength'] != 'null') ? sddl['strength'] : null,
        'sddlRouteOfAdministration': (sddl['route_of_administration'] != null || sddl['route_of_administration'] != 'null') ? sddl['route_of_administration'] : null,
        'sddlDosageForm': (sddl['dosage_form'] != null || sddl['dosage_form'] != 'null') ? sddl['dosage_form'] : null,
        'sddlRxOTCIndicator': (sddl['rx_otc_ind'] != null || sddl['rx_otc_ind'] != 'null') ? sddl['rx_otc_ind'] : null,
        'sddlAwpPrice': (sddl['awp'] != null || sddl['awp'] != 'null') ? sddl['awp'] : null,
        'sddlAwpType': (sddl['awp_lk_price_sub_type_id'] != null || sddl['awp_lk_price_sub_type_id'] != 'null') ? sddl['awp_lk_price_sub_type_id'] : null,
        'sddlAwpEffectiveDate': (sddl['awp_price_effective_date'] != null || sddl['awp_price_effective_date'] != 'null') ? sddl['awp_price_effective_date'] : null,
        'sddlWacPrice': (sddl['wac'] != null || sddl['wac'] != 'null') ? sddl['wac'] : null,
        'sddlWacType': (sddl['wac_lk_price_sub_type_id'] != null || sddl['wac_lk_price_sub_type_id'] != 'null') ? sddl['wac_lk_price_sub_type_id'] : null,
        'sddlWacEffectiveDate': (sddl['wac_price_effective_date'] != null || sddl['wac_price_effective_date'] != 'null') ? sddl['wac_price_effective_date'] : null,
        'sddlNdcStatus': (sddl['ndc_status'] != null || sddl['ndc_status'] != 'null') ? sddl['ndc_status'] : null
      }
      //=========RJHSFOUN-766 - END
      var savedata = {
        "wt_id": this.ndcWtId,
        "pi_name": this.ndcOtherDetails['pi_name'],
        "pi_link": this.ndcOtherDetails['pi_link'],
        "pi_status_date": this.ndcOtherDetails['pi_status_date'],
        "price_spec_id": this.ndcOtherDetails['price_spec_id'],
        "price_spec_notes": this.ndcOtherDetails['price_spec_notes'],
        "publish_notes": this.ndcOtherDetails['publish_note'],
        "req_to_publish_notes": this.ndcOtherDetails['req_to_publish_note'],
        "follow_up_date": this.ndcOtherDetails['follow_up_date'],
        "loggedin_userid": this.user['user_id'],
        "wq_list": {
          "ndc": this.ndcNumber,
          "wt_id": this.ndcWtId,
          "user_id": this.ndcOtherDetails['route_user_id'],
          "wq_notes": this.ndcOtherDetails['reason_notes'],
          "reason_code": this.ndcOtherDetails['reason_code'],
          "queue_id": this.saveQueueId,
          "routing_queue_id ": this.saveQueueId,
          //this.ndcOtherDetails['work_queue'],
          "reason_attribute_id": this.ndcOtherDetails['reason_attribute_name'],
          "routing_notes": this.ndcOtherDetails['routing_notes'],
          "stage_id": 1,
          "workqueues": workqueues,
          "rule_failures": rule_failures
        },
        "finalNDC": finalNDC
      }
      this.ndcSvc.publishNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
        if (ndcData['Result'] != null || ndcData['Result'] == "Success") {
          toastr.success("NDC Published Successfully");
          //this.releaseWorkQueueNdc();
          this.router.navigate(['home']);
        }
      });
    }
  }

  private cancel() {
    this.router.navigate(['home']);
  }

  private getChangedAttr(newObj, oldObj): Object {
    this.ndcChangedAttr = {};
    // Create arrays of property names
    var newProps = Object.getOwnPropertyNames(newObj);
    var oldProps = Object.getOwnPropertyNames(oldObj);
    delete newObj[""];
    delete oldObj[""];
    delete oldObj["package_quantity_status"];

    for (var i = 0; i < newProps.length; i++) {
      var propName = newProps[i];
      // Those property values are not equal
      if (newObj[propName] !== oldObj[propName]) {
        this.ndcChangedAttr[propName] = oldObj[propName];
      }
    }

    var Props = Object.getOwnPropertyNames(this.ndcChangedAttr);
    for (var loop = Props.length - 1; loop >= 0; loop--) {
      var statusProp = Props[loop] + 'Status';
      if (this.ndcChangedAttr[statusProp] != undefined) {
        delete this.ndcChangedAttr[Props[loop]];
        delete this.ndcChangedAttr[statusProp];
      }
    }

    return this.ndcChangedAttr;
  }

  private InitStatus() {
    this.attrubutStatus = {
      awp_status: 0,
      br_generic_indicator_status: 0,
      brand_name_status: 0,
      dosage_form_status: 0,
      generic_name_status: 0,
      inner_outer_package_indicator_status: 0,
      manufacturer_name_status: 0,
      ndc_status_date_status: 0,
      ndc_status_status: 0,
      package_description_status: 0,
      package_quantit_status: 0,
      package_size_status: 0,
      package_size_uom_status: 0,
      package_unit_dose_status: 0,
      repackager_ind_status: 0,
      route_of_administration_status: 0,
      rx_otc_ind_status: 0,
      sd_md_status: 0,
      strength_status: 0,
      tee_code_status: 0,
      wac_status: 0
    };
  }

  private sortByDescending(arrObj: any) {
    arrObj.sort(function (val1, val2) {
      if (val1.Id > val2.Id) {
        return -1;
      } else if (val1.Id < val2.Id) {
        return 1;
      } else {
        return 0;
      }
    });
  }

  private releaseWorkQueueNdc() {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this.ndc_hcpc_id = this.ndc_hcpc_id ? this.ndc_hcpc_id : this.ndcNumber;

    if (this.ndc_hcpc_id && this.queueId && this.user.user_id) {
      let objData = { "ndc_hcpc_id": this.ndc_hcpc_id, "queue_id": this.queueId, "user_id": this.user.user_id };
      this.ndcSvc.releaseWorkQueueNdc(objData).subscribe((res: any) => {
        var result = res.Result;
      })
    }
  }

  private getNdcAndLock(code: string, wtId: any, ndcStatus: string) {
    this.lockWorkQueueByUser(code, wtId);
    this.ndcStatus = ndcStatus;
    this.ndcList = new Array();
  }

  private lockWorkQueueByUser(code: string, wtId: any) {
    this.selectedCode = code;
    this.ndc_hcpc_id = code;
    this.queueId = 1;
    var userId = JSON.parse(localStorage.getItem('currentUser'));
    userId = userId['user_id'];

    let objData = { "ndc_hcpc_id": code, "queue_id": 1, "user_id": userId };
    this._datasvc.lockWorkQueueNdc(objData).subscribe((res: any) => {
      var result = res.Result;
      if (result == "Already locked by user") {
        this.modalLockExist.show();
      }
      else {
        this.getNDCByCode(code)
        this.modalNDCList.hide();
      }
    })
  }

  private viewNdcFailure() {
    this.router.navigate(['/ndcfailureReadOnly', this.selectedCode]);
  }

  private clearControls() {
    this.ndcOtherDetails = [];
    this.ndcOtherDetails = {};
    this.ndcOtherDetails['price_spec_id'] = 0;
    this.ndcOtherDetails['work_queue'] = 0;
    this.ndcOtherDetails['work_queue_type'] = 0;
    this.ndcOtherDetails['route_user_id'] = 0;

  }

  private clearNotes() {
    this.ndcOtherDetails['publish_note'] = "";
    this.ndcOtherDetails['req_to_publish_note'] = "";
  }

  private requestJson() {
    var self = this;
    var buildJson = {};
    var workqueues = [];
    //-------------------For New Ndc-----------------------
    //check all fildes are not blank from caller method
    self.attributeNameDropDown.forEach(element => {
      for (var prop in this.addNewNDC) {
        if (prop == element['attribute_name']) {
          workqueues.push({
            workqueue_id: 0,
            attribute_id: element['attribute_id'],
            attribute_name: element['attribute_name'],
            attribute_value: this.addNewNDC[prop]
          });
        }
      }
    });
    //-------------------For New Ndc End-------------------
    //-------------------For changes Attrbutes-------------
    var ndcAttributes = Object.getOwnPropertyNames(self.ndcSDDLAttributesBackup);
    var propName = '';
    var workqueueId = 0;
    var wqQueueId = 0;
    var wq_id = [];

    for (var i = 0; i < ndcAttributes.length; i++) {
      propName = ndcAttributes[i].toLowerCase().trim();
      switch (propName) {
        case 'generic_name':
        case 'brand_name':
        case 'strength':
        case 'route_of_administration':
        case 'dosage_form':
        case 'rx_otc_ind':
        case 'awp':
        case 'wac':
        case 'ndc_status':
        case 'br_generic_indicator':
        case 'package_size':
        case 'package_size_uom':
        case 'package_description':
        case 'package_unit_dose':
        case 'package_quantity':
        case 'repackager_ind':
        case 'sd_md':
        case 'tee_code':
        case 'inner_outer_package_indicator':
        case 'manufacturer_name':
        case 'cms_rebate':
          workqueueId = 0;
          wqQueueId = 1;
          if (self.ndcSDDLAttributesBackup[propName].toLowerCase().trim() != self.ndcSDDLAttributes[0][propName].toLowerCase().trim()) {
            var attr = self.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase().trim() == propName);
            if (self.ndcDiscrepancyAttributes != null) {
              wq_id = self.ndcDiscrepancyAttributes.filter(obj => obj['attribute_name'].toLowerCase() == propName);
              if (wq_id.length > 0) {
                workqueueId = wq_id[0]['workqueue_id'];
                wqQueueId = wq_id[0]['queue_id'];
              }
            }
            if (attr.length > 0) {
              workqueues.push({
                workqueue_id: workqueueId,
                wq_queue_id: wqQueueId,
                attribute_id: attr[0]['attribute_id'],
                attribute_name: attr[0]['attribute_name'],
                attribute_value: self.ndcSDDLAttributes[0][propName]
              });
            }
          }
          break;
        default:
          break;
      }
    }

    workqueues.forEach(obj => {
      if (obj["attribute_name"] == "package_size_uom") {
        var size = workqueues.filter(obj => obj['attribute_name'] == 'package_size');
        if (size.length > 0) {
          obj["attribute_value"] = size[0]['attribute_value'] + '|' + obj["attribute_value"];
          obj["attribute_name"] = "package_size";
          var wqIndex = workqueues.findIndex(obj => obj['attribute_name'] == 'package_size_uom');
          workqueues.splice(wqIndex, 1);
        } else {
          obj["attribute_value"] = (this.ndcSDDLAttributesBackup['package_size_uom'] == undefined ? "" : this.ndcSDDLAttributesBackup['package_size_uom']) + '|' + obj["attribute_value"];
          obj["attribute_name"] = "package_size";
          var wqIndex = workqueues.findIndex(obj => obj['attribute_name'] == 'package_size_uom');
          workqueues.splice(wqIndex, 1);
        }
      } else if (obj["attribute_name"] == "package_size") {
        var uom = workqueues.filter(obj => obj['attribute_name'] == 'package_size_uom');
        var pkgsizNuom = obj["attribute_value"].split('|');
        if (pkgsizNuom > 0) {
          obj["attribute_value"] = pkgsizNuom[0];
        }
        if (uom.length > 0) {
          obj["attribute_value"] = obj["attribute_value"] + '|' + uom[0]['attribute_value'];
          var wqIndex = workqueues.findIndex(obj => obj['attribute_name'] == 'package_size_uom');
          workqueues.splice(wqIndex, 1);
        } else {
          obj["attribute_value"] = obj["attribute_value"] + '|' + (this.ndcSDDLAttributesBackup['package_size_uom'] == undefined ? "" : this.ndcSDDLAttributesBackup['package_size_uom']);
        }
      }
    });

    //-------------------For changes Attrbutes End-------------------
    var ruleFailures = [];
    this.ndcRuleFailure.forEach(existing => {
      var attr = self.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase().trim() == existing['attribute_name'].toLowerCase().trim());
      if (attr.length > 0 && existing['attribute_status'] != null) {
        var objRF = {
          "workqueue_id": existing['workqueue_id'],
          "attribute_id": existing['attribute_id'],
          "attribute_status": existing['attribute_status']
        }
        ruleFailures.push(objRF);
      }
    });

    buildJson['loggedin_userid'] = this.user['user_id'];
    buildJson['wt_id'] = this.ndcWtId;
    buildJson['pi_name'] = this.ndcOtherDetails['pi_name'] != undefined ? this.ndcOtherDetails['pi_name'] : "";
    buildJson['pi_link'] = this.ndcOtherDetails['pi_link'] != undefined ? this.ndcOtherDetails['pi_link'] : "";
    buildJson['pi_status_date'] = this.ndcOtherDetails['pi_status_date'] != undefined ? this.ndcOtherDetails['pi_status_date'] : "";
    buildJson['price_spec_id'] = this.ndcOtherDetails['price_spec_id'] != undefined ? this.ndcOtherDetails['price_spec_id'] : "";
    buildJson['price_spec_notes'] = this.ndcOtherDetails['price_spec_notes'] != undefined ? this.ndcOtherDetails['price_spec_notes'] : "";
    buildJson['follow_up_date'] = this.ndcOtherDetails['follow_up_date'] != undefined ? this.ndcOtherDetails['follow_up_date'] : "";

    buildJson['wq_list'] = {
      "ndc": this.ndcNumber,
      "wt_id": this.ndcWtId,
      "user_id": this.ndcOtherDetails['route_user_id'],
      "stage_id": 1,
      "queue_id": this.saveQueueId,
      "wq_notes": this.ndcOtherDetails['reason_notes'] != undefined ? this.ndcOtherDetails['reason_notes'] : "",
      "reason_code": this.ndcOtherDetails['reason_code'] != "" || this.ndcOtherDetails['reason_code'] != undefined ? this.ndcOtherDetails['reason_code'] : 0,
      "reason_attribute_id": this.ndcOtherDetails['reason_attribute_name'] != undefined ? this.ndcOtherDetails['reason_attribute_name'] : "",
      "routing_queue_id": this.saveQueueId,
      "route_user_id": this.ndcOtherDetails['route_user_id'] != 0 ? this.ndcOtherDetails['route_user_id'] : this.user['user_id'],
      "routing_notes": this.ndcOtherDetails['routing_notes'] != undefined ? this.ndcOtherDetails['routing_notes'] : "",
      "workqueues": workqueues,
      "rule_failures": ruleFailures
    }

    buildJson['wq_list']['rjworkqueues'] = this.changedAttributeStatus();

    return buildJson;
  }

}