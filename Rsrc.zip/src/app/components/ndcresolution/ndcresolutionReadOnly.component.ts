/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, HostListener, Renderer } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs/Rx';

import { ConfigService } from '../../services/shared/config.service';
import { NDCFailureGridHead, NDCFailureMessage, WorkQueueType, DataSources } from '../../services/shared/config.const';
import { INDC_ATTRIBUTES, INDC_ATTRIBUTES_STATUS, INDC_PRICE_HISTORY, IUSER_MASTER, IDS_RJ_MAP, IWORKQUEUE_MAPPING } from '../../shared/interfaces/entities.interface';
import { GlobalService } from '../../services/shared/global.service';
import { DataService } from '../../services/data.service';
import { NdcResolutionService } from '../../services/ndcresolution.service';
import { PriceHistoryService } from '../../services/pricehistory.service';
import { ConversionService } from '../../services/conversion.service';

import { DropDown } from '../../shared/common';

import { ModalComponent } from '../shared/modalpopup.component';

declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'app-ndcfailure-readOnly',
  templateUrl: './ndcresolutionReadOnly.component.html?v=${new Date().getTime()}',
  providers: [NdcResolutionService, DataService, PriceHistoryService, ConversionService]
})
export class NdcResolutionOnlyComponent implements OnInit, AfterViewInit {

  user: IUSER_MASTER;
  mockRuleFailureUpdate: any;
  mockWorkQueue: DropDown[];
  reasonCodeDropDown: DropDown[];
  attributeNameDropDown: any;
  workQueueType: any;
  users: any;

  viewMode: boolean = false;
  ndcSearchResult: any[] = new Array();
  ndcSearchCode: string = '';
  ndcNumber: string = '';
  ndcWtId: number = 0;
  //prescribinginformation: Object;
  ndcDSAttributes: any;
  ndcRJAttributes: any;
  ndcSDDLAttributesBackup: any;
  ndcSDDLAttributes: any;
  ndcDiscrepancyAttributes: any;
  ndcChangedAttr: Object;
  ndcOtherDetails: Object;
  ndcRuleFailure: any[] = new Array();
  attrubutStatus: INDC_ATTRIBUTES_STATUS = {} as INDC_ATTRIBUTES_STATUS;

  msView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  fdbView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  rjView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  gsView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  msshow: boolean = true;
  fdbshow: boolean = true;
  rjshow: boolean = true;
  gsShow: boolean = true;

  conversionTranslate: any; //IDS_RJ_MAP = {} as IDS_RJ_MAP;
  selectedSuperSix: string = '';
  statusProp: string = '';

  newNDC: boolean = false;
  isNewNDC: boolean = false;
  priceHistoryshow: boolean = false;
  activePricing: string;
  ndcAWPWACHistoryBackup: INDC_PRICE_HISTORY[] = [] as INDC_PRICE_HISTORY[];
  ndcAWPWACHistory: INDC_PRICE_HISTORY[] = [] as INDC_PRICE_HISTORY[];

  isAddNDC: boolean = false;
  options: string[];
  datasources: any;
  pricespecification: any;
  activeHistoryTab: string;
  contexMenu;
  message;
  gridhead: any;

  @ViewChild('modalNDCList') modalNDCList: ModalComponent;
  @ViewChild('modalPublish') modalNPublish: ModalComponent;
  @ViewChild('fdbTab') div: ElementRef;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private configsvc: ConfigService,
    private elementRef: ElementRef,
    private ndcSvc: NdcResolutionService<INDC_ATTRIBUTES>,
    private dataSvc: DataService,
    private pricehistorySvc: PriceHistoryService<INDC_PRICE_HISTORY>,
    private conversionSvc: ConversionService<IDS_RJ_MAP>,
    private _globalSev: GlobalService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {
    this.isAddNDC = false;
    this.ndcNumber = this.route.snapshot.params['workqueue'];
    this.gridhead = NDCFailureGridHead;
    this.getNDCByCode(this.ndcNumber);
    this.message = NDCFailureMessage;
    this.contexMenu = this.configsvc.getcontexMenu();
    this.contexMenu.forEach(cm => cm.subject.subscribe(val => this.setStatus(val)));

    this.dataSvc.getDropdownData().subscribe((res: any) => {
      this.mockRuleFailureUpdate = res.mockRuleFailureUpdate;
      this.workQueueType = WorkQueueType;
      this.reasonCodeDropDown = res.HcpcNdcReasonCode;
    })
    this.dataSvc.getAllAttribute().subscribe((res: any) => {
      this.attributeNameDropDown = res['Result'];
    });
    this.dataSvc.getWorkQueueName().subscribe((res: any) => {
      this.mockWorkQueue = res;
    });
    this.dataSvc.getDataSource().subscribe((res: any) => {
      this.datasources = res['Result'];
    });
    this.setndcOtherDetails();
  }

  ngAfterViewInit() {
    $('#nextDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.ndcOtherDetails['followUp_date'] = event.target.value;
    });

    $('#piDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.ndcOtherDetails['pi_StatusDate'] = event.target.value;
    });

  }

  search() {
    if (this.ndcSearchCode.trim() == '') {
      toastr.error("Please enter NDC Code");
      return;
    } else {
      //this.modalNDCList.show();
      // if (this.ndcSearchCode.trim().length > 3) {
      this.dataSvc.getDistinctNDC(this.ndcSearchCode.trim()).subscribe((res: any) => {
        this.ndcSearchResult = res['Result'];
        if (this.ndcSearchResult.length == 0) {
          toastr.info("Record Not Found");
          return;
        }

        this.modalNDCList.show();
      });
      //}
    }
  }


  private getNDCByCode(code: string): any {

    this.ndcNumber = code;
    var ndcAttributesNew = [];
    if (this.ndcSearchResult.length > 0) {
      this.ndcWtId = this.ndcSearchResult.filter(obj => obj.ndc == code)[0]['wt_id'];
    }

    if (code != undefined) {
      this.ndcSvc.getNDCByNDC(code).subscribe((ndcattributes: INDC_ATTRIBUTES[]) => {
        //ashish
        if (ndcattributes != null) {
          ndcattributes.forEach(obj => {
            switch (obj.data_source_id) {
              case 1:
              case 2:
              case 3:
              case 4:
                var ifExist = ndcAttributesNew.filter(item => item.data_source_id == obj.data_source_id);
                if (ifExist.length == 0) {
                  if (obj['history'] == undefined) {
                    var historyToAdd = [];
                    var history = ndcattributes.filter(item => item.data_source_id == obj.data_source_id);
                    if (history.length > 1) {
                      for (var i = 1; i < history.length; i++) {
                        historyToAdd.push(history[i]);
                      }
                    }
                    obj['history'] = historyToAdd;
                    obj['showHistory'] = false;
                  }
                  ndcAttributesNew.push(obj);
                }
                break;
              case 6:
                var ifExist = ndcAttributesNew.filter(item => item.data_source_id == obj.data_source_id);
                if (ifExist.length == 0) {
                  var historyToAdd = [];
                  var history = ndcattributes.filter(item => item.data_source_id == obj.data_source_id);
                  if (history.length > 1) {
                    for (var i = 0; i < history.length; i++) {
                      ndcAttributesNew.push(history[i]);
                      break;
                    }
                  }
                }
                break;
              default:
                obj['history'] = [];
                obj['showHistory'] = false;
                ndcAttributesNew.push(obj);
                break;
            }
          });
        }
        //ashish closed
        this.ndcDSAttributes = ndcAttributesNew;
        this.ndcSDDLAttributes = ndcattributes.filter(obj => obj.data_source_id == 6);
        if (this.ndcSDDLAttributes != null && this.ndcSDDLAttributes.length != 0) {
          this.ndcWtId = this.ndcSDDLAttributes[0].wt_id;

          this.ndcSvc.getNDCPrescribingInformation(this.ndcWtId).subscribe((ndcprescribinginformation) => {
            if (ndcprescribinginformation != null) {
              this.ndcOtherDetails['pi_name'] = ndcprescribinginformation[0]['pi_name'];
              this.ndcOtherDetails['pi_link'] = ndcprescribinginformation[0]['pi_link'];
              this.ndcOtherDetails['pi_status_date'] = ndcprescribinginformation[0]['pi_status_date'];
            }
          });

          this.ndcSvc.getNDCPriceSpecificationNDCDetail(this.ndcWtId).subscribe((ndcPriceSpecification) => {
            if (ndcPriceSpecification != null && ndcPriceSpecification.length > 0) {
              this.ndcOtherDetails['price_spec_id'] = ndcPriceSpecification[0]['price_spec_id'];
              this.ndcOtherDetails['price_spec_notes'] = ndcPriceSpecification[0]['note_description'];
            }
          });
        }
        else {
          this.ndcWtId = 0;
        }
        this.InitStatus();

        var statusProps = Object.getOwnPropertyNames(this.attrubutStatus);
        if (this.ndcSDDLAttributes.length <= 0) {
          this.ndcSDDLAttributes[0] = this.attrubutStatus;
        }
        statusProps.forEach(prop => {
          this.ndcSDDLAttributes[0][prop] = 0
        });

        this.ndcSvc.getNDCRuleFailure(code).subscribe((ndcrulefailure) => {
          if (ndcrulefailure.length > 0) {
            this.ndcRuleFailure = ndcrulefailure;
            
            this._globalSev.stage_id = ndcrulefailure["stage_id"];
            if (this.ndcRuleFailure.length > 0) {
              this.ndcSvc.getDiscrepancyAttributes(code).subscribe((workqueitems: IWORKQUEUE_MAPPING[]) => {
                this.ndcDiscrepancyAttributes = workqueitems;
                if (this.ndcDiscrepancyAttributes != null && this.ndcSDDLAttributes[0] != null) {
                  this.ndcDiscrepancyAttributes.forEach(obj => {

                    switch (obj["attribute_name"].toLowerCase()) {
                      case "generic_name": this.ndcSDDLAttributes[0]['generic_name'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['generic_name_status'] = 2; break;
                      case "brand_name": this.ndcSDDLAttributes[0]['brand_name'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['brand_name_status'] = 2; break;
                      case "strength": this.ndcSDDLAttributes[0]['strength'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['strength_status'] = 2; break;
                      case "route_of_administration": this.ndcSDDLAttributes[0]['route_of_administration'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['route_of_administration_status'] = 2; break;
                      case "dosage_form": this.ndcSDDLAttributes[0]['dosage_form'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['dosage_form_status'] = 2; break;
                      case "rx_otc_ind": this.ndcSDDLAttributes[0]['rx_otc_ind'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['rx_otc_ind_status'] = 2; break;
                      case "awp": this.ndcSDDLAttributes[0]['awp'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['awp_status'] = 2; break;
                      case "wac": this.ndcSDDLAttributes[0]['wac'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['wac_status'] = 2; break;
                      case "ndc_status": this.ndcSDDLAttributes[0]['ndc_status'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['ndc_status_status'] = 2; break;
                      case "ndc_status_date": this.ndcSDDLAttributes[0]['ndc_status_date'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['ndc_status_date_status'] = 2; break;
                      case "br_generic_indicator": this.ndcSDDLAttributes[0]['br_generic_indicator'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['br_generic_indicator_status'] = 2; break;
                      case "package_size_uom":

                        this.ndcSDDLAttributes[0]['package_size_uom'] = obj["attribute_value"];
                      case "package_size":

                        this.ndcSDDLAttributes[0]['package_size'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_size_status'] = 2;
                        if (this.ndcSDDLAttributes[0]['package_size'] != null) {
                          // this.ndcSDDLAttributes[0]['package_size']=this.ndcSDDLAttributes[0]['package_size'] +'|'+ this.ndcSDDLAttributes[0]['package_size_uom'];
                          var pkgUOM = this.ndcSDDLAttributes[0]['package_size'].split("|");
                          if (pkgUOM.length > 0) {
                            this.ndcSDDLAttributes[0]['package_size'] = pkgUOM[0];
                            this.ndcSDDLAttributes[0]['package_size_uom'] = pkgUOM[1] == undefined ? "" : pkgUOM[1];
                          }
                        }
                        break;

                      //case "package_size_uom": this.ndcSDDLAttributes[0]['package_size_uom'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_size_uom_status'] = 2; break;
                      case "package_description": this.ndcSDDLAttributes[0]['package_description'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_description_status'] = 2; break;
                      case "package_unit_dose": this.ndcSDDLAttributes[0]['package_unit_dose'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_unit_dose_status'] = 2; break;
                      case "package_quantity": this.ndcSDDLAttributes[0]['package_quantity'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_quantit_status'] = 2; break;
                      case "repackager_ind": this.ndcSDDLAttributes[0]['repackager_ind'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['repackager_ind_status'] = 2; break;
                      case "sd_md": this.ndcSDDLAttributes[0]['sd_md'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['sd_md_status'] = 2; break;
                      case "tee_code": this.ndcSDDLAttributes[0]['tee_code'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['tee_code_status'] = 2; break;
                      case "inner_outer_package_indicator": this.ndcSDDLAttributes[0]['inner_outer_package_indicator'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['inner_outer_package_indicator_status'] = 2; break;
                      case "manufacturer_name": this.ndcSDDLAttributes[0]['manufacturer_name'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['manufacturer_name_status'] = 2; break;
                      case "cms_rebate": this.ndcSDDLAttributes[0]['cms_rebate'] = obj["attribute_value"]; break;
                      case "created_date": this.ndcSDDLAttributes[0]['created_date'] = obj["attribute_value"]; break;
                    }
                  });
                }

                //this.ndcSDDLAttributesBackup = Object.assign({}, this.ndcSDDLAttributes[0]);
                this.ndcSDDLAttributesBackup = JSON.parse(JSON.stringify(this.ndcSDDLAttributes[0]));

                //check ndcRuleFailure to change status and create link
                var self = this;
                var ths = Array.prototype.slice.call(document.getElementById("grid").getElementsByTagName("th"));
                this.ndcRuleFailure.forEach(function (obj) {
                  var status = obj['attribute_name'];
                  // self.ndcSDDLAttributes[0][status.toLowerCase() + '_status'] = 2;
                  // self.ndcSDDLAttributesBackup[status.toLowerCase() + '_status'] = 2;
                  if (obj['attribute_name'].toLowerCase() != 'awp' && obj['attribute_name'].toLowerCase() != 'wac' && obj['attribute_name'].toLowerCase() != 'ndc_status') {
                    var link = document.createElement("a");
                    link.setAttribute('href', "javascript:void(0)");
                    link.innerHTML = self.gridhead[status.toLowerCase()];
                    ths.forEach((th) => {
                      if (th.innerHTML.trim() == link.innerHTML.trim()) {
                        link.addEventListener("click", self.showCTpopup.bind(self));
                        th.innerHTML = '';
                        th.appendChild(link);
                      }
                    });
                  }
                });
              });

            }
          }
          else {
            // this.ndcSDDLAttributesBackup = Object.assign({}, this.ndcSDDLAttributes[0]);
            this.ndcSDDLAttributesBackup = JSON.parse(JSON.stringify(this.ndcSDDLAttributes[0]));
          }

          var prop = status.slice(0, -7);
          if (prop.trim().length > 0) {
            if (this.ndcSDDLAttributesBackup[prop] != event) {
              this.ndcSDDLAttributes[0][status] = 1;
            } else {
              this.ndcSDDLAttributes[0][status] = this.ndcSDDLAttributesBackup[status];
            }
          }

        });
        this.ndcSvc.getNDCPriceSpecificationDropDown().subscribe((pricespecification) => {
          this.pricespecification = pricespecification;
        });
      });
    }
    this.ndcSearchCode = '';
  }

  modelChange(status, event) {
    var prop = status.slice(0, -7);
    if (status != '') {
      if (this.ndcSDDLAttributesBackup[prop] != event) {
        
        this.ndcSDDLAttributes[status] = 1;
      } else {
        this.ndcSDDLAttributes[status] = this.ndcSDDLAttributesBackup[status];
      }
    }
  }

  showhide(ds: number) {
    if (this.isNewNDC == false) {
      switch (ds) {
        case 2:
          this.fdbshow = !this.fdbshow;
          this.fdbshow = !this.fdbshow;
          if (this.fdbView.length == 0) {
            this.fdbView = this.ndcDSAttributes.filter(X => X.data_source_id == ds)[0]['history'];
          }
          break;
        case 4:
          this.gsShow = !this.gsShow;
          if (this.gsView.length == 0) {
            this.gsView = this.ndcDSAttributes.filter(X => X.data_source_id == ds)[0]['history'];
          }
          break;
        case 6:
          this.rjshow = !this.rjshow;
          if (this.rjView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((rjView: INDC_ATTRIBUTES[]) => {
              this.rjView = rjView;
            })
          }
          break;
        case 7:
          this.msshow = !this.msshow;
          if (this.msView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((msView: INDC_ATTRIBUTES[]) => {
              
              this.msView = msView;
            })
          }
          break;
      }
    }
  }

    private showCTpopup(e) {
      debugger;
    if (e.srcElement.innerHTML != 'AWP Pr' && e.srcElement.innerHTML != 'WAC Pr' && e.srcElement.innerHTML != "Status") {
      this.selectedSuperSix = e.srcElement.innerHTML;
      var key = Object.keys(NDCFailureGridHead).find(key => NDCFailureGridHead[key] === e.srcElement.innerHTML);
      // this.conversionSvc.getConversionTranslation(key).subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
      //   this.conversionTranslate = ndcSuperSix['Result'];
      //   var x = document.getElementById("CTPopup");
      //   x.style.position = "relative";
      //   x.style.left = '550.5px';
      //   x.style.top = '-1926px';
      //   x.style.display = 'block';
      // });

      //==RUM-417=====      
      var attributesValues = this.ndcDSAttributes.map(a => a[key]);
      var uniqueattributValues = attributesValues.filter((x, i, a) => a.indexOf(x) == i);
      var rjDetails = [];
      if (uniqueattributValues != null && uniqueattributValues.length > 0) {
        uniqueattributValues.forEach(element => {
          var result = this.ndcDSAttributes.filter(item => item[key] == element);
          if (result != null && result.length > 1) {
            result.forEach(item => {
              var objRJDetails = {
                "wt_id": item.wt_id,
                "source_value": element,
                "data_source": item.data_source_name
              }
              rjDetails.push(objRJDetails);
            });
          }

          if (result != null && result.length == 1) {
            var objRJDetails = {
              "wt_id": result[0].wt_id,
              "source_value": element,
              "data_source": result[0].data_source_name
            }
            rjDetails.push(objRJDetails);
          }
        });

        var pullconversionTranslationMappingDataForNDC = {
          "attribute_name": key,
          "rjDetails": rjDetails
        }

        this.ndcSvc.getconversionTranslationMappingDataForNDC(pullconversionTranslationMappingDataForNDC).subscribe((conversionTranslationMap: INDC_ATTRIBUTES[]) => {

          this.conversionTranslate = conversionTranslationMap;
          var x = document.getElementById("CTPopup");
          x.style.position = "relative";
          x.style.left = '550.5px';
          x.style.top = '-1026px';
          x.style.display = 'block';

        });
      }
    }

    // var wt_id  = this.ndcDSAttributes.map(a => a[wt_id]);      
    //var uniqueattributValues=result.filter((x, i, a) => a.indexOf(x) == i);
    // if(uniqueattributValues!=null && uniqueattributValues.length>0)
    // for (var m = 0; m < uniqueattributValues.length; m++) {
    // this.conversionTranslate=this.conversionTranslate.filter(sc=>sc.ds_value==uniqueattributValues[m]); 
    //}

  }


  closeCTpopup() {
    var x = document.getElementById("CTPopup");
    x.style.display = 'none';
  }

  showhistory(ds, data_source_id, attribute_name) {
    this.activeHistoryTab = ds;
    this.activePricing = attribute_name;
    this.pricehistorySvc.getPriceHistory(this.ndcNumber, attribute_name).subscribe((pricehistory: INDC_PRICE_HISTORY[]) => {
      pricehistory.forEach((obj) => {
        this.ndcAWPWACHistoryBackup.push(obj);
      });
      this.ndcAWPWACHistory = this.ndcAWPWACHistoryBackup.filter(obj => obj.data_source_id === data_source_id && obj['attribute_name'] === attribute_name);
      this.priceHistoryshow = true;
    });
    this.ndcAWPWACHistoryBackup = [] as INDC_PRICE_HISTORY[];
  }

  closePriceHistory() {
    this.priceHistoryshow = false;
  }

  contexMenuClick(prop) {
    this.statusProp = prop;
  }

  setndcOtherDetails() {
    this.ndcOtherDetails = {
      reason_notes: "",
      reason_code: "",
      pi_name:"",
      pi_link: "",
      pi_status_date: new Date(),
      price_spec_id: 0,
      price_spec_notes: '',
      follow_up_date: "",
      work_queue: 0,
      work_queue_type: 0,
      route_user_id: 0,
      routing_notes: '',
      req_to_publish_note: '',
      reason_attribute_id: ''
    }
  }

  setStatus(id) {
    var prop = this.statusProp.slice(0, -7);
    //var maxId: number = Math.max.apply(Math, this.ndcDSAttributes.DataSource.RJ.map(function (o) { return o.Id; }))
    var updatedData = Object.assign({}, this.ndcSDDLAttributes);
    if (updatedData[prop] === this.ndcSDDLAttributesBackup[prop]) {
      toastr.error('Status not allowed to <br> change on old value');
      return;
    }

    // switch case not required directly assin id
    switch (id) {
      case 0: //Failure Resolved
        this.ndcSDDLAttributes[this.statusProp] = 0;
        this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        break;
      case 1: //Follow-Up
        //this.ndcSDDLAttributes[this.statusProp] = 1;
        break;
      case 2: //Further Routing
        //this.ndcSDDLAttributes[this.statusProp] = 2;
        break;
      case 3: //override value
        this.ndcSDDLAttributes[this.statusProp] = 3;
        if (this.ndcSDDLAttributesBackup[status] == undefined) {
          this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        }
        break;
      case 4: //Change Review
        this.ndcSDDLAttributes[this.statusProp] = 4;
        if (this.ndcSDDLAttributesBackup[status] == undefined) {
          this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        }
        break;
      default:
        toastr.info('Invalid selection');
        break;
    }
    this.statusProp = '';
  }

  addNDC() {
    this.isAddNDC = true;
    if (this.newNDC == false) {
      //var maxId: number = Math.max.apply(Math, this.ndcSDDLAttributes.map(function (o) { return o.Id; }))
      //var objNewNDC = { "Id": maxId + 1, "Generic_Name": "", "Generic_NameStatus": 0, "Brand_Name": "", "Brand_NameStatus": 0, "Strenth": "", "StrenthStatus": 0, "RoA": "", "RoAStatus": 0, "DF": "", "DFStatus": 0, "Rx_OTC_Ind": "", "Rx_OTC_IndStatus": 0, "AWPPrice": "", "AWPPriceStatus": 0, "WACPrice": "", "WACPriceStatus": 0, "Br_Generic_Indicator": "", "Br_Generic_IndicatorStatus": 0, "Package_Size": "", "Package_SizeStatus": 0, "Package_Size_UoM": "", "Package_Size_UoMStatus": 0, "Package_Description": "", "Package_DescriptionStatus": 0, "Package_Unit_Dose": "", "Package_Unit_DoseStatus": 0, "Package_Quantity": "", "Package_QuantityStatus": 0, "Repackager_Ind": "", "Repackager_IndStatus": 0, "SD_MD": "", "SD_MDStatus": 0, "Tee_Code": "", "Tee_CodeStatus": 0, "IO_Pkg_Ind": "", "IO_Pkg_IndStatus": 0, "Manufacturer_Name": "", "Manufacturer_NameStatus": 0, "CMS_Rebet": "", "CMS_RebetStatus": 0, "Date": "", "DateStatus": 0, "Reason": "", "ReasonStatus": 0 };    //this.msView=new Array();
      //this.ndcSDDLAttributes.unshift(objNewNDC);
      this.newNDC = true;
      //this.showhide("RJ");
    } else {
      toastr.error("Add Multiple NDC Not Allow");
    }
  }
  
  cancel() {
    this.router.navigate(['home']);
  }
  getChangedAttr(newObj, oldObj): Object {
    this.ndcChangedAttr = {};
    // Create arrays of property names
    var newProps = Object.getOwnPropertyNames(newObj);
    var oldProps = Object.getOwnPropertyNames(oldObj);
    delete newObj[""];
    delete oldObj[""];
    delete oldObj["package_quantity_status"];

    // If number of properties are different
    // if (newProps.length != oldProps.length) {
    //   return this.ndcChangedAttr;
    // }

    for (var i = 0; i < newProps.length; i++) {
      var propName = newProps[i];
      // Those property values are not equal
      if (newObj[propName] !== oldObj[propName]) {
        this.ndcChangedAttr[propName] = oldObj[propName];
      }
    }

    var Props = Object.getOwnPropertyNames(this.ndcChangedAttr);
    for (var loop = Props.length - 1; loop >= 0; loop--) {
      var statusProp = Props[loop] + 'Status';
      if (this.ndcChangedAttr[statusProp] != undefined) {
        delete this.ndcChangedAttr[Props[loop]];
        delete this.ndcChangedAttr[statusProp];
      }
    }

    return this.ndcChangedAttr;
  }

  InitStatus() {
    this.attrubutStatus = {
      awp_status: 0,
      br_generic_indicator_status: 0,
      brand_name_status: 0,
      dosage_form_status: 0,
      generic_name_status: 0,
      inner_outer_package_indicator_status: 0,
      manufacturer_name_status: 0,
      ndc_status_date_status: 0,
      ndc_status_status: 0,
      package_description_status: 0,
      package_quantit_status: 0,
      package_size_status: 0,
      package_size_uom_status: 0,
      package_unit_dose_status: 0,
      repackager_ind_status: 0,
      route_of_administration_status: 0,
      rx_otc_ind_status: 0,
      sd_md_status: 0,
      strength_status: 0,
      tee_code_status: 0,
      wac_status: 0
    };
  }
  sortByDescending(arrObj: any) {
    arrObj.sort(function (val1, val2) {
      if (val1.Id > val2.Id) {
        return -1;
      } else if (val1.Id < val2.Id) {
        return 1;
      } else {
        return 0;
      }
    });
  }
}

