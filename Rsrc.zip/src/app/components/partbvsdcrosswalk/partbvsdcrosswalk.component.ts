import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { GlobalService } from "./../../services/shared/global.service";
import { DataService } from '../../services/data.service';
import { NDCPartBvsDService } from '../../services/NDCPartBvsD.service';
import { IBD_SPEC } from '../../shared/interfaces/entities.interface';
import { IUSER_MASTER, IPART_BVSD_SUPER_SIX_MAP, INDC_ATTRIBUTES } from '../../shared/interfaces/entities.interface';
import { ModalComponent } from '../shared/modalpopup.component';

import { DropDown } from '../../shared/common';

import { WorkQueueType, Sections } from '../../services/shared/config.const';

declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'app-partbvsdcrosswalk',
  templateUrl: './partbvsdcrosswalk.component.html?v=${new Date().getTime()}',
  providers: [NDCPartBvsDService, DataService]
})

export class PartBvsDCrossWalkComponent implements OnInit, AfterViewInit {
  user: IUSER_MASTER;
  SelectedpartBvsD: number = 0;
  SelectedpartBvsDName: string = "";
  bvsdNDCDeatilsDataList: IPART_BVSD_SUPER_SIX_MAP[];
  bvsdDeleted: IPART_BVSD_SUPER_SIX_MAP[];
  bvsdDataListFilter: IPART_BVSD_SUPER_SIX_MAP[];
  bvsdDataListBackup: IPART_BVSD_SUPER_SIX_MAP[];
  bvsdDataListEditable: IPART_BVSD_SUPER_SIX_MAP[];
  newPartBvDCombination: IPART_BVSD_SUPER_SIX_MAP = {} as IPART_BVSD_SUPER_SIX_MAP;
  bvsDRuleFailure: any[] = new Array();
  bvsDdataInstance: IPART_BVSD_SUPER_SIX_MAP;

  isAddRow: boolean = false;
  isEditRow: boolean = false;
  bvsdName: any;
  ROAName: any;
  DFName: any;
  RXOTCName: any;

  sectionList: any[];
  direction: number;
  isDesc: boolean = false;
  column: string = 'narratives_name';
  columnSelected: any;
  statusProp: string = '';
  partBvsDReasonNotes: any[] = new Array();
  sortDropDown: DropDown[];

  bvsDDropdown: DropDown[];
  dosageFormDropdown: DropDown[];
  ROADropdown: DropDown[];
  rxOTCDropdown: DropDown[];
  ruleFailureDropDown: any;
  mockWorkQueue: DropDown[];
  reasonCodeDropDown: DropDown[];
  attributeNameDropDown: any;
  users: any;
  workQueueType: any;
  partBvsDOtherDetails: Object;
  PartBvsPartD: number = 0;
  NDC: string;
  brand_name: string;
  generic_name: string;
  strength: string;
  dosage_form: string;
  route_of_administration: string;
  part_bvsd_s6_wc_id: number;
  isRecCal: boolean = false;
  isPublishAllowed = false;
  isPublishRequestAllowed = false;
  isPublish: boolean = false;
  searchSuperSix = {
    narrativesNameSearch: "",
    genericNameSearch: "",
    ndcSearch: "",
    brandNameSearch: "",
  };

  filterparam = {
    brand_name: "",
    generic_name: "",
    strength: "",
    roa: "",
    dosage_form: "",
    route_of_administration: "",
    rxOtc: "",
  }

  searchpartBvspartDResult: any;
  preSearch: any = [{ "searchOn": 1, "data": [] }, { "searchOn": 2, "data": [] }, { "searchOn": 3, "data": [] }, { "searchOn": 4, "data": [] }];
  newData: any[] = new Array();
  genericNameList: any[] = new Array();
  brandNameList: any[] = new Array();
  ndcList: any[] = new Array();
  narrativesNameList: any[] = new Array();
  pushReasonNote: any;

  @ViewChild('modalSearchList') modalSearchList: ModalComponent;
  @ViewChild('modalReasonNotes') modalReasonNotes: ModalComponent;
  @ViewChild('modalDelete') modalDelete: ModalComponent;

  constructor(private _globalSev: GlobalService, private _router: Router,
    private NDCPartBvsDsvc: NDCPartBvsDService<IBD_SPEC>, private _datasvc: DataService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    if (this.user == undefined) {
      this._router.navigate(['/login']);
      return;
    }
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {
    if (this.user == undefined) {
      this._router.navigate(['/login']);
      return;
    }
    this.showWorkQueue();
    this.showWorkQueueType();
    this.setPermission();
    this.setPartBvsDOtherDetails();
    this.setOtherDropDowns();
    this.sectionList = Sections;
  }

  ngAfterViewInit() {
    $('#followUpDate').datepicker({
      format: 'mm/dd/yyyy',
      autoclose: true
    }).on('change', (event: any) => {
      this.partBvsDOtherDetails['followUpDate'] = event.target.value;
    });
  }

  private setOtherDropDowns() {

    this._datasvc.getDropdownData().subscribe((res: any) => {

      //Populate Sort Drodown
      this.sortDropDown = res.bvsDSortDropdown;
      this.columnSelected = this.sortDropDown[0].id;
      this.reasonCodeDropDown = res.HcpcNdcReasonCode;
      this.ruleFailureDropDown = res.mockRuleFailureUpdate;
      //Add new Row Drodown
      this.bvsDDropdown = res.bvsDDropdown;
      this.dosageFormDropdown = res.dosageFormDropdown;
      this.ROADropdown = res.ROADropdown;
      this.rxOTCDropdown = res.rxOTCDropdown;

    });

    this._datasvc.getAllAttribute().subscribe((res: any) => {
      this.attributeNameDropDown = res['Result'];
    });
    if (this.partBvsDOtherDetails != undefined) {
      this.partBvsDOtherDetails['attribute_id'] = "0";
      this.partBvsDOtherDetails['reason_code'] = "0";
    }
  }

  private setPermission() {

    switch (this.user.role_name) {
      case "L1-Initial":
      case "L1-Change": {
        this.isPublishAllowed = false;
        this.isPublishRequestAllowed = true;
        break;
      }
      case "L2-Initial":
      case "L2-Change":
      case "L2-Second level":
      case "L2-Publish": {
        this.isPublishAllowed = true;
        this.isPublishRequestAllowed = false;
        break;
      }
      default: {
        this.isPublishAllowed = false;
        this.isPublishRequestAllowed = false;
        break;
      }
    }
  }

  private showWorkQueue() {
    this._datasvc.getWorkQueueName().subscribe((res: any) => {
      this.mockWorkQueue = res;
    });
  }

  private showWorkQueueType() {
    // this._datasvc.getDropdownData().subscribe((res: any) => {
    //   this.workQueueType = WorkQueueType;
    // })

    this._datasvc.getStageName().subscribe((res: any) => {
      this.workQueueType = res;
    })


  }

  private setPartBvsDOtherDetails() {
    this.partBvsDOtherDetails = {
      follow_up_date: "",
      work_queue: 0,
      work_queue_type: 0,
      route_user_id: 0,
      further_routing_note: '',
      req_to_publish_note: '',
      publish_note: '',
      attribute_id: "0",
      reason_code: "0",
      reason_notes: ""

    }
  }

  private searchPramChange(event, searchOn: number) {
    var self = this;
    var eventLen = event.length;
    this.newData = new Array();

    if (eventLen < 1) {
      self.narrativesNameList = [];
      self.genericNameList = [];
      self.ndcList = [];
      self.brandNameList = [];
      return;
    }
    var getExists = this.preSearch.filter(obj => (obj.searchOn == searchOn));
    var existingData = getExists[0].data || [];

    if (existingData.length > 0) {
      getExists[0].data.forEach(function (val) {
        if (val.length > 0) {
          var isExit = val.startsWith(event)
          if (isExit == true) {
            self.newData.push(val);
          }
        }
      });
    }
    switch (searchOn) {
      case 1: //B vs D Part Name
        if (this.newData.length > 0) {
          self.narrativesNameList = this.newData;
        } else {
          self.narrativesNameList = [];
          this.NDCPartBvsDsvc.getDistinctPartBvsDName(event).subscribe((narrativesNameList) => {
            if (narrativesNameList['Result'] != null && narrativesNameList['Result'].length > 0) {
              narrativesNameList.Result.forEach(function (narrativeName) {
                //existingData.push(hcpc.hcpc_code);
                getExists[0].data.push(narrativeName.bvsd_name);
                self.narrativesNameList.push(narrativeName.bvsd_name);
              });
            } else {
              self.narrativesNameList = new Array();
            }
          });
        }
        break;
      case 2: //Generic Name
        if (this.newData.length > 0) {
          self.genericNameList = this.newData;
        } else {
          self.genericNameList = [];
          this.NDCPartBvsDsvc.getDistinctPartBVsDGeneric(event).subscribe((genericNameList) => {
            if (genericNameList['Result'] != null && genericNameList['Result'].length > 0) {
              // var arrHcpcDesc = hcpcDescList.map(function (prop) { return prop["hcpc_desc"]; })
              genericNameList.Result.forEach(function (genericName) {
                getExists[0].data.push(genericName.generic_name);
                self.genericNameList.push(genericName.generic_name);
              });
            } else {
              self.genericNameList = new Array();
            }
          });
        }
        break;
      case 3: //ndc
        if (this.newData.length > 0) {
          self.ndcList = this.newData;
        } else {
          self.ndcList = [];
          this._datasvc.getDistinctNDC(event).subscribe((ndcList) => {
            if (ndcList['Result'] != null && ndcList['Result'].length > 0) {
              ndcList.Result.forEach(function (ndc) {
                getExists[0].data.push(ndc.ndc);
                self.ndcList.push(ndc.ndc);
              });
            } else {
              self.ndcList = new Array();
            }
          });
        }
        break;
      case 4: //Populate brand name
        if (this.newData.length > 0) {
          self.brandNameList = this.newData;
        } else {
          self.brandNameList = [];
          this.NDCPartBvsDsvc.getDistinctPartBVsDBrand(event).subscribe((brandNameList) => {
            if (brandNameList['Result'] != null && brandNameList['Result'].length > 0) {
              brandNameList.Result.forEach(function (brandName) {
                getExists[0].data.push(brandName.brand_name);
                self.brandNameList.push(brandName.brand_name);
              });
            } else {
              self.brandNameList = new Array();
            }
          });
        }
        break;
    }
  }

  private selectedPram(value: string, selectedFor: number) {
    switch (selectedFor) {
      case 1: //hcpc_code
        this.searchSuperSix.narrativesNameSearch = value;
        this.narrativesNameList = new Array();
        break;
      case 2: //hcpc_desc
        this.searchSuperSix.genericNameSearch = value;
        this.genericNameList = new Array();
        break;
      case 3: //ndc
        this.searchSuperSix.ndcSearch = value;
        this.ndcList = new Array();
        break;
      case 4: //brandName
        this.searchSuperSix.brandNameSearch = value;
        this.brandNameList = new Array();
        break;
    }
  }

  //popup search result
  private search() {
    if (this.searchSuperSix.narrativesNameSearch == "" && this.searchSuperSix.genericNameSearch == "" && this.searchSuperSix.ndcSearch == "" && this.searchSuperSix.brandNameSearch == "") {
      toastr.error('Please enter atleast one search criteria');
    } else {
      this.NDCPartBvsDsvc.getNdcPartBvsDSearch(this.searchSuperSix.narrativesNameSearch, this.searchSuperSix.genericNameSearch, this.searchSuperSix.ndcSearch, this.searchSuperSix.brandNameSearch).subscribe((res: any) => {
        this.searchpartBvspartDResult = res;
        if (this.searchpartBvspartDResult != null && this.searchpartBvspartDResult.length > 0) {
          this.modalSearchList.show();
        }
        else {
          toastr.error("No Record Found.Please try with another search criteria.");
        }
      });
    }
  }

  //on search popup click
  private getPartBvsDAttributeDetails(bvsdId: number, bvsdName: string) {
    var self = this;
    this.clearControls();
    this.isRecCal = false;
    this.SelectedpartBvsD = bvsdId;
    this.SelectedpartBvsDName = bvsdName;
    this.bvsdDataListFilter = [];
    this.NDCPartBvsDsvc.getPartBvsDAttributeDetails(this.SelectedpartBvsD).subscribe((bvsdSuperSixList: IPART_BVSD_SUPER_SIX_MAP[]) => {

      if (bvsdSuperSixList != null && bvsdSuperSixList.length > 0) {
        this.bvsdDataListFilter = bvsdSuperSixList;
        this.bvsdDataListFilter.forEach(function (bvsdData) {
          bvsdData['showDetails'] = false;
          bvsdData['isActive'] = 'Y';
          bvsdData['generic_name_status'] = 0;
          bvsdData['brand_name_status'] = 0;
          bvsdData['strength_status'] = 0;
          bvsdData['dosage_form_status'] = 0;
          bvsdData['route_of_administration_status'] = 0;
          bvsdData['rx_otc_ind_status'] = 0;
          bvsdData['ndcs'] = [];
          if (bvsdData['part_bvsd_s6_wc_id'] == null) {
            bvsdData['generic_name_status'] = 2;
            bvsdData['brand_name_status'] = 2;
            bvsdData['strength_status'] = 2;
            bvsdData['dosage_form_status'] = 2;
            bvsdData['route_of_administration_status'] = 2;
            bvsdData['rx_otc_ind_status'] = 2;
          }

          if (bvsdData['part_bvsd_s6_wc_temp_id'] != null && bvsdData['part_bvsd_s6_wc_id'] != null) {
            bvsdData['generic_name'] == bvsdData['generic_name_old'] ? bvsdData['generic_name_status'] = 0 : bvsdData['generic_name_status'] = 2;
            bvsdData['brand_name'] == bvsdData['brand_name_old'] ? bvsdData['brand_name_status'] = 0 : bvsdData['brand_name_status'] = 2;
            bvsdData['strength'] == bvsdData['strength_old'] ? bvsdData['strength_status'] = 0 : bvsdData['strength_status'] = 2;
            bvsdData['dosage_form'] == bvsdData['dosage_form_old'] ? bvsdData['dosage_form_status'] = 0 : bvsdData['dosage_form_status'] = 2;
            bvsdData['route_of_administration'] == bvsdData['route_of_administration_old'] ? bvsdData['route_of_administration_status'] = 0 : bvsdData['route_of_administration_status'] = 2;
            bvsdData['rx_otc_ind'] == bvsdData['rx_otc_ind_old'] ? bvsdData['rx_otc_ind_status'] = 0 : bvsdData['rx_otc_ind_status'] = 2;
          }
          bvsdData['bvsdName'] = self.SelectedpartBvsDName;
        });
        this.bvsdDataListBackup = JSON.parse(JSON.stringify(this.bvsdDataListFilter));
        this.NDCPartBvsDsvc.getPartBvsDRuleFailures(this.SelectedpartBvsD).subscribe((ruleFailures: any) => {
          if ((ruleFailures != null && ruleFailures.length > 0)) {
            var filterRuleFailure = ruleFailures.filter(obj => obj.part_bvsd_s6_wc_temp_id != null || obj.part_bvsd_s6_wc_id != null);
            this.bvsDRuleFailure = filterRuleFailure;
          }
          else {
            this.bvsDRuleFailure = [];
          }
        });

        this.NDCPartBvsDsvc.getPartBvsDFollowupDate(this.SelectedpartBvsD).subscribe((bvsdSuperSix_follow_up_date: any) => {
          this.partBvsDOtherDetails['follow_up_date'] = (bvsdSuperSix_follow_up_date != null) ? bvsdSuperSix_follow_up_date[0].follow_up_date : '';
        });

        this.NDCPartBvsDsvc.getNdcPartBvsDFurtherRoutingNotes(this.SelectedpartBvsD).subscribe((bvsdSuperSix_Note_description: any) => {
          this.partBvsDOtherDetails['further_routing_note'] = (bvsdSuperSix_Note_description != null) ? bvsdSuperSix_Note_description[0].note_description : '';
        });
      } else {
        //this.SelectedpartBvsD = 0;
        toastr.info('selected part B vs D combination not found')
      }
      this.SetDropdownsToDefault();
      this.modalSearchList.hide();
    });
  }

  showStatus() {

  }

  private SetDropdownsToDefault() {

    this.partBvsDOtherDetails['work_queue_type'] = "0";
    this.partBvsDOtherDetails['route_user_id'] = "0";
    this.partBvsDOtherDetails['work_queue'] = "0";
  }

  //Show NDC details for Header Part B vs Part D
  private showNDCDetails(data) {
    var self = this;
    data.showDetails = !data.showDetails;
    if (self.isRecCal == false) {
      this.NDCPartBvsDsvc.getlistOfNdcsForCombination(data.part_bvsd_s6_wc_id, data.part_bvsd_s6_wc_temp_id).subscribe((bvsdSuperSixNdcDetails: INDC_ATTRIBUTES[]) => {
        var BvsDsvcNdcs = self.bvsdDataListFilter.filter(item => item.part_bvsd_s6_wc_id == data.part_bvsd_s6_wc_id && item.part_bvsd_s6_wc_temp_id == data.part_bvsd_s6_wc_temp_id);
        BvsDsvcNdcs.forEach(function (item) {
          item['ndcs'] = bvsdSuperSixNdcDetails;
        });
      });
    }
  }

  private checkdeletePartBvsD() {
    if (this.bvsdDataListFilter != undefined && this.bvsdDataListFilter.length > 0) {
      var selectedPartBvsD = this.bvsdDataListFilter.filter(obj => obj['status'] == true);
      if (selectedPartBvsD.length != 0) {
        this.modalDelete.show();
      } else if (this.bvsdDataListFilter != undefined) {
        toastr.error("Please select a Part B vs D item to delete");
        return;
      }

    } else {
      toastr.error("There is no PartBvsD available to delete.Please search PartBvsD first.");
      return;
    }

  }

  private deletePartBvsD() {
    var self = this;
    this.bvsdDeleted = (this.bvsdDeleted == undefined) ? [] : this.bvsdDeleted;
    var deleted = this.bvsdDataListFilter.filter(obj => obj['status'] == true);
    deleted.forEach(function (obj) {
      self.bvsdDeleted.push(obj);
      deleted['isActive'] = 'N';
    });

    this.bvsdDataListFilter = this.bvsdDataListFilter.filter(obj => obj['status'] != true);
  }

  private keepBvsD() {
    var deleteData = this.bvsdDataListFilter.filter(obj => obj['status'] == true);
    deleteData.forEach(function (obj) {
      obj['status'] = false
    });
    this.bvsdDataListFilter;
  }

  private userDropdown() {
    var queue_id = this.partBvsDOtherDetails['work_queue'];
    var work_queue_type = this.partBvsDOtherDetails['work_queue_type'];
    if (queue_id > 0 && work_queue_type > 0) {
      var role_type = work_queue_type == 1 ? "Initial" : "Second";
      this._datasvc.getUserByQueueId(queue_id, role_type).subscribe((res: any) => {
        this.users = res;
      });
    }
    else {
      this.users = null;
    }
  }

  private getPartBvsDNDCReasonNotes(part_bvsd_s6_wc_id: number,part_bvsd_s6_wc_temp_id:number) {

    this.partBvsDOtherDetails['attribute_id'] = "0";
    this.partBvsDOtherDetails["reason_code"] = "0";
    this.part_bvsd_s6_wc_id = part_bvsd_s6_wc_id;
    this.NDCPartBvsDsvc.getPartBvsDNDCReasonNotes(this.SelectedpartBvsD, this.part_bvsd_s6_wc_id,part_bvsd_s6_wc_temp_id).subscribe((res: any) => {
      this.partBvsDReasonNotes = res;
      this.modalReasonNotes.show();
    });
  }

  private saveReasonNotes() {

    if (this.partBvsDOtherDetails['reason_notes'] == "" || this.partBvsDOtherDetails['reason_code'] == 0 || this.partBvsDOtherDetails['attribute_id'] == 0 ||
      this.partBvsDOtherDetails['reason_notes'] == undefined || this.partBvsDOtherDetails['reason_code'] == undefined || this.partBvsDOtherDetails['attribute_id'] == undefined) {
      toastr.error("Please enter a valid reason notes ,reason code and atrribute name");
      return;
    }
    this.pushReasonNote = this.pushReasonNote || [];
    this.pushReasonNote.push({
      "part_bvsd_s6_wc_id": this.part_bvsd_s6_wc_id,
      "reasonCode": this.partBvsDOtherDetails['reason_code'],
      "reasonNote": this.partBvsDOtherDetails['reason_notes'],
      "attributeId": this.partBvsDOtherDetails['attribute_id'],
    });
    this.partBvsDOtherDetails = {
      reasonCode: 0,
      reasonNote: "",
      attributeId: 0,
    }
    this.modalReasonNotes.hide();
  }

  private clearReasonNotes() {
    this.partBvsDOtherDetails = {
      reasonCode: 0,
      reasonNote: "",
      attributeId: 0,
    }
    this.pushReasonNote = [];
  }

  private modelChange(part_bvsd_s6_wc_id, part_bvsd_s6_wc_temp_id, status, event) {
    var prop = status.slice(0, -7);
    var editBvsD = this.bvsdDataListFilter.filter(obj => obj['part_bvsd_s6_wc_id'] == part_bvsd_s6_wc_id && obj['part_bvsd_s6_wc_temp_id'] == part_bvsd_s6_wc_temp_id);
    var bkBvsD = this.bvsdDataListBackup.filter(obj => obj['part_bvsd_s6_wc_id'] == part_bvsd_s6_wc_id && obj['part_bvsd_s6_wc_temp_id'] == part_bvsd_s6_wc_temp_id);
    if (status != '') {
      if (bkBvsD[prop] != event) {
        editBvsD[0][status] = 1;
      } else {
        bkBvsD[status] = bkBvsD[status];
      }
    }
  }

  private filterbvdSuperSixData(): void {

    // this.ndcSuperSixData = this.masterNdcSuperSixData.filter(obj  =>  obj.super_six_name == this.activeTab);
    if (this.bvsdDataListFilter != undefined && (this.filterparam.brand_name || this.filterparam.generic_name || this.filterparam.strength ||
      this.filterparam.dosage_form || this.filterparam.route_of_administration || this.filterparam.rxOtc)) {

      this.bvsdDataListFilter = this.bvsdDataListFilter.filter(item =>
        ((this.filterparam.brand_name) ? (item.brand_name.toLowerCase().indexOf(this.filterparam['brand_name'].toLowerCase()) > -1) : 1)
        &&
        ((this.filterparam.generic_name) ? (item.generic_name.toLowerCase().indexOf(this.filterparam['generic_name'].toLowerCase()) > -1) : 1)
        &&
        ((this.filterparam.strength) ? (item.strength.toLowerCase().indexOf(this.filterparam['strength'].toLowerCase()) > -1) : 1)
        &&
        ((this.filterparam.dosage_form) ? (item.dosage_form.toLowerCase().indexOf(this.filterparam['dosage_form'].toLowerCase()) > -1) : 1)
        &&
        ((this.filterparam.route_of_administration) ? (item.route_of_administration.toLowerCase().indexOf(this.filterparam['route_of_administration'].toLowerCase()) > -1) : 1)
        &&
        ((this.filterparam.rxOtc) ? (item.rx_otc_ind.toLowerCase().indexOf(this.filterparam['rxOtc'].toLowerCase()) > -1) : 1)
      );

    }
    else {
      this.bvsdDataListFilter = this.bvsdDataListBackup;
    }
  }

  private filterRxOtc($event, rxotcValue) {
    if ($event.target.checked) {
      this.filterparam.rxOtc = rxotcValue;
    }
    this.filterbvdSuperSixData();
  }

  private clearControls() {
    this.partBvsDOtherDetails = [];
    this.partBvsDOtherDetails = [];
    this.partBvsDReasonNotes = [];
    this.isAddRow = false;
    this.bvsdDeleted = [];
    this.bvsDRuleFailure = [];

  }

  private showSection(section) {
    this.sectionList[section]['show'] = !this.sectionList[section]['show'];
  }

  private clear() {
    this.filterparam.generic_name = "";
    this.filterparam.brand_name = "";
    this.filterparam.strength = "";
    this.filterparam.dosage_form = "";
    this.filterparam.route_of_administration = "";
    this.filterparam.rxOtc = "";
  }

  private sort() {
    this.column = this.columnSelected.toString();
    this.direction = this.isDesc == false ? 1 : -1;
  }

  private recalPartBvsD() {
    if (this.SelectedpartBvsD == 0) {
      toastr.info("Please select a Part BvsD");
      return;
    }

    var self = this;

    var recalJson = {};
    recalJson['part_bvsd_id'] = this.SelectedpartBvsD;
    recalJson['partbvsdMap'] = [];
    var bvsdPropName;
    var isReasonNoteBlank: boolean = false;
    var isDuplicate = false;
    //Only Add hcpc
    if (this.isAddRow == true) {
      if ((this.newPartBvDCombination['narratives_name'] == "" || this.newPartBvDCombination['narratives_name'] == undefined) &&
        (this.newPartBvDCombination['generic_name'] == "" || this.newPartBvDCombination['generic_name'] == undefined) &&
        (this.newPartBvDCombination['brand_name'] == "" || this.newPartBvDCombination['brand_name'] == undefined) &&
        (this.newPartBvDCombination['strength'] == "" || this.newPartBvDCombination['strength'] == undefined) &&
        (this.newPartBvDCombination['dosage_form'] == "" || this.newPartBvDCombination['dosage_form'] == undefined) &&
        (this.newPartBvDCombination['route_of_administration'] == "" || this.newPartBvDCombination['route_of_administration'] == undefined) &&
        (this.newPartBvDCombination['rx_otc_ind'] == "" || this.newPartBvDCombination['rx_otc_ind'] == undefined)) {
        toastr.warning("Please fill all values in new PartBvsD combination");
        return;
      } else {        
        self.bvsdDataListFilter.forEach(function (bvsd) {
          if ((bvsd['generic_name'].toLowerCase().trim() == self.newPartBvDCombination['generic_name'].toLowerCase().trim()
            || bvsd['generic_name'] == '*' || self.newPartBvDCombination['generic_name'] == '*')
            && (bvsd['brand_name'].toLowerCase().trim() == self.newPartBvDCombination['brand_name'].toLowerCase().trim()
              || bvsd['brand_name'] == '*' || self.newPartBvDCombination['brand_name'] == '*')
            && (bvsd['strength'].toLowerCase().trim() == self.newPartBvDCombination['strength'].toLowerCase().trim()
              || bvsd['strength'] == '*' || self.newPartBvDCombination['strength'] == '*')
            && (bvsd['dosage_form'].toLowerCase().trim() == self.newPartBvDCombination['dosage_form'].toLowerCase().trim()
              || bvsd['dosage_form'] == '*' || self.newPartBvDCombination['dosage_form'] == '*')
            && (bvsd['route_of_administration'].toLowerCase().trim() == self.newPartBvDCombination['route_of_administration'].toLowerCase().trim()
              || bvsd['route_of_administration'] == '*' || self.newPartBvDCombination['route_of_administration'] == '*')
            && (bvsd['rx_otc_ind'].toLowerCase().trim() == self.newPartBvDCombination['rx_otc_ind'].toLowerCase().trim()
              || bvsd['rx_otc_ind'] == '*' || self.newPartBvDCombination['rx_otc_ind'] == '*')) {
            isDuplicate = true;
          }
        });
        if (isDuplicate == false) {
          
          var objNewPartBvD = {
            unique_id: null,
            narratives_name: this.newPartBvDCombination['narratives_name'],
            generic_name: this.newPartBvDCombination['generic_name'],
            brand_name: this.newPartBvDCombination['brand_name'],
            strength: this.newPartBvDCombination['strength'],
            dosage_form: this.newPartBvDCombination['dosage_form'],
            route_of_administration: this.newPartBvDCombination['route_of_administration'],
            rx_otc_ind: this.newPartBvDCombination['rx_otc_ind']
          }
          recalJson['partbvsdMap'].push(objNewPartBvD);
        }
        else {
          toastr.info("Newly added supersix combination is already present.Please try with new combination.");
          isDuplicate=false;
          return;
        }
      }
    }
    //check duplicity within the existing modified combination
    if (this.isAddRow == false){   
   //self.bvsdDataListFilter.forEach(function (bvsd) {
     if(self.bvsdDataListFilter != undefined || self.bvsdDataListFilter !=null){
      for (var index = 0; index < self.bvsdDataListFilter.length-1; index++){
      for (var innerIndex = index; innerIndex < self.bvsdDataListFilter.length-1; innerIndex++) {          
     
      if ((self.bvsdDataListFilter[index]['generic_name'].toLowerCase().trim() == self.bvsdDataListFilter[innerIndex+1]['generic_name'].toLowerCase().trim()
        || self.bvsdDataListFilter[index]['generic_name'] == '*' || self.bvsdDataListFilter[innerIndex+1]['generic_name'] == '*')
        && (self.bvsdDataListFilter[index]['brand_name'].toLowerCase().trim() == self.bvsdDataListFilter[innerIndex+1]['brand_name'].toLowerCase().trim()
          || self.bvsdDataListFilter[index]['brand_name'] == '*' || self.bvsdDataListFilter[innerIndex+1]['brand_name'] == '*')
        && (self.bvsdDataListFilter[index]['strength'].toLowerCase().trim() == self.bvsdDataListFilter[innerIndex+1]['strength'].toLowerCase().trim()
          || self.bvsdDataListFilter[index]['strength'] == '*' || self.bvsdDataListFilter[innerIndex+1]['strength'] == '*')
        && (self.bvsdDataListFilter[index]['dosage_form'].toLowerCase().trim() == self.bvsdDataListFilter[innerIndex+1]['dosage_form'].toLowerCase().trim()
          || self.bvsdDataListFilter[index]['dosage_form'] == '*' || self.bvsdDataListFilter[innerIndex+1]['dosage_form'] == '*')
        && (self.bvsdDataListFilter[index]['route_of_administration'].toLowerCase().trim() == self.bvsdDataListFilter[innerIndex+1]['route_of_administration'].toLowerCase().trim()
          || self.bvsdDataListFilter[index]['route_of_administration'] == '*' || self.bvsdDataListFilter[innerIndex+1]['route_of_administration'] == '*')
        && (self.bvsdDataListFilter[index]['rx_otc_ind'].toLowerCase().trim() == self.bvsdDataListFilter[innerIndex+1]['rx_otc_ind'].toLowerCase().trim()
          || self.bvsdDataListFilter[index]['rx_otc_ind'] == '*' || self.bvsdDataListFilter[innerIndex+1]['rx_otc_ind'] == '*')) {
        isDuplicate = true;
      }
    }    
  }
}
 
    if (isDuplicate == true){
    toastr.info("Existing supersix combination is already present more than once.\nPlease modify existing combination with unique values.");
    isDuplicate=false;
    return;
    }
  }
  
    //RUM-623    

    if (self.bvsdDataListFilter != undefined) {

      //self.bvsdDataListFilter.forEach(function (bvsd) {    
      self.bvsdDataListFilter.some(function (bvsd, index, _arr) {

        if (isReasonNoteBlank == true)
          return true;

        var bvsdProps = Object.getOwnPropertyNames(self.bvsdDataListFilter[0]);
        if (self.bvsdDataListBackup != undefined) {
          var backupbvsd = self.bvsdDataListBackup.filter(bk => bk['part_bvsd_s6_wc_id'] == bvsd['part_bvsd_s6_wc_id']);
        }

        for (var i = 0; i < bvsdProps.length; i++) {
          bvsdPropName = bvsdProps[i];
          switch (bvsdPropName) {
            case 'generic_name':
            case 'brand_name':
            case 'strength':
            case 'dosage_form':
            case 'route_of_administration':
            case 'rx_otc_ind':
              bvsd[bvsdPropName] = (bvsd[bvsdPropName] == null || bvsd[bvsdPropName] == undefined) ? "" : bvsd[bvsdPropName];
              if (bvsd['part_bvsd_s6_wc_id'] != null || bvsd['part_bvsd_s6_wc_temp_id'] != null) {
                if (backupbvsd != undefined && backupbvsd.length > 0) {
                  backupbvsd[0][bvsdPropName] = (backupbvsd[0][bvsdPropName] == null) ? "" : backupbvsd[0][bvsdPropName];
                  if (bvsd[bvsdPropName].toString().toLowerCase().trim() != backupbvsd[0][bvsdPropName].toString().toLowerCase().trim()) {

                    // if (bvsd['attributeId'] == 0 || bvsd['reasonCode'] == 0 || bvsd['reasonNote'] == "" ||
                    //   bvsd['attributeId'] == undefined || bvsd['reasonCode'] == undefined || bvsd['reasonNote'] == undefined){
                      if (self.pushReasonNote == undefined || self.pushReasonNote.length == 0){
                        isReasonNoteBlank = true;
                        bvsdProps = [];
                      }
                      else{
                        if (self.pushReasonNote != undefined && self.pushReasonNote.length > 0) {
                          var filterReasonNotes = self.pushReasonNote.filter(r => r['part_bvsd_s6_wc_id'] == bvsd['part_bvsd_s6_wc_id']);
                          if (filterReasonNotes.length == 0) {
                            isReasonNoteBlank = true;
                            bvsdProps = [];
                          }     
                        }                 
                  //}
                }
                }
              }
            }

              break;
            default:
              break;
          }

        }

      });
      if (isReasonNoteBlank) {
        toastr.error("Reason notes is missing for modified PartBvsD combnation.Please add valid reason notes.");
        return;
      }

    }

    //end of Rum 623

    this.bvsdDataListFilter.forEach(function (item) {
      var objPartBvsD = {};
      objPartBvsD["part_bvsd_s6_wc_id"] = item["part_bvsd_s6_wc_id"];
      objPartBvsD["part_bvsd_s6_wc_temp_id"] = item["part_bvsd_s6_wc_temp_id"];
      //objPartBvsD["unique_id"] = item["part_bvsd_s6_wc_id"] != null ? item["part_bvsd_s6_wc_id"] : item["part_bvsd_s6_wc_temp_id"];
      objPartBvsD["generic_name"] = item["generic_name"];
      objPartBvsD["brand_name"] = item["brand_name"];
      objPartBvsD["strength"] = item["strength"];
      objPartBvsD["dosage_form"] = item["dosage_form"];
      objPartBvsD["route_of_administration"] = item["route_of_administration"];
      objPartBvsD["rx_otc_ind"] = item["rx_otc_ind"];
      recalJson['partbvsdMap'].push(objPartBvsD);
    });

    this.bvsdDeleted.forEach(function (item) {
      var obj = {
        "isActive": "N",
        "s6_wildcard_id": (item['s6_wildcard_id'] == undefined) ? null : item['s6_wildcard_id'],
        "generic_name": item['generic_name'],
        "brand_name": item['brand_name'],
        "strength": item['strength'],
        "dosage_form": item['dosage_form'],
        "route_of_administration": item['route_of_administration'],
        "rx_otc_ind": item['rx_otc_ind'],
        "part_bvsd_s6_wc_id": item['part_bvsd_s6_wc_id'],
        "part_bvsd_s6_wc_temp_id": item['part_bvsd_s6_wc_temp_id']
      }
      recalJson['partbvsdMap'].push(obj);
    });

    if (recalJson['partbvsdMap'].length != 0) {
      this.NDCPartBvsDsvc.recalPartBvsD(recalJson).subscribe(recalPartBvD => {
        this.isAddRow = false;
        var bvsdnameAssociated = [];
        if (recalPartBvD != undefined) {
          if (recalPartBvD.length > -1) {
            //RUM-639---------------------------------
            recalPartBvD.forEach(function (item) {
              if (item.PartBvsdCombination.length > 0) {
                item.PartBvsdCombination.forEach(element => {
                   if (element.part_bvsd_s6_wc_id != item.part_bvsd_s6_wc_id)
                  bvsdnameAssociated.push(element.bvsd_name)
                });
              }
            });
            //
            
            if (bvsdnameAssociated.length > 0 && !this.isAddRow) {
              toastr.success("The Recal has been successfully completed.");
              toastr.info("Existing combination already exists in other PartBVsPartD:- \n" + " " + (bvsdnameAssociated.filter((x, i, a) => a.indexOf(x) == i)).toString());
            }else if (bvsdnameAssociated.length > 0 && this.isAddRow) {
              toastr.success("The Recal has been successfully completed.");
              toastr.info("Newly added combination already exists in other PartBVsPartD:- \n" + " " + (bvsdnameAssociated.filter((x, i, a) => a.indexOf(x) == i)).toString());
            }
            else {
              toastr.success("The Recal has been successfully completed.");
            }

            //End of Rum-639--------------------------
            self.isRecCal = true;
            this.bvsdDataListFilter = recalPartBvD;
            this.bvsdDataListFilter.forEach(function (recalitem) {
              recalitem['showDetails'] = false;
              recalitem['generic_name_status'] = 0;
              recalitem['brand_name_status'] = 0;
              recalitem['strength_status'] = 0;
              recalitem['dosage_form_status'] = 0;
              recalitem['route_of_administration_status'] = 0;
              recalitem['rx_otc_ind_status'] = 0;
              recalitem['bvsdName'] = self.SelectedpartBvsDName;
              if (recalitem['part_bvsd_s6_wc_id'] == undefined) {
                recalitem['part_bvsd_s6_wc_id'] = null;
                recalitem['generic_name_status'] = 2;
                recalitem['brand_name_status'] = 2;
                recalitem['strength_status'] = 2;
                recalitem['dosage_form_status'] = 2;
                recalitem['route_of_administration_status'] = 2;
                recalitem['rx_otc_ind_status'] = 2;
              }
              recalitem['part_bvsd_s6_wc_temp_id'] = (recalitem['part_bvsd_s6_wc_temp_id'] == undefined) ? null : recalitem['part_bvsd_s6_wc_temp_id'];
              recalitem['part_bvsd_s6_map_temp_id'] = (recalitem['part_bvsd_s6_map_temp_id'] == undefined) ? null : recalitem['part_bvsd_s6_map_temp_id'];

              if (recalitem['part_bvsd_s6_wc_temp_id'] != null && recalitem['part_bvsd_s6_wc_id'] != null) {
                recalitem['generic_name'] == recalitem['generic_name_old'] ? recalitem['generic_name_status'] = 0 : recalitem['generic_name_status'] = 2;
                recalitem['brand_name'] == recalitem['brand_name_old'] ? recalitem['brand_name_status'] = 0 : recalitem['brand_name_status'] = 2;
                recalitem['strength'] == recalitem['strength_old'] ? recalitem['strength_status'] = 0 : recalitem['strength_status'] = 2;
                recalitem['dosage_form'] == recalitem['dosage_form_old'] ? recalitem['dosage_form_status'] = 0 : recalitem['dosage_form_status'] = 2;
                recalitem['route_of_administration'] == recalitem['route_of_administration_old'] ? recalitem['route_of_administration_status'] = 0 : recalitem['route_of_administration_status'] = 2;
                recalitem['rx_otc_ind'] == recalitem['rx_otc_ind_old'] ? recalitem['rx_otc_ind_status'] = 0 : recalitem['rx_otc_ind_status'] = 2;
              }
              if (self.bvsdDeleted != undefined) {
                var deletedBvsD = self.bvsdDeleted.filter(obj => obj['part_bvsd_s6_wc_id'] == recalitem['part_bvsd_s6_wc_id']
                  && obj['part_bvsd_s6_wc_temp_id'] == recalitem['part_bvsd_s6_wc_temp_id']);
              }
              if (deletedBvsD != undefined && deletedBvsD.length > 0) {
                recalitem['isActive'] = 'N';
              }
              else {
                recalitem['isActive'] = 'Y';
              }
            });
          }
        } else {
          toastr.info("Server not respond");
        }
      });
    }
    this.newPartBvDCombination = {};

  }

  private savePartBvsD() {

    if (this.SelectedpartBvsD == 0) {
      toastr.info("Please select a Part BvsD");
      return;
    }
    if (this.isAddRow == true) {
      if ((this.newPartBvDCombination['narratives_name'] == "" || this.newPartBvDCombination['narratives_name'] == undefined) &&
        (this.newPartBvDCombination['generic_name'] == "" || this.newPartBvDCombination['generic_name'] == undefined) &&
        (this.newPartBvDCombination['brand_name'] == "" || this.newPartBvDCombination['brand_name'] == undefined) &&
        (this.newPartBvDCombination['strength'] == "" || this.newPartBvDCombination['strength'] == undefined) &&
        (this.newPartBvDCombination['dosage_form'] == "" || this.newPartBvDCombination['dosage_form'] == undefined) &&
        (this.newPartBvDCombination['route_of_administration'] == "" || this.newPartBvDCombination['route_of_administration'] == undefined) &&
        (this.newPartBvDCombination['rx_otc_ind'] == "" || this.newPartBvDCombination['rx_otc_ind'] == undefined)) {
        toastr.warning("Please fill all values in new PartBvsD combination");
        return;
      } else {
        toastr.warning("Please recal before save, request to publish or publish");
        return;
      }
    }
    var saveJson = this.RequestJSON();

    //requestTopublishJson['note_description'] = "";
    if (saveJson['partbvsdMap'].length != 0) {
      this.NDCPartBvsDsvc.savePartBvsD(saveJson).subscribe(saveBvD => {
        this.isAddRow = false;
        if (saveBvD.length > -1) {
          toastr.success("The save has been successfully completed.");
          //this.getPartBvsDAttributeDetails(this.SelectedpartBvsD, this.SelectedpartBvsDName);
          //this.clearControls();
          this._router.navigate(['home']);
        }
      });
      this.newPartBvDCombination = {};
    }

  }

  private requestToPublishPartBvsD() {
    if (this.SelectedpartBvsD == 0) {
      toastr.info("Please select a Part BvsD");
      return;
    }
    if (this.isAddRow == true) {
      if ((this.newPartBvDCombination['narratives_name'] == "" || this.newPartBvDCombination['narratives_name'] == undefined) &&
        (this.newPartBvDCombination['generic_name'] == "" || this.newPartBvDCombination['generic_name'] == undefined) &&
        (this.newPartBvDCombination['brand_name'] == "" || this.newPartBvDCombination['brand_name'] == undefined) &&
        (this.newPartBvDCombination['strength'] == "" || this.newPartBvDCombination['strength'] == undefined) &&
        (this.newPartBvDCombination['dosage_form'] == "" || this.newPartBvDCombination['dosage_form'] == undefined) &&
        (this.newPartBvDCombination['route_of_administration'] == "" || this.newPartBvDCombination['route_of_administration'] == undefined) &&
        (this.newPartBvDCombination['rx_otc_ind'] == "" || this.newPartBvDCombination['rx_otc_ind'] == undefined)) {
        toastr.warning("Please fill all values in new PartBvsD combination");
        return;
      } else {
        toastr.warning("Please recal before save, request to publish or publish");
        return;
      }
    }
    //Alays Rcal sud be done when user use save/publish/requesttopublish
    //this.recalPartBvsD();

    var requestTopublishJson = this.RequestJSON();
    requestTopublishJson['note_description'] = this.partBvsDOtherDetails['req_to_Publish_Note'];
    if (requestTopublishJson['partbvsdMap'].length != 0) {
      this.NDCPartBvsDsvc.requestToPublishPartBvsD(requestTopublishJson).subscribe(requestToPublish => {
        this.isAddRow = false;
        if (requestToPublish.length > -1) {
          toastr.success("Request to publish has been successfully completed.");
          //this.getPartBvsDAttributeDetails(this.SelectedpartBvsD, this.SelectedpartBvsDName);
          //this.clearControls();
          this._router.navigate(['home']);
        }
      });
    }
  }

  private publishPartBvsD() {
    this.isPublish = true;
    if (this.SelectedpartBvsD == 0) {
      toastr.info("Please select a Part BvsD");
      return;
    }
    if (this.isAddRow == true) {
      if ((this.newPartBvDCombination['narratives_name'] == "" || this.newPartBvDCombination['narratives_name'] == undefined) &&
        (this.newPartBvDCombination['generic_name'] == "" || this.newPartBvDCombination['generic_name'] == undefined) &&
        (this.newPartBvDCombination['brand_name'] == "" || this.newPartBvDCombination['brand_name'] == undefined) &&
        (this.newPartBvDCombination['strength'] == "" || this.newPartBvDCombination['strength'] == undefined) &&
        (this.newPartBvDCombination['dosage_form'] == "" || this.newPartBvDCombination['dosage_form'] == undefined) &&
        (this.newPartBvDCombination['route_of_administration'] == "" || this.newPartBvDCombination['route_of_administration'] == undefined) &&
        (this.newPartBvDCombination['rx_otc_ind'] == "" || this.newPartBvDCombination['rx_otc_ind'] == undefined)) {
        toastr.warning("Please fill all values in new PartBvsD combination");
        return;
      } else {
        toastr.warning("Please recal before save, request to publish or publish");
        return;
      }
    }
    //Alays Rcal sud be done when user use save/publish/requesttopublish
    //this.recalPartBvsD();        

    var publishJson = this.RequestJSON();

    publishJson['note_description'] = this.partBvsDOtherDetails['publish_Note'];
    if (publishJson['partbvsdMap'].length != 0) {
      this.NDCPartBvsDsvc.publishPartBvsD(publishJson).subscribe(publishPartBvsD => {
        this.isAddRow = false;
        if (publishPartBvsD.length > -1) {
          toastr.success("Publish has been successfully completed.");
          //this.getPartBvsDAttributeDetails(this.SelectedpartBvsD, this.SelectedpartBvsDName);
          //this.clearControls();
          this._router.navigate(['home']);
        }
      });
    }
  }

  private RequestJSON() {

    var self = this;
    var bvsdPropName;
    var saveJson = {};

    saveJson['user_id'] = this.user.user_id;
    saveJson['isActive'] = "";
    saveJson['part_bvsd_id'] = this.SelectedpartBvsD;
    saveJson['note_description'] = "";
    saveJson['partbvsdMap'] = [];
    saveJson['followUpDetails'] = {};
    saveJson['furtherRouting'] = {};
    saveJson['ruleFailuer'] = [];

    if (self.bvsdDataListFilter != undefined) {
      var partBvDidx = 0;
      self.bvsdDataListFilter.forEach(function (bvsd) {

        var bvsdProps = Object.getOwnPropertyNames(self.bvsdDataListFilter[0]);
        if (self.bvsdDataListBackup != undefined) {
          var backupbvsd = self.bvsdDataListBackup.filter(bk => bk['part_bvsd_s6_wc_id'] == bvsd['part_bvsd_s6_wc_id']);
        }
        var obj = {};
        var oWorkqueue = {};

        if (self.bvsdDeleted != undefined) {
          var deletedBvsD = self.bvsdDeleted.filter(obj => obj['part_bvsd_s6_wc_id'] == bvsd['part_bvsd_s6_wc_id']
            && obj['part_bvsd_s6_wc_temp_id'] == bvsd['part_bvsd_s6_wc_temp_id']);
        }

        if (deletedBvsD != undefined && deletedBvsD.length > 0) {
          obj['isActive'] = 'N';
        }
        else {
          obj['isActive'] = '';
        }
        // if (self.isRecCal == false && self.isPublish == true) {
        //   obj['isActive'] = '';
        // }
        obj['part_bvsd_id'] = self.SelectedpartBvsD;
        obj['s6_wildcard_id'] = (bvsd['s6_wildcard_id'] == undefined) ? null : bvsd['s6_wildcard_id'];
        obj['part_bvsd_s6_wc_id'] = (bvsd['part_bvsd_s6_wc_id'] == undefined) ? null : bvsd['part_bvsd_s6_wc_id'];
        obj['part_bvsd_s6_wc_temp_id'] = (bvsd['part_bvsd_s6_wc_temp_id'] == undefined) ? null : bvsd['part_bvsd_s6_wc_temp_id'];
        obj['generic_name'] = (bvsd['generic_name'] == undefined || bvsd['generic_name'] == null) ? '' : bvsd['generic_name'];
        obj['brand_name'] = (bvsd['brand_name'] == undefined || bvsd['brand_name'] == null) ? '' : bvsd['brand_name'];
        obj['strength'] = (bvsd['strength'] == undefined || bvsd['strength'] == null) ? '' : bvsd['strength'];
        obj['dosage_form'] = (bvsd['dosage_form'] == undefined || bvsd['dosage_form'] == null) ? '' : bvsd['dosage_form'];
        obj['route_of_administration'] = (bvsd['route_of_administration'] == undefined || bvsd['route_of_administration'] == null) ? '' : bvsd['route_of_administration'];
        obj['rx_otc_ind'] = (bvsd['rx_otc_ind'] == undefined || bvsd['rx_otc_ind'] == null) ? '' : bvsd['rx_otc_ind'];
        if (self.pushReasonNote != undefined && self.pushReasonNote.length > 0) {
          var filterReasonNotes = self.pushReasonNote.filter(r => r['part_bvsd_s6_wc_id'] == bvsd['part_bvsd_s6_wc_id']);
          if (filterReasonNotes.length > 0) {
            obj['attributeId'] = filterReasonNotes[0]['attributeId'];
            obj['reasonCode'] = filterReasonNotes[0]['reasonCode'];
            obj['reasonNote'] = filterReasonNotes[0]['reasonNote'];
          }
        }
        // else {
        //   obj['attributeId'] = null;
        //   obj['reasonCode'] = null;
        //   obj['reasonNote'] = null;
        // }

        saveJson['partbvsdMap'].push(obj);
        saveJson['partbvsdMap'][partBvDidx]['workqueues'] = [];

        for (var i = 0; i < bvsdProps.length; i++) {
          bvsdPropName = bvsdProps[i];
          switch (bvsdPropName) {
            case 'generic_name':
            case 'brand_name':
            case 'strength':
            case 'dosage_form':
            case 'route_of_administration':
            case 'rx_otc_ind':
            case 'billable_unit':
            case 'calc_flag':
              bvsd[bvsdPropName] = (bvsd[bvsdPropName] == null || bvsd[bvsdPropName] == undefined) ? "" : bvsd[bvsdPropName];
              if (bvsd['part_bvsd_s6_wc_id'] != null || bvsd['part_bvsd_s6_wc_temp_id'] != null) {
                if (backupbvsd != undefined && backupbvsd.length > 0) {
                  backupbvsd[0][bvsdPropName] = (backupbvsd[0][bvsdPropName] == null) ? "" : backupbvsd[0][bvsdPropName];
                  if (bvsd[bvsdPropName].toString().toLowerCase().trim() != backupbvsd[0][bvsdPropName].toString().toLowerCase().trim()) {
                    oWorkqueue = {
                      "workqueue_id": null,
                      "queue_id": 8,
                      "stage_id": bvsd['stage_id'] != undefined || bvsd['stage_id'] != null ? bvsd['stage_id'] : 2
                    }
                    saveJson['partbvsdMap'][partBvDidx]['workqueues'].push(oWorkqueue);
                    saveJson['partbvsdMap'][partBvDidx]['isActive'] = 'Y';
                  }
                }
              }
              break;
            default:
              break;
          }
        }
        if (bvsd['part_bvsd_s6_wc_id'] == null && bvsd['part_bvsd_s6_wc_temp_id'] == null && bvsd['part_bvsd_s6_map_temp_id'] == null) {
          oWorkqueue = {
            "workqueue_id": null,
            "queue_id": 8,
            "stage_id": bvsd['stage_id'] != undefined || bvsd['stage_id'] != null ? bvsd['stage_id'] : 2,
          }
          saveJson['partbvsdMap'][partBvDidx]['workqueues'].push(oWorkqueue);
          saveJson['partbvsdMap'][partBvDidx]['isActive'] = 'Y';
        }
        if (deletedBvsD != undefined && deletedBvsD.length > 0) {
          oWorkqueue = {
            "workqueue_id": null,
            "queue_id": 8,
            "stage_id": bvsd['stage_id'] != undefined || bvsd['stage_id'] != null ? bvsd['stage_id'] : 2,
          }
          saveJson['partbvsdMap'][partBvDidx]['workqueues'].push(oWorkqueue);
        }

        //prepare NDC details
        if (saveJson['partbvsdMap'].length > 0) {
          saveJson['partbvsdMap'][partBvDidx]['ndcMap'] = [];
          if (bvsd['ndcs'] != undefined) {
            bvsd['ndcs'].forEach(function (ndc) {
              var objNDC = {};
              objNDC['ndc'] = ndc['ndc'];
              objNDC['isActive'] = 'Y';
              objNDC['wt_id'] = ndc['wt_id'];
              objNDC['s6_id'] = (ndc['s6_id_fk'] == undefined) ? null : ndc['s6_id_fk'];   // will get from get method
              objNDC['part_bvsd_s6_wc_id'] = (bvsd['part_bvsd_s6_wc_id'] == undefined) ? null : bvsd['part_bvsd_s6_wc_id'];
              objNDC['part_bvsd_s6_map_id'] = (ndc['part_bvsd_s6_map_id'] == undefined) ? null : ndc['part_bvsd_s6_map_id'];
              objNDC['part_bvsd_s6_map_temp_id'] = ndc['part_bvsd_s6_map_temp_id'];

              objNDC['generic_name'] = ndc['generic_name'];
              objNDC['brand_name'] = ndc['brand_name'];
              objNDC['strength'] = ndc['strength'];
              objNDC['dosage_form'] = ndc['dosage_form'];
              objNDC['route_of_administration'] = ndc['route_of_administration'];
              objNDC['rx_otc_ind'] = ndc['rx_otc_ind'];
              objNDC['package_size'] = ndc['package_size'];
              objNDC['package_size_uom'] = ndc['package_size_uom'];
              objNDC['package_quantity'] = ndc['package_quantity'];
              objNDC['repackager_ind'] = ndc['repackager_ind'];
              objNDC['sd_md'] = ndc['sd_md'];
              objNDC['inner_outer_package_indicator'] = ndc['inner_outer_package_indicator'];
              saveJson['partbvsdMap'][partBvDidx]['ndcMap'].push(objNDC);

            });
          }
        }
        if (partBvDidx < self.bvsdDataListFilter.length) {
          partBvDidx++;
        }
      });
    }

    saveJson['followUpDetails'] = {
      "followUpDate": this.partBvsDOtherDetails["follow_up_date"]
    };

    saveJson['furtherRouting'] = {
      "queueName": this.partBvsDOtherDetails["work_queue"] == 0 ? null : this.partBvsDOtherDetails["work_queue"],
      "queueType": this.partBvsDOtherDetails["work_queue_type"] == 0 ? null : this.partBvsDOtherDetails["work_queue_type"],
      "routingUserId": this.partBvsDOtherDetails["route_user_id"] == 0 ? null : this.partBvsDOtherDetails["route_user_id"],
      "notes": this.partBvsDOtherDetails["note_description"] == undefined ? null : this.partBvsDOtherDetails["note_description"]
    };


    //Rule Failure
    this.bvsDRuleFailure.forEach(function (item) {
      var objRuleFailurePartBvsD = {};
      objRuleFailurePartBvsD["partbvsdId"] = item["part_bvsd_id"];
      objRuleFailurePartBvsD["description"] = item["attribute_status"];
      objRuleFailurePartBvsD["workqueueId"] = item["workqueue_id"];
      saveJson['ruleFailuer'].push(objRuleFailurePartBvsD);
    });
    return saveJson;

  }

  private setStatus(id) {
    var prop = this.statusProp.slice(0, -7);
    switch (id) {
      case 3: //override value
        this.bvsDdataInstance[this.statusProp] = 3;
        break;
      // case 4: //Change Review
      //   //this.bvsdDataListEditable..RJ[0][this.statusProp] = 4;
      //   break;
      default:
        toastr.info('Invalid selection');
        break;
    }
  }

  private addRow() {
    if (this.SelectedpartBvsD == 0) {
      toastr.info("Please select a Part BvsD");
      return;
    }
    this.newPartBvDCombination['PartBvsD_Name'] = this.SelectedpartBvsDName;
    this.isAddRow = true;
    this.isEditRow = false;
  }

  cancel() {
    this._router.navigate(['home']);
  }
  // CheckReasonNoteExistsForModPartbvsDCombination():any {
  //     }
}

