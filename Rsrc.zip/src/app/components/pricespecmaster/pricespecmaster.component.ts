import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { IUSER_MASTER, IPRICE_SPEC } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";
import { PriceSpecService } from '../../services/pricespec.service';
import { ModalComponent } from '../shared/modalpopup.component';

import { ConfigService } from '../../services/shared/config.service';

declare var $: any;

@Component({
  selector: 'app-pricespecmaster',
  templateUrl: './pricespecmaster.component.html?v=${new Date().getTime()}',
  providers: [PriceSpecService]
})
export class PriceSpecMasterComponent {

  user: IUSER_MASTER;
  priceSpecData: IPRICE_SPEC[];
  priceSpecFilterData: IPRICE_SPEC[];
  priceSpecSearch: string = "";
  price_spec_id: Number = 0;
  price_spec_name: string = "";
  price_spec_upload: any;
  price_spec_file_exists: any;
  price_spec_note: string = "";
  isNewRecord: boolean = false;
  requestData: FormData = new FormData();
  uploadFile: any;
  _baseUrl: string = '';

  preSearch: any[] = new Array();
  priceSpecCodeList: any[] = new Array();


  constructor(private _router: Router,
    private _priceSpecService: PriceSpecService<IPRICE_SPEC>,
    private _globalSev: GlobalService,
    private configSvc: ConfigService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
    this._baseUrl = configSvc.getApiURI();
  }

  searchPramChange(event) {
    var self = this;
    self.priceSpecCodeList = new Array();
    var eventLen = event.length;
    if (eventLen == 0) {
      //self.priceSpecCodeList = new Array();
      return;
    }


    this.preSearch.forEach(function (val) {
      var isExit = val['price_spec_name'].startsWith(event)
      if (isExit == true) {
        self.priceSpecCodeList.push(val);
      }
    });

    if (self.priceSpecCodeList.length == 0) {
      this._priceSpecService.getPriceSpec(event).subscribe((priceSpecNameList: IPRICE_SPEC[]) => {
        this.priceSpecData = priceSpecNameList;
        if (priceSpecNameList != null && priceSpecNameList.length > 0) {
          priceSpecNameList.forEach(function (itemPriceSpec) {
            var info = self.preSearch.filter(pc => pc.price_spec_id == itemPriceSpec.price_spec_id && pc.price_spec_name == itemPriceSpec.price_spec_name);
            if (info.length == 0) {
              self.preSearch.push(itemPriceSpec);
              self.priceSpecCodeList.push(itemPriceSpec);
            }
          });
        } else {
          self.priceSpecCodeList = new Array();
          this.price_spec_name = "";
          this.price_spec_note = '';
          this.price_spec_upload = '';
          this.price_spec_file_exists = '';
        }
      });
    }
  }

  selectedPram(value: string) {

    this.priceSpecSearch = value;
    this.priceSpecCodeList = new Array();
  }
  onBlur(val) {
    
     this.priceSpecCodeList = new Array();
     this.priceSpecSearch = "";

  }

  search() {

    this.isNewRecord = false;
    if (this.priceSpecSearch.trim() == '') {
      toastr.error("Please enter Price Specification Name");
      return;
    } else {
      this.exactPriceSpecMatch();
    }
  }

  exactPriceSpecMatch() {
    // var self = this;
    // if (self.priceSpecCodeList.length == 0) {
    //   toastr.info("Record Not Found");
    //   return;
    // }
    // if (self.priceSpecCodeList.length == 1) {
    this.getPriceSpecDetailsByCode(this.priceSpecSearch);
    //self.priceSpecCodeList = [];
    // }
  }

  getPriceSpecDetailsByCode(code: string): any {
    this.isNewRecord = false;
    this.priceSpecSearch = code;
    this._priceSpecService.getPriceSpecDetaiilsByCode(code).subscribe((pricespec: IPRICE_SPEC[]) => {
      this.priceSpecFilterData = pricespec;
      this.priceSpecCodeList = new Array();
      if (this.priceSpecFilterData != null) {
        this.price_spec_id = pricespec['price_spec_id'];
        this.price_spec_name = pricespec['price_spec_name'];
        this.price_spec_upload = pricespec['filename'];
        this.price_spec_file_exists = pricespec['filename'];
        this.price_spec_note = pricespec['note_description'];
        this.getUploadFile();
      }
      else {
        toastr.info("Details not available");
        this.price_spec_name = "";
        this.price_spec_note = "";
        this.price_spec_upload = "";
        this.price_spec_file_exists = "";
      }
    });
  }

  getUploadFile() {
    
    var servicePath = "getPriceSpecFile?priceSpecId=";
    this.uploadFile = this._baseUrl + servicePath + this.price_spec_id;
  }

  addPriceSpec() {
    this.price_spec_id = 0;
    this.price_spec_name = this.priceSpecSearch;
    this.price_spec_note = "";
    this.price_spec_upload = "";
    this.isNewRecord = true;
    this.price_spec_file_exists = "";
  }

  onClick(e) {
    e.target.value = null;
  }

  onFileChange(event) {
    let fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      let file: File = fileList[0];

      if ((file.name.split(".").pop()).toLowerCase() != "pdf" && (file.name.split(".").pop()).toLowerCase() != "html" && (file.name.split(".").pop()).toLowerCase() != "htm") {
        event.target.value = null;
        toastr.warning("The chosen file should be in pdf or htm or html format.");

      }
      else {
        this.requestData.append('file', file, file.name);
        if ((file.name.split(".").pop()).toLowerCase() == "pdf")
          this.requestData.append('pdf_or_html', "P");
        else if (((file.name.split(".").pop()).toLowerCase() == "html" || (file.name.split(".").pop()).toLowerCase() == "htm"))
          this.requestData.append('pdf_or_html', "H");
        this.price_spec_upload = file.name;
        this.price_spec_file_exists = "";  //to control donload file link
      }
    }
  }

  savePriceSpec() {
    this.priceSpecData = [];
    if (this.price_spec_name == "" || this.price_spec_note == "") {
      toastr.warning("None of the field should be empty");
      return;
    }

    if(this.price_spec_name.indexOf("*")!=-1)
    {
      toastr.warning("Special character not allowed in price spec.");
      return;
    }
    if (this.isNewRecord) {
      // this._priceSpecService.getPriceSpec(this.price_spec_name).subscribe((priceSpecNames: IPRICE_SPEC[]) => {
      //   var matchedPriceSpecName = priceSpecNames.filter(priceSpecName => priceSpecName.price_spec_name === this.price_spec_name);
      //   if (matchedPriceSpecName.length != 0) {
      this._priceSpecService.checkIfPriceSpecNameAlreadyExists(this.price_spec_name.trim()).subscribe((response: any) => {
        if (response) {
          toastr.error(this.price_spec_name + " already exists!  Please try with new Price Spec.");
          return;
        } else {
          this.save();
        }
      })
    } else {
      this.save();
    }
  }

  save() {
    
    this.requestData.append('price_spec_id', this.price_spec_id.toString());
    this.requestData.append('price_spec_name', this.price_spec_name);
    this.requestData.append('note_description', this.price_spec_note);
    this.price_spec_upload = "";
    this.price_spec_file_exists = "";   //Writing here to clear this field as this is not get clear after ajax post back
    this._priceSpecService.savePriceSpecDetails(this.requestData)
    this.clearControls();
  }

  cancelPriceSpecCode() {
    this._router.navigate(['home']);
  }

  clearControls() {
    this.priceSpecSearch = "";
    this.priceSpecFilterData = [];
    this.priceSpecData = [];
    this.price_spec_id = 0;
    this.price_spec_name = "";
    this.price_spec_note = "";
    this.price_spec_upload = "";
    this.price_spec_file_exists = "";

    $("#idFile").val('').clone(true);
    this.requestData = new FormData();
    this._router.navigate(['pricespecmaster']);
  }
}
