import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { GlobalService } from "./../../services/shared/global.service";
import { IUSER_MASTER, IREIMB_CODE } from '../../shared/interfaces/entities.interface';
import { ReimbMasterService } from '../../services/reimbmaster.service';
import { DataService } from '../../services/data.service';
import { DropDown } from '../../shared/common';
import { ModalComponent } from '../shared/modalpopup.component';

import { AutocompleteComponent } from '../shared/autocomplete.component';

declare var $: any;

@Component({
  selector: 'app-reimbmaster',
  templateUrl: './reimbmaster.component.html?v=${new Date().getTime()}',
  providers: [ReimbMasterService, DataService]
})
export class ReimbMasterComponent implements OnInit, AfterViewInit {

  user: IUSER_MASTER;
  actionCodeDropDown: DropDown[];
  reimbCodeData: IREIMB_CODE[];
  reimbCodeDataBackup: IREIMB_CODE[];
  NewReimbCode: any;
  reimbCodeChangesData: any;
  reimbCodeNoteData: any;
  isSearch: boolean = false;
  searchResult: any;
  isAddCodeChangeRow: boolean = false;
  isAddUserNotesRow: boolean = false;
  showTabs: boolean = true;
  existingReimCode = {
    hcpc_code: "",
    hcpc_desc: ""
  }

  searchPram = {
    hcpc_code: '',
    hcpc_desc: '',
    ndc: '',
  }

  preSearch: any = [{ "searchOn": 1, "data": [] }, { "searchOn": 2, "data": [] }, { "searchOn": 3, "data": [] }];
  newData: any[] = new Array();

  hcpcList: any[] = new Array();
  hcpcDescList: any[] = new Array();
  ndcList: any[] = new Array();

  @ViewChild('modalReimbCodeList') modalReimbCodeList: ModalComponent;
  @ViewChild('modalCheckNewReimbCode') modalCheckNewReimbCode: ModalComponent;

  constructor(private _globalSvc: GlobalService,
    private _router: Router,
    private _reimbMasterSvc: ReimbMasterService<IREIMB_CODE>,
    private _datasvc: DataService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSvc.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {
    //this.showReimbCodedata();
    this.setNewReimbCode();
    this.showTabs = false;
    this.isAddCodeChangeRow = false;
    this.isAddUserNotesRow = false;
  }

  ngAfterViewInit() {
    $('#EffectiveDate').datepicker({
      format: 'mm/dd/yyyy',
      //startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      if (this.showTabs)
        this.NewReimbCode['ori_code_eff_date'] = event.target.value;
      else
        this.reimbCodeData[0]['ori_code_eff_date'] = event.target.value;
    });

    $('#TerminalDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      if (this.showTabs)
        this.NewReimbCode['term_date'] = event.target.value;
      else
        this.reimbCodeData[0]['term_date'] = event.target.value;
    });

    $('#ActionDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.NewReimbCode['chg_eff_date'] = event.target.value;
    });
  }

  private setNewReimbCode() {
    this.NewReimbCode = {
      "hcpc_code": "",
      "ori_code_eff_date": "",
      "term_date": "",
      "is_admin_code": "",
      "is_noc_code": "",
      "cms_desc": "",
      "rj_addl_desc": "",
      "action_cd": "0",
      "chg_eff_date": "",
      "note_description": "",
      "strength": "",
      "strength_uom": "",
      "created_by": "",
      "created_date": new Date()
    }
  }

  private searchPramChange(event, searchOn: number) {
    var self = this;
    var eventLen = event.length;
    this.newData = new Array();

    self.hcpcList = [];
    self.hcpcDescList = [];
    self.ndcList = [];

    if (eventLen < 3) {
      return;
    }
    var getExists = this.preSearch.filter(obj => (obj.searchOn == searchOn));
    var existingData = getExists[0].data || [];

    if (existingData.length > 0) {
      getExists[0].data.forEach(function (val) {
        if (val.length > 0) {
          var isExit = val.startsWith(event)
          if (isExit == true) {
            self.newData.push(val);
          }
        }
      });
    }
    switch (searchOn) {
      case 1: //hcpc_code
        if (this.newData.length > 0) {
          self.hcpcList = this.newData;
        } else {
          this._reimbMasterSvc.getHCPCByCode(event).subscribe((hcpcList) => {
            if (hcpcList != null && hcpcList.length > 0) {
              hcpcList.forEach(function (hcpc) {

                var reim = self.preSearch.filter(r => r.searchOn == 1);
                var found = reim[0].data.indexOf(hcpc.hcpc_code);
                if (found == -1) {
                  getExists[0].data.push(hcpc.hcpc_code);
                  self.hcpcList.push(hcpc.hcpc_code);
                }
              });
            } else {
              self.hcpcList = new Array();
            }
          });
        }
        break;
      case 2: //hcpc_desc
        debugger;
        if (this.newData.length > 0) {
          self.hcpcDescList = this.newData;
        } else {
          this._reimbMasterSvc.getHCPCByDescription(event).subscribe((hcpcDescList) => {
            if (hcpcDescList != null && hcpcDescList.length > 0) {
              hcpcDescList.forEach(function (desc) {
                var hcpcDesc = desc['rj_addl_desc'] != null ? desc['rj_addl_desc'] : desc['cms_desc'];
                getExists[0].data.push(hcpcDesc);
                self.hcpcDescList.push(hcpcDesc);
              });
            } else {
              self.hcpcDescList = new Array();
            }
          });
        }
        break;
      case 3: //ndc
        if (this.newData.length > 0) {
          self.ndcList = this.newData;
        } else {
          this._datasvc.getDistinctNDC(event).subscribe((ndcList) => {
            if (ndcList['Result'] != null && ndcList['Result'].length > 0) {
              ndcList.Result.forEach(function (ndc) {
                getExists[0].data.push(ndc.ndc);
                self.ndcList.push(ndc.ndc);
              });
            } else {
              self.ndcList = new Array();
            }
          });
        }
        break;
    }
  }

  private selectedPram(value: string, selectedFor: number) {
    switch (selectedFor) {
      case 1: //hcpc_code
        this.searchPram.hcpc_code = value;
        this.hcpcList = new Array();
        break;
      case 2: //hcpc_desc
        this.searchPram.hcpc_desc = value;
        this.hcpcDescList = new Array();
        break;
      case 3: //ndc
        this.searchPram.ndc = value;
        this.ndcList = new Array();
        break;
    }
  }

  private search() {
    if (this.searchPram.hcpc_code == "" && this.searchPram.hcpc_desc == "" && this.searchPram.ndc == "") {
      toastr.error('Enter searching criteria');
    } else {
      this._reimbMasterSvc.getHcpcCodeWithHcpcDesc(this.searchPram.hcpc_code, this.searchPram.hcpc_desc, this.searchPram.ndc).subscribe((res: any) => {
        this.searchResult = res;
        if (this.searchResult != undefined && this.searchResult.length > 0) {
          this.modalReimbCodeList.show();
          this.isAddCodeChangeRow = false;
          this.isAddUserNotesRow = false;
          this.isSearch = true;
          this.showTabs = false;
        }
        else {
          toastr.error("Record not found");
        }
      });
      this.clearAntocompleate();
    }
  }

  private getReimbByCode(hcpc_code, hcpc_desc, ndc): any {
    hcpc_code != null ? this.searchPram.hcpc_code = hcpc_code : this.searchPram.hcpc_code = "";
    hcpc_desc != null ? this.searchPram.hcpc_desc = hcpc_desc : this.searchPram.hcpc_desc = "";
    ndc != null ? this.searchPram.ndc = ndc : this.searchPram.ndc = "";
    this.showTabs = false;

    this._reimbMasterSvc.getReimbCode(this.searchPram).subscribe((res: any) => {
      this.reimbCodeData = res;
    });

    this._reimbMasterSvc.getReimbCodeChange(this.searchPram).subscribe((res: any) => {

      this.reimbCodeChangesData = res;
    });

    this._reimbMasterSvc.getReimbCodeNotes(this.searchPram.hcpc_code).subscribe((res: any) => {
      this.reimbCodeNoteData = res;
    });


    this.reimbCodeDataBackup = Object.assign({}, this.reimbCodeData);
    this.modalReimbCodeList.hide();
    this.ngAfterViewInit();
  }

  private redirectInfocode() {
    this._globalSvc.Overwrite = this.searchPram.hcpc_code.trim();
    this._router.navigate(['/hcpcinfocodecrosswalk'])
  }

  private onSelectionChange(codeType, entry) {
    if (codeType == 'adminCode') {
      this.NewReimbCode.is_admin_code = entry;
    }
    else if (codeType == 'nocCode') {
      this.NewReimbCode.is_noc_code = entry;
    }
  }

  private CheckReimCodeExists() {
    this._reimbMasterSvc.getHCPCByCode(this.searchPram.hcpc_code).subscribe((hcpcList) => {
      if (hcpcList != null && hcpcList.length == 0) {
        this.addNewReimbCode();
      }
      else if (hcpcList != null && hcpcList.length > 0 && hcpcList[0]['hcpc_status'] == "Active") {
        this.existingReimCode.hcpc_code = hcpcList[0]['hcpc_code'];
        this.modalCheckNewReimbCode.show();
      }
      else {
        toastr.warning("Reimb code already exists with Active status.Please try with new Reim code");
        return;
      }
    });
  }

  private updateExistingReimbCode() {
    this.modalCheckNewReimbCode.hide();
    // var newReimbCode = this.searchPram.hcpc_code;
    this.getReimbByCode(this.searchPram.hcpc_code, this.searchPram.hcpc_desc, this.searchPram.ndc)

  }

  private addNewReimbCode() {
    this.showTabs = true;
    this.isAddUserNotesRow = false;
    this.isAddCodeChangeRow = false;
    this.NewReimbCode = new Array();
    this.NewReimbCode['hcpc_code'] = newReimbCode;
    this.clearAntocompleate();
    var newReimbCode = this.searchPram.hcpc_code;
    this.showTabs = true;
    this.NewReimbCode['hcpc_code'] = newReimbCode;
    this.reimbCodeChangesData = [{
      "cms_desc": "",
      "rj_addl_desc": "",
      "action_cd": "",
      "chg_eff_date": "",
      "strength": "",
      "strength_uom": ""
    }];
    this.reimbCodeNoteData = [{
      "note_description": "",
      "created_by": "",
      "created_date": ""
    }]
    this.reimbCodeData = [];
  }

  private addCodeChangeRow() {
    this.isAddCodeChangeRow = true;
    this._datasvc.getDropdownData().subscribe((res: any) => {
      this.actionCodeDropDown = res.ActionCodeDropDown;
    })
  }

  private addUserNotesRow() {
    this.isAddUserNotesRow = true;
  }

  private save() {
    debugger;
    var oNotes;
    var pushNotes = [];
    var oCodeChangeDetails;
    var pushCodeChangeDetails = [];
    for (var prop in this.NewReimbCode) {
      if (this.NewReimbCode[prop] == undefined) { this.NewReimbCode[prop] = ""; }
    }
    if (this.showTabs) {
      if ((this.NewReimbCode['hcpc_code'] == undefined || this.NewReimbCode['hcpc_code'] == "")
        || (this.NewReimbCode['ori_code_eff_date'] == undefined || this.NewReimbCode['ori_code_eff_date'] == "")
        // || (this.NewReimbCode['term_date'] == undefined || this.NewReimbCode['term_date'] == "")
        || (this.NewReimbCode['is_admin_code'] == undefined || this.NewReimbCode['is_admin_code'] == "")
        || (this.NewReimbCode['is_noc_code'] == undefined || this.NewReimbCode['is_noc_code'] == "")) {
        toastr.warning("Enter Reim Code ,Effective date , Termination date,Admin code and NOC code");
        return;
      }
      if ((this.NewReimbCode['cms_desc'] == undefined || this.NewReimbCode['cms_desc'] == "") ||
        ((this.NewReimbCode['rj_addl_desc'] == undefined || this.NewReimbCode['rj_addl_desc'] == "")) ||
        ((this.NewReimbCode['strength'] == undefined || this.NewReimbCode['strength'] == "")) ||
        ((this.NewReimbCode['strength_uom'] == undefined || this.NewReimbCode['strength_uom'] == ""))) {
        toastr.warning("Please use Add Row option to enter code changes related details");
        return;
      }
      else {
        oCodeChangeDetails = {
          "hcpc_desc_chg_id": 0,
          "rc_id": 0,
          "cms_desc": this.NewReimbCode['cms_desc'],
          "rj_addl_desc": this.NewReimbCode['rj_addl_desc'],
          "action_cd": "",
          "chg_eff_date": "",
          "strength": this.NewReimbCode['strength'],
          "strength_uom": this.NewReimbCode['strength_uom']
        }
        pushCodeChangeDetails.push(oCodeChangeDetails);
      }
      if (this.NewReimbCode['note_description'] == undefined || this.NewReimbCode['note_description'] == "") {
        // toastr.warning("Please use Add Row option to Enter Notes in Notes table");
        // return;
      }
      else {
        oNotes = {
          "hcpc_notes_id": 0,
          "note_description": this.NewReimbCode['note_description'],
          "created_by": this.user['user_name'],
          "created_date": new Date()
        }
        pushNotes.push(oNotes);
      }
    }
    else {
      if ((this.reimbCodeData[0]['hcpc_code'] == undefined || this.reimbCodeData[0]['hcpc_code'] == "") || ((this.reimbCodeData[0]['ori_code_eff_date'] == undefined || this.reimbCodeData[0]['ori_code_eff_date'] == "")) || ((this.reimbCodeData[0]['term_date'] == undefined || this.reimbCodeData[0]['term_date'] == ""))) {
        toastr.warning("Reim Code ,Effective date and Termination date cant be blank");
        return;
      }
      if (this.isAddCodeChangeRow) {
        if ((this.NewReimbCode['cms_desc'] == undefined || this.NewReimbCode['cms_desc'] == "") ||
          ((this.NewReimbCode['rj_addl_desc'] == undefined || this.NewReimbCode['rj_addl_desc'] == "")) ||
          ((this.NewReimbCode['action_cd'] == undefined || this.NewReimbCode['action_cd'] == "")) ||
          ((this.NewReimbCode['chg_eff_date'] == undefined || this.NewReimbCode['chg_eff_date'] == "")) ||
          ((this.NewReimbCode['strength'] == undefined || this.NewReimbCode['strength'] == "")) ||
          ((this.NewReimbCode['strength_uom'] == undefined || this.NewReimbCode['strength_uom'] == ""))) {
          toastr.warning("Please use Add Row option to enter code changes related details");
          return;
        }
        else {
          oCodeChangeDetails = {
            "hcpc_desc_chg_id": 0,
            "rc_id": 0,
            "cms_desc": this.NewReimbCode['cms_desc'],
            "rj_addl_desc": this.NewReimbCode['rj_addl_desc'],
            "action_cd": this.NewReimbCode['action_cd'] != null ? this.NewReimbCode['action_cd'].substr(0, 14) : "",
            "chg_eff_date": this.NewReimbCode['chg_eff_date'],
            "strength": this.NewReimbCode['strength'],
            "strength_uom": this.NewReimbCode['strength_uom']
          }
          pushCodeChangeDetails.push(oCodeChangeDetails);
        }
      }
      if (this.isAddUserNotesRow) {
        if (this.NewReimbCode['note_description'] == undefined || this.NewReimbCode['note_description'] == "") {
          toastr.warning("Please use Add Row option to Enter Notes in Notes table");
          return;
        }
        else {
          oNotes = {
            "hcpc_notes_id": 0,
            "note_description": this.NewReimbCode['note_description'],
            "created_by": this.user['user_name'],
            "created_date": new Date()
          }
          pushNotes.push(oNotes);
        }
      }
    }

    var saveData = {
      "reimb_master_details": {
        "rc_id": this.showTabs == false ? this.reimbCodeData[0]['rc_id'] : 0,
        "hcpc_code": this.showTabs == false ? this.reimbCodeData[0]['hcpc_code'] : this.NewReimbCode['hcpc_code'],
        "ori_code_eff_date": this.showTabs == false ? this.reimbCodeData[0]['ori_code_eff_date'] : this.NewReimbCode['ori_code_eff_date'],
        "term_date": this.showTabs == false ? this.reimbCodeData[0]['term_date'] : (this.NewReimbCode['term_date'] == "" ? null : this.NewReimbCode['term_date']),
        "is_admin_code": this.showTabs == false ? this.reimbCodeData[0]['is_admin_code'] : this.NewReimbCode['is_admin_code'],
        "is_noc_code": this.showTabs == false ? this.reimbCodeData[0]['is_noc_code'] : this.NewReimbCode['is_noc_code']
      },
      "code_change_details": pushCodeChangeDetails,
      "notes": pushNotes
    }

    this._reimbMasterSvc.SaveReimbCode(saveData).subscribe((res: any) => {

      if (res['Result'] != null || res['Result'] == "Success") {
        toastr.success("Reimb Master Data saved successfully");
        this.searchPram['hcpc_code'] = this.NewReimbCode['hcpc_code'];
        this.getReimbByCode(this.searchPram.hcpc_code, this.searchPram.hcpc_desc, this.searchPram.ndc);
        this.cancel();
      }
    });
    this.showTabs = false;
  }

  private cancel() {
    this.isAddUserNotesRow = false;
    this.isAddCodeChangeRow = false;
    this.NewReimbCode = new Array();
    this.clearAntocompleate();
    this._router.navigate(['home']);
  }

  private clearAntocompleate() {
    this.hcpcList = new Array();
    this.hcpcDescList = new Array();
    this.ndcList = new Array();
  }
}
