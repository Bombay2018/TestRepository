import { Component, OnInit, AfterViewInit, ElementRef, Input, ViewChild } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Router } from '@angular/router';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';


import { IUSER_MASTER, IFILE_UPLOAD_MASTER } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";
import { DataService } from '../../services/data.service';
import { ConfigService } from '../../services/shared/config.service';
import { UploadFileService } from '../../services/uploadFile.service';
//import {MultipartUploader} from "../../plugins/multipart-upload/multipart-uploader";

declare var $: any;

@Component({
  selector: 'app-uploadmaster',
  moduleId: module.id,
  templateUrl: './uploadmaster.component.html?v=${new Date().getTime()}',
  providers: [DataService, UploadFileService]
})
export class UploadMasterComponent implements OnInit {

  user: IUSER_MASTER;
  uploadFileMaster: IFILE_UPLOAD_MASTER = {} as IFILE_UPLOAD_MASTER;
  uploadFileDetails: FormData= new FormData();
  //uploader:FileUploader = new FileUploader({url: 'https://evening-anchorage-3159.herokuapp.com/api/'});
  //@ViewChild('fileInput') inputEl: ElementRef;  

  constructor(private http: Http, private _globalSev: GlobalService, private dataSvc: DataService,
    private _router: Router,private uploadFileService: UploadFileService<IFILE_UPLOAD_MASTER>) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);

  }


  ngOnInit() {
    this.uploadFileMaster['type']="0";
    this.uploadFileMaster['eff_Date']="";
    this.uploadFileMaster['file']="";

  }
  ngAfterViewInit() {
    $('#effectiveDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.uploadFileMaster['eff_Date'] = event.target.value;
    });

  }

  saveUploadMaster() {

    if (this.uploadFileMaster.eff_Date == "" || this.uploadFileMaster.file == "" || this.uploadFileMaster.type == "0") {

      toastr.error("Please enter all field details ");
      return;
    }
    else {

      //     $.ajax({
      //     url: 'http://192.168.133.150:9000/services/UploadMaster',
      //     type: "POST",
      //     contentType: false,
      //     processData: false,
      //     data: this.uploadFileDetails,
      //     success: function (response) {
      //       toastr.success("File details uploaded successfully");
      //       this.cancelUpload();
      //     },
      //     error: function () {
      //       toastr.error("Error while saving File details");  
      //       this.uploadFileMaster.type="0";
      //       this.cancelUpload();
      //     }
      // });
      //   $.ajax({
      //     url: 'http://192.168.133.150:9000/services/UploadMaster',
      //     type: "POST",
      //     contentType: false,
      //     processData: false,
      //     data: this.formData,
      //     success: function (response) {
      //       toastr.success("File detail uploaded successfully");
      //       this.uploadFileMaster.type="0";
      //     },
      //     error: function () {
      //       toastr.error("Error while saving File details");  
      //       this.uploadFileMaster.type="0";
      //     }
      // });
      this.uploadFileDetails.append('eff_date', this.uploadFileMaster.eff_Date);
      this.uploadFileDetails.append('type', this.uploadFileMaster.type);

      this.uploadFileMaster['file']="";
      this.uploadFileService.uploadFileDetails(this.uploadFileDetails);
      //var narrativeResponse=this.uploadFileService.uploadFileDetails(this.uploadFileDetails);
       
      // if (narrativeResponse === "success"){
     
      //   toastr.success("File detail uploaded successfully");
      // }
      // else if (narrativeResponse === "error"){
      //   toastr.error("Error while saving File details");        
      // }

      this.ClearUploadControl();
     
    
  }
}

  cancelUpload() {
    // this.uploadFileMaster['eff_Date'] = "";
    // this.uploadFileMaster['file'] = "";
    // this.uploadFileMaster['type'] = "0";
    this._router.navigate(['home']);
  }

  ClearUploadControl() {
    this.uploadFileMaster['eff_Date'] = "";
    this.uploadFileMaster['file'] = "";
    this.uploadFileMaster['type'] = "0";
    this.uploadFileDetails=new FormData();
    this._router.navigate(['uploadmaster']);
    
  }
  onClick(e){
    e.target.value=null;
  }

  onFileChange(e) {
    let fileList: FileList = e.target.files;
    if (fileList.length > 0) {
      let file: File = fileList[0];

      if ((file.name.split(".").pop()).toLowerCase() !="xlsx" && (file.name.split(".").pop()).toLowerCase() !="XLSX") {
        e.target.value=null; 
        toastr.warning("The chosen file should be in XLSX/xlsx format.");       
        return;
      }
      else{
        this.uploadFileMaster.file=file.name;
        this.uploadFileDetails.append('file', file, file.name);
      }

      

      //         $.ajax({
      //     url: 'http://192.168.133.150:9000/services/UploadMaster',
      //     type: "POST",
      //     contentType: false,
      //     processData: false,
      //     data: formData,
      //     success: function (response) {
      //       toastr.success("File detail uploaded successfully");
      //       this.uploadFileMaster.type="0";
      //     },
      //     error: function () {
      //       toastr.error("Error while saving File details");  
      //       this.uploadFileMaster.type="0";
      //     }
      // });
      //     let headers = new Headers();
      //     /** No need to include Content-Type in Angular 4 */
      //      headers.append('ContentType', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      //     headers.append('Accept', 'application/json');
      //     let options = new RequestOptions({ headers: headers });
      //     this.http.post(`http://192.168.133.150:9000/services/UploadMaster`, formData, options)
      //         .map(
      //           res => res.json()
      //         )
      //         .catch(
      //           error => Observable.throw(error)
      //         )
      //         .subscribe(
      //             data => console.log('success'),
      //             error => console.log(error)
      //         )
      // }
      // 
      // let inputEl: HTMLInputElement = this.inputEl.nativeElement;
      // let fileCount: number = inputEl.files.length;
      // this.formData = new FormData();
      // 
      //  //this.formData.append('file', inputEl.files.item(0),inputEl.files.item(0).name);  
      // // this.uploadFileMaster.file.append('file', inputEl.files.item(0),inputEl.files[0]['name']); 
      // //this.uploadFileMaster.file.append('file', inputEl.files.item(0),inputEl.files[0]['name']);  
      // //this.uploadFileMaster.file.append('type',  "user_info");
      //}
      // onFileChange1(event) {      
      //   if(event.target.files && event.target.files.length > 0) {
      //     let file = event.target.files[0];        
      //     this.formData = new FormData();
      //     this.formData.append('file', file);
      //     this.uploadFileMaster.file=  this.formData;
      //     this.uploadFileMaster.type=  "user_info";

      //   }
      // }
    }
  }
}


