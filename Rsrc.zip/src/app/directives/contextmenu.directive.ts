import { Directive, Input } from '@angular/core';
import { ContextMenuService } from './../services/shared/contextmenu.service';

@Directive({
  selector: '[context-menu]',
  host: { '(contextmenu)': 'rightClicked($event)' }
})
export class ContextMenuDirective {
  @Input('context-menu') contexMenu;

  constructor(private _contextMenuService: ContextMenuService) { }

  rightClicked(event: MouseEvent) {
    var cell: any = event.currentTarget;
    switch (cell.className) {
      case "danger":
        this.contexMenu[0].enable = true;
        this.contexMenu[1].enable = true;
        break;

      default:
        this.contexMenu[0].enable = true;
        this.contexMenu[1].enable = true;
    }
    this._contextMenuService.show.next(
      { event: event, obj: this.contexMenu }
    );
    event.preventDefault();
  }
}