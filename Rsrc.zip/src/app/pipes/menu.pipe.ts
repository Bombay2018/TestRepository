import {Pipe, PipeTransform} from '@angular/core';

@Pipe({  name: 'menuAccess' })
export class menuAccess implements PipeTransform {
  transform(records: Array<any>, main?: any): any {
      return records.filter(mnu => mnu.menu==main); 
  }
}