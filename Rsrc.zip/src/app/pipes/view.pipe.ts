
import {Pipe, PipeTransform} from '@angular/core';

@Pipe({  name: 'viewfilter' })
export class viewfilter implements PipeTransform {
  transform(records: Array<any>, args?: any): any {
      return records.filter(ndc => ndc.calc_flag!=args.calflag); 
  }
}
