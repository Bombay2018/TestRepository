import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers,RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { ConfigService } from '../services/shared/config.service';
import { IBD_SPEC,IPART_BVSD_SUPER_SIX_MAP,INDC_ATTRIBUTES,IDDC10_ATTRIBUTES,IDDC10_SAVE_ATTRIBUTES } from '../shared/interfaces/entities.interface';

@Injectable()
export class DDC10Service<T>{

    private _baseUrl: string = '';
    private _headers: any;

    constructor(private http: Http, private configSvc: ConfigService,) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    //Distinct searches

    getDistinctICDCodes(ICD_Code: string){
        return this.http
            //.get(this._baseUrl + 'DistinctICDCodes?icdCode=' + ICD_Code )
            .get(this._baseUrl + 'DistinctIcdForXwalk?icd10=' + ICD_Code )
            .map(resp => resp.json());
    }
    getDistinctICDCodesDetails(ICD_Code: string,ICD_Description: string){
        return this.http
            .get(this._baseUrl + 'retrieveIcd10AndDesc?icd10=' + ICD_Code + '&Desc=' + ICD_Description)
            .map(resp => resp.json().Result);
    }

    getDistinctICDCodesDesc(ICD_Description: string){
        return this.http
            .get(this._baseUrl + 'DistinctICDCodesDesc?icdDesc=' + ICD_Description)
            .map(resp => resp.json());
    }

    //End of Distinct searches

    //Serach popup service
    //hcpc_code=J901&icdCode=a04
    //'http://192.168.133.31:9000/services/'
    getDDC10Search(hcpc_code:string,icdCode:string,ICD_Description: string): Observable<any[]> {
        return this.http
            .get(this._baseUrl + 'HcpcDdc10Search?hcpc_code=' + hcpc_code + '&icd10=' + icdCode + '&short_title=' + ICD_Description)
            .map((res: Response) => {
                //console.log(res.json().Result[0])
                return <any[]>res.json().Result
            });
    }
    //hcpc_icd10_xwalk_id=4
    //Get Details based on HCPC-ICD code
    //'http://192.168.133.31:9000/services/'
    getDDC10DetailsByDDCCode(rc_id: Number): Observable<IDDC10_ATTRIBUTES[]> {
        return this.http
            .get(this._baseUrl + 'HcpcICDCodesDescSearchData?rc_id='+rc_id)
            .map((res: Response) => {
                return <IDDC10_ATTRIBUTES[]>res.json().Result;
            });
    }
    // 'http://192.168.133.31:9000/services/'
    getExactHCPCCode(hcpc_code:string): Observable<any[]> {
        return this.http
            .get(this._baseUrl + 'retrieveHcpcCode?hcpc_code=' + hcpc_code)
            .map((res: Response) => {
                //console.log(res.json().Result[0])
                return <any[]>res.json().Result
            });
    }

    getChildICDDetails(icdCode:string): Observable<any[]> {
        return this.http
            .get(this._baseUrl + 'IcdDetailList?icd10=' + icdCode)
            .map((res: Response) => {
                //console.log(res.json().Result[0])
                return <any[]>res.json().Result
            });
    }

    
    HcpcIcdCodeMappingSave(saveDDC10Mapping: any) {
        let body = saveDDC10Mapping;
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post( this._baseUrl + 'HcpcIcdCodeMappingSave', body, options)
            .map(resp => resp.json());
            //'http://192.168.133.31:9000/services/' 
            //'http://192.168.133.159:8081/services/'

    }



}