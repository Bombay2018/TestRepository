import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IBD_SPEC, IPART_BVSD_SUPER_SIX_MAP, INDC_ATTRIBUTES } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class NDCPartBvsDService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public NDCPartBvsD: IBD_SPEC;

    constructor(private http: Http, private configSvc: ConfigService, ) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getDistinctPartBvsDStatus(): Observable<any[]> {
        return this.http
            .get(this._baseUrl + 'retrieveDistinctPartBvsDStatus')
            .map(resp => resp.json());
    }

    getDistinctPartBvsDName(bvsd_name: string) {
        return this.http
            .get(this._baseUrl + 'retrieveDistinctPartBvsDName?bvsd_name=' + bvsd_name)
            .map((res: Response) => {
                return res.json()
            });
    }

    getDistinctPartBVsDGeneric(genericNameSearch: string) {
        return this.http
            .get(this._baseUrl + 'NdcPartBVsDGenericName?genericNameSearch=' + genericNameSearch)
            .map(resp => resp.json());
    }

    getDistinctPartBVsDBrand(brandNameSearch: string) {
        return this.http
            .get(this._baseUrl + 'NdcPartBVsDBrandName?brandNameSearch=' + brandNameSearch)
            .map(resp => resp.json());
    }

    getNdcPartBvsDSearch(BvsDName: string, GenericName: string, NDC: string, BrandName: string): Observable<any[]> {
        return this.http
            .get(this._baseUrl + 'NdcPartBvsDSearch?BvsDName=' + BvsDName + '&GenericName=' + GenericName + '&NDC=' + NDC + '&BrandName=' + BrandName + '&BvsDStatus =')
            .map((res: Response) => {
                return <any[]>res.json().Result
            });
    }

    getPartBvsDAttributeDetails(part_bvsd_id: Number): Observable<IPART_BVSD_SUPER_SIX_MAP[]> {
        return this.http
            .get(this._baseUrl + 'PartBvsDAttributeDetails?part_bvsd_id=' + part_bvsd_id)
            .map((res: Response) => {
                return <IPART_BVSD_SUPER_SIX_MAP[]>res.json().Result;
            });
    }

    getlistOfNdcsForCombination(combinationId: Number, combinationTempId: Number): Observable<INDC_ATTRIBUTES[]> {

        var url = '';
        if (combinationId != null) {
            url = 'listOfNdcsForCombination?combinationId=' + combinationId;
        }
        else {
            url = 'listOfNdcsForCombination?combinationTempId=' + combinationTempId;
        }
        return this.http
            .get(this._baseUrl + url)
            .map((res: Response) => {
                return <INDC_ATTRIBUTES[]>res.json().Result;
            });
    }

    getPartBvsDRuleFailures(part_bvsd_id: Number): Observable<any> {
        return this.http
            .get(this._baseUrl + 'listOfRuleFailuresPartBvsD?partBvsDId=' + part_bvsd_id)
            .map((res: Response) => {
                return <any[]>res.json().Result;
            });
    }

    getPartBvsDFollowupDate(part_bvsd_id: Number): Observable<any> {
        return this.http
            .get(this._baseUrl + 'PartBvsDFollowupDate?part_bvsd_id=' + part_bvsd_id)
            .map((res: Response) => {
                return <any[]>res.json().Result;
            });
    }

    getNdcPartBvsDFurtherRoutingNotes(part_bvsd_id: Number): Observable<any> {
        return this.http
            .get(this._baseUrl + 'NdcPartBvsDFurtherRoutingNotes?part_bvsd_id=' + part_bvsd_id)
            .map((res: Response) => {
                return <any[]>res.json().Result;
            });
    }

    recalPartBvsD(reqJson) {
        let options = new RequestOptions({ headers: this._headers });
        let body = reqJson;
        return this.http
            .post(this._baseUrl + 'recalPricePartBvsD', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    requestToPublishPartBvsD(reqJson) {
        let options = new RequestOptions({ headers: this._headers });
        let body = reqJson;
        return this.http
            .post(this._baseUrl + 'reuestToPublishPartBvsDCrossWalk', body, options)
            .map((res: Response) => {
                return res.json().result;
            });
    }

    publishPartBvsD(reqJson) {
        let options = new RequestOptions({ headers: this._headers });
        let body = reqJson;
        return this.http
            .post(this._baseUrl + 'publishPartBvsDCrossWalk', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    savePartBvsD(reqJson) {

        let options = new RequestOptions({ headers: this._headers });
        let body = reqJson;
        var url = this._baseUrl + 'savePartBvsDCrossWalk';
        return this.http
            .post(url, body, options)
            .map((res: Response) => {
                return res.json().result;
            });
    }

    getPartBvsDNDCReasonNotes(part_bvsd_id: number, part_bvsd_s6_wc_id: number,part_bvsd_s6_wc_temp_id:number) {
        return this.http
            
        //.get(this._baseUrl + 'PartBvsDNDCReasonNotes?part_bvsd_s6_wc_id=' + part_bvsd_s6_wc_id + '&part_bvsd_id=' + part_bvsd_id)
        .get(this._baseUrl + 'PartBvsDNDCReasonNotes?part_bvsd_id=' + part_bvsd_id + '&part_bvsd_s6_wc_id=' + part_bvsd_s6_wc_id + '&part_bvsd_s6_wc_temp_id=' + part_bvsd_s6_wc_temp_id )
            .map((res: Response) => {
                return <any[]>res.json().Result;
            });
    }
}
