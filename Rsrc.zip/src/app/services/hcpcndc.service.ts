import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IHCPC_SUPER_SIX_COMBINATION, INDC_ATTRIBUTES, IADMIN_CODE, IHCPC_PRICING, IHCPC_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class HCPCNDCService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public hcpcSuperSix: IHCPC_SUPER_SIX_COMBINATION;

    constructor(
        private http: Http,
        private configSvc: ConfigService) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getHCPCByCode(hcpcCode: string) {
        return this.http
            .get(this._baseUrl + "retrieveDistinctHCPCCode?hcpc_code=" + hcpcCode)
            .map(resp => resp.json().Result);
    }

    getHCPCByDescription(hcpcDescription: string) {
        return this.http
            .get(this._baseUrl + "retrieveDistinctHCPCCodeDescription?hcpc_desc=" + hcpcDescription)
            .map(resp => resp.json().Result);
    }

    getHCPCDetails(searchingData) {
        return this.http
            .get(this._baseUrl + "retrieveHCPCDetails?hcpc_code=" + searchingData.hcpc_code + "&hcpc_desc=" + searchingData.hcpc_desc + "&ndc=" + searchingData.ndc)
            .map(resp => resp.json().Result as IHCPC_MASTER[]);
    }

    getHCPCByRcId(rc_id : number) {
        return this.http
            .get(this._baseUrl + 'gethcpcdetails?rcId=' + rc_id)
            .map(resp => resp.json().Result as string[]);
    }

    getHCPCSuperSix(rc_id) {
        return this.http
            .get(this._baseUrl + 'HcpcAttributeDetails?rc_id=' + rc_id)
            .map(resp => resp.json().Result);
    }

    getHcpcPrice(hcpcCode) {
        return this.http
            .get(this._baseUrl + 'retrieveHCPCNDCPricingDetails?hcpc_code=' + hcpcCode)
            .map(resp => resp.json().Result);
    }

    getReasonNotes(s6_wildcard_hcpcs_id, isTemp) {
        return this.http
            .get(this._baseUrl + 'retrieveHCPCNDCReasonNotes?s6_combination_id=' + s6_wildcard_hcpcs_id + "&isTemp=" + isTemp)
            .map(resp => resp.json().Result as string[]);
    }

    //on grid + click
    // getHcpcNdcs(data) {
    //     let options = new RequestOptions({ headers: this._headers });
    //     let body = data;
    //     return this.http
    //         .post(this._baseUrl + 'FetchNdcDetailsForHcpcCombination', body, options)
    //         .map((res: Response) => {
    //             return res.json().Result;
    //         });
    // }

    getNdcndcDiscrepancy(ndcs) {
        //http://192.168.133.74:79/services/FetchWorkQueueRecordsForNdcByHcpcCombination?ndc='08290309571','49999043005'
        return this.http
            .get(this._baseUrl + 'FetchWorkQueueRecordsForNdcByHcpcCombination?hcpc_code=' + ndcs)
            // .get(this._baseUrl + 'FetchWorkQueueRecordsForNdcByHcpcCombination?hcpc_code=' + hcpcCode)
            .map(resp => resp.json().Result as string[]);
    }

    getHcpcStatus(hcpcCode: string) {
        return this.http
            .get(this._baseUrl + 'retrieveChangedHcpcAttributeDetails?hcpc_code=' + hcpcCode)
            .map(resp => resp.json().Result as string[]);
    }

    getRoutingNotes(hcpcCode) {
        return this.http
            .get(this._baseUrl + 'retrieveHCPCNDCFurtherRoutingNotes?hcpc_code=' + hcpcCode)
            .map(resp => resp.json().Result as string[]);
    }

    getAdminCode(hcpcCode: string) {
        return this.http
            .get(this._baseUrl + 'retrieveHCPCNDCAdminCodes?hcpc_code=' + hcpcCode)
            .map(resp => resp.json().Result as IADMIN_CODE[]);
    }

    getdistictAdminCode(adminCode: string) {
        return this.http
            .get(this._baseUrl + 'searchadmincode?adminCode=' + adminCode)
            .map(resp => resp.json());
    }

    IsValidAdminCode(adminCode: string) {
        return this.http
            .get(this._baseUrl + 'isValidAdminCode?adminCode=' + adminCode)
            .map(resp => resp.json().Result);
    }

    deleteAdminCode(data) {
        let options = new RequestOptions({ headers: this._headers });
        let body = data;
        return this.http
            .post(this._baseUrl + 'deletedmincode', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    saveAdminCode(data) {
        let options = new RequestOptions({ headers: this._headers });
        let body = data;
        return this.http
            .post(this._baseUrl + 'saveadmincode', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    getPopupPricingData(hcpcCode: string) {
        return this.http
            //.get('http://192.168.133.159:8081/services/retrieveHCPCNDCPriceChangeDescriptionDetails?hcpc_code=' + hcpcCode)
            .get(this._baseUrl + 'retrieveHCPCNDCPriceChangeDescriptionDetails?hcpc_code=' + hcpcCode)
            .map(resp => resp.json().Result as IADMIN_CODE[]);
    }

    getPopupPricingHistoryData(hcpcCode: string) {
        return this.http
            //.get('http://192.168.133.159:8081/services/retrieveHCPCNDCPriceChangeDescriptionHistoryDetails?hcpc_code=' + hcpcCode)
            .get(this._baseUrl + 'retrieveHCPCNDCPriceChangeDescriptionHistoryDetails?hcpc_code=' + hcpcCode)
            .map(resp => resp.json().Result as IADMIN_CODE[]);
    }

    getHCPCRuleFailure(data) {
        let options = new RequestOptions({ headers: this._headers });
        let body = {'hcpc' : data};
        return this.http
            .post(this._baseUrl + 'HcpcRuleFailureDetails', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    recalHcpc(reqJson) {
        let options = new RequestOptions({ headers: this._headers });
        let body = reqJson;
        return this.http
            .post(this._baseUrl + 'hcpcNdcRecal', body, options)
            // .post('http://192.168.133.152:8081/services/hcpcNdcRecal', body, options)
            .map((res: Response) => {
                return res.json().result;
            });
    }

    requestToPublishHcpc(reqJson) {
        let options = new RequestOptions({ headers: this._headers });
        let body = reqJson;
        return this.http
            .post(this._baseUrl + 'hcpcNdcRequestToPublish', body, options)
            .map((res: Response) => {
                return res.json().result;
            });
    }

    publishHcpc(reqJson) {
        let options = new RequestOptions({ headers: this._headers });
        let body = reqJson;
        return this.http
            //.post('http://192.168.133.158:8081/services/publishhcpc', body, options)
            .post(this._baseUrl + 'publishhcpc', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    saveHcpc(reqJson) {
        
        let options = new RequestOptions({ headers: this._headers });
        let body = reqJson;
        var url = this._baseUrl + 'savehcpc';
        return this.http
            .post(url, body, options)
            .map((res: Response) => {
                return res.json().result;
            });
    }

    // async getPrice(currency: string): Promise<number> {
    //     const response = await this.http.get(this.currentPriceUrl).toPromise();
    //     return response.json().bpi[currency].rate;
    //   }

    getHCPCSearchData(): Observable<IHCPC_MASTER[]> {
        return this.http
            .get("app/shared/mockdata/mockHCPC_SearchResult.json")
            .map(resp => resp.json() as IHCPC_MASTER[]);
    }

    savePricing(data) {
        let options = new RequestOptions({ headers: this._headers });
        let body = data;
        return this.http
            .post(this._baseUrl + 'saveawp', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }
}