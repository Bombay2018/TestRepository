//getHTTPHeader
import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IINFO_CODE_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class InfoCodeService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public infoCode: IINFO_CODE_MASTER;

    constructor(private http: Http,
        private configSvc: ConfigService) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getInfoCode(ndcCode: string): Observable<IINFO_CODE_MASTER[]> {
        return this.http
            .get(this._baseUrl + 'DistinctInfoCodes?infoCode=' + ndcCode)
            .map((res: Response) => {
                return <IINFO_CODE_MASTER[]>res.json().Result
            });
    }

    getInfoByCode(ndcCode: string): Observable<IINFO_CODE_MASTER[]> {
        return this.http
            .get(this._baseUrl + 'InfoCodeDetails?infoCode=' + ndcCode)
            .map((res: Response) => {
                //console.log(res.json().Result[0])
                return <IINFO_CODE_MASTER[]>res.json().Result[0]
            });
    }

    saveInfoCode(saveInfoCode: IINFO_CODE_MASTER[]) {
        let body = saveInfoCode[0];
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'SaveInfoCodeDetails', body, options)
            .map(resp => resp.json());

    }
}