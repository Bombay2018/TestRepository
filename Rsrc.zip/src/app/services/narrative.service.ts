//getHTTPHeader
import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { INARRATIVE_MASTER, INARRATIVE_SAVE_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class NarrativeService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public narrative: INARRATIVE_MASTER;

    constructor(private http: Http,
        private configSvc: ConfigService) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getNarrativesNameAndTypeList(narrativeName: string, narrativeType: string): Observable<INARRATIVE_MASTER[]> {  
        return this.http
            .get(this._baseUrl + 'DistinctNarrativesNameAndType?narrativeName=' + narrativeName + "&narrativeType=" + narrativeType)
            .map((res: Response) => {
                return <INARRATIVE_MASTER[]>res.json()
            });
    }

    getDistinctNarrativesName(narrativeName: string): Observable<INARRATIVE_MASTER[]> {
        return this.http
            .get(this._baseUrl + 'DistinctNarrativesName?narrativeName=' + narrativeName)
            .map((res: Response) => {
                return <INARRATIVE_MASTER[]>res.json()
            });
    }

    getDistinctNarrativesType(): Observable<any> {
        return this.http
            .get(this._baseUrl + 'DistinctNarrativesType')
            .map(resp => resp.json());

    };

    getNarrativesMasterDetails(narrativeName: string, narrativeType: string) {
        return this.http
        .get(this._baseUrl + 'NarrativesDetails?narrativeName=' + narrativeName + "&narrativeType=" + narrativeType)
            .map(resp => resp.json());
    }

    checkIfNarrativeNameAlreadyExists(narrativeName: string) {
        return this.http
            .get(this._baseUrl + 'checkIfNarrativeNameAlreadyExists?narrativeName=' + narrativeName)
            .map(resp => resp.json().Result);
    }

    // saveNarrativesMasterDetails(narrativeDetails: INARRATIVE_SAVE_MASTER) {
    //     let body = narrativeDetails;
    //     let options = new RequestOptions({ headers: this._headers });
    //     return this.http
    //        .post(this._baseUrl + 'SaveNarrativesMasterDetails', body, options)
    //         .map(resp => resp.json());

    // }  

    saveNarrativesMasterDetails(narrativeDetails: FormData) {
        // let body = narrativeDetails;
        // let options = new RequestOptions({ headers: this._headers });
        // return this.http
        //    .post(this._baseUrl + 'SaveNarrativesMasterDetails', body, options)
        //     .map(resp => resp.json());
        //this._baseUrl + 'SaveNarrativesMasterDetails',
        $.ajax({
            url: this._baseUrl + 'SaveNarrativesMasterDetails',   //'http://192.168.133.74:9001/services/SaveNarrativesMasterDetails',
            type: "POST",
            contentType: false,
            processData: false,
            data: narrativeDetails,
            success: function (response) {
                if (response != null && typeof (response) == "string") {
                    if (((JSON.parse(response)).Result) == "success") {
                        toastr.success("Narrative Master details saved successfully.");
                    }
                }
            },
            error: function (xhr, status, error) {
                if (xhr.status == 200)
                    toastr.success("File details save successfully");
                else if (xhr.status == 500) {
                    if (xhr.responseText == "")
                        toastr.error("There is a system issue.Please contact administrator.");
                    else
                        toastr.error(xhr.responseText);
                }
            }
        });
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }
        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;
        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}