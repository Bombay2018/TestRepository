//getHTTPHeader
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { INDC_ATTRIBUTES, IWORKQUEUE_MAPPING } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class NdcResolutionService<T>{
    private _baseUrl: string = '';
    private _headers: any;
    
    public ndc: INDC_ATTRIBUTES;

    constructor(private http: Http, private configSvc: ConfigService) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    lockWorkQueue(ndcNumber: string): Observable<INDC_ATTRIBUTES[]> {
        return this.http
            .get(this._baseUrl + 'LockWorkQueueByUser?ndc=' + ndcNumber)
            .timeout(100000)
            .map((res: Response) => {
                return <INDC_ATTRIBUTES[]>res.json().Result[0];
            });
    }

    releaseWorkQueue(workqueueId: number){
        let body = {"workqueue_id":workqueueId,"flag" :1};
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'releaseWorkQueue', body, options)
            .map(resp => resp.json());
    }

    getNDCByNDC(ndcNumber: string): Observable<INDC_ATTRIBUTES[]> {
        return this.http
            .get(this._baseUrl + 'NdcAttributeDetailsWithDataSource?ndc='+ndcNumber)
            .map((res: Response) => {
                return <INDC_ATTRIBUTES[]>res.json().Result;
            });
    }

    getNDCHistory(ndcNumber: string, dataSourceId: number): Observable<INDC_ATTRIBUTES[]> {
        return this.http
            .get(this._baseUrl + 'NdcAttributeDetailsWithDataSourceHistory?dataSourceId=' + dataSourceId + '&ndc=' + ndcNumber)
            .map((res: Response) => {
                return <INDC_ATTRIBUTES[]>res.json().Result;
            });
    }

    getDiscrepancyAttributes(ndc: string): Observable<IWORKQUEUE_MAPPING[]> {
        return this.http
            .get(this._baseUrl + 'WorkQueueItemForNdc?ndc=' + ndc)
            .map((res: Response) => {
                return <IWORKQUEUE_MAPPING[]>res.json().Result;
            });
    }

    getNDCRuleFailure(ndcNumber: string) {
        return this.http
            .get(this._baseUrl + 'RuleFailureDetails?ndc='+ ndcNumber)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    getNDCPriceSpecificationDropDown() {
        return this.http
            .get(this._baseUrl + 'PriceSpecification')
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    getNDCPriceSpecificationNDCDetail(wt_Id: number) {
        
        return this.http
            .get(this._baseUrl + 'PriceSpecForNdc?wtId=' + wt_Id)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    getNDCPrescribingInformation(wt_Id: number) {
        return this.http
            .get(this._baseUrl + 'retrievePrescribingInformationDetails?wt_id=' + wt_Id)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    saveNDCResolution(json:Object){
        let body = json;
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'saveNDCResolutionDetails', body, options)
            .map(resp => resp.json());
    }

    saveNewNDCResolution(json:Object){
        let body = json;
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'saveNDCDetails', body, options)
            .map(resp => resp.json());
    }

    requestPublishNDCResolution(json:Object){
        let body = json;
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'requestToPublish', body, options)
            .map(resp => resp.json());
    }

    publishNDCResolution(json:Object){
        let body = json;
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'publishNDC', body, options)
            .map(resp => resp.json());
    }

    // getNdcFailureByCode(ndc:string) {
    //     return this.http
    //     .get(this._baseUrl+"RuleFailureDetails?ndc="+ndc)
    //     .map(resp => resp.json());
    // }

    getconversionTranslationMappingDataForNDC(json:Object){
        let body = json;
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'conversionTranslationMappingDataForNDC', body, options)
            .map(resp => resp.json().Result);
    }
    releaseWorkQueueNdc(objData:any) {
        return this.http
            .post(this._baseUrl+ 'releaseWorkQueue',objData)
            .map(resp => resp.json());
    }
    
   
}