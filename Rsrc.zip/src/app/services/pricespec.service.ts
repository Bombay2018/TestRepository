//getHTTPHeader
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IPRICE_SPEC } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class PriceSpecService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public priceSpec: IPRICE_SPEC;

    constructor(private http: Http,
        private configSvc: ConfigService) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getPriceSpec(pricespecName: string): Observable<IPRICE_SPEC[]> {
        return this.http
            .get(this._baseUrl + 'DistinctPriceSpec?priceSpecName=' + pricespecName)
            .map((res: Response) => {
                return <IPRICE_SPEC[]>res.json().Result
            });
    }

    getPriceSpecDetaiilsByCode(pricespecName: string): Observable<IPRICE_SPEC[]> {
        return this.http
            .get(this._baseUrl + 'PriceSpecDetails?priceSpecName=' + pricespecName)
            .map((res: Response) => {
                return <IPRICE_SPEC[]>res.json().Result[0]
            });
    }

    checkIfPriceSpecNameAlreadyExists(price_spec_name: string) {
        return this.http
            .get(this._baseUrl + 'checkIfPriceSpecNameAlreadyExists?price_spec_name=' + price_spec_name)
            .map(resp => resp.json().Result);
    }

    savePriceSpecDetails(savePriceSpecDetail: FormData) {
        // let body = savePriceSpecDetail[0];
        // let options = new RequestOptions({ headers: this._headers });
        // return this.http
        //     .post(this._baseUrl + 'SavePriceSpecDetails', body, options)
        //     .map(resp => resp.json());

        $.ajax({
            url: this._baseUrl + 'SavePriceSpecDetails',   // 'http://192.168.133.74:9001/services/SavePriceSpecDetails',
            type: "POST",
            contentType: false,
            processData: false,
            data: savePriceSpecDetail,
            success: function (response) {
                
                //console.log(response);           
                //msg= response.statusText;
                // msg=response;
                //   if(response.status==200)
                //   JSON.parse(response.responseText)['Result']
                //   else

                if (response != null && typeof (response) == "string") {
                    if (((JSON.parse(response)).Result) == "success") {
                        toastr.success("Price Spec details saved successfully.");
                    }
                }

            },
            error: function (xhr, status, error) {
                if (xhr.status == 200)
                    toastr.success("File details save successfully");
                else if (xhr.status == 500) {
                    if (xhr.responseText == "")
                        toastr.error("There is a system issue.Please contact administrator.");
                    else
                        toastr.error(xhr.responseText);
                }
            }
        });
    }

    getUploadFile(price_spec_id) {
        return this.http
            .get(this._baseUrl + 'getPriceSpecFile?priceSpecId=' + 1218)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}