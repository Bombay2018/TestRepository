//getHTTPHeader
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IREIMB_CODE } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
@Injectable()
export class ReimbMasterService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public reimbCode: IREIMB_CODE;

    constructor(private http: Http,
        private configSvc: ConfigService) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }
    
    getHCPCByCode(reimbCode: string) {
        return this.http
            .get(this._baseUrl + "DistinctHcpcCode?hcpc_code=" + reimbCode)
            .map(resp => resp.json().Result);
    }

    getHCPCByDescription(hcpcDescription: string) {
        return this.http
            .get(this._baseUrl + "retrieveDistinctHCPCCodeDescription?hcpc_desc=" + hcpcDescription)
            .map(resp => resp.json().Result);
    }

    getHcpcCodeWithHcpcDesc(hcpc_code, hcpc_desc, ndc) {
        let body = {
            "hcpc_code": hcpc_code,
            "hcpc_desc": hcpc_desc,
            "ndc": ndc
        };
        let options = new RequestOptions({ headers: this._headers });
        
        return this.http
            .post(this._baseUrl + 'DistinctHcpcCodeAndHcpcDesc', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    getReimbCode(searchPram) {
        let body = {
            "hcpc_code": searchPram.hcpc_code,
            "hcpc_desc": searchPram.hcpc_desc
        };
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'HcpcDetailsByHcpcCodeAndHcpcDesc', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    getReimbCodeChange(searchPram) {
        
        let body = {
            "hcpc_code": searchPram.hcpc_code,
            "hcpc_desc": searchPram.hcpc_desc
        };
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'HcpcCodeChangeDetails', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    getReimbCodeNotes(hcpc_code: string) {
        return this.http
            .get(this._baseUrl + "ReimbCodeMasterNote?hcpc_code=" + hcpc_code)
            .map(resp => resp.json().Result);
    }

    SaveReimbCode(jsonData: Object) {
        let body = jsonData;
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'SaveReimbMasterDetails', body, options)
            .map(resp => resp.json());
    }
}