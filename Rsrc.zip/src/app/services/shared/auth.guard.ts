import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { GlobalService } from './../../services/shared/global.service';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private _globalSvc: GlobalService) {
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot, ): boolean {
    debugger;
    if (localStorage['currentUser'] != undefined) {
      this._globalSvc.user=JSON.parse(localStorage['currentUser'])['user_name'];
      if (this._globalSvc.user != undefined) {
        // logged in so return true
        return true;
      }
    }
    // not logged in so redirect to login page with the return url
    this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }
}
