export const MenuList = [
  { "menu": 1, "routerLink": 'ndcresolution', "role_name": 'NDC_RESOLUTION', "menu_name": 'NDC Resolution' },
  { "menu": 1, "routerLink": 'partBvsDcrosswalk', "role_name": 'PART_BVSD_CROSSWALK', "menu_name": 'Part B vs Part D Crosswalk' },
  { "menu": 1, "routerLink": 'ndcconversionmapping', "role_name": 'CONVERSION_TRANSLATION', "menu_name": 'Conversion/Translation Screen' },
  { "menu": 2, "routerLink": 'hcpcndccrosswalk', "role_name": 'HCPC_NDC', "menu_name": 'Super Six(NDC) crosswalk + Pricing' },
  { "menu": 2, "routerLink": 'hcpcinfocodecrosswalk', "role_name": 'INFO_CODE_CROSSWALK', "menu_name": 'Info Code Crosswalk' },
  { "menu": 2, "routerLink": 'reimbmaster', "role_name": 'REIMB_CODE', "menu_name": 'Reimb Code Master/Maintenance' },
  { "menu": 3, "routerLink": 'indicationidccrosswalk', "role_name": 'DDC10_CROSSWALK', "menu_name": 'DDC 10 crosswalk' },
  { "menu": 4, "routerLink": 'infocodemaster', "role_name": 'INFO_CODES', "menu_name": 'Info Codes' },
  { "menu": 4, "routerLink": 'pricespecmaster', "role_name": 'PRICE_SPECS', "menu_name": 'Price Specs' },
  { "menu": 4, "routerLink": 'narrativemaster', "role_name": 'NARRATIVES', "menu_name": 'Narratives' },
  { "menu": 4, "routerLink": 'uploadmaster', "role_name": 'FILE_UPLOAD', "menu_name": 'File Uploads' }
];

export const QueueName=[
  {"role_name": 'NDC_RESOLUTION',"queue_name":'NDC_Discrepancy'},
  {"role_name": 'PART_BVSD_CROSSWALK',"queue_name":'SDDL-BvsD_Mapping'},
  {"role_name": 'SDDL-HCPC_Mapping', "queue_name":'SDDL-HCPC_Mapping'},
  {"role_name": 'Conversion_Mapping', "queue_name":'Conversion_Mapping'}
];

export const StageName=[
  {"stage_id":1,"stage_type":'Initial'},
  {"stage_id":2,"stage_type":'Second_Level'},
  {"stage_id":3, "stage_type":'Review'}
];

export const NDCFailureGridHead = {
  "generic_name": "Generic Name",
  "brand_name": "Brand Name",
  "strength": "Strength",
  "route_of_administration": "RoA",
  "dosage_form": "DF",
  "rx_otc_ind": "Rx",
  "awp": "AWP Pr",
  "wac": "WAC Pr",
  "ndc_status": "Status",
  "ndc_status_date": "Status Date", // to be deleted
  // "active_date": "Active Date",
  // "inactive_date": "Inactive Date",
  // "termination_date": "Termination Date",
  "br_generic_indicator": "B/G Ind",
  "package_size": "PKG Size",
  "package_size_uom": "PKG Size UoM",
  "package_description": "PKG Desc",
  "package_unit_dose": "PKG Unit Dose",
  "package_quantity": "PKG QTY",
  "repackager_ind": "Re PKG Ind",
  "sd_md": "SD/MD",
  "tee_code": "Tee Code",
  "inner_outer_package_indicator": "Inner Package",
  "manufacturer_name": "MfG Name",
  "cms_rebate": "CMS Rebate",
  "date": "Date",
  "notes_reason": "Notes Reason"
}

export const NDCFailureMessage = {
  "Generic_Name": "Generic Name", "Generic_NameStatus": "Generic Name Status",
  "Brand_Name": "Brand Name", "Brand_NameStatus": "Brand Name Status",
  "Strenth": "Strenth", "StrenthStatus": "Strenth Status",
  "RoA": "RoA", "RoAStatus": "RoA Status",
  "DF": "DF", "DFStatus": "DF Status",
  "Rx_OTC_Ind": "Rx", "Rx_OTC_IndStatus": "Rx Status",
  "AWPPrice": "AWP Pr", "AWPPriceStatus": "AWP Pr Status",
  "WACPrice": "WAC Pr", "WACPriceStatus": "WAC Pr. Status",
  "Br_Generic_Indicator": "B/G Ind", "Br_Generic_IndicatorStatus": "B/G Ind Status",
  "Package_Size": "PKG Size", "Package_SizeStatus": "PKG Size Status",
  "Package_Size_UoM": "PKG Size UoM", "Package_Size_UoMStatus": "PKG Size UoM Status",
  "Package_Description": "PKG Desc", "Package_DescriptionStatus": "PKG Desc Status",
  "Package_Unit_Dose": "PKG Unit Dose", "Package_Unit_DoseStatus": "PKG Unit Dose Status",
  "Package_Quantity": "PKG QTY", "Package_QuantityStatus": "PKG QTY Status",
  "Repackager_Ind": "Re-PKG Ind", "Repackager_IndStatus": "Re-PKG Ind",
  "SD_MD": "Dose/Multi Dose Ind", "SD_MDStatus": "Dose/Multi Dose Ind Status",
  "Tee_Code": "Tee Code", "Tee_CodeStatus": "Tee Code Status",
  "IO_Pkg_Ind": "I/O PKG Ind", "IO_Pkg_IndStatus": "I/O PKG Ind Status",
  "Manufacturer_Name": "Mfg Name", "Manufacturer_NameStatus": "Mfg Name Status",
  "CMS Rebate": "CMS Rebate", "CMS_RebetStatus": "CMS Rebate Status",
  "Date": "Date", "DateStatus": "DateStatus",
  "Reason": "Notes/Reason", "ReasonStatus": "Notes/Reason"
};

export const DataSources = [
  { "Id": 1, "datasource": "MS" },
  { "Id": 2, "datasource": "FDB" },
  { "Id": 3, "datasource": "RB" },
  { "Id": 4, "datasource": "GS" },
  { "Id": 6, "datasource": "RJ" }
]

export const WorkQueueType =
  [
    { "Id": 1, "description": "Initial Review" },
    { "Id": 2, "description": "Second Level Review" }
  ];

export const PriceDesc = { awpFirst: "", awpSecond: "", awpNote: "", awpDate: "", wacFirst: "", wacSecond: "", wacNote: "", wacDate: "", aspFirst: "", aspSecond: "", aspNote: "", aspDate: "", apcFirst: "", apcSecond: "", apcNote: "", apcDate: "", cmacFirst: "", cmacSecond: "", cmacNote: "", cmacDate: "" }

export const Sections =
  [
    { "section": 0, "show": true },
    { "section": 1, "show": true },
    { "section": 2, "show": true },
    { "section": 3, "show": true },
    { "section": 4, "show": true },
    { "section": 5, "show": true }
  ];

export const PopoverConfig =
  [
    { "id": 1, "description": "Lock NDC", "title": "Information", "message": "<br/>work queue is already locked by another user.<br/>Do you want to view?", "YesCaption": "View", "YesMethod": "showViewMode", "NoCaption": "Cancel", },
    { "id": 2, "description": "Delete", "title": "Confirmation", "message": "<br/>Are you sure to delete?", "YesCaption": "Yes", "YesMethod": "deleteFollowUp", "NoCaption": "No", }
  ];
