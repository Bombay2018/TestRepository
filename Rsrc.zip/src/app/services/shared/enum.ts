export enum attributeChangeOption {
  'Failure Resolved' = 0,
  'Follow-Up' =1,
  'Further Routing'=2,
  'Override Value'=3,
  'Change Review'=4
} 