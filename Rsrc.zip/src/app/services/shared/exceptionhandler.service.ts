import { ErrorHandler, Injectable, Injector, Provider } from '@angular/core';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
//import * as StackTrace from 'stacktrace-js';
import {IUSER_MASTER} from '../../shared/interfaces/entities.interface';
import { UserService } from './../user.service';

import { LoggerService } from './logger.service';


@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

    constructor( private injector: Injector, private logger: LoggerService, private UserSvc:UserService<IUSER_MASTER>) { }

    handleError(error) {
      
    //const loggingService = this.injector.get(LoggingService);
    const location = this.injector.get(LocationStrategy);
    const message = error.message ? error.message : error.status==0?'An Internal server error occured when rquesting resource.\nPlease contact service administrator.':error.statusText;
    const url = location instanceof PathLocationStrategy ? location : '';
   // this.logger.error(message, this);

    console.warn('Error Location: ' +location);
    console.warn('Error message: ' +message);
    console.warn('Error url: ' +url);
    //console.log('Error: '+ message);

   // get the stack trace, lets grab the last 10 stacks only
    /*StackTrace.fromError(error).then(stackframes => {
      const stackString = stackframes
        .splice(0, 20)
        .map(function(sf) {
          return sf.toString();
        }).join('\n');
        //log on the server
        this.logger.log({ message, url, stack: stackString });
        });*/
        alert('Error: '+ message);
        this.UserSvc.logout();
        //window.location.href=window.location.host+'/#/login';
       // throw error;
  }
  
}