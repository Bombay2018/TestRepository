import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from "rxjs/Observable";
import {IUSER_MASTER} from '../../shared/interfaces/entities.interface';

@Injectable()
export class GlobalService {

    private userName= new BehaviorSubject<string>('');
    private _showNavBar: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
    
    currentUser=this.userName.asObservable();
    setNavBar= this._showNavBar.asObservable();

    public user: IUSER_MASTER;
    public stage_id: number;
    public queue_id: number;
    public workqueuetype : string = '';
    public Overwrite : any;

   //this.user:IUSER_MASTER=<IUSER_MASTER>JSON.parse(localStorage.getItem('currentUser'));

   constructor(){
    //this.user = JSON.parse(localStorage.getItem('currentUser'));
   }

    getLoggedUser(userName:string){
        this.userName.next(userName);
    }

    showNavBar(isShow: boolean, user:string) {
        this._showNavBar.next(isShow);
        this.userName.next(user);
    }
}