//getHTTPHeader
import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IFILE_UPLOAD_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

declare var $: any;

@Injectable()
export class UploadFileService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public uploadFileDetail: IFILE_UPLOAD_MASTER;

    constructor(private http: Http,
        private configSvc: ConfigService) {
        this._baseUrl =configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
        //'http://192.168.133.130:9000/services/UploadMaster';
        //'http://192.168.133.130:9000/services/'
    }      
    
    
   uploadFileDetails(uploadFileDetail: FormData):any {
         //var msg="";
        // uploadFileDetail={} as IFILE_UPLOAD_MASTER;
        // uploadFileDetail=uploadFileDetail;
        // let body = uploadFileDetail;
        // let options = new RequestOptions({ headers: this._headers });
        // return this.http
        //     .post(this._baseUrl + 'UploadMaster', body, options)
        //     .map(resp => resp.json());

        $.ajax({
        url: this._baseUrl + 'UploadMaster',
        type: "POST",
        contentType: false,
        processData: false,
        data: uploadFileDetail,
        success: function (response) {
            
            //console.log(response);           
            //msg= response.statusText;
          // msg=response;
        //   if(response.status==200)
        //   JSON.parse(response.responseText)['Result']
        //   else

        if(response !=null)
          toastr.success(response.Result); 
          
        },
        error: function (xhr,status,error) {
            if(xhr.status==200)
            toastr.success("File details save successfully");
            else if(xhr.status==500){
            if(xhr.responseText=="")
            toastr.error("There is a system issue.Please contact administrator.");
            else
            toastr.error(xhr.responseText);
        }
           
            
            
        }
    });            
     //return msg;
   }
}