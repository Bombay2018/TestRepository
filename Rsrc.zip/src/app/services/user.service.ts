import { Injectable, Output } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IUSER_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { GlobalService } from './../services/shared/global.service';

@Injectable()
export class UserService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public user: IUSER_MASTER;
    public isAuthenicated: boolean;

    constructor(private http: Http, private configsvc: ConfigService, private _globalSvc: GlobalService) {
        this._baseUrl = configsvc.getApiURI();
        this._headers = configsvc.getHTTPHeader();
    }
    //getUser(Iuser: IUSER_MASTER): Observable<IUSER_MASTER> {

    getUser(Iuser): Observable<IUSER_MASTER> {
        let data = {
            "user_name": Iuser.user_name,
            "password": Iuser.password
        };
        let options = new RequestOptions({ headers: this._headers });
        let body = JSON.stringify(data);
        return this.http
            .post(this._baseUrl + 'login', body, options)
            .map((res: Response) => {
                //var resObj=res.json().Result[0];                
                //return <IUSER_MASTER>resObj;                
                return res.json().Result[0];
            });
    }

    getUserPrivileges(user_id: number): Observable<IUSER_MASTER> {
        return this.http
            .get(this._baseUrl + 'retrieveAllUserPrivileges?user_id=' + user_id)
            .map((res: Response) => {
                //console.log(res.json().Result)
                return <IUSER_MASTER>res.json().Result;
            });
    }

    //retrieveAllUserPrivileges
    // getAllUser(Iuser: IUSER_MASTER[]): Observable<IUSER_MASTER[]> {

    // }

    logout() {
        // remove user from local storage & global service to log user out
        this._globalSvc.user = null;
        //localStorage.removeItem('currentUser');
    }

    setUserLoggedIn(): boolean {
        return this.isAuthenicated = true;
    }

    public authenicated(user: IUSER_MASTER) {
        this.isAuthenicated = true;
    }

}