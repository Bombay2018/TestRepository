import { Injectable } from '@angular/core';

export class DropDown {
    id: string;
    value: string;
};
