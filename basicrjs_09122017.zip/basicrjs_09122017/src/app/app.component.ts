/// <reference path="../app/components/shared/toastr.d.ts" />
import { Component, HostListener } from '@angular/core';

import { IUSER_MASTER } from '../app/shared/interfaces/entities.interface';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  // directives: [ConfirmationComponent]
})


export class AppComponent {
  // user:IUSER_MASTER=<IUSER_MASTER>JSON.parse(localStorage.getItem('currentUser'));

  constructor() {
    toastr.options = { positionClass: 'toast-top-center' };
    // debugger;
    // if(this.user!=null){
    // alert(this.user.user_name);
    // }
  }

  ngOnInit(): any {
  }

  @HostListener('window:popstate', ['$event'])
  onPopState(event) {
    // alert('pressed browser button!');
  }
}
