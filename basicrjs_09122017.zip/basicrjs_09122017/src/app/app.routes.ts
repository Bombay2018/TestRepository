import { NgModule, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './services/shared/auth.guard';

import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { NDCFailureComponent } from './components/ndcfailure/ndcfailure.component';
import { NdcconversionmappingComponent } from './components/ndcconversionmapping/ndcconversionmapping.component';
import { HcpcNdcCrosswalkComponent } from './components/hcpcndccrosswalk/hcpcndccrosswalk.component';
import { IndicationIdcCrosswalkComponent } from './components/indicationidccrosswalk/indicationidccrosswalk.component';
import { InfoCodeMasterComponent } from './components/infocodemaster/infocodemaster.component';
import { NarrativeMasterComponent } from './components/narrativemaster/narrativemaster.component';
import { UploadMasterComponent } from './components/uploadmaster/uploadmaster.component';
import { PIMasterComponent } from './components/pimaster/pimaster.component';
import { PriseSpecMasterComponent } from './components/prisespecmaster/prisespecmaster.component';
import { ReimbMasterComponent } from './components/reimbmaster/reimbmaster.component';
import { NdcBdCrosswalkComponent } from './components/ndcbdcrosswalk/ndcbdcrosswalk.component';
import { HcpcInfoCodeCrosswalkComponent } from './components/hcpcinfocodecrosswalk/hcpcinfocodecrosswalk.component';

const appRoutes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'login',component: LoginComponent},
    { path: 'home', component: HomeComponent },
    { path: 'ndcfailure/:workqueue', canActivate:[AuthGuard],component: NDCFailureComponent},
    { path: 'ndcfailure',component: NDCFailureComponent},
    { path: 'ndcconversionmapping',component: NdcconversionmappingComponent},
    { path: 'hcpcndccrosswalk',component: HcpcNdcCrosswalkComponent},
    { path: 'indicationidccrosswalk',component: IndicationIdcCrosswalkComponent},
    { path: 'infocodemaster',component: InfoCodeMasterComponent},
    { path: 'narrativemaster',component: NarrativeMasterComponent},
    { path: 'uploadmaster',component: UploadMasterComponent},
    { path: 'pimaster',component: PIMasterComponent},
    { path: 'prisespecmaster',component: PriseSpecMasterComponent},
    { path: 'reimbmaster',component: ReimbMasterComponent},
    { path: 'ndcbdrosswalk',component: NdcBdCrosswalkComponent},
    { path: 'hcpcinfocodecrosswalk',component: HcpcInfoCodeCrosswalkComponent}
];
 
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);