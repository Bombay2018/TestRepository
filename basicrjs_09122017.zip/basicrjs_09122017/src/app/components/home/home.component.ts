/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, Directive } from '@angular/core';
import { Router } from '@angular/router';

import {GlobalEventsManager} from "./../../services/shared/globaleventsmanager.service";
import {HomeService} from "./../../services/home.service";
import { DataService } from '../../services/data.service';
import { Repository } from '../../repository/implement/repository.service';
import { IUSER_MASTER, IWorkQueue, IFOLLOWUP_MASTER } from '../../shared/interfaces/entities.interface';
//import { UserService } from '../../services/user.service';
import { workqueue, DropDown } from '../../shared/common';
import { ConfirmationService } from "../../services/shared/confirmation.service";

declare var $: any;


@Component({
    moduleId: module.id,
    selector: 'app-home',
    templateUrl: './home.component.html',
    providers: [HomeService, DataService, Repository, ConfirmationService]
})

export class HomeComponent implements AfterViewInit {
    user: IUSER_MASTER;
    isDesc: boolean = false;
    column: string = 'ImpactedElement';
    direction: number;
    selectedColumn: Object = {};
    dropDown: DropDown[];
    workqueuedata: IWorkQueue[];
    workqueuedataFilter: IWorkQueue[];
    calendarFollowUp: IFOLLOWUP_MASTER[];
    calendarFollowUpFilter : IFOLLOWUP_MASTER[];
    el: HTMLElement;
    todayDate: any;
    differenceInDate: any;
    differenceInMonth: any;
    differenceInYear: any;
    ImpactedElement: string;
    RuleFailure: string;
    AttributeFailed: string;
    Status: string;
    statusFilter: string;
    switchResult: any;
    NDCFollowUp: string="";
    drugNameFollowUp: string="";
    HCPCFollowUp: string="";
    dateFollowUp: Date;
    noteFollowUp: string="";

    seldate:Date;

    @ViewChild('taskDate') div: ElementRef;

    constructor(
        private homeSvc:HomeService<IWorkQueue>,
        private datasvc: DataService,
        private workqueue: workqueue,
        private router: Router,
        private elementRef: ElementRef,
        private _globalEventsManagerSev: GlobalEventsManager,
        private _confirmationSev: ConfirmationService) {

        this._globalEventsManagerSev.showNavBar.emit(true);

        this.user = JSON.parse(localStorage.getItem('currentUser'));
        
        toastr.options = { positionClass: 'toast-top-center' };
    }

    ngOnInit() {
        
        this.todayDate = new Date().getDate();
        this.showWorkQueueData();
        this.showFollowup();
        this.datasvc.getDropdownData().subscribe((res: any) => {
            this.dropDown = res.HomeGridDropdown;
        })
    }

    showConfirmDialog() {
        this._confirmationSev.activate("Are you sure?","Title")
            .then(res => console.log(`Confirmed: ${res}`));
    }
    
    showWorkQueueData() {
        this.homeSvc.getWorkqueue().subscribe((WorkQueue: IWorkQueue[]) => {
            WorkQueue.sort(function(a,b) {return (a.DateAdded> b.DateAdded) ? 1 : ((b.DateAdded> a.DateAdded) ? -1 : 0);} );
            this.workqueuedata = WorkQueue;
            this.workqueuedataFilter = WorkQueue;
        });
    }

    filterFollowupTask()
    {
        debugger;
        //this.todayDate = new Date().getDate();
        //this.differenceInMonth = new Date().getMonth();
        //this.differenceInYear = new Date().getFullYear();
        var todayDate = new Date("09/05/2017");
        this.calendarFollowUpFilter= this.calendarFollowUp.filter(obj => obj.follow_up_date == todayDate);
    }

    showFollowup() {
        this.homeSvc.getCalendarFollowUp(this.user.user_id).subscribe((calendarData: IFOLLOWUP_MASTER[]) => {
            this.calendarFollowUp = calendarData;
            this.calendarFollowUpFilter = calendarData;
            this.filterFollowupTask();
        });
    }

    ngAfterViewInit() {
        $('.date').datepicker({
            format: 'mm/dd/yyyy',
            startDate: new Date(),
            autoclose: true
        }).on('change', (event: any) => {
            this.dateFollowUp = event.target.value;
        });

        $('.inlineDate div').datepicker({
            multidate: true,
            multidateSeparator: ",",
            todayHighlight: true,
            datesDisabled: ['08/06/2017', '08/21/2017'],
            beforeShowDay : function (date) {
                if (date.getMonth() == (new Date()).getMonth()) {
                     switch (date.getDate()) {
                        // case 15:
                        //     return {classes: 'highlight', tooltip: 'Title'};
                        case 18:
                             return {"cls":'green'};
                        // case 21:
                        //      return [true, 'css-class-to-highlight', 'tooltipText'];
                     }
                }
             }
        }).on("changeDate", function (e) {
            this.seldate = new Date(e.date)
            console.log(this.seldate);
       });
    }

    getDateDifference(DateAdded): boolean {
        this.differenceInDate = new Date().getDate() - new Date(DateAdded).getDate();
        this.differenceInMonth = new Date().getMonth() - new Date(DateAdded).getMonth();
        this.differenceInYear = new Date().getFullYear() - new Date(DateAdded).getFullYear();
        if (this.differenceInDate >= 30 || this.differenceInMonth > 1 || this.differenceInMonth == 1 && this.differenceInDate >= 30 || this.differenceInYear >= 1) {
            return true;
        }
        return false;
    }
    
    showNDCdetail(ImpactedElement: workqueue, RuleFailure: string) {
        this.workqueue = ImpactedElement;
        if (RuleFailure == "NDC") {
            this.router.navigate(['/ndcfailure', this.workqueue]);
        }
        else if(RuleFailure == "HCPC") {
            this.router.navigate(['/hcpcndccrosswalk']);
        }
    }

    sort(selectedColumn) {
        this.column = this.selectedColumn.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    filterStatus($event, statusValue) {
        if ($event.target.checked) {
            this.statusFilter = statusValue;
        }
        this.filterWorkQueueData();
    }
    
    filterWorkQueueData(): void {
        if (this.ImpactedElement || this.RuleFailure || this.AttributeFailed || this.Status || this.statusFilter) {
            this.workqueuedataFilter = this.workqueuedata.filter
                (item =>
                    ((this.RuleFailure) ? (item.RuleFailure.toLowerCase().indexOf(this.RuleFailure.toLowerCase()) > -1) : 1)
                    &&
                    ((this.ImpactedElement) ? (item.ImpactedElement.toLowerCase().indexOf(this.ImpactedElement.toLowerCase()) > -1) : 1)
                    &&
                    ((this.AttributeFailed) ? (item.AttributeFailed.toLowerCase().indexOf(this.AttributeFailed.toLowerCase()) > -1) : 1)
                    &&
                    ((this.Status) ? (item.Status.toLowerCase().indexOf(this.Status.toLowerCase()) > -1) : 1)
                    &&
                    ((this.statusFilter) ? (item.Status.toLowerCase().indexOf(this.statusFilter.toLowerCase()) > -1) : 1)
                );
        }
        else {
            this.workqueuedataFilter = this.workqueuedata;
        }
    }

    clear() {
        this.ImpactedElement = "";
        this.RuleFailure = "";
        this.AttributeFailed = "";
        this.Status = "";
        this.workqueuedataFilter = this.workqueuedata;
    }

    parseDate(dateString: string): Date {
        if (dateString) {
            return new Date(dateString);
        } else {
            return null;
        }
    }
    saveAddFollowUp() {

        if (this.NDCFollowUp && this.drugNameFollowUp && this.HCPCFollowUp  &&
            this.dateFollowUp && this.noteFollowUp) {
            var maxId = Math.max.apply(Math, this.calendarFollowUp.map(function (o) { return o.follow_up_id; }));
            this.calendarFollowUp.push({
                follow_up_id : maxId + 1,
                ndc: this.NDCFollowUp,
                drug_name: this.drugNameFollowUp,
                hcpc: this.HCPCFollowUp,
                follow_up_date: this.dateFollowUp,
                note:this.noteFollowUp
            });
        }
        else{
           toastr.warning("None of the field should be empty while adding follow-up");
        }
    }

    deleteFollowUpTask(taskId,isNdcFollowup)
    {
        if(isNdcFollowup == "false")
        {
        var arrLenght = this.calendarFollowUp.length - 1;
        for (let i = arrLenght; i >= 0; i--)
        {
        if (this.calendarFollowUp[i]['task_id'] == taskId) {
                var index = this.calendarFollowUp.indexOf(this.calendarFollowUp[i]);
                this.calendarFollowUp.splice(index, 1);
            }
        }
    }
    else
    {
        toastr.error("NDC Resolution Follow-up cannot be deleted");
    }
    }
}