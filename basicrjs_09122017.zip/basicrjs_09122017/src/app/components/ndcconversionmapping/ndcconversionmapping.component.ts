import { Component, OnInit } from '@angular/core';
import { IDS_RJ_MAP } from '../../shared/interfaces/entities.interface';
import { ConversionService } from '../../services/conversion.service';
import { DropDown } from '../../shared/common';
import {GlobalEventsManager} from "./../../services/shared/globaleventsmanager.service";

declare var $: any;

@Component({
    selector: 'app-ndcconversionmapping',
    moduleId: module.id,
    templateUrl: './ndcconversionmapping.component.html',
    providers: [ConversionService]
})
export class NdcconversionmappingComponent implements OnInit {
    
    dropDown: DropDown[];
    addRowDS : DropDown[];
    addRowCT : DropDown[];
    ndcSuperSixData: IDS_RJ_MAP[];
    ndcSuperSixDataFilter: IDS_RJ_MAP[];
    masterNdcSuperSixData: IDS_RJ_MAP[];

    isDesc: boolean = false;
    column: string = 'data_source_name';
    direction: number;
    columnSelected: any;
    data_source_name: string;
    ds_value: string;
    user: string;
    new_data_source_name: string;
    new_ds_value: string;
    new_rj_value: string;
    new_map_type: string;
    new_created_date: string;
    new_user: string;
    isAddRow: boolean = false;
    isEdit: boolean = false;
    editRowId: number;
    showRowSelectedError: boolean = false;
    ct_filter: string;
    activeTab :string ="generic_name";

    constructor(private conversionService: ConversionService<IDS_RJ_MAP>,private _globalEventsManagerSev: GlobalEventsManager) {
        this._globalEventsManagerSev.showNavBar.emit(true);

        this.dropDown = [{ id: 'data_source_name', value: 'Data Source' },
        { id: 'ds_value', value: 'Source Value' },
        { id: 'rj_value', value: 'RJ Value' },
        { id: 'map_type', value: 'Convert / Translate' },
        { id: 'created_date', value: 'created_date' },
        { id: 'user', value: 'user' }];

        this.addRowDS=[{ id: 'Medispan', value: 'Medispan' },
        { id: 'RedBook', value: 'RedBook' },
        { id: 'GoldStandard', value: 'Gold Standard' },
        { id: 'FirstDataBank', value: 'First Data Bank' }];

        this.addRowCT=[{ id: 'C', value: 'C' },{ id: 'T', value: 'T' }];
    }

    ngOnInit() {
        this.showNdcSuperSixData();
    }
    showNdcSuperSixData() {
        this.conversionService.getNdcSuperSixData().subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
            this.masterNdcSuperSixData = ndcSuperSix;
            this.ndcSuperSixData = ndcSuperSix;
            this.ndcSuperSixDataFilter = ndcSuperSix; // user updated data to be stored
            this.filterSuperSixTab('generic_name');
            
        //     this.masterNdcSuperSixData = new Array();
        //     ndcGenericName.forEach((obj) => {
        //         this.masterNdcSuperSixData.push(Object.assign({}, obj));
        //     })
        });
    }

    filterSuperSixTab(superSixName:string)
    {
        this.data_source_name = "";
        this.ds_value = "";
        this.user = "";
        this.activeTab = superSixName;
        this.ndcSuperSixDataFilter= this.masterNdcSuperSixData.filter(obj => obj.super_six_name == superSixName);
    }

    showcalender(){
        $('#addDate').created_datepicker({
                format: 'mm/dd/yyyy',
                autoclose: true
             }).on('change', (event: any) => {
            this.new_created_date = event.target.value;
        });
    }
    sort() {
        //this.isDesc = !this.isDesc;
        this.column = this.columnSelected.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    filterCT($event, ctValue) {
        if ($event.target.checked) {
            this.ct_filter = ctValue;
        }
        this.filterNdcSuperSixData();
    }

    filterNdcSuperSixData(): void {
        this.ndcSuperSixData = this.masterNdcSuperSixData.filter(obj => obj.super_six_name == this.activeTab);
        
        if (this.data_source_name || this.ds_value || this.user ||this.ct_filter) {
            this.ndcSuperSixDataFilter = this.ndcSuperSixData.filter(item =>
                    ((this.data_source_name) ? (item.data_source_name.toLowerCase().indexOf(this.data_source_name.toLowerCase()) > -1) : 1)
                    &&
                    ((this.ds_value) ? (item.ds_value.toLowerCase().indexOf(this.ds_value.toLowerCase()) > -1) : 1)
                    &&
                    ((this.user) ? (item.user.toLowerCase().indexOf(this.user.toLowerCase()) > -1) : 1)
                    &&
                    ((this.ct_filter) ? (item.map_type.toLowerCase().indexOf(this.ct_filter.toLowerCase()) > -1) : 1)
                );
        }
        else {
            this.ndcSuperSixDataFilter= this.masterNdcSuperSixData.filter(obj => obj.super_six_name == this.activeTab);
        }
    }

    clear() {
        this.data_source_name = "";
        this.ds_value = "";
        this.user = "";
        this.showNdcSuperSixData();
    }

    checkAll(event) {
        if (event == true) {
            console.log("True");
            for (let data of this.ndcSuperSixDataFilter) {
                data.is_selected = true;
            }
        }
        else {
            for (let data of this.ndcSuperSixDataFilter) {
                data.is_selected = false;
            }
        }
    }

    addRow() {
        this.new_data_source_name = "";
        this.new_ds_value = "";
        this.new_rj_value = "";
        this.new_map_type = "";
        this.new_created_date = "";
        this.new_user = "";
        this.isAddRow = true;
        this.isEdit = false;
    }

    deleteRow() {
        this.showRowSelectedError = this.isRecordSelected();
        if(this.showRowSelectedError == true) {
            toastr.error("You must select atleast 1 row to delete");
        }
        var arrLenght = this.ndcSuperSixDataFilter.length - 1;
        for (let i = arrLenght; i >= 0; i--) {
            if (this.ndcSuperSixDataFilter[i]['is_selected'] == true) {
                var index = this.ndcSuperSixDataFilter.indexOf(this.ndcSuperSixDataFilter[i]);
                this.ndcSuperSixDataFilter.splice(index, 1);
            }
        }
    }

    isRecordSelected(): boolean {
        for (let data of this.ndcSuperSixDataFilter) {
            if (data.is_selected == true) {
                return false;
            }
            return true;
        }
    }

    edit(Id) {
        this.isAddRow = false;
        this.editRowId = Id;
        this.isEdit = true;
    }
    saveNdcSuperSixData() {
        if (this.isAddRow == true) {
            var maxId = Math.max.apply(Math, this.ndcSuperSixDataFilter.map(function (o) { return o.ds_rj_id; }));
            if (this.new_data_source_name != "" && this.new_ds_value != "" && this.new_rj_value != "" &&
                this.new_map_type != "") 
            {                    
                this.ndcSuperSixDataFilter.push({
                    ds_rj_id : maxId + 1,
                    data_source_id : 1,
                    attribute_id : 1,
                    data_source_name : this.new_data_source_name,
                    ds_value : this.new_ds_value, 
                    rj_value : this.new_rj_value,
                    map_type : this.new_map_type,
                    created_date : this.new_created_date, 
                    user: this.new_user,
                    super_six_name : "generic_name"
                });
                this.isAddRow = false;
            }
            else
            {
                toastr.error("None of the field should be empty will adding new row");
            }
        }
        //this.showNdcSuperSixData();
        this.isEdit = false;
    }

    cancel() {
        this.showNdcSuperSixData();
        this.isAddRow = false;
        this.isEdit = false;
        this.showRowSelectedError = false;
    }
}
