import { Directive, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[isNumber]'
})
export class AllowNumberDirective {

  constructor() { }

  @Input() isNumber: boolean;
  @Input() allowNegative: boolean = false;
  @Input() allowDecimal: boolean = true;
  @Input() decimalUpto: number;


  /* @HostListener('keydown', ['$event']) onKeyDown(event) {
     let e = <KeyboardEvent> event;
     if (this.number) {
       if ([46, 8, 9, 27, 13, 110, 190].indexOf(e.keyCode) !== -1 ||
         // Allow: Ctrl+A
         (e.keyCode == 65 && e.ctrlKey === true) ||
         // Allow: Ctrl+C
         (e.keyCode == 67 && e.ctrlKey === true) ||
         // Allow: Ctrl+V
         (e.keyCode == 86 && e.ctrlKey === true) ||
         // Allow: Ctrl+X
         (e.keyCode == 88 && e.ctrlKey === true) ||
         // Allow: home, end, left, right
         (e.keyCode >= 35 && e.keyCode <= 39)) {
           // let it happen, don't do anything
           return;
         }
         // Ensure that it is a number and stop the keypress
         if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
             e.preventDefault();
         }
       }
   }*/
  @HostListener('blur', ['$event']) onblur(event) {
    // console.log(event.target.value);
    var oVal = event.target.value;
    if (event.target.value == '' || parseFloat(event.target.value) == 0.0 || oVal.indexOf('-') > 0) {
      event.target.value = 0.00;
    }
    else if (this.allowDecimal == false) {
      event.target.value = parseInt(event.target.value);
    }
    else {
      if (this.decimalUpto) {
        var fixedValue = parseFloat(event.target.value).toFixed(this.decimalUpto);
      }
      else {
        var fixedValue = parseFloat(event.target.value).toFixed(2);
      }
      event.target.value = fixedValue;
    }
  }
  @HostListener('keydown', ['$event']) onKeyDown(event) {
    if (event) {
      return this.isNumberKey(event);
    }
  }
  
  isNumberKey(event) {

    var keyCode = [8, 9, 36, 35, 37, 39, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 110, 173];
    if (this.allowNegative == true) {
      var minusCode = [109, 189];
      keyCode = keyCode.concat(minusCode);
    }
    if (this.allowDecimal == true) {
      var decimalCode = [190];
      keyCode = keyCode.concat(decimalCode);
    }
    if (keyCode.indexOf(event.which) == -1) {
      event.preventDefault();
    }
    else {
      var oVal = event.target.value;
      if ([109, 173].indexOf(event.which) > -1 && oVal.indexOf('-') > -1) event.preventDefault();
      else if ([110, 190].indexOf(event.which) > -1 && oVal.indexOf('.') > -1) event.preventDefault();
    }
    /* let charCode = (event.which) ? event.which : event.keyCode;
     if (charCode > 31 && (charCode < 48 || charCode > 57)){
         return false;
     }
    return true;*/
  }
}

// <input type="text" number="true" />