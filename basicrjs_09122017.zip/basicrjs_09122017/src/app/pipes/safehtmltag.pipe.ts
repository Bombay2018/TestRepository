import { SafeHtml, SafeStyle, SafeScript, SafeUrl, SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';
import { Pipe, PipeTransform, ElementRef  } from '@angular/core';

@Pipe({
    name: 'safehtml'
})
export class SafeHTMLPipe {

    constructor(protected _sanitizer: DomSanitizer) {
    }

    public transform(value: string, type: string = 'html', el: any): SafeHtml | SafeStyle | SafeScript | SafeUrl | SafeResourceUrl {
        console.log(el);
        switch (type) {
            case 'html': return this._sanitizer.bypassSecurityTrustHtml(value);
            case 'style': return this._sanitizer.bypassSecurityTrustStyle(value);
            case 'script': return this._sanitizer.bypassSecurityTrustScript(value);
            case 'url': return this._sanitizer.bypassSecurityTrustUrl(value);
            case 'resourceUrl': return this._sanitizer.bypassSecurityTrustResourceUrl(value);
            default: throw new Error(`Invalid safe type specified: ${type}`);
        }
    }

}

//<div [innerHTML]="product.description | safehtml: 'html'"></div>
//<div [style.background-image]="'url(' + product.imageUrl + ')' | safehtml: 'style'"></div>