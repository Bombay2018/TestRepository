export enum attributeChangeOption {
  'Failure Resolved' = 0,
  'Follow-Up' =1,
  'Further Routing'=2,
  'Override Value'=3,
  'Change Review'=4,
  'Overrides Values/Change Review' =5
} 

export enum attributeDiscrepancy {
  'No Conflict' = 0,
  'Change'=1,
  'Conflict' =2,
  'Override'=3
} 