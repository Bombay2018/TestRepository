export interface IWorkQueue {
    UserId: number;
    IsRouted: string;
    ImpactedElement: string;
    RuleFailure: string;
    AttributeFailed: string;
    Status: string;
    WorkQueueType : string;
    DateAdded: Date
}

export interface IFOLLOWUP_MASTER {
    follow_up_id: number;
    ndc: string;
    drug_name: string;
    hcpc: string;
    follow_up_date?: Date;
    notes_id?: number;
    note?:string;
    user_id?: string;
    is_active?: string;
    created_date?: Date;
    modified_date?: Date;

    is_ndc_followup?: boolean; // added by sayali for delete operation
}


export interface IINFO_CODE {
    id: number;
    info_code: string;
    info_note: string;
}
export interface IPRICE_SPEC {
    id: number;
    price_spec_name: string;
    price_spec_upload: string;
    price_spec_note: string;
}

export interface IREIMB_CODE {
    reimb_code : number;
    reimb_code_description : string;
    reimb_Additional_description :  string;
    ndc : number;
    effective_date : Date;
    terminal_date : Date;
    is_admin_code : boolean;
    is_noc_code : boolean;
    action_code : number;
    action_date : Date;
    strength : string;
    Strength_UoM : string;
    note ?: string;
    user : string;
    date : Date;
}
//--------------------------mock end


export interface IUSER_MASTER extends IROLE_MASTER {
    user_id: number;
    user_name: string;
    password: string;
    is_active: string;
    created_date?: Date;
    modified_date?: Date;
}

export interface IROLE_MASTER {
    role_id: number;
    role_name: string;
    role_type: string;
    role_privilege: string;
    is_active?: string;
    created_date?: Date;
    modified_date?: Date;
}

export interface IUSER_ROLE_MAP {
    user_role_id: number;
    user_id: number;
    role_id: number;
    is_active?: string;
    created_date?: Date;
    modified_date?: Date;
}

export interface INDC_ATTRIBUTES extends IDATA_SOURCE_MASTER {
    wt_id: number;
    data_source_id: number;
    ndc: string;
    ndc_delimiter: number;
    ndc_status?: string;
    ndc_status_date?: string;
    generic_name?: string;
    brand_name?: string;
    strength?: string;
    dosage_form?: string;
    rx_otc_ind?: string;
    route_of_administration?: string;
    br_generic_indicator?: string;
    therapeutic_class?: string;
    manufacturer_name?: string;
    package_description?: string;
    package_size?: number;
    package_size_uom?: string;
    package_unit_dose?: string;
    package_quantity?: number;
    repackager_ind?: string;
    sd_md?: string;
    tee_code?: string;
    sddl_record_status?: string;
    is_rule_run?: string;
    inner_outer_package_indicator: string;
    created_date?: string;
    modified_date?: string;
}

export interface INDC_ATTRIBUTES_CONVERTED {
    ct_wt_id: Number;
    wt_id: number;
    generic_name?: string;
    brand_name?: string;
    strength?: string;
    dosage_form?: string;
    rx_otc_ind?: string;
    route_of_administration?: string;
    br_generic_indicator?: string;
    therapeutic_class?: string;
    manufacturer_name?: string;
    package_description?: string;
    package_size?: string;
    package_unit_dose?: string;
    repackager_ind?: string;
    sd_md?: string;
    tee_code?: string;
    inner_outer_package_indicator?: string;
    created_date?: string;
    modified_date?: string;
}

export interface INDC_PRICE {
    sddl_price_id: number
    wt_id: number;
    price_type: number;
    package_price?: number;
    price_effective_date?: string;
    created_date?: string;
    modified_date?: string;
}

export interface ISDDL_SUPER_SIX_MAP {
    sddl_super_six_id: number;
    wt_id: number;
    generic_name?: string;
    brand_name?: string;
    strength?: string;
    dosage_form?: string;
    rx_otc_ind?: string;
    route_of_administration?: string;
    created_date?: string;
    modified_date?: string;
}

export interface ISDDL_SUPER_SIX_MASTER {

    SDDL_SUPER_SIX_ID: number;
    SDDL_ID: number;
    Generic_Name: string;
    Brand_Name: string;
    Strength: string;
    Strength_UoM: string;
    Dosage_Form: string;
    Rx_OTC_Ind: string;
    Route_of_Administration: string;
    Created_By: string;
    Created_string: string;
    Modified_By: string;
    Modified_string: string;

}

export interface IDATA_SOURCE_MASTER {

    data_source_id: number;
    data_source_name?: string;
    is_active?: string;
    created_date?: string;
    modified_date?: string;
}

export interface IATTRIBUTE_MASTER {

    attribute_id: number;
    attribute_name?: string;
    is_structured?: string;
    visible_after_days?: number;
    is_active: string;
    is_mapping_required?: string
    created_date: string;
    modified_date: string

}

export interface ISDDL_SOURCE_MAPPING {
    sddl_source_mapping_id: number;
    data_source_id?: number;
    attribute_id?: number;
    wt_id?: number;
    is_overide?: string;
    is_manual_review?: string;
    created_date?: string;
    modified_date?: string;
}

export interface ISDDL_SOURCE_MAPPING_HISTORY {
    sddl_source_mapping_his_id: number;
    sddl_source_mapping_id: number;
    data_source_id?: number;
    attribute_id?: number;
    wt_id: number;
    is_overide?: string;
    is_manual_review?: string;
    created_date?: string;
    modified_date?: string;
}

export interface INDC_ATTRIBUTES_HISTORY {
    wt_his_id: number;
    wt_id?: number;
    data_source_id?: number;
    ndc?: string;
    ndc_delimiter?: number;
    ndc_status?: string;
    ndc_status_date?: string;
    generic_name?: string;
    brand_name?: string;
    strength?: string;
    dosage_form?: string;
    rx_otc_ind?: string;
    route_of_administration?: string;
    br_generic_indicator?: string;
    therapeutic_class?: string;
    manufacturer_name?: string;
    package_description?: string;
    package_size?: string;
    package_size_uom?: string;
    package_unit_dose?: string;
    package_quantity?: string;
    repackager_ind?: string;
    sd_md?: string;
    tee_code?: string;
    sddl_record_status?: string;
    is_rule_run?: string;
    inner_outer_package_indicator?: string;
    created_date: string;
    modified_date?: string
}

export interface INDC_PRICE_HISTORY {
    sddl_price_his_id: number;
    sddl_price_id?: number;
    wt_id?: number;
    price_type?: number;
    package_price?: number;
    price_effective_date?: string;
    created_date?: string;
    modified_date?: string;
}

export interface IBATCH_MASTER {
    batch_id: number
    batch_size?: string;
    service_name?: string;
    created_date?: string;
    modified_date?: string

}

export interface IBATCH_EXCEPTION {
    exception_id: number;
    batch_id?: number;
    exception_reason?: string;
    exception_desc?: string;
    parameter_name?: string;
    parameter_value?: string;
    attribute_id?: number;
    attribute_value?: string;
    origin?: string;
    created_date?: string;
    modified_date?: string;
}

export interface IBATCH_EXECUTION_STATUS {

    batch_execution_id: number;
    batch_id?: number;
    parameter_name?: string;
    parameter_value?: string;
    is_success?: string;
    created_date?: string;
    modified_date?: string;
}

export interface IATTRIBUTE_ROLE_MAPPING {
    attr_rol_map_id: number;
    attribute_id?: number;
    queue_id?: number;
    role_id?: number;
    is_active?: string;
    created_date: string;
    modified_date?: string;
}


export interface IATTRIBUTE_ROLE_MAPPING_HISTORY {

    ATTR_ROL_MAP_ID_HIS: number;
    Attribute_Id: number;
    Queue_Name: string;
    Role_ID: number;
    Created_By: string;
    Created_string: string;
    Modified_By: string;
    Modified_string: string;
}

export interface IQUEUE_MASTER {
    queue_id: number;
    queue_name: string
    is_active: string
    created_date: string
    modified_date?: string;
}

export interface INOTIFICATION_MASTER {
    notification_id: number;
    notification_label?: string;
    due_after_days?: number;
    intimation?: number;
    attribute_id?: number;
    queue_id?: number;
    created_date: string;
    modified_date: string;
}

export interface IWORKQUEUE_MAPPING {
    workqueue_id: number;
    transaction_Id: number;
    wt_id_input: number;
    wt_id_final?: number;
    attribute_id: number;
    attribute_value?: string;
    is_active?: string;
    queue_id: number;
    created_date?: string;
    modified_date?: string;
}

export interface IWORKQUEUE_TRANSACTION {
    primary_table: string;
    temp_table: string;
    primary_table_id: string;
}

export interface INDC_WORKQUEUE_MAPPING_HISTORY {
    workqueue_his_id: number;
    workqueue_id?: number;
    process_instance_id: string;
    task_id: number;
    wt_id_input: number;
    wt_id_final?: number;
    attribute_id: number;
    attribute_value?: string;
    is_active?: string;
    created_date?: string;
    modified_date?: string;
}

export interface IDS_RJ_MAP extends IDATA_SOURCE_MASTER {
    ds_rj_id: number;
    data_source_id: number;
    attribute_id: number;
    ds_value: string;
    rj_value?: string;
    map_type?: string;
    created_date?: string;
    modified_date?: string;

    user: string; // added by sayali for filter functionality
    is_selected?: boolean; //added by sayali for delete functionality
    super_six_name: string; //added by sayali for tabs value
}

export interface IHCPC_WORKQUEUE_MAPPING {

}
export interface IINDICATION_ADMINCODES_WORKQUEUE_MAPPING {

}
export interface IINDICATION_DOSES_WORKQUEUE_MAPPING {

}
export interface IINDICATION_DDC10_WORKQUEUE_MAPPING {

}
export interface IHCPC_CODEPRICE_WORKQUEUE_MAPPING {

}
export interface IINDICATION_DOSING_WORKQUEUE_MAPPING {

}
export interface ISDDL_PARTB_D_WORKQUEUE_MAPPING {

}
