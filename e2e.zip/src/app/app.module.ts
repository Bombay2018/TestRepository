import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { HttpClientXsrfModule } from '@angular/common/http';
import { RoutingModule} from './routing/routing.module';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { TopNavbarComponent } from './shared/topnavbar/topnavbar.component';

import { UserService } from './services/user.service';
import { ConfigService } from './services/shared/config.service';
import { GlobalEventsManager } from './services/globaleventsmanager.service';
import { QuoteComponent } from './quote/quote.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NotFoundComponent,
    TopNavbarComponent,
    QuoteComponent
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RoutingModule,
    FormsModule
    
  ],
  providers: [ConfigService,GlobalEventsManager,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
