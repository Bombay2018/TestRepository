/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit } from '@angular/core';

import {GlobalEventsManager} from "../services/globaleventsmanager.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  ups_title:string;

  constructor(private _globalEventsManagerSev: GlobalEventsManager)
  {
      this._globalEventsManagerSev.showNavBar.emit(true);
      toastr.options = { positionClass: 'toast-top-center' };
  }

  ngOnInit() {

    this.ups_title = 'UPS IPR';
    //toastr.warning("None of the field should be empty while adding follow-up");
  }

  doSave(){
    toastr.success("Data save successfuly");
  };

}
