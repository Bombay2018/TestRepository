import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {IUSER_MASTER} from './../shared/interfaces/entities.interface';
import {UserService} from './../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[UserService]
})
export class LoginComponent implements OnInit {

  public user:IUSER_MASTER = {user_name:'', password:''} as IUSER_MASTER;

  constructor(private _routes:Router, private _userSev:UserService<IUSER_MASTER>){
  }

  ngOnInit() {
  }

  doLogin(){
    this._userSev.getUser(this.user).subscribe(
    resdata => this.isValidUser(resdata as IUSER_MASTER)
   );
}

isValidUser(user:IUSER_MASTER){
  debugger;
  this.user=user;
  if(this.user!= undefined){    
    user.password='';
    localStorage.setItem('currentUser', JSON.stringify(user));
    /* the global event manger to show the nav bar */
    //this._globalEventsManagerSev.showNavBar(true);
    // this._globalEventsManagerSev.showNavBar.emit(true);
    this._routes.navigate(['/home']);
  }else{
    //toastr.error("Invalid userId or password");
    localStorage.setItem('currentUser', '');
    this._routes.navigate(['/login']);
  }
}

}
