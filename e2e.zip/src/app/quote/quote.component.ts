import { Component, OnInit } from '@angular/core';
/// <reference path="../shared/toastr.d.ts" />

@Component({
  selector: 'app-quote',
  templateUrl: './quote.component.html',
  styleUrls: ['./quote.component.css']
})
export class QuoteComponent implements OnInit {

  constructor() { 
    toastr.options = { positionClass: 'toast-top-center' };
  }

  ngOnInit() {
  }

  checkQuote(){
    toastr.success("Thank you for submiiting Quote.Sales representative will get back to you shortly");
  
  }

}
