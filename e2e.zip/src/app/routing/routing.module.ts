import { NgModule,ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';


import { LoginComponent } from '../login/login.component';
import { HomeComponent } from '../home/home.component';
import { QuoteComponent } from '../quote/quote.component';
import { NotFoundComponent } from '../not-found/not-found.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot([
      // Configure the routes...Routes are objects. Default patterns  
      { path: '', component: LoginComponent },
      //{path:'',redirectTo:'/login',pathMatch:'full'},  
      {path:'login',component:LoginComponent},
      {path:'home',component:HomeComponent},  
      {path:'quote',component:QuoteComponent},   
      {path:'**',component:NotFoundComponent}
    ])
  ],
  declarations: [],
  exports:[RouterModule]
})
export class RoutingModule { }
