import { Injectable, EventEmitter } from '@angular/core';
import { BehaviorSubject } from "rxjs";
import { Observable } from "rxjs";

@Injectable()
export class GlobalEventsManager {

   /* private _showNavBar: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
    public showNavBarEmitter: Observable<boolean> = this._showNavBar.asObservable();

    constructor() {}

    showNavBar(ifShow: boolean) {
        this._showNavBar.next(ifShow);
    }*/

    public showNavBar: EventEmitter<boolean> = new EventEmitter();
}