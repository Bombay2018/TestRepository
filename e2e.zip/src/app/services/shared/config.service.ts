import { Injectable } from '@angular/core';
//import { Headers } from '@angular/http';
import { HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';

@Injectable()
export class ConfigService {

    _apiURI: string;
    _header: any;

    constructor() {
        this._apiURI = 'http://localhost:4200';
    }

    getApiURI() {
        return this._apiURI;
    }

    getApiHost() {
        return this._apiURI.replace('api/', '');
    }

    getHTTPHeader() {
        this._header = new HttpHeaders({
           // 'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization',
            //'Access-Control-Allow-Origin': '*',
           // 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Content-Type': 'application/json'
        });

        return this._header;

    }
  
}