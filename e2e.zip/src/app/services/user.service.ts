import { Injectable, EventEmitter } from '@angular/core';
//import { Http, Response, Headers, RequestOptions } from '@angular/http';
//import {HttpClientModule, HttpClient} from '@angular/common/http'
import { HttpClient, HttpParams ,HttpResponse} from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map,tap,catchError } from 'rxjs/operators';

import { IUSER_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';


@Injectable()
export class UserService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public user: IUSER_MASTER;
    public sessionEvent: EventEmitter<any>;
    public isAuthenicated: boolean;

    constructor(private http: HttpClient, private configsvc: ConfigService) {
        this.sessionEvent = new EventEmitter();
        this._baseUrl = configsvc.getApiURI();
        this._headers = configsvc.getHTTPHeader();
    }

    getUser(Iuser: IUSER_MASTER): Observable<IUSER_MASTER> {
        debugger;
        let data = {
            "uname": Iuser.user_name,
            "pwd": Iuser.password
        };
        let options = ({ headers: this._headers });
        let body = JSON.stringify(data);
        // return this.http
        //     .post(this._baseUrl+ 'login', body, options)
        //     .pipe(map((res: Response) => {
        //         console.log(res.json())
        //         return <IUSER_MASTER>res.json();
        //         // return users.find(obj => obj.user_name == data.user_name && obj.password == data.pwd);
        //     }));

        return this.http.get<IUSER_MASTER>(this._baseUrl + "/assets/user.json")
        //.pipe(map((res: Response) =>res.json()));
    //   .pipe(
    //     //catchError(this.handleError('getUser', []))
    //   );
        
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}