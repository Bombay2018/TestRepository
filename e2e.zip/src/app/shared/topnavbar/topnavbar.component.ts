import { Component } from '@angular/core';

import {GlobalEventsManager} from "../../services/globaleventsmanager.service";

@Component({
  selector: 'navbar',
  templateUrl: './topnavbar.component.html'
})
export class TopNavbarComponent {
  public showNavBar : boolean;
  constructor(private _globalEventsManagerSev: GlobalEventsManager) { 
    /*this._globalEventsManagerSev.showNavBar.subscribe((mode : boolean) =>{
            this.showNavBar = mode;
        });*/
     this._globalEventsManagerSev.showNavBar.subscribe((mode)=>{
            // mode will be null the first time it is created, so you need to igonore it when null
            if (mode !== null) {
              this.showNavBar = mode;
            }
        });
  }
}
