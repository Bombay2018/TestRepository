import { Component, OnInit } from '@angular/core';
import {GlobalEventsManager} from "./../../services/shared/globaleventsmanager.service";

@Component({
  selector: 'app-indicationidccrosswalk',
  templateUrl: './indicationidccrosswalk.component.html'
})
export class IndicationIdcCrosswalkComponent implements OnInit {

  constructor(private _globalEventsManagerSev: GlobalEventsManager) 
  {
    this._globalEventsManagerSev.showNavBar.emit(true);
  }


  ngOnInit() {
  }

}
