import { Component, OnInit } from '@angular/core';
import {GlobalEventsManager} from "./../../services/shared/globaleventsmanager.service";

@Component({
  selector: 'app-uploadmaster',
  moduleId: module.id,
  templateUrl: './uploadmaster.component.html'
})
export class UploadMasterComponent implements OnInit {

  constructor(private _globalEventsManagerSev: GlobalEventsManager) 
  {
    this._globalEventsManagerSev.showNavBar.emit(true);
  } 

  ngOnInit() {
  }

}
