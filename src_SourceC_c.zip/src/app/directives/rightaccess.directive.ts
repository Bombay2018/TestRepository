import { Directive, ElementRef, Input, AfterViewInit } from '@angular/core';

@Directive({
    selector: '[rightAccess]'
})

export class RightAccessDirective implements AfterViewInit {

    constructor(private elRef: ElementRef) {

    }

    ngAfterViewInit(): void {

    }

}

