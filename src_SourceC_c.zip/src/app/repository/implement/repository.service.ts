import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { ConfigService } from '../../services/shared/config.service';
import { IRepositoryGeneric } from '../interface/Irepositorygeneric.interface';

@Injectable()
export class Repository<TEntity> implements IRepositoryGeneric<TEntity>{
    private _url: string='';
    baseurl;
    action;

    constructor(private http: Http, private configService: ConfigService) {
        this.baseurl=configService.getApiHost();
     }

   getAll(action:string): Observable<TEntity[]> {
        debugger;
      // this._url=`${this.baseurl}${action}`;
      this._url='https://jsonplaceholder.typicode.com' +'/posts/1';
       return this.http.get(this._url).map(resp=>resp.json() as TEntity[])
       .catch(this.handleError);
    }

    getById(action:string,id: number): Observable<TEntity> {
        this._url=`${this.baseurl}${action}`;
        return this.http.get(`${this._url}${id}`).map(resp=>resp.json() as TEntity)
        .catch(this.handleError);
    }

    getByCode(action:string,code: string): Observable<TEntity> {
        this._url=`${this.baseurl}${action}`;
        return this.http.get(`${this._url}${code}`).map(resp=>resp.json() as TEntity)
        .catch(this.handleError);
    }

    add(action:string, entity: TEntity):  Observable<TEntity>  {
        debugger;
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        this._url=`${this.baseurl}${action}`;
        this._url='https://reqres.in/api/users';
        return this.http.post(this._url, JSON.stringify(entity), {
            headers: headers
        })
        .map((res: Response) => {
            return res.json();
        })
        .catch(this.handleError);
    }

    update(action:string, entity: TEntity): Observable<boolean> {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        this._url=`${this.baseurl}${action}`;

        return this.http.post(this._url, JSON.stringify(entity), {
            headers: headers
        })
        .map((res: Response) => {
            return false;
        })
        .catch(this.handleError);
    }

    delete(action:string, id: number): Observable<boolean> {
        this._url=`${this.baseurl}${action}`;
        return this.http.delete(this._url + id)
        .map((res: Response) => {
            return res;
        })
        .catch(this.handleError);
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';
 
        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }
 
        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;
 
        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}