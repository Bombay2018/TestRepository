//getHTTPHeader
import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IPRICE_SPEC } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class PriceSpecService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public priceSpec: IPRICE_SPEC;

    constructor(private http: Http,
         private configSvc: ConfigService, 
         private repository: Repository<IPRICE_SPEC> ) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getPriceSpec(): Observable<IPRICE_SPEC[]> {
        return this.http.get("app/shared/mockdata/mockPriceSpecMaster.json")
                        .map(resp => resp.json() as IPRICE_SPEC[])
                        .catch(this.handleError);
    }
    
    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}