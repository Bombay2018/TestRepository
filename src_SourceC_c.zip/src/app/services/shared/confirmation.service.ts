import { Injectable, TemplateRef } from '@angular/core';

@Injectable()
export class ConfirmationService {
   activate: (message?: string, title?: string) => Promise<boolean>;
}
