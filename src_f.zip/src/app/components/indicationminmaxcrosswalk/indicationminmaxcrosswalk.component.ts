import { Component, OnInit } from '@angular/core';
import {GlobalEventsManager} from "./../../services/shared/globaleventsmanager.service";

@Component({
  selector: 'app-indicationminmaxcrosswalk',
  templateUrl: './indicationminmaxcrosswalk.component.html'
})
export class IndicationMinMaxCrosswalkComponent implements OnInit {

  constructor(private _globalEventsManagerSev: GlobalEventsManager)
  {
    this._globalEventsManagerSev.showNavBar.emit(true);
  }

  ngOnInit() {
  }

}
