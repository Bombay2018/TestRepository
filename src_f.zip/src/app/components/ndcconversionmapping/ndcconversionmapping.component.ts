import { Component, OnInit } from '@angular/core';

import { IUSER_MASTER, IDS_RJ_MAP } from '../../shared/interfaces/entities.interface';
import { DataService } from '../../services/data.service';
import { ConversionService } from '../../services/conversion.service';
import { DropDown } from '../../shared/common';
import { GlobalEventsManager } from "./../../services/shared/globaleventsmanager.service";

declare var $: any;

@Component({
    selector: 'app-ndcconversionmapping',
    moduleId: module.id,
    templateUrl: './ndcconversionmapping.component.html',
    providers: [ConversionService, DataService]
})
export class NdcconversionmappingComponent implements OnInit {

    dropDown: DropDown[];
    addRowDS: any;
    addRowCT: DropDown[];
    ndcSuperSixData: IDS_RJ_MAP[];
    ndcSuperSixDataFilter: IDS_RJ_MAP[];
    masterNdcSuperSixData: IDS_RJ_MAP[];
    

    logInUser:IUSER_MASTER;
    superSix:any;
    isDesc: boolean = false;
    column: string = 'data_source_name';
    direction: number;
    columnSelected: any;
    data_source_name: string;
    ds_value: string;
    user: string;
    new_data_source_name: string;
    new_ds_value: string;
    new_rj_value: string;
    new_map_type: string;
    new_created_date: string;
    new_user: string;
    isAddRow: boolean = false;
    isEdit: boolean = false;
    editRowId: number;
    showRowSelectedError: boolean = false;
    ct_filter: string;
    activeTab: string = '';

    constructor(private datasvc: DataService, private conversionService: ConversionService<IDS_RJ_MAP>, private _globalEventsManagerSev: GlobalEventsManager) {
        this._globalEventsManagerSev.showNavBar.emit(true);
    }

    ngOnInit() {
        this.logInUser=<IUSER_MASTER>JSON.parse(localStorage.getItem('currentUser'));
        this.datasvc.getDataSource().subscribe((res: any) => {
            this.addRowDS = res['retrieveAllDataSourceDetails'];
        });
       /* this.datasvc.getAllAttribute().subscribe((res: any) => {
            debugger;
            this.superSix = res['retrieveAllAttributeDetails'].filter(obj  =>  obj.attribute_id>1 && obj.attribute_id < 8);
            //this.superSix = res['retrieveAllAttributeDetails'];
        });*/

        this.datasvc.getDropdownData().subscribe((res: any) => {
            this.dropDown = res.CTGridDropdown;
            this.addRowCT = res.ConversionTranslation;
        })
        this.showNdcSuperSixData('');
    }

    showNdcSuperSixData(activeTab:string) {
        debugger;
        this.activeTab = this.activeTab == '' ? 'generic_name' : activeTab;
        this.conversionService.getConversionTranslation(this.activeTab).subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
            this.masterNdcSuperSixData = ndcSuperSix['conversionTranslationMappingDataList'];
            this.ndcSuperSixData = ndcSuperSix['conversionTranslationMappingDataList'];
            this.ndcSuperSixDataFilter = ndcSuperSix['conversionTranslationMappingDataList']; // user updated data to be stored
        });
    }

    showcalender() {
        $('#addDate').created_datepicker({
            format: 'mm/dd/yyyy',
            autoclose: true
        }).on('change', (event: any) => {
            this.new_created_date = event.target.value;
        });
    }
    sort() {
        //this.isDesc = !this.isDesc;
        this.column = this.columnSelected.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    filterCT($event, ctValue) {
        if ($event.target.checked) {
            this.ct_filter = ctValue;
        }
        this.filterNdcSuperSixData();
    }

    filterNdcSuperSixData(): void {
        debugger;
       // this.ndcSuperSixData = this.masterNdcSuperSixData.filter(obj  =>  obj.super_six_name == this.activeTab);

        if (this.data_source_name || this.ds_value || this.user || this.ct_filter) {
            this.ndcSuperSixDataFilter = this.ndcSuperSixData.filter(item =>
                ((this.data_source_name) ? (item.data_source_name.toLowerCase().indexOf(this.data_source_name.toLowerCase()) > -1) : 1)
                &&
                ((this.ds_value) ? (item.ds_value.toLowerCase().indexOf(this.ds_value.toLowerCase()) > -1) : 1)
                &&
                ((this.user) ? (item.modified_by.toLowerCase().indexOf(this.user.toLowerCase()) > -1) : 1)
                &&
                ((this.ct_filter) ? (item.map_type.toLowerCase().indexOf(this.ct_filter.toLowerCase()) > -1) : 1)
            );
        }
        else {
            this.ndcSuperSixDataFilter = this.masterNdcSuperSixData;
        }
    }

    clear() {
        this.data_source_name = "";
        this.ds_value = "";
        this.user = "";
        this.ndcSuperSixDataFilter = this.masterNdcSuperSixData;
    }

    checkAll(event) {
        if (event == true) {
            for (let data of this.ndcSuperSixDataFilter) {
                data.is_selected = true;
            }
        }
        else {
            for (let data of this.ndcSuperSixDataFilter) {
                data.is_selected = false;
            }
        }
    }

    addRow() {
        this.new_data_source_name = "";
        this.new_ds_value = "";
        this.new_rj_value = "";
        this.new_map_type = "";
        this.new_created_date = "";
        this.new_user = "";
        this.isAddRow = true;
        this.isEdit = false;
    }

    deleteRow() {
        var convTranId = [];
        for (let i = 0; i < this.ndcSuperSixDataFilter.length; i++) {
            if (this.ndcSuperSixDataFilter[i]['is_selected'] == true) {
                convTranId.push(this.ndcSuperSixDataFilter[i].ds_rj_id);
            }
        }
        if (convTranId.length > 0) {
            this.conversionService.deleteConversionTranslation(convTranId).subscribe((res: JSON) => {
                if (res['result'].toLowerCase() == 'success') {
                    this.showNdcSuperSixData(this.activeTab);
                } else {
                    toastr.error("failed to delete /n internal sever error");
                }
            });
        } else {
            toastr.error("You must select atleast 1 row to delete");
        }
    }

    edit(Id) {
        this.isAddRow = false;
        this.editRowId = Id;
        this.isEdit = true;
    }

    saveNdcSuperSixData() {
        if (this.isAddRow == true) {
            var maxId = Math.max.apply(Math, this.ndcSuperSixDataFilter.map(function (o) { return o.ds_rj_id; }));
            if (this.new_data_source_name != "" && this.new_ds_value != "" && this.new_rj_value != "" && this.new_map_type != "") {
                    // {
                    // "data_source_id":1,
                    // "attribute_id": 2,
                    // "ds_value": "01600ML",
                    // "rj_value": "1ML",
                    // "map_type": "T"  
                    // }
                    
                var newSuperSixTC : IDS_RJ_MAP={} as IDS_RJ_MAP;
                newSuperSixTC.data_source_id=0;
                newSuperSixTC.attribute_id=0;
                newSuperSixTC.ds_value=this.new_ds_value;
                newSuperSixTC.rj_value=this.new_rj_value;
                newSuperSixTC.map_type=this.new_map_type;
                newSuperSixTC.modified_by=this.logInUser.user_name;

                this.ndcSuperSixDataFilter.push({
                    ds_rj_id: maxId + 1,
                    data_source_id: 1,
                    attribute_id: 1,
                    data_source_name: this.new_data_source_name,
                    ds_value: this.new_ds_value,
                    rj_value: this.new_rj_value,
                    map_type: this.new_map_type,
                    //created_date : this.new_created_date, 
                    modified_by: this.new_user,
                    super_six_name: "generic_name"
                });
                this.isAddRow = false;
            }
            else {
                toastr.error("None of the field should be empty will adding new row");
            }
        }
        this.showNdcSuperSixData(this.activeTab);
        this.isEdit = false;
    }

    cancel() {
        this.showNdcSuperSixData(this.activeTab);
        this.isAddRow = false;
        this.isEdit = false;
        this.showRowSelectedError = false;
    }
}


        // this.conversionService.getNdcSuperSixData().subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
        //     this.masterNdcSuperSixData = ndcSuperSix;
        //     this.ndcSuperSixData = ndcSuperSix;
        //     this.ndcSuperSixDataFilter = ndcSuperSix; // user updated data to be stored
        //     this.filterSuperSixTab('generic_name');

        // //     this.masterNdcSuperSixData = new Array();
        // //     ndcGenericName.forEach((obj) => {
        // //         this.masterNdcSuperSixData.push(Object.assign({}, obj));
        // //     })
        // });
    
    
        // filterSuperSixTab(superSixName: string) {
            
        //     this.data_source_name = "";
        //     this.ds_value = "";
        //     this.user = "";
        //     this.activeTab = superSixName;
        //     this.ndcSuperSixDataFilter = this.masterNdcSuperSixData.filter(obj  =>  obj.super_six_name == superSixName);
        // }