/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, HostListener, Renderer } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs/Rx';
//import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { GlobalEventsManager } from "./../../services/shared/globaleventsmanager.service";

import { ConfigService } from '../../services/shared/config.service';
import { NDCFailureGridHead } from '../../services/shared/config.const';
import { INDC_ATTRIBUTES, INDC_PRICE_HISTORY, IUSER_MASTER } from '../../shared/interfaces/entities.interface';
import { DataService } from '../../services/data.service';
import { NDCService } from '../../services/ndc.service';
import { PriceHistoryService } from '../../services/pricehistory.service';

import { ModalComponent } from '../shared/modalpopup.component';
//import { OrderBy } from './../../pipes/orderby.pipe';

import { attributeChangeOption } from '../../services/shared/enum';

declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'app-ndcfailure',
  templateUrl: './ndcfailure.component.html',
  providers: [NDCService, PriceHistoryService, DataService]
})
export class NDCFailureComponent implements OnInit, AfterViewInit {

  mockdataNDCFailure: any;
  mockPriceHistory: any;
  mockNDCSearchResult: any[] = new Array();
  mockRuleFailureUpdate: any;
  mockWorkQueue: any;
  mockWorkQueueType: any;
  mockUser: any;

  viewMode: boolean = false;
  contexMenu;
  message;
  masterNDCFailure: any;
  ndcSearchCode: string = '';
  msView: any[] = new Array();
  fdbView: any[] = new Array();
  rjView: any[] = new Array();
  gsView: any[] = new Array();
  statusProp: string = '';
  newNDC: boolean = false;
  msshow: boolean = true;
  fdbshow: boolean = true;
  rjshow: boolean = true;
  gsShow: boolean = true;
  isNewNDC: boolean = false;
  priceHistoryshow: boolean = false;
  pricing: string = '';
  isAddNDC: boolean = false;
  changedNDCAttr: any = {};
  options: string[];
  ndcPublishNotes: string;
  //attrCnangeOptions : typeof attributeChangeOption = attributeChangeOption;
  datasources: any;
  gridhead: any;
  trustedUrl: any;

  @ViewChild('modalNDCList') modalNDCList: ModalComponent;
  @ViewChild('modalPublish') modalNPublish: ModalComponent;
  @ViewChild('fdbTab') div: ElementRef;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private configsvc: ConfigService,
    private elementRef: ElementRef,
    private ndcsvc: NDCService<INDC_ATTRIBUTES>,
    private datasvc: DataService,
    private pricehistorysvc: PriceHistoryService<INDC_PRICE_HISTORY>,
    private _globalEventsManagerSev: GlobalEventsManager) {
    this._globalEventsManagerSev.showNavBar.emit(true);

    /* 
       })
       
       this.sortByDescending(this.mockdataNDCFailure.DataSource.RJ);
        const max = this.mockdataNDCFailure.DataSource.RJ.reduce(function (prev, current) {
          return (prev.y > current.y) ? current : prev
        })
        this.masterNDCFailure = Object.assign({}, max);
     */
  }

  ngOnInit() {
    this.isAddNDC = false;
    var NDCcode: string = this.route.snapshot.params['workqueue'];
    // this.gridhead.route_of_administration='<a [href]="'+this.gridhead.route_of_administration+'">the link from above</a>';
    this.getNDCByCode(NDCcode);

    var options = Object.keys(attributeChangeOption);
    this.options = options.slice(options.length / 2);
    console.log(this.options);

    this.datasvc.getDropdownData().subscribe((res: any) => {
      this.mockRuleFailureUpdate = res.mockRuleFailureUpdate;
      this.mockWorkQueue = res.mockWorkQueue;
      this.mockWorkQueueType = res.mockWorkQueueType;
      this.mockUser = res.mockUser;
    })

    this.message = {
      "Generic_Name": "Generic Name", "Generic_NameStatus": "Generic Name Status",
      "Brand_Name": "Brand Name", "Brand_NameStatus": "Brand Name Status",
      "Strenth": "Strenth", "StrenthStatus": "Strenth Status",
      "RoA": "RoA", "RoAStatus": "RoA Status",
      "DF": "DF", "DFStatus": "DF Status",
      "Rx_OTC_Ind": "Rx", "Rx_OTC_IndStatus": "Rx Status",
      "AWPPrice": "AWP Pr", "AWPPriceStatus": "AWP Pr Status",
      "WACPrice": "WAC Pr", "WACPriceStatus": "WAC Pr. Status",
      "Br_Generic_Indicator": "B/G Ind", "Br_Generic_IndicatorStatus": "B/G Ind Status",
      "Package_Size": "PKG Size", "Package_SizeStatus": "PKG Size Status",
      "Package_Size_UoM": "PKG Size UoM", "Package_Size_UoMStatus": "PKG Size UoM Status",
      "Package_Description": "PKG Desc", "Package_DescriptionStatus": "PKG Desc Status",
      "Package_Unit_Dose": "PKG Unit Dose", "Package_Unit_DoseStatus": "PKG Unit Dose Status",
      "Package_Quantity": "PKG QTY", "Package_QuantityStatus": "PKG QTY Status",
      "Repackager_Ind": "Re-PKG Ind", "Repackager_IndStatus": "Re-PKG Ind",
      "SD_MD": "Dose/Multi Dose Ind", "SD_MDStatus": "Dose/Multi Dose Ind Status",
      "Tee_Code": "Tee Code", "Tee_CodeStatus": "Tee Code Status",
      "IO_Pkg_Ind": "I/O PKG Ind", "IO_Pkg_IndStatus": "I/O PKG Ind Status",
      "Manufacturer_Name": "Mfg Name", "Manufacturer_NameStatus": "Mfg Name Status",
      "CMS Rebate": "CMS Rebate", "CMS_RebetStatus": "CMS Rebate Status",
      "Date": "Date", "DateStatus": "DateStatus",
      "Reason": "Notes/Reason", "ReasonStatus": "Notes/Reason"
    }



    this.contexMenu = this.configsvc.getcontexMenu();
    this.contexMenu.forEach(cm => cm.subject.subscribe(val => this.setStatus(val)));

    /*document.addEventListener('blur', function (e) {
      alert('click');
    }, false);*/

  }

  ngAfterViewInit() {
    $('#nextDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.mockdataNDCFailure.FollowUp.followupDate = event.target.value;
    });

  }

  modelChange(status, event) {
    var prop = status.slice(0, -7);
    if (this.masterNDCFailure[prop] != event) {
      this.mockdataNDCFailure.DataSource.RJ[0][status] = 1;
    } else {
      this.mockdataNDCFailure.DataSource.RJ[0][status] = this.masterNDCFailure[status];
    }
  }

  search() {
    if (this.ndcSearchCode.trim() == '') {
      toastr.error("Please enter NDC Code");
      return;
    } else {
      this.modalNDCList.show();
    }
  }

  getNDCByCode(code: string): any {
    debugger;
    this.gridhead = NDCFailureGridHead;
    var user = localStorage.getItem('currentUser');
    this.ndcsvc.getMockNdcFailureByCode().subscribe((ndcfailure: INDC_ATTRIBUTES[]) => {
      if (this.mockNDCSearchResult.length == 0) {
        var arrSearchNDC = new Array();
        ndcfailure.forEach(function (obj) {
          obj['RuleFailure'] = [];
          arrSearchNDC.push(obj.ndc);
        });
        this.mockNDCSearchResult = arrSearchNDC;
      }
      if (code != undefined) {
        debugger;
        this.mockdataNDCFailure = ndcfailure.find(obj => obj.ndc == code);
        this.sortByDescending(this.mockdataNDCFailure.DataSource.RJ);
        const max = this.mockdataNDCFailure.DataSource.RJ.reduce(function (prev, current) {
          return (prev.y > current.y) ? current : prev
        })
        this.masterNDCFailure = Object.assign({}, max);
        this.showhide('default');
        this.modalNDCList.hide();

        var props = Object.getOwnPropertyNames(this.masterNDCFailure);
        var ths = Array.prototype.slice.call(document.getElementById("grid").getElementsByTagName("th"));
        for (var i = 0; i < props.length; i++) {
          var propName = props[i];
          if (propName.slice(-6).toLowerCase() == 'status') {
            if (this.masterNDCFailure[propName] == 2) {
              debugger;
              var link = document.createElement("a");
              link.setAttribute('href', "javascript:void(0)");
              link.innerHTML = this.gridhead[propName.slice(0, -7)];
              var pram = propName.slice(0, -7);
              ths.forEach((th) => {
                if (th.innerHTML.indexOf(link.innerHTML) !== -1) {
                  var id = this.mockdataNDCFailure.RuleFailure.length + 1;
                  var objRuleFailure = { "Id": id, "Rule": th.innerHTML, "Description": "System Generated Text Messages", "FailureId": this.masterNDCFailure[propName] }
                  this.mockdataNDCFailure.RuleFailure.push(objRuleFailure);
                  link.addEventListener("click", this.showConvertTranslate, false);
                  th.innerHTML = '';
                  th.appendChild(link);
                }
              });
            }
          }
        }
      }
    });
  }

  showConvertTranslate(e) {
    alert(e.srcElement.innerHTML + ' Popup issue');
    var x= document.getElementById("CTPopup");
    x.style.display = 'block';
  }

  closeCTpopup()
  {
    var x= document.getElementById("CTPopup");
    x.style.display = 'none';
  }

  showhide(pram: string) {
    if (this.isNewNDC == false) {
      switch (pram) {
        case "MS":
          this.msshow = !this.msshow;
          this.msView = new Array();
          this.msView = this.msshow == true ? this.mockdataNDCFailure.DataSource.MS : this.mockdataNDCFailure.DataSource.MS.slice(0, 1);
          break;
        case "FDB":
          this.fdbshow = !this.fdbshow;
          this.fdbView = new Array();
          this.fdbView = this.fdbshow == true ? this.mockdataNDCFailure.DataSource.FDB : this.mockdataNDCFailure.DataSource.FDB.slice(0, 1);
          break;
        case "GS":
          this.gsShow = !this.gsShow;
          this.gsView = new Array();
          this.gsView = this.gsShow == true ? this.mockdataNDCFailure.DataSource.GS : this.mockdataNDCFailure.DataSource.GS.slice(0, 1);
          break;
        case "RJ":
          this.rjshow = !this.rjshow;
          this.rjView = new Array();
          this.rjView = this.rjshow == true ? this.mockdataNDCFailure.DataSource.RJ : this.mockdataNDCFailure.DataSource.RJ.slice(0, 1);
          break;
        default:
          this.msView = this.mockdataNDCFailure.DataSource.MS.slice(0, 1);
          this.fdbView = this.mockdataNDCFailure.DataSource.FDB.slice(0, 1);
          this.gsView = this.mockdataNDCFailure.DataSource.GS.slice(0, 1);
          this.rjView = this.mockdataNDCFailure.DataSource.RJ.slice(0, 1);
      }
    }
  }

  showhistory(price, ds) {

    /* this.pricehistorysvc.getPriceHistory().subscribe((pricehistory: INDC_PRICE_HISTORY) => {
       debugger;
       this.mockPriceHistory = pricehistory;
     });*/
    if (this.mockPriceHistory == undefined) {
      this.datasources = [
        { "Id": 1, "datasource": "Medispan" },
        { "Id": 2, "datasource": "FDB" },
        { "Id": 3, "datasource": "GS" },
        { "Id": 4, "datasource": "Redbook" },
        { "Id": 5, "datasource": "RJ" }
      ]
      this.mockPriceHistory = {
        "MS": [{ "pricing": "AWP", "Price_Effective": "08/08/2017", "Unit_Price": '1.0', "Price_Note": "MS Note 1" },
        { "pricing": "AWP", "Price_Effective": "08/09/2017", "Unit_Price": '2.2', "Price_Note": "MS Note 2" },
        { "pricing": "WAC", "Price_Effective": "08/15/2017", "Unit_Price": '2.1', "Price_Note": "MS Note 1" },
        { "pricing": "WAC", "Price_Effective": "08/08/2017", "Unit_Price": '2.8', "Price_Note": "MS Note 2" }
        ],
        "RB": [{ "pricing": "WAC", "Price_Effective": "08/04/2017", "Unit_Price": '7.9', "Price_Note": "RB Note 1" },
        { "pricing": "AWP", "Price_Effective": "08/09/2017", "Unit_Price": '2.4', "Price_Note": "RB Note 1" },
        { "pricing": "WAC", "Price_Effective": "08/06/2017", "Unit_Price": '10.9', "Price_Note": "RB Note 2" },
        { "pricing": "AWP", "Price_Effective": "08/01/2017", "Unit_Price": '2.5', "Price_Note": "RB Note 2" }
        ],
        "FDB": [{ "pricing": "AWP", "Price_Effective": "08/08/2017", "Unit_Price": '2.50', "Price_Note": "FDB Note 1" },
        { "pricing": "WAC", "Price_Effective": "08/06/2017", "Unit_Price": '2.55', "Price_Note": "FDB Note 1" },
        { "pricing": "WAC", "Price_Effective": "08/11/2017", "Unit_Price": '2.6', "Price_Note": "FDB Note 2" },
        { "pricing": "AWP", "Price_Effective": "08/14/2017", "Unit_Price": '3.9', "Price_Note": "FDB Note 2" }
        ],
        "GS": [{ "pricing": "WAC", "Price_Effective": "08/02/2017", "Unit_Price": '2.4', "Price_Note": "GS Note 1" },
        { "pricing": "AWP", "Price_Effective": "08/03/2017", "Unit_Price": '2.5', "Price_Note": "GS Note 1" },
        { "pricing": "AWP", "Price_Effective": "08/08/2017", "Unit_Price": '2.9', "Price_Note": "GS Note 2" },
        { "pricing": "WAC", "Price_Effective": "08/07/2017", "Unit_Price": '3.0', "Price_Note": "GS Note 2" }
        ],
        "RJ": [{ "pricing": "WAC", "Price_Effective": "08/04/2017", "Unit_Price": '6.9', "Price_Note": "RJ Note 1" },
        { "pricing": "AWP", "Price_Effective": "08/09/2017", "Unit_Price": '3.4', "Price_Note": "RJ Note 1" },
        { "pricing": "WAC", "Price_Effective": "08/06/2017", "Unit_Price": '18.9', "Price_Note": "RJ Note 2" },
        { "pricing": "AWP", "Price_Effective": "08/01/2017", "Unit_Price": '2.5', "Price_Note": "RJ Note 2" }
        ]
      };
    }
    this.priceHistoryshow = true;
    this.pricing = price == 1 ? "AWP" : "WAC";
    if (document.getElementById(ds) == null) {
      setTimeout(function () { document.getElementById(ds).click(); }, 1000);
    } else {
      document.getElementById(ds).click();
    }
  }

  contexMenuClick(prop) {
    this.statusProp = prop;
  }

  // setConflict(code): string {
  //   var style = '';
  //   switch (code) {
  //     case 1:
  //       style = "success";
  //       break;
  //     case 2:
  //       style = "danger";
  //       break;
  //     case 3:
  //       style = "primary";
  //       break;
  //     case 4:
  //       style = "warning";
  //       break;
  //     default:
  //       style = "";
  //   }
  //   return style;
  // }

  setStatus(id) {
    debugger;
    var prop = this.statusProp.slice(0, -7);
    var maxId: number = Math.max.apply(Math, this.mockdataNDCFailure.DataSource.RJ.map(function (o) { return o.Id; }))
    var updatedData = Object.assign({}, this.mockdataNDCFailure.DataSource.RJ.find(obj => obj.Id == maxId));
    if (updatedData[prop] === this.masterNDCFailure[prop]) {
      toastr.error('Status not allowed to <br> change on old value');
      return;
    }

    // switch case not required directly assin id
    switch (id) {
      case 0: //Failure Resolved
        this.mockdataNDCFailure.DataSource.RJ[0][this.statusProp] = 0;
        break;
      case 1: //Follow-Up
        //this.mockdataNDCFailure.DataSource.RJ[0][this.statusProp] = 1;
        break;
      case 2: //Further Routing
        //this.mockdataNDCFailure.DataSource.RJ[0][this.statusProp] = 2;
        break;
      case 3: //override value
        this.mockdataNDCFailure.DataSource.RJ[0][this.statusProp] = 3;
        break;
      case 4: //Change Review
        this.mockdataNDCFailure.DataSource.RJ[0][this.statusProp] = 4;
        break;
      default:
        toastr.info('Invalid selection');
        break;
    }

    this.statusProp = '';
  }

  addNDC() {
    this.isAddNDC = true;
    if (this.newNDC == false) {
      var maxId: number = Math.max.apply(Math, this.mockdataNDCFailure.DataSource.RJ.map(function (o) { return o.Id; }))
      var objNewNDC = { "Id": maxId + 1, "Generic_Name": "", "Generic_NameStatus": 0, "Brand_Name": "", "Brand_NameStatus": 0, "Strenth": "", "StrenthStatus": 0, "RoA": "", "RoAStatus": 0, "DF": "", "DFStatus": 0, "Rx_OTC_Ind": "", "Rx_OTC_IndStatus": 0, "AWPPrice": "", "AWPPriceStatus": 0, "WACPrice": "", "WACPriceStatus": 0, "Br_Generic_Indicator": "", "Br_Generic_IndicatorStatus": 0, "Package_Size": "", "Package_SizeStatus": 0, "Package_Size_UoM": "", "Package_Size_UoMStatus": 0, "Package_Description": "", "Package_DescriptionStatus": 0, "Package_Unit_Dose": "", "Package_Unit_DoseStatus": 0, "Package_Quantity": "", "Package_QuantityStatus": 0, "Repackager_Ind": "", "Repackager_IndStatus": 0, "SD_MD": "", "SD_MDStatus": 0, "Tee_Code": "", "Tee_CodeStatus": 0, "IO_Pkg_Ind": "", "IO_Pkg_IndStatus": 0, "Manufacturer_Name": "", "Manufacturer_NameStatus": 0, "CMS_Rebet": "", "CMS_RebetStatus": 0, "Date": "", "DateStatus": 0, "Reason": "", "ReasonStatus": 0 };    //this.msView=new Array();
      this.mockdataNDCFailure.DataSource.RJ.unshift(objNewNDC);
      this.newNDC = true;
      this.showhide("RJ");
    } else {
      toastr.error("Add Multiple NDC Not Allow");
    }
  }

  save() {
    var errorList = [];
    this.isAddNDC = false;

    if (this.newNDC = true) {
      //valiadation To Do 
      // var objNewNDC = { "Id": 1, "Generic_Name": "", "Generic_NameStatus": 0, "Brand_Name": "", "Brand_NameStatus": 0, "Strenth": "", "StrenthStatus": 0, "RoA": "", "RoAStatus": 0, "DF": "", "DFStatus": 0, "Rx_OTC_Ind": "", "Rx_OTC_IndStatus": 0, "AWPPrice": "", "AWPPriceStatus": 0, "WACPrice": "", "WACPriceStatus": 0, "Br_Generic_Indicator": "", "Br_Generic_IndicatorStatus": 0, "Package_Size": "", "Package_SizeStatus": 0, "Package_Size_UoM": "", "Package_Size_UoMStatus": 0, "Package_Description": "", "Package_DescriptionStatus": 0, "Package_Unit_Dose": "", "Package_Unit_DoseStatus": 0, "Package_Quantity": "", "Package_QuantityStatus": 0, "Repackager_Ind": "", "Repackager_IndStatus": 0, "SD_MD": "", "SD_MDStatus": 0, "Tee_Code": "", "Tee_CodeStatus": 0, "IO_Pkg_Ind": "", "IO_Pkg_IndStatus": 0, "Manufacturer_Name": "", "Manufacturer_NameStatus": 0, "CMS_Rebet": "", "CMS_RebetStatus": 0, "Date": "", "DateStatus": 0, "Reason": "", "ReasonStatus": 0 };    //this.msView=new Array();
    }
    if (this.mockdataNDCFailure != undefined && this.mockdataNDCFailure.DataSource.RJ != null) {
      var maxId: number = Math.max.apply(Math, this.mockdataNDCFailure.DataSource.RJ.map(function (o) { return o.Id; }))
      var updatedData = Object.assign({}, this.mockdataNDCFailure.DataSource.RJ.find(obj => obj.Id == maxId));
      this.isChangedAttr(this.masterNDCFailure, updatedData);

      for (var prop in this.changedNDCAttr) {
        if (this.changedNDCAttr.hasOwnProperty(prop)) {
          debugger;
          errorList.push(this.message[prop] + '<br/>');
        }
      }
      if (this.mockdataNDCFailure.FollowUp.followupDate == "" && (this.mockdataNDCFailure.FurtherRouting.UserId == "" && this.mockdataNDCFailure.FurtherRouting.WorkQueueId == "" && this.mockdataNDCFailure.FurtherRouting.WorkQueueTypeId == "" && this.mockdataNDCFailure.FurtherRouting.Notes == "")) {
        toastr.error("Any of Follow up or Further Routing is to be field");
      }
      if ((this.mockdataNDCFailure.Prescribe.Link == "" && this.mockdataNDCFailure.Prescribe.Notes == "") && (this.mockdataNDCFailure.PriceSpec.SpecificationId == "" && this.mockdataNDCFailure.PriceSpec.Notes == "")) {
        toastr.error("PI and Price Spec/Drug Monograph should not be empty");
      }
      if (errorList.length > 0) {
        errorList.splice(0, 0, 'Following are the error(s):<br/>')
        toastr.error(errorList.toString().replace(",", ""));
        return;
      }
    }
    console.log(this.mockdataNDCFailure.FollowUp.followupDate);
    this.newNDC = false;
    this.mockdataNDCFailure.FollowUp.followupDate = "";
    this.mockdataNDCFailure.FurtherRouting.UserId = "";
    this.mockdataNDCFailure.FurtherRouting.WorkQueueId = "";
    this.mockdataNDCFailure.FurtherRouting.WorkQueueTypeId = "";
    this.mockdataNDCFailure.FurtherRouting.Notes = "";
    this.mockdataNDCFailure.Prescribe.Link = "";
    this.mockdataNDCFailure.Prescribe.Notes = "";
    this.mockdataNDCFailure.PriceSpec.SpecificationId = "";
    this.mockdataNDCFailure.PriceSpec.Notes = "";
  }
  savePublish() {
    if (this.ndcPublishNotes == undefined) {
      toastr.error("publish Note cannot be empty");
    }
    this.ndcPublishNotes = undefined;
  }

  cancel() {
    this.ngOnInit();
  }

  sortByDescending(arrObj: any) {
    arrObj.sort(function (val1, val2) {
      if (val1.Id > val2.Id) {
        return -1;
      } else if (val1.Id < val2.Id) {
        return 1;
      } else {
        return 0;
      }
    });
  }

  selectedtributeChangeOption(value: string) {
    console.log(attributeChangeOption[value]);
  }

  //this.fieldAllowedValues.filter(obj => obj.Name == fieldName);
  isChangedAttr(newObj, oldObj): Object {

    this.changedNDCAttr = {};
    // Create arrays of property names
    var newProps = Object.getOwnPropertyNames(newObj);
    var oldProps = Object.getOwnPropertyNames(oldObj);

    // If number of properties is different,
    // objects are not equivalent
    if (newProps.length != oldProps.length) {
      return this.changedNDCAttr;
    }

    for (var i = 0; i < newProps.length; i++) {
      var propName = newProps[i];

      // If values of same property are not equal,
      // objects are not equivalent
      if (newObj[propName] !== oldObj[propName]) {
        this.changedNDCAttr[propName] = oldObj[propName];
      }
    }

    var Props = Object.getOwnPropertyNames(this.changedNDCAttr);
    for (var loop = Props.length - 1; loop >= 0; loop--) {
      var statusProp = Props[loop] + 'Status';
      if (this.changedNDCAttr[statusProp] != undefined) {
        delete this.changedNDCAttr[Props[loop]];
        delete this.changedNDCAttr[statusProp];
      }
    }
    // If we made it this far, objectsare considered equivalent
    return this.changedNDCAttr;
  }

  
}
