import { Directive, ElementRef, Input, AfterViewInit, OnChanges } from '@angular/core';

@Directive({
    selector: '[discripancyStatus]'
})
export class DiscripancyStatusDirective implements  OnChanges {
    @Input('discripancyStatus') colourCode: number;

    constructor(private elRef: ElementRef) {

    }

    ngOnChanges(changes) {
        switch (this.colourCode) {
            case 1:
                this.elRef.nativeElement.className = "success";
                break;
            case 2:
                this.elRef.nativeElement.className = "danger";
                break;
            case 3:
                this.elRef.nativeElement.className = "primary";
                break;
            case 4:
                this.elRef.nativeElement.className = "warning";
                break;
            default:
                this.elRef.nativeElement.className = "";
                break;
        }
    }
}

// <h4 [discripancyStatus] [code]=2>Directive Demo</h4>