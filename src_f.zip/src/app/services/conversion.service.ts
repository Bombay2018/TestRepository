//getHTTPHeader
import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IDS_RJ_MAP } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class ConversionService<T>{
    private _baseUrl: string = '';
    private _headers: any;


    constructor(private http: Http,
         private configSvc: ConfigService, 
         private repository: Repository<IDS_RJ_MAP> ) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getNdcSuperSixData(): Observable<IDS_RJ_MAP[]> {
        return this.http
        .get("app/shared/mockdata/mockdatandcGenericName.json")
        .map(resp => resp.json() as IDS_RJ_MAP[]);
    }

    getConversionTranslation(code:string): Observable<IDS_RJ_MAP[]>{
        return this.http
        .get(this._baseUrl+'ConversionTranslationMappingData?attributeName='+code)
        .map(resp => resp.json() as IDS_RJ_MAP[]);
    }

    saveConversionTranslation(newCT:IDS_RJ_MAP[]) {
        debugger;
     
        let body = {
            "convTranId": newCT
        };
        let options = new RequestOptions({ headers: this._headers });
        return this.http
        .post(this._baseUrl+ 'saveNDCConversion', body, options)
        .map(resp => resp.json());
    }

    deleteConversionTranslation(Ids:IDS_RJ_MAP[]) {
        debugger;
        let body = {
            "convTranId": Ids
        };
        let options = new RequestOptions({ headers: this._headers });
        return this.http
        .post(this._baseUrl+ 'DeleteConversionTranslationMappingData', body, options)
        .map(resp => resp.json());
    }

  
    
    
   
}