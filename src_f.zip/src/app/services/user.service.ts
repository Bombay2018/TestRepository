import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IUSER_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class UserService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public user: IUSER_MASTER;
    public sessionEvent: EventEmitter<any>;
    public isAuthenicated: boolean;

    constructor(private http: Http, private configsvc: ConfigService, private repository: Repository<IUSER_MASTER>) {
        this.sessionEvent = new EventEmitter();
        this._baseUrl = configsvc.getApiURI();
        this._headers = configsvc.getHTTPHeader();
    }

    getUser(Iuser: IUSER_MASTER): Observable<IUSER_MASTER> {
        let data = {
            "user_name": Iuser.user_name,
            "password": Iuser.password
        };
        let options = new RequestOptions({ headers: this._headers });
        let body = JSON.stringify(data);
        return this.http
            .post(this._baseUrl+ 'login', body, options)
            .map((res: Response) => {
               // console.log(res.json().Result[0])
                return <IUSER_MASTER>res.json().Result[0];
                // return users.find(obj => obj.user_name == data.user_name && obj.password == data.pwd);
            });
        //.map((res: Response) => res.json());
    }

    getUserfromNodejs(user: IUSER_MASTER): Observable<IUSER_MASTER> {
        let data = {
            "username": user.user_name,
            "pwd": user.password
        }

        return this.http.post('http://localhost:3000/login', data, {
            headers: this._headers
        })
            .map((res: Response) => {
                return <IUSER_MASTER>res.json();
            });

        //---------------------------------------------------------------
        /* return this.http.get(this._baseUrl)
         .map((response: Response) => <IUser[]> response.json())
         .do(data => console.log(JSON.stringify(data)))
         .catch(this.handleError);*/
    }

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }
    
    setUserLoggedIn(): boolean {
        return this.isAuthenicated = true;
    }

    public authenicated(user: IUSER_MASTER) {
        this.isAuthenicated = true;
        this.sessionEvent.emit(user);
    }

    public logoutold() {
        this.isAuthenicated = false;
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}