import { NgModule, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './services/shared/auth.guard';

import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { NDCFailureComponent } from './components/ndcfailure/ndcfailure.component';
import { NDCFailureReadOnlyComponent } from './components/ndcfailure/ndcFailureReadOnly.component';
import { NdcconversionmappingComponent } from './components/ndcconversionmapping/ndcconversionmapping.component';
import { HcpcNdcCrosswalkComponent } from './components/hcpcndccrosswalk/hcpcndccrosswalk.component';
import { IndicationIdcCrosswalkComponent } from './components/indicationidccrosswalk/indicationidccrosswalk.component';
import { InfoCodeMasterComponent } from './components/infocodemaster/infocodemaster.component';
import { NarrativeMasterComponent } from './components/narrativemaster/narrativemaster.component';
import { UploadMasterComponent } from './components/uploadmaster/uploadmaster.component';
import { PIMasterComponent } from './components/pimaster/pimaster.component';
import { PriseSpecMasterComponent } from './components/prisespecmaster/prisespecmaster.component';
import { ReimbMasterComponent } from './components/reimbmaster/reimbmaster.component';
import { NdcBdCrosswalkComponent } from './components/ndcbdcrosswalk/ndcbdcrosswalk.component';
import { HcpcInfoCodeCrosswalkComponent } from './components/hcpcinfocodecrosswalk/hcpcinfocodecrosswalk.component';
import { IndicationAdminCrosswalkComponent } from './components/indicationadmincrosswalk/indicationadmincrosswalk.component';
import { IndicationMinMaxCrosswalkComponent } from './components/indicationminmaxcrosswalk/indicationminmaxcrosswalk.component';
// canActivate:[AuthGuard],
const appRoutes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'login',component: LoginComponent},
    { path: 'home',component: HomeComponent},
    { path: 'ndcfailure/:workqueue/:id/:qId/:uId', canActivate:[AuthGuard],component: NDCFailureComponent},
    { path: 'ndcfailure',canActivate:[AuthGuard],component: NDCFailureComponent},
    { path: 'ndcfailureReadOnly/:workqueue', canActivate:[AuthGuard],component: NDCFailureReadOnlyComponent},
    { path: 'ndcconversionmapping',canActivate:[AuthGuard],component: NdcconversionmappingComponent},
    { path: 'hcpcndccrosswalk',component: HcpcNdcCrosswalkComponent},
    { path: 'indicationidccrosswalk',canActivate:[AuthGuard],component: IndicationIdcCrosswalkComponent},
    { path: 'indicationadmincrosswalk',canActivate:[AuthGuard],component: IndicationAdminCrosswalkComponent},
    { path: 'indicationminmaxcrosswalk',canActivate:[AuthGuard],component: IndicationMinMaxCrosswalkComponent},
    { path: 'infocodemaster',canActivate:[AuthGuard],component: InfoCodeMasterComponent},
    { path: 'narrativemaster',canActivate:[AuthGuard],component: NarrativeMasterComponent},
    { path: 'uploadmaster',canActivate:[AuthGuard],component: UploadMasterComponent},
    { path: 'pimaster',canActivate:[AuthGuard],component: PIMasterComponent},
    { path: 'prisespecmaster',canActivate:[AuthGuard],component: PriseSpecMasterComponent},
    { path: 'reimbmaster',canActivate:[AuthGuard],component: ReimbMasterComponent},
    { path: 'ndcbdrosswalk',component: NdcBdCrosswalkComponent},
    { path: 'hcpcinfocodecrosswalk',canActivate:[AuthGuard],component: HcpcInfoCodeCrosswalkComponent}
];
 
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);