import { Component, OnInit, ViewChild } from '@angular/core';

import { IUSER_MASTER, IINFO_CODE, IHCPC_CODE_LIST, IHCPCINFO_SAVE_CODE, IHCPCINFO_GET_CODE } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";
import { ModalComponent } from '../shared/modalpopup.component';
import { InfoCodeService } from '../../services/infocode.service';
import { HcpcCodeService } from '../../services/hcpcCode.service';

@Component({
  selector: 'app-hcpcinfocodecrosswalk',
  templateUrl: './hcpcinfocodecrosswalk.component.html',
  providers: [InfoCodeService, HcpcCodeService]
})
export class HcpcInfoCodeCrosswalkComponent implements OnInit {

  user: IUSER_MASTER;
  infoHCPCCodeData: IHCPC_CODE_LIST[];
  hcpcInfoCodeDataList: IHCPCINFO_GET_CODE[]
  infoCodeDataList: IINFO_CODE[];
  infoCodeFilterData: IINFO_CODE[]=[] as IINFO_CODE[];;
  hcpcInfoCodeRemoveFromLeft = [];
  hcpcInfoCodeSaveData : IHCPCINFO_GET_CODE[]=[] as IHCPCINFO_GET_CODE[];
  infoCodeSearchText: string = "";
  hcpcCodeSearchText: string = "";
  selected_hcpc_code: string = "";
  selected_hcpc_description: string = ""; 

  @ViewChild('modalHCPCCodeList') modalHCPCCodeList: ModalComponent;

  constructor(private _globalSev: GlobalService, private infoCodeService: InfoCodeService<IINFO_CODE>,
    private hcpcCodeService: HcpcCodeService<IHCPC_CODE_LIST>) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {

  }

  showInfoCodedata() {

    this.infoCodeService.getInfoCode(this.infoCodeSearchText.trim()).subscribe((infoCode: IINFO_CODE[]) => {
      this.infoCodeDataList = infoCode;
      if (this.infoCodeDataList.length == 0) {
        toastr.warning("No record found for info code" + " " + this.infoCodeSearchText);
        this.infoCodeSearchText = "";
        return;
      }
      else {
        var index;
        this.infoCodeFilterData = this.infoCodeDataList;
        // only show those info code which are not present at right side
        var result = this.infoCodeFilterData.filter(item => this.hcpcInfoCodeDataList.some(infocode => infocode.info_code.trim() == item.info_code.trim()));
        var count=this.infoCodeFilterData.length;;
        for (var i = 0; i < count; i++) {
          index = this.infoCodeFilterData.indexOf(result[i]);
          if (index > -1) {
            this.infoCodeFilterData.splice(index, 1);
          }
        }        
      }
    });
    if(this.infoCodeFilterData!=null && this.infoCodeFilterData.length==0)
    toastr.error("Infocode searched for" + this.infoCodeSearchText + "  already associted with   " + this.selected_hcpc_code + "    Please search new Info code");
  }

  showHCPCInfoCodedata() {
    this.hcpcCodeService.getDistinctHCPCCode(this.hcpcCodeSearchText.trim()).subscribe((hcpcCodeData: IHCPC_CODE_LIST[]) => {
      this.infoHCPCCodeData = hcpcCodeData["Result"];
      if (this.infoHCPCCodeData != null && this.infoHCPCCodeData.length > 1) {
        this.modalHCPCCodeList.show();
      }
      else if (this.infoHCPCCodeData != null) {
        this.hcpcCodeService.getInfoCodeByHCPCCode(this.hcpcCodeSearchText.trim()).subscribe((res: any) => {
          this.hcpcInfoCodeDataList = res['Result'];
          this.selected_hcpc_code = res['Result'][0].hcpc_code;
          this.selected_hcpc_description = res['Result'][0].hcpc_desc;
        });
      }
      else
      toastr.error("No record found found for HCPC code " + this.hcpcCodeSearchText);
    });
  }

  getInfoCodeByHCPCCode(hcpc: IHCPC_CODE_LIST): any {
    this.hcpcCodeService.getInfoCodeByHCPCCode(hcpc.hcpc_code).subscribe((hcpcInfoCode: IHCPCINFO_GET_CODE[]) => {
      this.hcpcInfoCodeDataList = hcpcInfoCode["Result"];
      this.selected_hcpc_code = hcpc.hcpc_code;
      this.selected_hcpc_description = hcpc.hcpc_desc;

    });
    this.modalHCPCCodeList.hide();
  }

  // getInfoByCode(code: string): any {
  //   this.infoCodeFilterData = this.infoCodeDataList.filter(obj => obj.info_code == code);
  // }

  InfoCodesearch() {
   
    if (this.infoCodeSearchText.trim() == '') {
      toastr.error("Please enter valid Info Code");
      return;
    } else {
      this.showInfoCodedata();
    }
   }

  HcpcCodesearch() {
   
    if (this.hcpcCodeSearchText.trim() == '') {
      toastr.error("Please enter valid HCPC Code");
      return;
    }
    else {
      this.showHCPCInfoCodedata();
    }
  }
  RemoveInfoCode() {
    var index;   
    var isItemSelected: boolean = false;

    if (this.hcpcInfoCodeDataList == null) {
      toastr.error("Please select atleast 1 info code to remove");
      return;
    }

    for (let i = 0; i < this.hcpcInfoCodeDataList.length; i++) {
      if (this.hcpcInfoCodeDataList[i]['is_selected'] == true) {
        this.hcpcInfoCodeDataList[i]['status'] = -1;
        var infoCodeMovedDataLtoR = {
          info_code_id: 0,
          info_code: "",
          note_description: "",
          is_selected: false
        };
       
        infoCodeMovedDataLtoR.info_code_id = this.hcpcInfoCodeDataList[i].info_code_id;
        infoCodeMovedDataLtoR.info_code = this.hcpcInfoCodeDataList[i].info_code;
        this.infoCodeFilterData.push(infoCodeMovedDataLtoR);

        this.hcpcInfoCodeRemoveFromLeft.push(this.hcpcInfoCodeDataList[i]);
        this.hcpcInfoCodeSaveData.push(this.hcpcInfoCodeDataList[i]);
        isItemSelected = true;
      }      

    }
    if (!isItemSelected) {
      toastr.error("Please select atleast 1 info code to remove");
      return;
    }

    var result = this.hcpcInfoCodeDataList.filter(item => this.hcpcInfoCodeRemoveFromLeft.some(hcpcCode => hcpcCode.info_code.trim() == item.info_code.trim()));
    var count=this.hcpcInfoCodeDataList.length;
    for (var i = 0; i < count; i++) {      
      index = this.hcpcInfoCodeDataList.indexOf(result[i]);
      if (index > -1) {
        this.hcpcInfoCodeDataList.splice(index, 1);
      }
    }

  }

  AddInforCode() {
    var index;
    
    var isItemSelected: boolean = false;
    var infoCodeMovedDataRtoL = [];
    if (this.infoCodeFilterData == null) {
      toastr.error("Please select atleast 1 info code to add");
      return;
    }

    for (let i = 0; i < this.infoCodeFilterData.length; i++) {
      if (this.infoCodeFilterData[i]['is_selected'] == true) {
        infoCodeMovedDataRtoL.push(this.infoCodeFilterData[i]);
        var hcpcInfoCodeMovedDataRtoL = {
          hcpc_info_code_map_id: 0,
          hcpc_code: "",
          hcpc_desc: "",
          info_code_id: 0,
          info_code: "",
          is_selected: false,
          rc_id: 0,
          status: 1
        };
        //obj => obj.info_code == code);
        //hcpcInfoCodeMovedDataRtoL.info_code = this.infoCodeFilterData[i].info_code;
        var result1 = this.hcpcInfoCodeSaveData.filter(item => item.info_code ==this.infoCodeFilterData[i].info_code);
        if (result1 !=null && result1.length > 0) {
          for (var j = 0; j < this.hcpcInfoCodeSaveData.length; j++) {
            index = this.hcpcInfoCodeSaveData.indexOf(result1[j]);
            if (index > -1) {
              this.hcpcInfoCodeSaveData.splice(index, 1);
              result1[j].is_selected=false;
              this.hcpcInfoCodeDataList.push(result1[j]);
            }
          }
          
        }
        else {
          hcpcInfoCodeMovedDataRtoL.rc_id = this.hcpcInfoCodeDataList[0].rc_id;
          hcpcInfoCodeMovedDataRtoL.info_code_id = this.infoCodeFilterData[i].info_code_id;
          hcpcInfoCodeMovedDataRtoL.info_code = this.infoCodeFilterData[i].info_code;
          hcpcInfoCodeMovedDataRtoL.status = 0;
          this.hcpcInfoCodeDataList.push(hcpcInfoCodeMovedDataRtoL);
        }
        
        this.hcpcInfoCodeSaveData.push(hcpcInfoCodeMovedDataRtoL);
       
        isItemSelected = true;
      }
    }
    if (!isItemSelected) {
      toastr.error("Please select atleast 1 info code to add");
      return;
    }

    var result = this.infoCodeFilterData.filter(item => infoCodeMovedDataRtoL.some(hcpcCode => hcpcCode.info_code.trim() == item.info_code.trim()));
    var count=this.infoCodeFilterData.length;
    for (var i = 0; i < count; i++) {
      index = this.infoCodeFilterData.indexOf(result[i]);
      if (index > -1) {
        this.infoCodeFilterData.splice(index, 1);
      }
    }

  }

  Save() { 

    var hcpcInfoCode = [];
    var objHcpcInfoCode={
      info_code_id:0,
      hcpc_info_code_map_id:0,
      status:-2
    }
    this.hcpcInfoCodeSaveData.forEach(function (obj) {

      objHcpcInfoCode.hcpc_info_code_map_id=obj.hcpc_info_code_map_id;
      objHcpcInfoCode.info_code_id=obj.info_code_id;
      objHcpcInfoCode.status=obj.status;
      hcpcInfoCode.push(objHcpcInfoCode);

    });
    var savedata = {
      "rc_id": this.hcpcInfoCodeSaveData[0].rc_id,
      "info_code_list": hcpcInfoCode
    }
   
    if (savedata != null) {
      if(savedata.rc_id==0){
      toastr.info("There is no new infor code to be associted with HCPC code  " + this.selected_hcpc_code);
      return;
      }
      this.hcpcCodeService.savehcpcInfoCodeDataList(savedata).subscribe((res: JSON) => {
          if (res['Result'].toLowerCase() == 'success') {             
              toastr.success("New info code associed with hcpc successfully");
              this.hcpcInfoCodeSaveData=[];
              hcpcInfoCode=[];
              this.infoCodeDataList=[];
          } else {
              toastr.error("failed to save due to /n internal sever error");
              this.hcpcInfoCodeSaveData=[];
              hcpcInfoCode=[];
              this.infoCodeDataList=[];
          }
      });
    }    
  }

  cancel() {
    this.hcpcCodeSearchText = "";
    this.infoCodeSearchText = "";
    this.selected_hcpc_code = "";
    this.selected_hcpc_description = "";
    this.infoCodeFilterData = [];
    this.hcpcInfoCodeDataList = [];
    this.hcpcInfoCodeSaveData=[];
    
  }

}
