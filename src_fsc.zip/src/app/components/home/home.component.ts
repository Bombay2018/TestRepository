/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, Directive } from '@angular/core';
import { Router } from '@angular/router';

import { HomeService } from "./../../services/home.service";
import { DataService } from '../../services/data.service';
import { IUSER_MASTER, IWorkQueue, IFOLLOWUP_MASTER } from '../../shared/interfaces/entities.interface';
//import { workqueue, DropDown, OutPram } from '../../shared/common';
import { GlobalService } from '../..//services/shared/global.service';
import { DropDown } from '../../shared/common';
import { ModalComponent } from '../shared/modalpopup.component';

declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'app-home',
    templateUrl: './home.component.html',
    providers: [HomeService, DataService]
})

export class HomeComponent implements AfterViewInit {
    user: IUSER_MASTER;
    isDesc: boolean = false;
    column: string = 'Date_Added';
    direction: number;
    selectedColumn: Object = {};
    dropDown: DropDown[];
    workqueuedata: IWorkQueue[];
    workqueuedataFilter: IWorkQueue[];
    calendarFollowUp: IFOLLOWUP_MASTER[];
    calendarFollowUpFilter: IFOLLOWUP_MASTER[];
    el: HTMLElement;
    todayDate: any;
    differenceInDate: any;
    differenceInMonth: any;
    differenceInYear: any;
    ImpactedElement: string;
    WorkQueueType: string;
    stage_id: number;
    RuleFailure: string;
    AttributeFailed: string;
    Status: string;
    statusFilter: string;
    switchResult: any;
    newfollowup: IFOLLOWUP_MASTER = {} as IFOLLOWUP_MASTER;
    selectedCode: string;
    selectedRuleFailure: string;
    seldate: Date;

    @ViewChild('taskDate') div: ElementRef;
    @ViewChild('modalLockExist') modalLockExist: ModalComponent;

    constructor(
        private homeSvc: HomeService<IWorkQueue>,
        private dataSvc: DataService,
        private router: Router,
        private elementRef: ElementRef,
        private _globalSev: GlobalService) {
        this.user = JSON.parse(localStorage.getItem('currentUser'));
        toastr.options = { positionClass: 'toast-top-center' };
        debugger;
        if (this.user != undefined) {
            this._globalSev.showNavBar(true, this.user.user_name);
        }else { 
            this._globalSev.showNavBar(true, ''); 
        }
    }

    ngOnInit() {
        localStorage.removeItem('followupdates');
        this.todayDate = new Date().getDate();
        this.showWorkQueueData();
        this.showFollowup();
        this.dataSvc.getDropdownData().subscribe((res: any) => {
            this.dropDown = res.HomeGridDropdown;
            this.selectedColumn = this.dropDown[0].id;
        });
        this.sortDefault();
        // this._globalSev.getLoggedUser(this.user.user_name);

    }
    sortDefault() {
        this.column = 'Date_Added';
        this.direction = this.isDesc == false ? 1 : -1;
    }
    showWorkQueueData() {
        this.homeSvc.getWorkqueue(this.user.user_id).subscribe((WorkQueue: IWorkQueue[]) => {
            debugger;
            if (WorkQueue['Result'] != null) {
                this.workqueuedata = WorkQueue['Result'];
                this.workqueuedataFilter = WorkQueue['Result'];
            }
        });
    }

    showFollowup() {
        this.homeSvc.getCalendarFollowUp(this.user.user_id).subscribe((calendarData: IFOLLOWUP_MASTER[]) => {
            this.calendarFollowUp = calendarData['result'];
            this.calendarFollowUpFilter = this.calendarFollowUp.filter(obj => ((new Date(obj.follow_up_date)).getDate() == (new Date()).getDate()) && ((new Date(obj.follow_up_date)).getMonth()==(new Date()).getMonth()));
            this.calendarFollowUp = calendarData['result'];
            var followupdates = [];
            calendarData['result'].forEach(function (obj) {
                followupdates.push(obj.follow_up_date);
                // $(".datepicker td:contains(" + new Date(obj.follow_up_date).getDate() + ")").addClass('danger');
            });
            localStorage.setItem('followupdates', JSON.stringify(followupdates));
        });
    }

    ngAfterViewInit() {
        $('.date').datepicker({
            format: 'mm/dd/yyyy',
            startDate: new Date(),
            autoclose: true
        }).on('change', (event: any) => {
            this.newfollowup.follow_up_date = event.target.value;
        });

        $('.inlineDate div').datepicker({
            multidate: false,
            multidateSeparator: ",",
            todayHighlight: true,
            beforeShowDay: function (date) {
                if (localStorage.getItem('followupdates') != null && localStorage.getItem('followupdates') != '') {
                    var followupDates = JSON.parse(localStorage.getItem('followupdates'));
                    followupDates.forEach(function (followupdate) {
                        if (new Date(followupdate).getMonth() == date.getMonth() && new Date(followupdate).getDate() == date.getDate()) {
                            if (date.getDate() < (new Date()).getDate()) {
                                $(".datepicker td:contains(" + date.getDate() + ")").addClass('danger');
                            } else if (date.getDate() >= (new Date()).getDate()) {
                                $(".datepicker td:contains(" + date.getDate() + ")").removeClass('today').addClass('success');
                            }
                        }
                    })
                }
            }.bind(this), //.apply(this),               
        }).on("changeDate", function (e) {
            this.seldate = new Date(e.date)
            if (localStorage.getItem('followupdates') != null && localStorage.getItem('followupdates') != '') {
                var followupDates = JSON.parse(localStorage.getItem('followupdates'));
                var selMonthDate = new Date((e.date).getFullYear(), (e.date).getMonth(), 1);
                while (selMonthDate.getMonth() === (e.date).getMonth()) {
                    followupDates.forEach(function (followupdate) {
                        if (new Date(followupdate).getMonth() == e.date.getMonth() && new Date(followupdate).getDate() == selMonthDate.getDate()) {
                            if (selMonthDate.getDate() < (new Date()).getDate()) {
                                $(".datepicker td:contains(" + selMonthDate.getDate() + ")").addClass('danger');
                            } else if (selMonthDate.getDate() >= (new Date()).getDate()) {
                                $(".datepicker td:contains(" + selMonthDate.getDate() + ")").removeClass('today').addClass('success');
                            }
                        }
                    })
                    selMonthDate.setDate(selMonthDate.getDate() + 1);
                }
            }
            this.calendarFollowUpFilter = this.calendarFollowUp.filter(obj => ((new Date(obj.follow_up_date)).getDate() == (new Date(this.seldate)).getDate()) && ((new Date(obj.follow_up_date)).getMonth() == (new Date(this.seldate)).getMonth()));
        }.bind(this));
    }

    showNDCdetail(code: string, ruleFailure: string, row: any) {
        this.lockWorkQueueByUser(code, ruleFailure, row);

    }

    sort() {
        this.column = this.selectedColumn.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    filterStatus($event, statusValue) {
        if ($event.target.checked) {
            this.statusFilter = statusValue;
        }
        this.filterWorkQueueData();
    }

    filterWorkQueueData(): void {
        if (this.ImpactedElement || this.WorkQueueType || this.RuleFailure || this.AttributeFailed || this.Status || this.statusFilter) {
            this.workqueuedataFilter = this.workqueuedata.filter
                (item =>
                    ((this.RuleFailure) ? (item.Rule_Failure.toLowerCase().indexOf(this.RuleFailure.toLowerCase()) > -1) : 1)
                    &&
                    ((this.ImpactedElement) ? (item.Impacted_Element.indexOf(this.ImpactedElement.toLowerCase()) > -1) : 1)
                    &&
                    ((this.WorkQueueType) ? (item.Work_Queue_Type.toLowerCase().indexOf(this.WorkQueueType.toLowerCase()) > -1) : 1)
                    &&
                    ((this.AttributeFailed) ? (item.Attribute_Failed.toLowerCase().indexOf(this.AttributeFailed.toLowerCase()) > -1) : 1)
                    &&
                    ((this.Status) ? (item.Status.toLowerCase().indexOf(this.Status.toLowerCase()) > -1) : 1)
                    &&
                    ((this.statusFilter) ? (item.Status.toLowerCase().indexOf(this.statusFilter.toLowerCase()) > -1) : 1)
                );
        }
        else {
            this.workqueuedataFilter = this.workqueuedata;
        }
    }

    clear() {
        this.ImpactedElement = "";
        this.RuleFailure = "";
        this.AttributeFailed = "";
        this.Status = "";
        this.workqueuedataFilter = this.workqueuedata;
    }

    parseDate(dateString: string): Date {
        if (dateString) {
            return new Date(dateString);
        } else {
            return null;
        }
    }

    saveFollowUp() {
        if (this.newfollowup.ndc && this.newfollowup.hcpc && this.newfollowup.drug_name &&
            this.newfollowup.follow_up_date && this.newfollowup.notes) {
            this.newfollowup.user_id = this.user.user_id;
            // newfollowup.is_ndc_followup=false;
            this.homeSvc.saveFollowUp(this.newfollowup).subscribe(
                resdata => this.showFollowup()
            );
        }
        else {
            toastr.warning("None of the field should be empty while adding follow-up");
        }
        this.newfollowup.ndc = "";
        this.newfollowup.hcpc = "";
        this.newfollowup.drug_name = "";
        this.newfollowup.follow_up_date = undefined;
        this.newfollowup.notes = "";
    }

    deleteFollowUpTask(followUpId) {
        if (confirm("Are you sure you want to delete this Task?")) {
            this.homeSvc.deleteFollowUp(followUpId).subscribe(
                resdata => this.showFollowup()
            );
        }
        else {
            return false;
        }
    }

    lockWorkQueueByUser(code: string, ruleFailure: string, row: any) {
        this.selectedCode = code;
        this.selectedRuleFailure = ruleFailure;
        var users = JSON.parse(localStorage.getItem('currentUser'));
        localStorage.setItem('userId', users.user_id);
        let objData = { "ndc_hcpc_id": row["Impacted_Element"], "queue_id": row["Impacted queue_id"], "user_id": users.user_id };
        this.dataSvc.lockWorkQueueNdc(objData).subscribe((res: any) => {
            var result = res.Result;
            if (result == "Already locked by user") {
                this.modalLockExist.show();
            }
            else {
                debugger;
                var wq = this.workqueuedata.filter(obj => obj.Impacted_Element === code && obj.Rule_Failure === ruleFailure)[0];
                this._globalSev.queue_id = wq["Impacted queue_id"];
                this._globalSev.stage_id = wq["stage_id"];

                if (wq.Rule_Failure == "NDC") {
                    this.router.navigate(['/ndcfailure', { workqueue: code, id: row["Impacted_Element"], qId: row["Impacted queue_id"], uId: users.user_id }]);
                }
                else if (wq.Rule_Failure == "HCPC") {
                    this.router.navigate(['/hcpcndccrosswalk']);
                } else if ("Conversion/Translation") {
                    this.router.navigate(['/ndcfailure', { workqueue: code, id: row["Impacted_Element"], qId: row["Impacted queue_id"], uId: users.user_id }]);
                }
                localStorage.removeItem('followupdates');
            }
        })
    }
    viewNdcFailure() {
        var code = this.selectedCode;
        var wq = this.workqueuedata.filter(obj => obj.Impacted_Element === code && obj.Rule_Failure === this.selectedRuleFailure)[0];
        debugger;
        if (wq.Work_Queue_Type == "Initial") {
            this._globalSev.stage_id = 1;
        }

        if (wq.Rule_Failure == "NDC") {
            this.router.navigate(['/ndcfailureReadOnly', code]);
        }
        else if (wq.Rule_Failure == "HCPC") {
            this.router.navigate(['/hcpcndccrosswalk']);
        } else if (wq.Rule_Failure == "Conversion/Translation") {
            this.router.navigate(['/ndcfailureReadOnly', code]);
        }
        localStorage.removeItem('followupdates');
    }
}