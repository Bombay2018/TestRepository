import { Component, ViewChild } from '@angular/core';
import { GlobalService } from "./../../services/shared/global.service";
import { InfoCodeService } from '../../services/infocode.service';
import { IUSER_MASTER, IBD_SPEC, IINFO_CODE_MASTER } from '../../shared/interfaces/entities.interface';
import { ModalComponent } from '../shared/modalpopup.component';

@Component({
  selector: 'app-infocodemaster',
  templateUrl: './infocodemaster.component.html',
  providers: [InfoCodeService]
})
export class InfoCodeMasterComponent {
  user: IUSER_MASTER;
  infoCodeData: IINFO_CODE_MASTER[];
  infoCodeFilterData: IINFO_CODE_MASTER[];
  infoCodeReturn: string = "";
  infoCodeSearch: string = "";
  info_code_id: number = 0;
  info_code: string = "";
  info_note: string = "";
  isAddingNewInfoCode: boolean = false;

  @ViewChild('modalInfoCodeList') modalInfoCodeList: ModalComponent;

  constructor(private infoCodeService: InfoCodeService<IINFO_CODE_MASTER>,
    private _globalSev: GlobalService) {
    //this._globalSev.showNavBar.emit(true);
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  showInfoCodedata() {
    this.infoCodeFilterData = [];
    this.infoCodeService.getInfoCode(this.infoCodeSearch).subscribe((infoCode: IINFO_CODE_MASTER[]) => {
      this.infoCodeData = infoCode;

      if (this.infoCodeData.length == 0) {
        toastr.warning("No record found for info code" + " " + this.infoCodeSearch);
        this.infoCodeSearch = "";
        return;
      }

      if (this.infoCodeData != null && this.infoCodeData.length > 1) {
        this.modalInfoCodeList.show();
      } else {
        this.getInfoByCode(this.infoCodeData[0].info_code);
      }
    });
  }

  search() {
    if (this.infoCodeSearch.trim() == '') {
      toastr.error("Please enter Valid Info Code");
      return;
    } else {
      this.showInfoCodedata();

    }
  }

  addInfoCode() {
    this.info_code_id = 0;
    this.info_code = this.infoCodeSearch;
    this.info_note = "";  
    this.isAddingNewInfoCode = true;

  }

  //With Service data
  getInfoByCode(code: string): any {
    this.infoCodeService.getInfoByCode(code).subscribe((infoCode: IINFO_CODE_MASTER[]) => {
      this.infoCodeFilterData = infoCode;
      this.info_code_id = infoCode['info_code_id'];
      this.info_code = infoCode['info_code'];
      this.info_note = infoCode['note_description'];
    });
    this.modalInfoCodeList.hide();
  }
  isInfoCodeExist() : boolean {
      var isRecordExist : boolean= false;
      this.infoCodeService.getInfoCode(this.infoCodeSearch).subscribe((infoCodes: IINFO_CODE_MASTER[]) => {
        if (infoCodes.length == 0) {
          isRecordExist = false;
        } else {
          var matchedInfoCodes = infoCodes.filter( infoCode => infoCode.info_code === this.infoCodeSearch);
          isRecordExist = matchedInfoCodes.length != 0;
        }
    })
    return isRecordExist;
  }
  saveInfoCode() {
    this.infoCodeData = [];
    if (this.info_code == "" || this.info_note == "") {
      toastr.warning("None of the field should be empty");
      return;
    }
    if(this.isAddingNewInfoCode) {
        this.infoCodeService.getInfoCode(this.infoCodeSearch).subscribe((infoCodes: IINFO_CODE_MASTER[]) => {
          var matchedInfoCodes = infoCodes.filter( infoCode => infoCode.info_code === this.infoCodeSearch);
          if(matchedInfoCodes.length != 0){
            toastr.error("Entered info Code exist!");
            return;
          } else {
            this.save();
          }

        })
    } else {
      this.save();
  }
}
  save() {
      this.infoCodeData.push({
        "info_code_id": this.info_code_id,
        "info_code": this.info_code,
        "note_description": this.info_note
      });

      this.infoCodeService.saveInfoCode(this.infoCodeData).subscribe((infoCode: IINFO_CODE_MASTER[]) => {
        this.infoCodeReturn = infoCode['Result'];
        if (this.infoCodeReturn == "success"){
          toastr.success("Info code saved successfully");
          this.cancelInfoCode();
        }
        else {
          toastr.error("Error while saving Info Code");
        }
      });
    }
  
  cancelInfoCode() {
    this.infoCodeSearch = "";
    this.infoCodeFilterData = [];
    this.infoCodeData = [];
    this.info_code_id = 0;
    this.info_code = "";
    this.info_note = "";
    this.isAddingNewInfoCode = false;
  }
}

