/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { GlobalService } from "./../../services/shared/global.service";
import { IUSER_MASTER } from './../../shared/interfaces/entities.interface';
import { UserService } from './../../services/user.service';

@Component({
  moduleId: module.id,
  selector: 'app-login',
  templateUrl: './login.component.html',
  providers: [UserService]
})


export class LoginComponent implements OnInit {

  userInfo: IUSER_MASTER = { user_name: '', password: '' } as IUSER_MASTER;
  constructor(
    private _routes: Router,
    private _userSev: UserService<IUSER_MASTER>,
    private _globalSev: GlobalService) { }

  ngOnInit() {
    this._globalSev.showNavBar(false, '');
    this._userSev.logout();
  }

  doLogin() {
    if (this.userInfo.password != "" && this.userInfo.user_name != "") {
      this._userSev.getUser(this.userInfo).subscribe(
        resdata => this.isValidUser(resdata)
      );
    } else {
      toastr.error("Please enter user name or password");
    }
  }

  isValidUser(user) {
    if (user.user_id != undefined) {
      this.userInfo = user;
      this._userSev.isAuthenicated = true;
      user.password = '';
      this._globalSev.user = user;
      localStorage.setItem('currentUser', JSON.stringify(user));
      this._globalSev.showNavBar(true, user.user_name);
      this._routes.navigate(['home']);
    } else {
      toastr.error("Invalid user name or password");
      localStorage.setItem('currentUser', '');
      this._routes.navigate(['login']);
    }
  }
}
