/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, HostListener, Renderer } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs/Rx';
import { OnDestroy } from '@angular/core';

import { ConfigService } from '../../services/shared/config.service';
import { NDCFailureGridHead, NDCFailureMessage, WorkQueueType, DataSources } from '../../services/shared/config.const';
import { INDC_ATTRIBUTES, INDC_ATTRIBUTES_STATUS, INDC_PRICE_HISTORY, IUSER_MASTER, IDS_RJ_MAP, IWORKQUEUE_MAPPING } from '../../shared/interfaces/entities.interface';
import { GlobalService } from '../../services/shared/global.service';
import { DataService } from '../../services/data.service';
import { NDCService } from '../../services/ndc.service';
import { PriceHistoryService } from '../../services/pricehistory.service';
import { ConversionService } from '../../services/conversion.service';

import { DropDown } from '../../shared/common';

import { ModalComponent } from '../shared/modalpopup.component';
//import { OrderBy } from './../../pipes/orderby.pipe';

import { attributeChangeOption } from '../../services/shared/enum';

declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'app-ndcfailure',
  templateUrl: './ndcfailure.component.html',
  providers: [NDCService, DataService, PriceHistoryService, ConversionService]
})
export class NDCFailureComponent implements OnInit, AfterViewInit, OnDestroy {

  user: IUSER_MASTER;
  mockRuleFailureUpdate: any;
  mockWorkQueue: DropDown[];
  reasonCodeDropDown: DropDown[];
  attributeNameDropDown: any;
  workQueueType: any;
  ndc_hcpc_id: any;
  queueId: any;
  mockUser: any;
  workQueueRow: any;
  selectedCode: any;
  userId: any;

  viewMode: boolean = false;
  ndcSearchResult: any[] = new Array();
  ndcSearchCode: string = '';
  ndcNumber: string = '';
  ndcStatus:string='';
  ndcWtId: number = 0;
  //prescribinginformation: Object;
  ndcDSAttributes: any;
  ndcSDDLAttributes: any;
  ndcSDDLAttributesBackup: any;
  ndcDiscrepancyAttributes: any;
  ndcChangedAttr: Object;
  ndcOtherDetails: Object;
  ndcRuleFailure: any[] = new Array();
  attrubutStatus: INDC_ATTRIBUTES_STATUS = {} as INDC_ATTRIBUTES_STATUS;

  msView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  fdbView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  rjView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  gsView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  addNewNDC: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  msshow: boolean = true;
  fdbshow: boolean = true;
  rjshow: boolean = true;
  gsShow: boolean = true;
  activeHistoryTab: number = 0;

  conversionTranslate: any; //IDS_RJ_MAP = {} as IDS_RJ_MAP;
  selectedSuperSix: string = '';
  statusProp: string = '';

  isSearch: boolean = false;
  newNDC: boolean = false;
  isNewNDC: boolean = false;
  priceHistoryshow: boolean = false;
  activePricing: string;
  ndcAWPWACHistoryBackup: INDC_PRICE_HISTORY[] = [] as INDC_PRICE_HISTORY[];
  ndcAWPWACHistory: INDC_PRICE_HISTORY[] = [] as INDC_PRICE_HISTORY[];

  isAddNDC: boolean = false;
  options: string[];
  //attrCnangeOptions : typeof attributeChangeOption = attributeChangeOption;
  datasources: any;
  pricespecification: any;
  saveQueueId: number;
  contexMenu;
  message;
  gridhead: any;
  isL1User: boolean = false;
  isAdminUser: boolean = true;
  isL2User: boolean = false;

  @ViewChild('modalNDCList') modalNDCList: ModalComponent;
  @ViewChild('modalRequestPublish') modalRequestPublish: ModalComponent;
  @ViewChild('modalPublish') modalPublish: ModalComponent;
  @ViewChild('modalLockExist') modalLockExist: ModalComponent;
  @ViewChild('fdbTab') div: ElementRef;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private configsvc: ConfigService,
    private elementRef: ElementRef,
    private ndcSvc: NDCService<INDC_ATTRIBUTES>,
    private dataSvc: DataService,
    private pricehistorySvc: PriceHistoryService<INDC_PRICE_HISTORY>,
    private conversionSvc: ConversionService<IDS_RJ_MAP>,
    private _globalSev: GlobalService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {
    this.isAddNDC = false;
    this.ndcNumber = this.route.snapshot.params['workqueue'];
    this.ndc_hcpc_id = this.route.snapshot.params['id'];
    this.queueId = this.route.snapshot.params['qId'];
    this.saveQueueId = this.queueId;
    this.userId = this.route.snapshot.params['uId'];
    this.gridhead = NDCFailureGridHead;
    this.getNDCByCode(this.ndcNumber);
    this.message = NDCFailureMessage;
    this.contexMenu = this.configsvc.getcontexMenu();
    this.contexMenu.forEach(cm => cm.subject.subscribe(val => this.setStatus(val)));
    if ((this.user.role_name == "L1-Initial") || (this.user.role_name == "L1-Change")) {
      this.isL1User = true;
      this.isAdminUser = false;
      this.isL2User = false;
    }
    else if ((this.user.role_name == "L2-Initial") || (this.user.role_name == "L2-Change") || (this.user.role_name == "L2-Second level")) {
      this.isL1User = false;
      this.isAdminUser = false;
      this.isL2User = true;
    }
    this.dataSvc.getDropdownData().subscribe((res: any) => {
      this.mockRuleFailureUpdate = res.mockRuleFailureUpdate;
      this.ndcRuleFailure['attribute_status'] = this.mockRuleFailureUpdate[0].description;
      this.workQueueType = WorkQueueType;
      this.reasonCodeDropDown = res.HcpcNdcReasonCode;
      this.ndcOtherDetails['reason_notes'] = this.reasonCodeDropDown[0].id;
    })
    this.dataSvc.getAllAttribute().subscribe((res: any) => {
      this.attributeNameDropDown = res['Result'];
    });
    this.dataSvc.getWorkQueueName().subscribe((res: any) => {
      this.mockWorkQueue = res;
    });
    this.dataSvc.getDataSource().subscribe((res: any) => {

      this.datasources = res['Result'];
    });
    this.setndcOtherDetails();
  }

  ngAfterViewInit() {
    $('#followDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.ndcOtherDetails['follow_up_date'] = event.target.value;
    });

    $('#piDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.ndcOtherDetails['pi_status_date'] = event.target.value;
    });

  }

  showUser(queue_id) {
    this.dataSvc.getUserByQueueId(queue_id).subscribe((res: any) => {
      this.mockUser = res;
    });
  }

  search() {
    this.isSearch = true;
    this.isAddNDC = false;
    this.clearControls();
    if (this.ndcSearchCode.trim() == '') {
      toastr.error("Please enter NDC Code");
      return;
    } else {
      this.dataSvc.getDistinctNDC(this.ndcSearchCode.trim()).subscribe((res: any) => {
        this.ndcSearchResult = res['Result'];
        if (this.ndcSearchResult.length == 0) {
          toastr.info("Record Not Found");
          return;
        }
        else if (this.ndcSearchResult.length == 1) {
          this.getNDCByCode(res['Result'][0]['ndc']);
          this.ndcStatus=res['Result'][0]['ndc_status'];
          this.ndcSearchCode = "";
        }
        else if (this.ndcSearchResult.length > 1) {
          this.modalNDCList.show();
          this.ndcSearchCode = "";
        }
        else {
          this.getNDCByCode(this.ndcSearchCode.trim());
          this.ndcSearchCode = "";
        }
      });

    }

  }

  getNDCByCode(code: string): any {
    this.ndcNumber = code;
    

    if (this.ndcSearchResult.length > 0) {
      this.ndcWtId = this.ndcSearchResult.filter(obj => obj.ndc == code)[0]['wt_id'];
    }

    if (code != undefined) {
      this.ndcSvc.getNDCByNDC(code).subscribe((ndcattributes: INDC_ATTRIBUTES[]) => {
        this.ndcDSAttributes = ndcattributes;
        //this.ndcSDDLAttributes = ndcattributes.filter(obj => obj.data_source_id == 6);
        this.ndcSDDLAttributes = ndcattributes.filter(obj => obj.data_source_id == 6);
        this.InitStatus();

        var statusProps = Object.getOwnPropertyNames(this.attrubutStatus);
        statusProps.forEach(prop => {
          this.ndcSDDLAttributes[0][prop] = 0
        });
        //this.ndcSDDLAttributesBackup = Object.assign({}, this.ndcSDDLAttributes);
        this.ndcWtId = this.ndcSDDLAttributes[0].wt_id;

        this.ndcSvc.getNDCRuleFailure(code).subscribe((ndcrulefailure) => {

          this.ndcRuleFailure = ndcrulefailure;
          if (ndcrulefailure['queue_name'] == "NDC_Discrepancy") {
            this.saveQueueId = 1;
          }
          else {
            this.saveQueueId = 5;
          }
          this._globalSev.stage_id = ndcrulefailure["stage_id"];

          if (this.ndcRuleFailure.length > 0) {
            this.ndcSvc.getDiscrepancyAttributes(code).subscribe((workqueitems: IWORKQUEUE_MAPPING[]) => {
              this.ndcDiscrepancyAttributes = workqueitems;
              if (this.ndcDiscrepancyAttributes != null && this.ndcSDDLAttributes[0] != null) {
                this.ndcDiscrepancyAttributes.forEach(obj => {

                  switch (obj["attribute_name"].toLowerCase()) {
                    case "generic_name": this.ndcSDDLAttributes[0]['generic_name'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['generic_name_status'] = 2; break;
                    case "brand_name": this.ndcSDDLAttributes[0]['brand_name'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['brand_name_status'] = 2; break;
                    case "strength": this.ndcSDDLAttributes[0]['strength'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['strength_status'] = 2; break;
                    case "route_of_administration": this.ndcSDDLAttributes[0]['route_of_administration'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['route_of_administration_status'] = 2; break;
                    case "dosage_form": this.ndcSDDLAttributes[0]['dosage_form'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['dosage_form_status'] = 2; break;
                    case "rx_otc_ind": this.ndcSDDLAttributes[0]['rx_otc_ind'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['rx_otc_ind_status'] = 2; break;
                    case "awp": this.ndcSDDLAttributes[0]['awp'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['awp_status'] = 2; break;
                    case "wac": this.ndcSDDLAttributes[0]['wac'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['wac_status'] = 2; break;
                    case "ndc_status": this.ndcSDDLAttributes[0]['ndc_status'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['ndc_status_status'] = 2; break;
                    case "ndc_status_date": this.ndcSDDLAttributes[0]['ndc_status_date'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['ndc_status_date_status'] = 2; break;
                    case "br_generic_indicator": this.ndcSDDLAttributes[0]['br_generic_indicator'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['br_generic_indicator_status'] = 2; break;
                    case "package_size": this.ndcSDDLAttributes[0]['package_size'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_size_status'] = 2; break;
                    case "package_size_uom": this.ndcSDDLAttributes[0]['package_size_uom'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_size_uom_status'] = 2; break;
                    case "package_description": this.ndcSDDLAttributes[0]['package_description'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_description_status'] = 2; break;
                    case "package_unit_dose": this.ndcSDDLAttributes[0]['package_unit_dose'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_unit_dose_status'] = 2; break;
                    case "package_quantity": this.ndcSDDLAttributes[0]['package_quantity'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['package_quantit_status'] = 2; break;
                    case "repackager_ind": this.ndcSDDLAttributes[0]['repackager_ind'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['repackager_ind_status'] = 2; break;
                    case "sd_md": this.ndcSDDLAttributes[0]['sd_md'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['sd_md_status'] = 2; break;
                    case "tee_code": this.ndcSDDLAttributes[0]['tee_code'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['tee_code_status'] = 2; break;
                    case "inner_outer_package_indicator": this.ndcSDDLAttributes[0]['inner_outer_package_indicator'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['inner_outer_package_indicator_status'] = 2; break;
                    case "manufacturer_name": this.ndcSDDLAttributes[0]['manufacturer_name'] = obj["attribute_value"]; this.ndcSDDLAttributes[0]['manufacturer_name_status'] = 2; break;
                    case "cms_rebate": this.ndcSDDLAttributes[0]['cms_rebate'] = obj["attribute_value"]; break;
                    case "created_date": this.ndcSDDLAttributes[0]['created_date'] = obj["attribute_value"]; break;
                  }
                });
              }
              this.ndcSDDLAttributesBackup = Object.assign({}, this.ndcSDDLAttributes[0]);
              //check ndcRuleFailure to change status and create link
              debugger;
              var self = this;
              var ths = Array.prototype.slice.call(document.getElementById("grid").getElementsByTagName("th"));
              this.ndcRuleFailure.forEach(function (obj) {

                var status = obj['attribute_name'];
                // self.ndcSDDLAttributes[0][status.toLowerCase() + '_status'] = 2;
                // self.ndcSDDLAttributesBackup[status.toLowerCase() + '_status'] = 2;
                if (obj['attribute_name'].toLowerCase() != 'awp' && obj['attribute_name'].toLowerCase() != 'wac' && obj['attribute_name'].toLowerCase() != 'ndc_status') {
                  var link = document.createElement("a");
                  link.setAttribute('href', "javascript:void(0)");
                  link.innerHTML = self.gridhead[status.toLowerCase()];
                  ths.forEach((th) => {
                    if (th.innerHTML.trim() == link.innerHTML.trim()) {
                      link.addEventListener("click", self.showCTpopup.bind(self));
                      th.innerHTML = '';
                      th.appendChild(link);
                    }
                  });
                }
              });
            });
          }

          var prop = status.slice(0, -7);
          if (prop.trim().length > 0) {
            if (this.ndcSDDLAttributesBackup[prop] != event) {
              this.ndcSDDLAttributes[0][status] = 1;
            } else {
              this.ndcSDDLAttributes[0][status] = this.ndcSDDLAttributesBackup[status];
            }
          }
        });

        this.ndcSvc.getNDCPrescribingInformation(this.ndcWtId).subscribe((ndcprescribinginformation) => {
          if (ndcprescribinginformation != null) {
            this.ndcOtherDetails['pi_link'] = ndcprescribinginformation['pi_link'];
            this.ndcOtherDetails['pi_status_date'] = ndcprescribinginformation['pi_status_date'];
          }
        });

        // this.ndcSvc.getNDCPriceSpecificationNDCDetail(this.ndcWtId).subscribe((ndcPriceSpecification) => {
        //   if (ndcPriceSpecification != null) {
        //     this.ndcOtherDetails['price_spec_id'] = ndcPriceSpecification['price_spec_id'];
        //     this.ndcOtherDetails['price_spec_notes'] = ndcPriceSpecification['note_description'];
        //   }
        // });

        this.ndcSvc.getNDCPriceSpecificationDropDown().subscribe((pricespecification) => {
          this.pricespecification = pricespecification;
        });
      });
    }
    this.ndcSearchCode = '';
  }

  modelChange(status, event) {
    var prop = status.slice(0, -7);
    if (status != '') {
      if (this.ndcSDDLAttributesBackup[prop] != event) {
        this.ndcSDDLAttributes[0][status] = 1;
      } else {
        this.ndcSDDLAttributes[0][status] = this.ndcSDDLAttributesBackup[status];
      }
    }
  }

  showhide(ds: number) {
    if (this.isNewNDC == false) {
      switch (ds) {
        case 2:
          this.fdbshow = !this.fdbshow;
          if (this.fdbView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((fdbView: INDC_ATTRIBUTES[]) => {

              this.fdbView = fdbView;
            })
          }
          //this.fdbView = this.fdbshow == true ? this.ndcDSAttributes.DataSource.FDB : this.ndcDSAttributes.DataSource.FDB.slice(0, 1);
          break;
        case 4:
          this.gsShow = !this.gsShow;
          if (this.gsView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((gsView: INDC_ATTRIBUTES[]) => {

              this.gsView = gsView;
            })
          }
          // this.gsView = this.gsShow == true ? this.ndcDSAttributes.DataSource.GS : this.ndcDSAttributes.DataSource.GS.slice(0, 1);
          break;
        case 6:
          this.rjshow = !this.rjshow;
          if (this.rjView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((rjView: INDC_ATTRIBUTES[]) => {

              this.rjView = rjView;
            })
          }
          break;
        case 7:
          this.msshow = !this.msshow;
          if (this.msView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((msView: INDC_ATTRIBUTES[]) => {

              this.msView = msView;
            })
          }
          break;
      }
    }
  }

  showCTpopup(e) {
    if (e.srcElement.innerHTML != 'AWP Pr' && e.srcElement.innerHTML != 'WAC Pr' && e.srcElement.innerHTML != "Status") {
      this.selectedSuperSix = e.srcElement.innerHTML;
      var key = Object.keys(NDCFailureGridHead).find(key => NDCFailureGridHead[key] === e.srcElement.innerHTML);
      this.conversionSvc.getConversionTranslation(key).subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
        this.conversionTranslate = ndcSuperSix['Result'];

        var x = document.getElementById("CTPopup");
        x.style.position = "relative";
        x.style.left = '550.5px';
        x.style.top = '-1926px';
        x.style.display = 'block';
      });
    }
  }

  closeCTpopup() {
    var x = document.getElementById("CTPopup");
    x.style.display = 'none';
  }

  showhistory(ds, data_source_id, attribute_name) {
    this.activeHistoryTab = ds;
    this.activePricing = attribute_name;
    this.pricehistorySvc.getPriceHistory(this.ndcNumber, attribute_name).subscribe((pricehistory: INDC_PRICE_HISTORY[]) => {
      pricehistory.forEach((obj) => {
        this.ndcAWPWACHistoryBackup.push(obj);
      });
      this.ndcAWPWACHistory = this.ndcAWPWACHistoryBackup.filter(obj => obj.data_source_id === data_source_id && obj['attribute_name'] === attribute_name);
      this.priceHistoryshow = true;
    });
    this.ndcAWPWACHistoryBackup = [] as INDC_PRICE_HISTORY[];
  }

  closePriceHistory() {
    this.priceHistoryshow = false;
  }
  contexMenuClick(prop) {
    this.statusProp = prop;
  }

  setndcOtherDetails() {
    this.ndcOtherDetails = {
      reason_notes: "",
      reason_code: "",
      pi_name: "",
      pi_link: "",
      pi_status_date: new Date(),
      price_spec_id: 0,
      price_spec_notes: '',
      follow_up_date: "",
      work_queue: 0,
      work_queue_type: 0,
      route_user_id: 0,
      routing_notes: '',
      req_to_publish_note: '',
      publish_note: '',
      reason_attribute_id: ''
    }
  }

  setStatus(id) {
    var prop = this.statusProp.slice(0, -7);
    //var maxId: number = Math.max.apply(Math, this.ndcDSAttributes.DataSource.RJ.map(function (o) { return o.Id; }))
    var updatedData = Object.assign({}, this.ndcSDDLAttributes[0]);
    if (updatedData[prop] === this.ndcSDDLAttributesBackup[prop]) {
      toastr.error('Status not allowed to <br> change on old value');
      return;
    }

    // switch case not required directly assin id
    switch (id) {
      case 0: //Failure Resolved
        this.ndcSDDLAttributes[0][this.statusProp] = 0;
        this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        break;
      case 1: //Follow-Up
        //this.ndcSDDLAttributes[this.statusProp] = 1;
        break;
      case 2: //Further Routing
        //this.ndcSDDLAttributes[this.statusProp] = 2;
        break;
      case 3: //override value
        this.ndcSDDLAttributes[0][this.statusProp] = 3;
        if (this.ndcSDDLAttributesBackup[status] == undefined) {
          this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        }
        break;
      case 4: //Change Review
        this.ndcSDDLAttributes[0][this.statusProp] = 4;
        if (this.ndcSDDLAttributesBackup[status] == undefined) {
          this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        }
        break;
      default:
        toastr.info('Invalid selection');
        break;
    }
    this.statusProp = '';
  }

  addNDC() {
    this.isAddNDC = true;
    if (this.newNDC == false) {
      this.newNDC = true;
    }
    else {
      toastr.error("Add Multiple NDC Not Allow");
    }
  }

  saveNewNDC(serviceType, ndc) {

    if (this.addNewNDC['generic_name'] && this.addNewNDC['brand_name'] && this.addNewNDC['strength'] && this.addNewNDC['route_of_administration']
      && this.addNewNDC['dosage_form'] && this.addNewNDC['rx_otc_ind'] && this.addNewNDC['awp'] && this.addNewNDC['wac'] && this.addNewNDC['ndc_status']
      && this.addNewNDC['ndc_status_date'] && this.addNewNDC['br_generic_indicator'] && this.addNewNDC['package_size'] && this.addNewNDC['package_size_uom']
      && this.addNewNDC['package_description'] && this.addNewNDC['package_unit_dose'] && this.addNewNDC['package_quantity'] && this.addNewNDC['repackager_ind']
      && this.addNewNDC['sd_md'] && this.addNewNDC['tee_code'] && this.addNewNDC['inner_outer_package_indicator'] && this.addNewNDC['manufacturer_name']
      && this.addNewNDC['cms_rebate']) {
      var workqueues = [];
      this.attributeNameDropDown.forEach(element => {
        for (var prop in this.addNewNDC) {
          if (prop == element['attribute_name']) {
            workqueues.push({
              workqueue_id: 0,
              attribute_id: element['attribute_id'],
              attribute_name: element['attribute_name'],
              attribute_value: this.addNewNDC[prop]
            });
          }
        }
      });
      if (this.ndcOtherDetails['route_user_id'] == 0) {
        this.ndcOtherDetails['route_user_id'] = this.user['user_id'];
      }
      if (this.ndcOtherDetails['reason_code'] == "" || this.ndcOtherDetails['reason_code'] == undefined) {
        this.ndcOtherDetails['reason_code'] = 0;
      }
      //if (this.ndcOtherDetails['follow_up_date'] == undefined) { this.ndcOtherDetails['follow_up_date'] = ""; }
      if (this.ndcOtherDetails['reason_attribute_name'] == undefined) { this.ndcOtherDetails['reason_attribute_name'] = ""; }
      if (this.ndcOtherDetails['price_spec_id'] == undefined) { this.ndcOtherDetails['price_spec_id'] = 0; }
      if (this.ndcOtherDetails['pi_link'] == undefined) { this.ndcOtherDetails['pi_link'] = ""; }
      if (this.ndcOtherDetails['price_spec_notes'] == undefined) { this.ndcOtherDetails['price_spec_notes'] = ""; }
      if (this.ndcOtherDetails['pi_status_date'] == undefined) { this.ndcOtherDetails['pi_status_date'] = ""; }
      if (this.ndcOtherDetails['reason_notes'] == undefined) { this.ndcOtherDetails['reason_notes'] = ""; }
      if (this.ndcOtherDetails['routing_notes'] == undefined) { this.ndcOtherDetails['routing_notes'] = ""; }

      var savedata = {
        "pi_link": this.ndcOtherDetails['pi_link'],
        "pi_status_date": this.ndcOtherDetails['pi_status_date'],
        "price_spec_id": this.ndcOtherDetails['price_spec_id'],
        "price_spec_notes": this.ndcOtherDetails['price_spec_notes'],
        "loggedin_userid": this.user['user_id'],
        "wq_list": {
          "ndc": ndc,
          "user_id": this.ndcOtherDetails['route_user_id'],
          "wq_notes": this.ndcOtherDetails['reason_notes'],
          "reason_code": this.ndcOtherDetails['reason_code'],
          "reason_attribute_id": this.ndcOtherDetails['reason_attribute_name'],
          "routing_notes": this.ndcOtherDetails['routing_notes'],
          "workqueues": workqueues,
        }
      }
      this.ndcSvc.saveNewNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
        if (ndcData['status'] != null || ndcData['status'] == "Success") {
          toastr.success("New NDC Data Saved Successfully");
        }
      });
      this.router.navigate(['home']);
    }
    else {
      toastr.warning("All the RJ fields should be filled");
    }
  }

  save(serviceType) {
    var errorList = [];
    this.isAddNDC = false;
    var props = Object.getOwnPropertyNames(this.gridhead);
    props.forEach(prop => {
      if (this.ndcSDDLAttributes[0][prop] == "") {
        errorList.push(this.gridhead[prop] + '<br/>');
      }
    });
    if (errorList.length > 0) {
      errorList.splice(0, 0, 'Following are the error(s):<br/>')
      toastr.error(errorList.toString().replace(",", ""));
      return;
    }
    if (this.ndcSDDLAttributes[0] == undefined) {
      toastr.error("Any attribute updates not made");
      return;
    }
    else {
      this.getChangedAttr(this.ndcSDDLAttributesBackup, this.ndcSDDLAttributes[0]);

      var that = this;
      var workqueues = [];
      for (var prop in that.ndcChangedAttr) {

        var attr = that.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase() == prop && obj['attribute_name'].toLowerCase() != this.attrubutStatus['attribute_name']);
        var wq_id = that.ndcDiscrepancyAttributes.filter(obj => obj['attribute_name'].toLowerCase() == prop);

        if (attr.length > 0) {
          if (wq_id.length > 0) {
            workqueues.push({
              workqueue_id: wq_id[0]['workqueue_id'],
              wq_queue_id: wq_id[0]['queue_id'],
              attribute_id: attr[0]['attribute_id'],
              attribute_name: attr[0]['attribute_name'],
              attribute_value: this.ndcChangedAttr[prop]
            });
          } else {
            workqueues.push({
              workqueue_id: 0,
              wq_queue_id: 1,
              attribute_id: attr[0]['attribute_id'],
              attribute_name: attr[0]['attribute_name'],
              attribute_value: this.ndcChangedAttr[prop]
            });
          }
        }
      }
      var rule_failures = [];
      this.ndcRuleFailure.forEach(existing => {
        var attr = that.attributeNameDropDown.filter(obj => obj['attribute_name'] == existing['attribute_name']);
        if (attr.length > 0 && existing['attribute_status'] != null) {
          rule_failures.push(existing);
        }
      });

      if (this.ndcOtherDetails['route_user_id'] == 0) {
        this.ndcOtherDetails['route_user_id'] = this.user['user_id'];
      }
      if (this.ndcOtherDetails['reason_code'] == "" || this.ndcOtherDetails['reason_code'] == undefined) {
        this.ndcOtherDetails['reason_code'] = 0;
      }
      if (this.ndcOtherDetails['follow_up_date'] == undefined) { this.ndcOtherDetails['follow_up_date'] = ""; }
      if (this.ndcOtherDetails['reason_attribute_name'] == undefined) { this.ndcOtherDetails['reason_attribute_name'] = ""; }
      if (this.ndcOtherDetails['price_spec_id'] == undefined) { this.ndcOtherDetails['price_spec_id'] = 0; }
      if (this.ndcOtherDetails['pi_link'] == undefined) { this.ndcOtherDetails['pi_link'] = ""; }
      if (this.ndcOtherDetails['price_spec_notes'] == undefined) { this.ndcOtherDetails['price_spec_notes'] = ""; }
      if (this.ndcOtherDetails['pi_status_date'] == undefined) { this.ndcOtherDetails['pi_status_date'] = ""; }
      if (this.ndcOtherDetails['reason_notes'] == undefined) { this.ndcOtherDetails['reason_notes'] = ""; }
      if (this.ndcOtherDetails['routing_notes'] == undefined) { this.ndcOtherDetails['routing_notes'] = ""; }

      var savedata = {
        "wt_id": this.ndcWtId,
        "pi_link": this.ndcOtherDetails['pi_link'],
        "pi_status_date": this.ndcOtherDetails['pi_status_date'],
        "price_spec_id": this.ndcOtherDetails['price_spec_id'],
        "price_spec_notes": this.ndcOtherDetails['price_spec_notes'],
        "follow_up_date": this.ndcOtherDetails['follow_up_date'],
        "loggedin_userid": this.user['user_id'],
        "wq_list": {
          "ndc": this.ndcNumber,
          "wt_id": this.ndcWtId,
          "user_id": this.ndcOtherDetails['route_user_id'],
          "wq_notes": this.ndcOtherDetails['reason_notes'],
          "reason_code": this.ndcOtherDetails['reason_code'],
          "queue_id": this.saveQueueId,
          //this.ndcOtherDetails['work_queue'],
          "reason_attribute_id": this.ndcOtherDetails['reason_attribute_name'],
          "routing_notes": this.ndcOtherDetails['routing_notes'],
          "stage_id": 1,
          "workqueues": workqueues,
          "rule_failures": rule_failures
        }
      }
    }
    if (serviceType == "RequestPublish") {
      this.requestPublishServiceCall(savedata);
    }
    else if (serviceType == "Save") {
      this.saveServiceCall(savedata);
    } else {
      this.publish(savedata)
    }
    this.newNDC = false;
    this.setndcOtherDetails();
    this.router.navigate(['home']);
  }

  saveServiceCall(savedata) {
    this.ndcSvc.saveNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
      if (ndcData['Result'] != null || ndcData['Result'] == "Success") {
        toastr.success("NDC Resolution Page Data Saved Successfully");
      }
    });
  }

  requestPublishServiceCall(savedata) {
    this.ndcSvc.requestPublishNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
      if (ndcData['Result'] != null || ndcData['Result'] == "Success") {
        toastr.success("NDC Resolution Page Data Saved and Requested for Publish Successfully")
      }
    });
  }

  publish(savedata) {
    this.ndcSvc.publishNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
      if (ndcData['Result'] != null || ndcData['Result'] == "Success") {
        toastr.success("NDC Resolution Page Data Saved and Published Successfully")
      }
    });
  }

  savePublish() {

    if (this.ndcOtherDetails['req_to_publish_note'] == '') {
      toastr.error("Request to publish Note cannot be empty");
    } else {
      this.save("RequestPublish");
      this.modalRequestPublish.hide();
      this.ndcOtherDetails['req_to_publish_note'] == '';
    }
  }

  actualPublish() {
    if (this.ndcOtherDetails['publish_note'] == '') {
      toastr.error("publish Note cannot be empty");
    } else {
      this.modalPublish.hide();
      //this.save('publish');
      this.ndcOtherDetails['publish_note'] == '';
      //================changes made on 12-Oct-2017
      var errorList = [];
      var props = Object.getOwnPropertyNames(this.gridhead);
      props.forEach(prop => {
        if (this.ndcSDDLAttributes[0][prop] == "") {
          errorList.push(this.gridhead[prop] + '<br/>');
        }
      });
      if (errorList.length > 0) {
        errorList.splice(0, 0, 'Following are the error(s):<br/>')
        toastr.error(errorList.toString().replace(",", ""));
        return;
      }

      this.getChangedAttr(this.ndcSDDLAttributesBackup, this.ndcSDDLAttributes[0]);

      var that = this;
      var workqueues = [];
      

      for (var prop in this.ndcChangedAttr) {

        var attr = that.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase() == prop && obj['attribute_name'].toLowerCase() != this.attrubutStatus['attribute_name']);

        if (attr.length > 0) {
          workqueues.push({
            workqueue_id: 0,
            wq_queue_id: 1,
            attribute_id: attr[0]['attribute_id'],
            attribute_name: attr[0]['attribute_name'],
            attribute_value: this.ndcChangedAttr[prop]
          });
        }
      }
      this.ndcDiscrepancyAttributes.forEach(existing => {

        attr = that.attributeNameDropDown.filter(obj => obj['attribute_name'].toLowerCase() == existing['attribute_name'] && obj['attribute_name'].toLowerCase() != this.attrubutStatus['attribute_name'] );
        if (attr.length > 0) {
          workqueues.push({
            workqueue_id: existing['workqueue_id'],
            wq_queue_id: existing['queue_id'],
            attribute_id: attr[0]['attribute_id'],
            attribute_name: attr[0]['attribute_name'],
            attribute_value: existing['attribute_value']
          });
        }
      });

      var rule_failures = [];
      this.ndcRuleFailure.forEach(existing => {
        var attr = that.attributeNameDropDown.filter(obj => obj['attribute_name'] == existing['attribute_name']);
        if (attr.length > 0 && existing['attribute_status'] != null) {
          rule_failures.push(existing);
        }
      });

      if (this.ndcOtherDetails['route_user_id'] == 0) {
        this.ndcOtherDetails['route_user_id'] = this.user['user_id'];
      }
      if (this.ndcOtherDetails['reason_code'] == "" || this.ndcOtherDetails['reason_code'] == undefined) {
        this.ndcOtherDetails['reason_code'] = 0;
      }
      if (this.ndcOtherDetails['follow_up_date'] == undefined) { this.ndcOtherDetails['follow_up_date'] = ""; }
      if (this.ndcOtherDetails['reason_attribute_name'] == undefined) { this.ndcOtherDetails['reason_attribute_name'] = ""; }
      if (this.ndcOtherDetails['price_spec_id'] == undefined) { this.ndcOtherDetails['price_spec_id'] = 0; }
      if (this.ndcOtherDetails['pi_link'] == undefined) { this.ndcOtherDetails['pi_link'] = ""; }
      if (this.ndcOtherDetails['price_spec_notes'] == undefined) { this.ndcOtherDetails['price_spec_notes'] = ""; }
      if (this.ndcOtherDetails['pi_status_date'] == undefined) { this.ndcOtherDetails['pi_status_date'] = ""; }
      if (this.ndcOtherDetails['reason_notes'] == undefined) { this.ndcOtherDetails['reason_notes'] = ""; }
      if (this.ndcOtherDetails['routing_notes'] == undefined) { this.ndcOtherDetails['routing_notes'] = ""; }

      var savedata = {
        "wt_id": this.ndcWtId,
        "pi_link": this.ndcOtherDetails['pi_link'],
        "pi_status_date": this.ndcOtherDetails['pi_status_date'],
        "price_spec_id": this.ndcOtherDetails['price_spec_id'],
        "price_spec_notes": this.ndcOtherDetails['price_spec_notes'],
        "follow_up_date": this.ndcOtherDetails['follow_up_date'],
        "loggedin_userid": this.user['user_id'],
        "wq_list": {
          "ndc": this.ndcNumber,
          "wt_id": this.ndcWtId,
          "user_id": this.ndcOtherDetails['route_user_id'],
          "wq_notes": this.ndcOtherDetails['reason_notes'],
          "reason_code": this.ndcOtherDetails['reason_code'],
          "queue_id": this.saveQueueId,
          //this.ndcOtherDetails['work_queue'],
          "reason_attribute_id": this.ndcOtherDetails['reason_attribute_name'],
          "routing_notes": this.ndcOtherDetails['routing_notes'],
          "stage_id": 1,
          "workqueues": workqueues,
          "rule_failures": rule_failures
        }
      }
      this.ndcSvc.publishNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
        if (ndcData['Result'] != null || ndcData['Result'] == "Success") {
          toastr.success("NDC Resolution Page Data Saved and Published Successfully")
        }
      });

      this.router.navigate(['home']);

      //=================End changes================

    }
  }

  cancel() {
    var userId = localStorage.getItem('userId');
    userId = this.userId ? this.userId : userId;
    this.ndc_hcpc_id = this.ndc_hcpc_id ? this.ndc_hcpc_id : this.ndcNumber;
    if (this.ndc_hcpc_id && this.queueId && userId) {
      let objData = { "ndc_hcpc_id": this.ndc_hcpc_id, "queue_id": this.queueId, "user_id": userId };
      this.ndcSvc.releaseWorkQueueNdc(objData).subscribe((res: any) => {
        var result = res.Result;
        this.router.navigate(['home']);
      })
    } else {
      this.router.navigate(['home']);
    }
  }

  selectedtributeChangeOption(value: string) {
    //console.log(attributeChangeOption[value]);
  }

  getChangedAttr(newObj, oldObj): Object {
    this.ndcChangedAttr = {};
    // Create arrays of property names
    var newProps = Object.getOwnPropertyNames(newObj);
    var oldProps = Object.getOwnPropertyNames(oldObj);
    delete newObj[""];
    delete oldObj[""];
    delete oldObj["package_quantity_status"];

    //If number of properties are different
    // if (newProps.length != oldProps.length) {
    //   return this.ndcChangedAttr;
    // }

    for (var i = 0; i < newProps.length; i++) {
      var propName = newProps[i];
      // Those property values are not equal
      if (newObj[propName] !== oldObj[propName]) {
        this.ndcChangedAttr[propName] = oldObj[propName];
      }
    }

    var Props = Object.getOwnPropertyNames(this.ndcChangedAttr);
    for (var loop = Props.length - 1; loop >= 0; loop--) {
      var statusProp = Props[loop] + 'Status';
      if (this.ndcChangedAttr[statusProp] != undefined) {
        delete this.ndcChangedAttr[Props[loop]];
        delete this.ndcChangedAttr[statusProp];
      }
    }

    return this.ndcChangedAttr;
  }

  InitStatus() {
    this.attrubutStatus = {
      awp_status: 0,
      br_generic_indicator_status: 0,
      brand_name_status: 0,
      dosage_form_status: 0,
      generic_name_status: 0,
      inner_outer_package_indicator_status: 0,
      manufacturer_name_status: 0,
      ndc_status_date_status: 0,
      ndc_status_status: 0,
      package_description_status: 0,
      package_quantit_status: 0,
      package_size_status: 0,
      package_size_uom_status: 0,
      package_unit_dose_status: 0,
      repackager_ind_status: 0,
      route_of_administration_status: 0,
      rx_otc_ind_status: 0,
      sd_md_status: 0,
      strength_status: 0,
      tee_code_status: 0,
      wac_status: 0
    };
  }
  sortByDescending(arrObj: any) {
    arrObj.sort(function (val1, val2) {
      if (val1.Id > val2.Id) {
        return -1;
      } else if (val1.Id < val2.Id) {
        return 1;
      } else {
        return 0;
      }
    });
  }

  releaseWorkQueueNdc() {
    var userId = localStorage.getItem('userId');
    userId = this.userId ? this.userId : userId;
    this.ndc_hcpc_id = this.ndc_hcpc_id ? this.ndc_hcpc_id : this.ndcNumber;
    if (this.ndc_hcpc_id && this.queueId && userId) {

      let objData = { "ndc_hcpc_id": this.ndc_hcpc_id, "queue_id": this.queueId, "user_id": userId };
      this.ndcSvc.releaseWorkQueueNdc(objData).subscribe((res: any) => {
        debugger
        var result = res.Result;

      })
    }

  }
  getNdcAndLock(code: string, wtId: any,ndcStatus: string) {

    this.lockWorkQueueByUser(code, wtId);
    this.ndcStatus=ndcStatus;
  }
  lockWorkQueueByUser(code: string, wtId: any) {

    this.selectedCode = code;
    this.ndc_hcpc_id = code;
    this.queueId = 1;
    var userId = JSON.parse(localStorage.getItem('currentUser'));
    userId = userId['user_id'];

    let objData = { "ndc_hcpc_id": code, "queue_id": 1, "user_id": userId };
    this.dataSvc.lockWorkQueueNdc(objData).subscribe((res: any) => {
      var result = res.Result;
      if (result == "Already locked by user") {
        this.modalLockExist.show();
      }
      else {
        this.getNDCByCode(code)
        this.modalNDCList.hide();
      }
    })
  }
  ngOnDestroy() {

    this.releaseWorkQueueNdc();
  }
  viewNdcFailure() {
    this.router.navigate(['/ndcfailureReadOnly', this.selectedCode]);
  }

  clearControls() {

    this.ndcOtherDetails = [];
    this.ndcOtherDetails = {};
    this.ndcOtherDetails['price_spec_id'] = 0;
    this.ndcOtherDetails['work_queue'] = 0;
    this.ndcOtherDetails['work_queue_type'] = 0;
    this.ndcOtherDetails['route_user_id'] = 0;

  }
}

