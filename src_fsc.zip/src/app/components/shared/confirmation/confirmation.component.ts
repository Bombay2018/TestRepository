import { Component, OnInit } from '@angular/core';
import { ConfirmationService } from '../../../services/shared/confirmation.service'

const KEY_ESC = 27;

@Component({
    moduleId: module.id,
    selector: 'confirm-dialog',
    templateUrl: '../confirmation/confirmation.html',
    styleUrls: ['../confirmation/confirmation.css']
})

export class ConfirmationComponent implements OnInit {
    title:string;
    message:string;
    okText:string;
    cancelText:string;

    private _confirmElement:any;
    private _cancelButton:any;
    private _okButton:any;

    private _defaults = {
        title: 'Confirmation',
        message: 'Do you want to cancel your changes?',
        cancelText: 'Cancel',
        okText: 'OK'
    };

    constructor(confirmService: ConfirmationService) {
        confirmService.activate = this.activate.bind(this);
    }

    ngOnInit():any {
        this._confirmElement = document.getElementById('confirmationModal');
        this._cancelButton = document.getElementById('cancelButton');
        this._okButton = document.getElementById('okButton')
    }

    _setLabels(message = this._defaults.message, title = this._defaults.title) {
        this.title = title;
        this.message = message;
        this.okText = this._defaults.okText;
        this.cancelText = this._defaults.cancelText;
    }

    activate(message = this._defaults.message, title = this._defaults.title) {
        this._setLabels(message, title);

        let promise = new Promise<boolean>(resolve => {
            this._show(resolve);
        });
        return promise;
    }

    private _show(resolve:(boolean) => any) {
        debugger;
        document.onkeyup = null;

        let negativeOnClick = (e:any) => resolve(false);
        let positiveOnClick = (e:any) => resolve(true);

        if (!this._confirmElement || !this._cancelButton || !this._okButton) return;

        this._confirmElement.style.opacity = 0;
        this._confirmElement.style.zIndex = 9999;

        this._cancelButton.onclick = ((e:any) => {
            e.preventDefault();
            if (!negativeOnClick(e)) this._hideDialog();
        })

        this._okButton.onclick = ((e:any) => {
            e.preventDefault();
            if (!positiveOnClick(e)) this._hideDialog()
        });

        this._confirmElement.onclick = () => {
            this._hideDialog();
            return negativeOnClick(null);
        };

        document.onkeyup = (e:any) => {
            if (e.which == KEY_ESC) {
                this._hideDialog();
                return negativeOnClick(null);
            }
        };

        this._confirmElement.style.opacity = 1;
    }

    private _hideDialog() {
        document.onkeyup = null;
        this._confirmElement.style.opacity = 0;
        window.setTimeout(() => this._confirmElement.style.zIndex = -1, 400);
    }

}