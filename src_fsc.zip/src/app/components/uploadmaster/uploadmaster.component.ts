import { Component, OnInit ,AfterViewInit} from '@angular/core';
import { FileUploader } from 'ng2-file-upload';

import { IUSER_MASTER,IFILE_UPLOAD_MASTER } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";
import { DataService } from '../../services/data.service';
import { ConfigService } from '../../services/shared/config.service';
import { UploadFileService } from '../../services/uploadFile.service';

declare var $: any;

@Component({
  selector: 'app-uploadmaster',
  moduleId: module.id,
  templateUrl: './uploadmaster.component.html',
  providers: [ DataService,UploadFileService]
})
export class UploadMasterComponent implements OnInit {

  user: IUSER_MASTER; 
  uploadFileDetails:IFILE_UPLOAD_MASTER;  
  uploadFileMaster :Object={} as Object;
  uploader:FileUploader = new FileUploader({url: 'https://evening-anchorage-3159.herokuapp.com/api/'});
  
    constructor(private _globalSev: GlobalService,private dataSvc: DataService,
      private uploadFileService: UploadFileService<IFILE_UPLOAD_MASTER>) {
      this.user = JSON.parse(localStorage.getItem('currentUser'));
      this._globalSev.showNavBar(true, this.user.user_name);
    } 

  ngOnInit() {
    this.uploadFileMaster['uploadFile']="";
    this.uploadFileMaster['effective_Date']="";
    this.uploadFileMaster['type']="0";
  }
  ngAfterViewInit() {
    $('#effectiveDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {  
      this.uploadFileMaster['effective_Date'] = event.target.value;    
    });
  
  } 

  saveUploadMaster() {   
    
    if (this.uploadFileMaster['effective_Date']  == '' && this.uploadFileMaster['uploadFile']=='' &&  this.uploadFileMaster['type']=="0") {
      
      
      toastr.error("Please enter values ");
          
      return;
    }

    else{

    this.uploadFileService.uploadFileDetails(this.uploadFileMaster).subscribe((uploadfileRes: IFILE_UPLOAD_MASTER[]) => {
    //  this.infoCodeReturn = infoCode['Result'];
      if (uploadfileRes['Result'][0] == "success")
        toastr.success("File detail uploaded successfully");
      else {
        toastr.error("Error while saving File details");        
      }
      this.uploadFileMaster=[];    
      this.uploadFileMaster['type']="0";
    });
  }
  }

  cancelUpload() {  
    this.uploadFileMaster=[];    
    this.uploadFileMaster['type']="0";
    }
}
