export interface IRepository {
    baseurl: string;
    action: string;
}