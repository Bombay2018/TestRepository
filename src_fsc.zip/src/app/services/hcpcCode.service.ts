//getHTTPHeader
import { Injectable } from '@angular/core';
import { Http, Response, Headers,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IHCPC_CODE_LIST,IHCPCINFO_GET_CODE,IINFO_CODE } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class HcpcCodeService<T>{
    private _baseUrl: string = '';
    private _headers: any;
    public hcpcCode: IHCPC_CODE_LIST;

    constructor(private http: Http,
         private configSvc: ConfigService, 
         private repository: Repository<IHCPC_CODE_LIST> ) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    // getInfoCodeMaster(ndcCode: string): Observable<IINFO_CODE[]> {
    //          return this.http.get("app/shared/mockdata/mockINFOSearchResult.json")
    //                      .map(resp => resp.json() as IINFO_CODE[])
    //                      .catch(this.handleError);
    // }

    getInfoCodeMaster(ndcCode: string): Observable<IINFO_CODE[]> {
        return this.http.get("app/shared/mockdata/mockINFOSearchResult.json")
                    .map(resp => resp.json() as IINFO_CODE[])
                    .catch(this.handleError);
    }

    // gethcpcCode(): Observable<any> {
    //     return this.http.get("app/shared/mockdata/mockhcpcCodeSearchResult.json")
    //                     .map(resp => resp.json())
    //                     .catch(this.handleError);
    // }

    getDistinctHCPCCode(hcpc_code: string): Observable<IHCPC_CODE_LIST[]> {
        return this.http
        .get(this._baseUrl+ 'retrieveDistinctHCPCCode?hcpc_code='+hcpc_code)
        .map((res: Response) => {        
            return <IHCPC_CODE_LIST[]>res.json()       
    });
    }

    // getInfoCodeByHCPCCode(): Observable<any> {
    //     return this.http.get("app/shared/mockdata/mockhcpcCodeSearchResult.json")
    //                     .map(resp => resp.json())
    //                     .catch(this.handleError);
    // }

    getInfoCodeByHCPCCode(hcpc_code: string): Observable<IHCPCINFO_GET_CODE[]> {
        return this.http
        .get(this._baseUrl+ 'HcpcInfoCodeMappingHcpcSearch?hcpc_code='+hcpc_code)
        .map((res: Response) => {        
            return <IHCPCINFO_GET_CODE[]>res.json()       
    });
    }

     savehcpcInfoCodeDataList(savehcpcInfoCode: any) {
        let body = savehcpcInfoCode;
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'HcpcInfoCodeMappingSave', body, options)
            .map(resp => resp.json());
    
    }  
    
    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}