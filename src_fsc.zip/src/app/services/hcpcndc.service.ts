import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IHCPC_SUPER_SIX_COMBINATION, INDC_ATTRIBUTES, IADMIN_CODE, IHCPC_PRICING, IHCPC_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class HCPCNDCService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public hcpcSuperSix: IHCPC_SUPER_SIX_COMBINATION;

    constructor(
        private http: Http,
        private configSvc: ConfigService) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getHCPCByCode(hcpcCode: string) {
        return this.http
            .get(this._baseUrl + "retrieveDistinctHCPCCode?hcpc_code=" + hcpcCode)
            .map(resp => resp.json().Result);
    }

    getHCPCByDescription(hcpcDescription: string) {
        debugger;
        return this.http
            .get(this._baseUrl + "retrieveDistinctHCPCCodeDescription?hcpc_desc=" + hcpcDescription)
            .map(resp => resp.json().Result);
    }

    getHCPCDetails(searchingData) {
        //hcpc_code:string, hcpc_desc:string, ndc:string
        debugger;
        return this.http
            .get(this._baseUrl + "retrieveHCPCDetails?hcpc_code=" + searchingData.hcpc_code + "&hcpc_desc=" + searchingData.hcpc_desc + "&ndc=" + searchingData.ndc)
            .map(resp => resp.json() as IHCPC_MASTER[]);
    }

    getHCPCSuperSix(hcpcCode): Observable<IHCPC_SUPER_SIX_COMBINATION> {
        this._baseUrl = 'http://192.168.133.105:79/services/'
        return this.http
            .get(this._baseUrl + 'HcpcAttributeDetails?hcpc_code=' + hcpcCode)
            .map(resp => resp.json() as IHCPC_SUPER_SIX_COMBINATION);
    }

    getHcpcPrice(hcpcCode): Observable<IHCPC_PRICING[]> {
        // return this.http
        //     .get("app/shared/mockdata/mockHCPC_PriceData.json")
        //     .map(resp => resp.json() as IHCPC_PRICING[]);
        this._baseUrl = 'http://192.168.133.105:79/services/'
        return this.http
            .get(this._baseUrl + 'retrieveHCPCNDCPricingDetails?hcpc_code=' + hcpcCode)
            .map(resp => resp.json() as IHCPC_PRICING[]);
    }

    // async getPrice(currency: string): Promise<number> {
    //     const response = await this.http.get(this.currentPriceUrl).toPromise();
    //     return response.json().bpi[currency].rate;
    //   }

    getHCPCRuleFailure() {
        return this.http
            .get("app/shared/mockdata/mockHCPC_SuperSixData.json")
            .map(resp => resp.json().Rule_Failure);
    }

    getHcpcNdc(): Observable<INDC_ATTRIBUTES> {
        return this.http
            .get("app/shared/mockdata/mockHCPC_NdcData.json")
            .map(resp => resp.json() as INDC_ATTRIBUTES);
    }

    getHCPCSearchData(): Observable<IHCPC_MASTER[]> {
        return this.http
            .get("app/shared/mockdata/mockHCPC_SearchResult.json")
            .map(resp => resp.json() as IHCPC_MASTER[]);
    }

    getHCPCAdminCodes(): Observable<IADMIN_CODE> {
        return this.http
            .get("app/shared/mockdata/mockadmincodes.json")
            .map(resp => resp.json() as IADMIN_CODE);
    }
}