//getHTTPHeader
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IREIMB_CODE } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class ReimbMasterService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public reimbCode: IREIMB_CODE;

    constructor(private http: Http,
        private configSvc: ConfigService,
        private repository: Repository<IREIMB_CODE>) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getDistinctCodeWithDesc(hcpc_code: string, hcpc_desc: string) {
        debugger;
        let body = {
            "hcpc_code": hcpc_code,
            "hcpc_desc": hcpc_desc
        };
        let options = new RequestOptions({ headers: this._headers });
        
        return this.http
            .post(this._baseUrl + 'DistinctHcpcCodeAndHcpcDesc', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    getReimbCode(hcpc_code,hcpc_desc){
        let body = {
            "hcpc_code": hcpc_code,
            "hcpc_desc": hcpc_desc
        };
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'HcpcDetailsByHcpcCodeAndHcpcDesc', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
    }

    getReimbCodeChange(hcpc_code,hcpc_desc){
        let body = {
            "hcpc_code": hcpc_code,
            "hcpc_desc": hcpc_desc
        };
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'HcpcCodeChangeDetails', body, options)
            .map((res: Response) => {
                return res.json().Result;
            });
        // return this.http.get("app/shared/mockdata/mockReimbSearchResult.json")
        //     .map(resp => resp.json() as IREIMB_CODE[])
    }

    getReimbCodeNotes(hcpc_code: string) {
        //this._baseUrl="192.168.133.81:79/services/";
        debugger;
        return this.http
            .get(this._baseUrl + "ReimbCodeMasterNote?hcpc_code=" + hcpc_code)
            .map(resp => resp.json().Result);
    }

    getDistinctHcpcCode(reimbCode: string) {
        //this._baseUrl="192.168.133.81:79/services/";
        debugger;
        return this.http
            .get(this._baseUrl + "DistinctHcpcCode?hcpc_code=" + reimbCode)
            .map(resp => resp.json());
    }

    getDistinctHcpcDesc(reimbDesc: string) {
        return this.http
            .get(this._baseUrl + "DistinctHcpcDesc?hcpc_desc=" + reimbDesc)
            .map(resp => resp.json());
    }

    SaveReimbCode(json:Object) {
        let body = json;
        let options = new RequestOptions({ headers: this._headers });
        return this.http
            .post(this._baseUrl + 'SaveReimbMasterDetails', body, options)
            .map(resp => resp.json());
    }
}