import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IUSER_MASTER, IINFO_CODE, IHCPC_CODE_LIST, IHCPCINFO_SAVE_CODE, IHCPCINFO_GET_CODE } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";
import { ModalComponent } from '../shared/modalpopup.component';
import { InfoCodeService } from '../../services/infocode.service';
import { HcpcCodeService } from '../../services/hcpcCode.service';

@Component({
  selector: 'app-hcpcinfocodecrosswalk',
  templateUrl: './hcpcinfocodecrosswalk.component.html',
  providers: [InfoCodeService, HcpcCodeService]
})
export class HcpcInfoCodeCrosswalkComponent implements OnInit {

  user: IUSER_MASTER;
  infoHCPCCodeData: IHCPC_CODE_LIST[];
  hcpcInfoCodeDataList: IHCPCINFO_GET_CODE[]
  infoCodeDataList: IINFO_CODE[];
  infoCodeFilterData: IINFO_CODE[]=[] as IINFO_CODE[];
  hcpcInfoCodeSaveData : IHCPCINFO_GET_CODE[]=[] as IHCPCINFO_GET_CODE[];
  infoCodeSearchText: string = "";
  hcpcCodeSearchText: string = "";
  selected_hcpc_code: string = "";
  selected_rc_id: number = 0;
  selected_hcpc_description: string = ""; 
  isAssocitedInfoCode:boolean=false;

  @ViewChild('modalHCPCCodeList') modalHCPCCodeList: ModalComponent;

  constructor(
    private route: ActivatedRoute,private _globalSev: GlobalService, private infoCodeService: InfoCodeService<IINFO_CODE>,
    private hcpcCodeService: HcpcCodeService<IHCPC_CODE_LIST>) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
    if(this.route.snapshot.params['reimCode']!=null){
      this.hcpcCodeSearchText = this.route.snapshot.params['reimCode'];      
    }
  }

  ngOnInit() {
      
    // alert(this.hcpcCodeSearchText);
  }

  showInfoCodedata() {

    this.infoCodeService.getInfoCode(this.infoCodeSearchText.trim()).subscribe((infoCode: IINFO_CODE[]) => {
      this.infoCodeDataList = infoCode;
      if (this.infoCodeDataList.length == 0) {
        toastr.warning("No record found for info code" + " " + this.infoCodeSearchText);
        this.infoCodeSearchText = "";
        return;
      }
      else {
        var index;
        this.infoCodeFilterData = this.infoCodeDataList;
        // only show those info code which are not present at right side
        var result = this.infoCodeFilterData.filter(item => this.hcpcInfoCodeDataList.some(infocode => infocode.info_code.trim() == item.info_code.trim()));
        var count=this.infoCodeFilterData.length;;
        for (var i = 0; i < count; i++) {
          index = this.infoCodeFilterData.indexOf(result[i]);
          if (index > -1) {
            this.infoCodeFilterData.splice(index, 1);
            this.isAssocitedInfoCode=true;
          }
        }   
        
        if(this.infoCodeFilterData!=null && this.infoCodeFilterData.length==0)
        toastr.error("Infocode searched for" + this.infoCodeSearchText + "  already associted with   " + this.selected_hcpc_code + "    .Please search new Info code");
        
      }
    });
   
  }

  showHCPCInfoCodedata() {
    this.hcpcCodeService.getDistinctHCPCCode(this.hcpcCodeSearchText.trim()).subscribe((hcpcCodeData: IHCPC_CODE_LIST[]) => {
      this.infoHCPCCodeData = hcpcCodeData["Result"];

      if (this.infoHCPCCodeData != null && this.infoHCPCCodeData.length > 0)
      {
        this.selected_hcpc_code = hcpcCodeData["Result"][0].hcpc_code;
        this.selected_hcpc_description = hcpcCodeData["Result"][0].hcpc_desc;
        this.selected_rc_id=hcpcCodeData["Result"][0].rc_id;
      }

      if (this.infoHCPCCodeData != null && this.infoHCPCCodeData.length > 1) {
        this.modalHCPCCodeList.show();
      }
      else if (this.infoHCPCCodeData != null) {
        this.hcpcCodeService.getInfoCodeByHCPCCode(this.hcpcCodeSearchText.trim()).subscribe((res: any) => {
          this.hcpcInfoCodeDataList = res['Result'];          
          if(this.hcpcInfoCodeDataList.length==0){
          toastr.info("No associated info code found found for HCPC code " + this.hcpcCodeSearchText);
          }
        });
      }
      else
      toastr.error("No record found found for HCPC code " + this.hcpcCodeSearchText);
    });
  }

  getInfoCodeByHCPCCode(hcpc: IHCPC_CODE_LIST): any {
    this.hcpcCodeService.getInfoCodeByHCPCCode(hcpc.hcpc_code).subscribe((hcpcInfoCode: IHCPCINFO_GET_CODE[]) => {
      this.hcpcInfoCodeDataList = hcpcInfoCode["Result"];
      this.selected_hcpc_code = hcpc.hcpc_code;
      this.selected_hcpc_description = hcpc.hcpc_desc;
      this.selected_rc_id=hcpc.rc_id;
      if(this.hcpcInfoCodeDataList.length==0){
      toastr.info("No associated info code found found for HCPC code " + this.hcpcCodeSearchText);
      }

    });
    this.modalHCPCCodeList.hide();
  }

  // getInfoByCode(code: string): any {
  //   this.infoCodeFilterData = this.infoCodeDataList.filter(obj => obj.info_code == code);
  // }

  InfoCodesearch() {
   
    if (this.infoCodeSearchText.trim() == '') {
      toastr.error("Please enter valid Info Code");
      return;
    } else {
      this.showInfoCodedata();
    }
   }

  HcpcCodesearch() {
   
    if (this.hcpcCodeSearchText.trim() == '') {
      toastr.error("Please enter valid HCPC Code");
      return;
    }
    else {
      this.showHCPCInfoCodedata();
    }
  }
  RemoveInfoCode() {
    var index;   
    var isItemSelected: boolean = false;
    var hcpcInfoCodeRemoveFromLeft = [];

    if (this.hcpcInfoCodeDataList == null) {
      toastr.error("Please select atleast 1 info code to remove");
      return;
    }

    for (let i = 0; i < this.hcpcInfoCodeDataList.length; i++) {
      if (this.hcpcInfoCodeDataList[i]['is_selected'] == true) {       
        var infoCodeMovedDataLtoR = {
          info_code_id: 0,
          info_code: "",
          note_description: "",
          is_selected: false
        };
        var hcpcInfoCodeMovedDataLtoR = {
          hcpc_info_code_map_id: 0,
          hcpc_code: "",
          hcpc_desc: "",
          info_code_id: 0,
          info_code: "",
          is_selected: false,
          rc_id: 0,
          status: 1
        };
        infoCodeMovedDataLtoR.info_code=this.hcpcInfoCodeDataList[i].info_code;
        infoCodeMovedDataLtoR.info_code_id=this.hcpcInfoCodeDataList[i].info_code_id;      
        

        var result1 = this.hcpcInfoCodeSaveData.filter(item => item.info_code ==this.hcpcInfoCodeDataList[i].info_code);
        if(result!=null && result1.length>0){
          var count=this.hcpcInfoCodeSaveData.length;
          for (var m = 0; i < count; i++) {      
            index = this.hcpcInfoCodeSaveData.indexOf(result1[m]);
            if (index > -1) {
              this.hcpcInfoCodeSaveData.splice(index, 1);
            }
          }
        }   
        else {
          hcpcInfoCodeMovedDataLtoR.hcpc_info_code_map_id = this.hcpcInfoCodeDataList[i].hcpc_info_code_map_id;
          hcpcInfoCodeMovedDataLtoR.rc_id = this.selected_rc_id;
          hcpcInfoCodeMovedDataLtoR.info_code_id = this.hcpcInfoCodeDataList[i].info_code_id;
          hcpcInfoCodeMovedDataLtoR.info_code = this.hcpcInfoCodeDataList[i].info_code;
          hcpcInfoCodeMovedDataLtoR.status = -1;
          
        } 
        //Add info code to right list     
        this.infoCodeFilterData.push(infoCodeMovedDataLtoR);
        //Add deleted item to list
        this.hcpcInfoCodeSaveData.push(hcpcInfoCodeMovedDataLtoR);
        //Remove item from left list
        hcpcInfoCodeRemoveFromLeft.push(this.hcpcInfoCodeDataList[i]);         

        isItemSelected = true;
      }      

    }
    if (!isItemSelected) {
      toastr.error("Please select atleast 1 info code to remove");
      return;
    }        

    var result = this.hcpcInfoCodeDataList.filter(item => hcpcInfoCodeRemoveFromLeft.some(hcpcCode => hcpcCode.info_code.trim() == item.info_code.trim()));
    var count=this.hcpcInfoCodeDataList.length;
    for (var i = 0; i < count; i++) {      
      index = this.hcpcInfoCodeDataList.indexOf(result[i]);
      if (index > -1) {
        this.hcpcInfoCodeDataList.splice(index, 1);
      }
    }    

  }

  AddInforCode() {
    var index;
    
    var isItemSelected: boolean = false;
    var infoCodeMovedDataRtoL = [];
    if (this.infoCodeFilterData == null) {
      toastr.error("Please select atleast 1 info code to add");
      return;
    }

    for (let i = 0; i < this.infoCodeFilterData.length; i++) {
      if (this.infoCodeFilterData[i]['is_selected'] == true) {
        infoCodeMovedDataRtoL.push(this.infoCodeFilterData[i]);
        var hcpcInfoCodeMovedDataRtoL = {
          hcpc_info_code_map_id: 0,
          hcpc_code: "",
          hcpc_desc: "",
          info_code_id: 0,
          info_code: "",
          is_selected: false,
          rc_id: 0,
          status: 1
        };
        //obj => obj.info_code == code);
        //hcpcInfoCodeMovedDataRtoL.info_code = this.infoCodeFilterData[i].info_code;
        var result1 = this.hcpcInfoCodeSaveData.filter(item => item.info_code ==this.infoCodeFilterData[i].info_code);
        if (result1 !=null && result1.length > 0) {
          for (var j = 0; j < this.hcpcInfoCodeSaveData.length; j++) {
            index = this.hcpcInfoCodeSaveData.indexOf(result1[j]);
            if (index > -1) {
              this.hcpcInfoCodeSaveData.splice(index, 1);
              result1[j].is_selected=false;
              this.hcpcInfoCodeDataList.push(result1[j]);
            }
          }
          
        }
        else {
          
          hcpcInfoCodeMovedDataRtoL.rc_id = this.selected_rc_id;
          hcpcInfoCodeMovedDataRtoL.info_code_id = this.infoCodeFilterData[i].info_code_id;
          hcpcInfoCodeMovedDataRtoL.info_code = this.infoCodeFilterData[i].info_code;
          hcpcInfoCodeMovedDataRtoL.status = 0;
          this.hcpcInfoCodeDataList.push(hcpcInfoCodeMovedDataRtoL);
        }
        
        this.hcpcInfoCodeSaveData.push(hcpcInfoCodeMovedDataRtoL);
       
        isItemSelected = true;
      }
    }
    if (!isItemSelected) {
      toastr.error("Please select atleast 1 info code to add");
      return;
    }

    var result = this.infoCodeFilterData.filter(item => infoCodeMovedDataRtoL.some(hcpcCode => hcpcCode.info_code.trim() == item.info_code.trim()));
    var count=this.infoCodeFilterData.length;
    for (var i = 0; i < count; i++) {
      index = this.infoCodeFilterData.indexOf(result[i]);
      if (index > -1) {
        this.infoCodeFilterData.splice(index, 1);
      }
    }
    
  }

  Save() { 

    var hcpcInfoCode = [];
    var objHcpcInfoCode={
      info_code_id:0,
      hcpc_info_code_map_id:0,
      status:-2
    }
    this.hcpcInfoCodeSaveData.forEach(function (obj) {
      var objHcpcInfoCode={
        info_code_id:0,
        hcpc_info_code_map_id:0,
        status:-2
      }
      objHcpcInfoCode.hcpc_info_code_map_id=obj.hcpc_info_code_map_id;
      objHcpcInfoCode.info_code_id=obj.info_code_id;
      objHcpcInfoCode.status=obj.status;
      hcpcInfoCode.push(objHcpcInfoCode);

    });
    var savedata = {
      "rc_id": this.selected_rc_id,
      "info_code_list": hcpcInfoCode
    }
   
    if (savedata != null) {
      if(hcpcInfoCode.length==0){
      toastr.info("There is no new infor code is associted with HCPC code  " + this.selected_hcpc_code + "Please add/delete info code.");
      return;
      }
      this.hcpcCodeService.savehcpcInfoCodeDataList(savedata).subscribe((res: JSON) => {
          if (res['Result'].toLowerCase() == 'success') {             
              toastr.success("New info code associed with hcpc successfully");
              this.hcpcInfoCodeSaveData=[];
              hcpcInfoCode=[];
              this.infoCodeDataList=[];
              savedata=null;
              this.cancel();
          } else {
              toastr.error("failed to save due to /n internal sever error");             
          }
      });
    }    
  }

  cancel() {
    this.hcpcCodeSearchText = "";
    this.infoCodeSearchText = "";
    this.selected_hcpc_code = "";
    this.selected_hcpc_description = "";
    this.infoCodeFilterData = [];
    this.hcpcInfoCodeDataList = [];
    this.hcpcInfoCodeSaveData=[];
    this.isAssocitedInfoCode=false;
    
  }

}
