import { Component, OnInit, ViewChild } from '@angular/core';

import { IUSER_MASTER, INARRATIVE_MASTER, INARRATIVE_SAVE_MASTER } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";
import { NarrativeService } from '../../services/narrative.service';
import { ModalComponent } from '../shared/modalpopup.component';
import { DropDown } from '../../shared/common';

@Component({
  selector: 'app-narrativemaster',
  templateUrl: './narrativemaster.component.html',
  providers: [NarrativeService]
})
export class NarrativeMasterComponent implements OnInit {

  user: IUSER_MASTER;
  narrativeType: DropDown[];
  searchResultList: INARRATIVE_MASTER[];
  searchResultDetails: INARRATIVE_MASTER = {} as INARRATIVE_MASTER;
  narrativeData: INARRATIVE_SAVE_MASTER = {} as INARRATIVE_SAVE_MASTER;
  narrativeMasterDetails = {
    narrativesNameSearch: "",
    narrativesTypeSearch: ""
  };
  isSearch: boolean = false;

  @ViewChild('modalNarrativeList') modalNarrativeList: ModalComponent;

  constructor(private narrativeService: NarrativeService<INARRATIVE_MASTER>, private _globalSev: GlobalService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {

    this.LoadNarrativeType();

  }

  LoadNarrativeType() {
    this.narrativeService.getDistinctNarrativesType().subscribe((res: any) => {
      this.narrativeType = res['Result'];
      this.narrativeMasterDetails.narrativesTypeSearch = "0";
      this.searchResultDetails.narratives_type="0";
      this.searchResultDetails.bvsd_status="0";
      //this.columnSelected = this.sortDropDown[0].id;

    });

  }
  search() {
    this.isSearch = true;
    if (this.narrativeMasterDetails.narrativesNameSearch.trim() == '' || this.narrativeMasterDetails.narrativesTypeSearch.trim() == "0") {
      toastr.error("Please enter Valid NarrativeName and NarrativeTpe");
      return;
    } else if (this.narrativeMasterDetails.narrativesNameSearch.trim() != '' && this.narrativeMasterDetails.narrativesTypeSearch.trim() != "0") {
      
      this.narrativeService.getDistinctNarrativesNameAndType(this.narrativeMasterDetails.narrativesNameSearch.trim(),this.narrativeMasterDetails.narrativesTypeSearch.trim()).subscribe((res: any) => {
        this.searchResultList = res['Result'];
        if(this.searchResultList!=null && this.searchResultList.length>1){
            this.modalNarrativeList.show();
        } 
        else {
          this.narrativeService.getNarrativesMasterDetails(this.narrativeMasterDetails.narrativesNameSearch.trim(), this.narrativeMasterDetails.narrativesTypeSearch.trim()).subscribe((res: any) => {
            this.searchResultDetails = res['Result'][0];
    
          });
        }     

      });
    }    

  }
  addnewNarrative() {
    this.isSearch = false;
    if(this.narrativeMasterDetails.narrativesNameSearch.length==0)
    toastr.error("Please enter atleast Narrative Name");

    this.narrativeService.getNarrativesMasterDetails(this.narrativeMasterDetails.narrativesNameSearch.trim(), this.narrativeMasterDetails.narrativesTypeSearch.trim()).subscribe((res: any) => {
      
        //check existing then disallow insert 
      if (res['Result'].length>0 && res['Result'][0].part_bvsd_id >0)
      toastr.error("Narrative details already exists.Try with new Narratvie Name and Narrative Type");
      else{
        this.searchResultDetails.narratives_name=this.narrativeMasterDetails.narrativesNameSearch;
        this.searchResultDetails.narratives_type="0";
        this.searchResultDetails.bvsd_status="0";     
        this.searchResultDetails.b_reason="";
        this.searchResultDetails.d_reason="";
        this.narrativeMasterDetails.narrativesTypeSearch = "0";
      }      
    });
  }
  getNarrativeList(narativeDetails: INARRATIVE_MASTER) {
    this.narrativeService.getNarrativesMasterDetails(narativeDetails.narratives_name, narativeDetails.narratives_type).subscribe((res: any) => {
      this.searchResultDetails = res['Result'][0];
      this.modalNarrativeList.hide();
    });
  }
  saveNarrativeDetails() {
    
    if (this.isSearch == false) {
      this.narrativeData.partBvsdId = 0;      
    }
    else  {
      this.narrativeData.partBvsdId = this.searchResultDetails.part_bvsd_id;
    }     
      this.narrativeData.narrativeType = this.searchResultDetails.narratives_type;
      this.narrativeData.narrativeName = this.searchResultDetails.narratives_name;
      this.narrativeData.bvsdStatus = this.searchResultDetails.bvsd_status;
      this.narrativeData.bReason = this.searchResultDetails.b_reason;
      this.narrativeData.dReason = this.searchResultDetails.d_reason;
    
    this.narrativeService.saveNarrativesMasterDetails(this.narrativeData).subscribe((narrativeResponse: INARRATIVE_MASTER) => {
      if (narrativeResponse['Result'] == "success")
        toastr.success("Narrative Details saved successfully");
      else {
        toastr.error("Error while saving Info Code");

      }
    });
  }

  cancelNarrative() {
    this.narrativeMasterDetails.narrativesTypeSearch = "0";
    this.narrativeMasterDetails.narrativesNameSearch="";
    this.searchResultDetails.narratives_type="0";
    this.searchResultDetails.bvsd_status="0";
    this.searchResultDetails.narratives_name="";
    this.searchResultDetails.b_reason="";
    this.searchResultDetails.d_reason="";
    }
}