import { Component, OnInit,AfterViewInit,ViewChild } from '@angular/core';
import {GlobalService} from "./../../services/shared/global.service";
import { NDCPartBvsDService } from '../../services/NDCPartBvsD.service';
import { IBD_SPEC } from '../../shared/interfaces/entities.interface';
import { IUSER_MASTER,IPART_BVSD_SUPER_SIX_MAP,INDC_ATTRIBUTES } from '../../shared/interfaces/entities.interface';
import { ModalComponent } from '../shared/modalpopup.component';
import { DataService } from '../../services/data.service';
import { DropDown } from '../../shared/common';
import { ConfigService } from '../../services/shared/config.service';
declare var $: any;
@Component({
  selector: 'app-ndcbdcrosswalk',
  templateUrl: './ndcbdcrosswalk.component.html',
  providers: [NDCPartBvsDService,DataService]
})
export class NdcBdCrosswalkComponent implements OnInit,AfterViewInit {
  user: IUSER_MASTER;
  mockNarativeTypeData: IBD_SPEC[];
  bvsdNDCDeatilsDataList:IPART_BVSD_SUPER_SIX_MAP[];
  masterbvsdDataList:IPART_BVSD_SUPER_SIX_MAP[];
  bvsdDataListFilter:IPART_BVSD_SUPER_SIX_MAP[];
  bvsdDataListEditable:IPART_BVSD_SUPER_SIX_MAP[];
  addSuperSix: IPART_BVSD_SUPER_SIX_MAP = {} as IPART_BVSD_SUPER_SIX_MAP;
  bvsDdataInstance:IPART_BVSD_SUPER_SIX_MAP;
  narrativesNameSearch: string="";
  genericNameSearch:string="";
  ndcSearch:string="";
  brandNameSearch:string="";
  bvsdStatusSearch:string="";
  isAddRow:boolean = false;
  isEditRow :boolean= false; 
  bvsdName: any;
  ROAName: any;
  DFName:any;
  RXOTCName:any;
  IsShowNDCDetails:boolean = false;
  direction: number;
  isDesc: boolean = false;
  column: string = 'narratives_name';
  columnSelected: any;
  contexMenu;
  statusProp: string = '';
  sortDropDown: DropDown[];
  partBvsDData:IPART_BVSD_SUPER_SIX_MAP[];
  bvsDDropdown:DropDown[];
  dosageFormDropdown:DropDown[];
  ROADropdown:DropDown[];
  rxOTCDropdown:DropDown[];
  bvsDStatusDropdown:DropDown[];
  NDC:string;
  brand_name:string;
  generic_name:string;
  strength:string;
  dosage_form:string;
  route_of_administration:string;
  searchSuperSix={
    narrativesNameSearch:"",
    genericNameSearch:"",
    ndcSearch:"",
    brandNameSearch:"",
    bvsdStatusSearch:""
  }; 

  

  @ViewChild('modalBvsDNameList') modalBvsDNameList: ModalComponent;
  @ViewChild('modalGenericNameList') modalGenericNameList: ModalComponent;
  @ViewChild('modalBrandNameList') modalBrandNameList: ModalComponent;
  @ViewChild('modalNDCCodeList') modalNDCCodeList: ModalComponent;

  constructor(private _globalSev: GlobalService,
    private NDCPartBvsDsvc: NDCPartBvsDService<IBD_SPEC>,private datasvc: DataService,private configsvc: ConfigService,)
    {
      this.user = JSON.parse(localStorage.getItem('currentUser'));
      this._globalSev.showNavBar(true, this.user.user_name);
    }

  ngOnInit() {

    // this.NDCPartBvsDsvc.getNarativeTypeData().subscribe((res: IBD_SPEC[]) => {
    //   this.mockNarativeTypeData = res['Result'];            
    // })
//   this.showbvsdCodedata();
//   this.NDCPartBvsDsvc.getbvsdDataList("bvsDPartName").subscribe((bvsdSuperSix: IPART_BVSD_SUPER_SIX_MAP) => {
//     //console.log(bvsdSuperSix);
//      this.bvsdDataListFilter = bvsdSuperSix['bvsdDataList'];
//      this.masterbvsdDataList = bvsdSuperSix['bvsdDataList']; // user updated data to be stored
//      this.bvsdDataListEditable = bvsdSuperSix['bvsdDataList'];     
// });

    this.searchSuperSix.bvsdStatusSearch="Select";
    this.datasvc.getDropdownData().subscribe((res: any) => {

      //Populate Sort Drodown
      this.sortDropDown = res.bvsDSortDropdown;
      this.columnSelected = this.sortDropDown[0].id;

      //Populate Narative Drodown
      this.mockNarativeTypeData=res.narativeDropdown; 

      //Add new Row Drodown
      this.bvsDDropdown = res.bvsDDropdown;
      this.dosageFormDropdown = res.dosageFormDropdown;
      this.ROADropdown = res.ROADropdown;
      this.rxOTCDropdown = res.rxOTCDropdown;
      this.bvsDStatusDropdown=res.bvsDStatusDropdown;
  });

  this.contexMenu = this.configsvc.getcontexMenu();
  this.contexMenu.forEach(cm => cm.subject.subscribe(val => this.setStatus(val)));

  }

  ngAfterViewInit() {
    $('#followUpDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    });
  }


  contexMenuClick(prop,data) {
    this.statusProp = prop;
    this.bvsDdataInstance=data;
  }
  modelChange(data,status, event) {
    var prop = status.slice(0, -7);
    if (this.masterbvsdDataList[prop] != event) {
           data.generic_name_status = 1;
    } else {
           data.generic_name_status = this.masterbvsdDataList[status];
    }
  }

  setStatus(id) {
      var prop = this.statusProp.slice(0, -7);
    // var maxId: number = Math.max.apply(Math, this.bvsdDataListEditable.DataSource.RJ.map(function (o) { return o.Id; }))
    // var updatedData = Object.assign({}, this.bvsdDataListEditable.DataSource.RJ.find(obj => obj.Id == maxId));
    // if (updatedData[prop] === this.masterbvsdDataList[prop]) {
    //   toastr.error('Status not allowed to <br> change on old value');
    //   return;
    
    // switch case not required directly assin id
    switch (id) {
      // case 0: //Failure Resolved
      //  // this.bvsdDataListEditable..RJ[0][this.statusProp] = 0;
      //   break;
      // case 1: //Follow-Up
      //   //this.mockdataNDCFailure.DataSource.RJ[0][this.statusProp] = 1;
      //   break;
      // case 2: //Further Routing
      //   //this.mockdataNDCFailure.DataSource.RJ[0][this.statusProp] = 2;
      //   break;
      case 3: //override value
         this.bvsDdataInstance[this.statusProp] = 3;
        break;
      // case 4: //Change Review
      //   //this.bvsdDataListEditable..RJ[0][this.statusProp] = 4;
      //   break;
      default:
        toastr.info('Invalid selection');
        break;
    }

    //this.statusProp = '';
  }


  showbvsdCodedata() {
    this.NDCPartBvsDsvc.getpartBvsDData().subscribe((reimbCode: IPART_BVSD_SUPER_SIX_MAP[]) => {
      this.partBvsDData = reimbCode;
      //this.reimbCodeDataFilter = reimbCode;
      //console.log(this.reimbCodeData);
    });
  }

  clear() {
    this.generic_name = "";
    this.brand_name = "";
    this.strength = "";
    this.route_of_administration = "";
    this.dosage_form = "";   
    
}
  
  search() {
    
    
    if (this.searchSuperSix.narrativesNameSearch == '' && this.searchSuperSix.genericNameSearch.trim() == '' && this.searchSuperSix.ndcSearch.trim() == '' && this.searchSuperSix.brandNameSearch.trim() == '' && (this.searchSuperSix.bvsdStatusSearch=='Select' || this.searchSuperSix.bvsdStatusSearch.trim()=='' )) {
      
      this.bvsdDataListFilter = [];
      this.masterbvsdDataList = []; // user updated data to be stored
      this.bvsdDataListEditable = []; 
      toastr.error("Please enter BvsD Name or Generic Name or NDC or Brand Name or bvsD Status ");
          
      return;
    }
    else{
      this.showbvsdCodedata();
      this.NDCPartBvsDsvc.getbvsdDataList(this.searchSuperSix).subscribe((bvsdSuperSix: IPART_BVSD_SUPER_SIX_MAP) => {
        //console.log(bvsdSuperSix);
         this.bvsdDataListFilter = bvsdSuperSix['bvsdDataList'];
         this.masterbvsdDataList = bvsdSuperSix['bvsdDataList']; // user updated data to be stored
         this.bvsdDataListEditable = bvsdSuperSix['bvsdDataList'];     
    });
    }
    // } else if (this.narrativesNameSearch.trim() != '') {
    //    this.modalBvsDNameList.show();
    // }
    // else if (this.genericNameSearch.trim() != '') {
    //    this.modalGenericNameList.show();
    // }
    // else if (this.ndcSearch.trim() != '') {
    //    this.modalNDCCodeList.show();
    // }
    // else if (this.brandNameSearch.trim() != '') {
    //    this.modalBrandNameList.show();
    // }
  }

  sort() {
    
    this.column = this.columnSelected.toString();
    this.direction = this.isDesc == false ? 1 : -1;
}

  addRow() {   
    this.isAddRow = true;
    this.isEditRow = false;
}

showNDCDetails(data){
  this.NDCPartBvsDsvc.getbvsdNDCDataList("ndcNumber").subscribe((bvsdSuperSix: INDC_ATTRIBUTES) => {
    if(this.IsShowNDCDetails==false)
    {
     this.bvsdNDCDeatilsDataList = bvsdSuperSix['ndcDetails'];        
    }
    
    data.IsShowNDCDetails=!data.IsShowNDCDetails;

  });  
}
cancel() {
 
  this.isAddRow = false;
  //this.isEditRow = false;
 // this.showRowSelectedError = false;

}

filterbvdSuperSixData(): void {
  debugger;
  // this.ndcSuperSixData = this.masterNdcSuperSixData.filter(obj  =>  obj.super_six_name == this.activeTab);

  if (this.brand_name || this.generic_name || this.strength || this.dosage_form || this.route_of_administration) {
      this.bvsdDataListFilter = this.bvsdDataListFilter.filter(item =>
          ((this.brand_name) ? (item.brand_name.toLowerCase().indexOf(this.brand_name.toLowerCase()) > -1) : 1)
          &&
          ((this.generic_name) ? (item.generic_name.toLowerCase().indexOf(this.generic_name.toLowerCase()) > -1) : 1)
          &&
          ((this.strength) ? (item.strength.toLowerCase().indexOf(this.strength.toLowerCase()) > -1) : 1)
          &&
          ((this.dosage_form) ? (item.dosage_form.toLowerCase().indexOf(this.dosage_form.toLowerCase()) > -1) : 1)
          &&
          ((this.route_of_administration) ? (item.dosage_form.toLowerCase().indexOf(this.route_of_administration.toLowerCase()) > -1) : 1)
      );
  }
  else {
      this.bvsdDataListFilter = this.masterbvsdDataList;
  }
}
}
