import { Component, OnInit } from '@angular/core';

import { IUSER_MASTER, IDS_RJ_MAP } from '../../shared/interfaces/entities.interface';
import { DataService } from '../../services/data.service';
import { ConversionService } from '../../services/conversion.service';
import { DropDown } from '../../shared/common';
import { GlobalService } from "./../../services/shared/global.service";

declare var $: any;

@Component({
    selector: 'app-ndcconversionmapping',
    moduleId: module.id,
    templateUrl: './ndcconversionmapping.component.html',
    providers: [ConversionService, DataService]
})
export class NdcconversionmappingComponent implements OnInit {

    logInUser: IUSER_MASTER;
    dropDown: DropDown[];
    allDS: any;
    addRowCT: DropDown[];
    ndcSuperSixData: IDS_RJ_MAP[];
    ndcSuperSixDataFilter: IDS_RJ_MAP[];
    masterNdcSuperSixData: IDS_RJ_MAP[];

    
    superSix: any;
    isDesc: boolean = false;
    column: string = 'data_source_name';
    direction: number;
    columnSelected: any;
    data_source_name: string;
    ds_value: string;
    user: string;
    isAddRow: boolean = false;
    addSuperSix: IDS_RJ_MAP = {} as IDS_RJ_MAP;
    isEditRow: boolean = false;
    editIds: number[] = new Array();
    editRowId: number;
    showRowSelectedError: boolean = false;
    ct_filter: string;
    activeTab: string = '';
    attributeId: number = 2;

    constructor(private datasvc: DataService, private conversionSvc: ConversionService<IDS_RJ_MAP>, private _globalSev: GlobalService) {
        this.logInUser = JSON.parse(localStorage.getItem('currentUser'));
        this._globalSev.showNavBar(true, this.logInUser.user_name);
    }

    ngOnInit() {

        this.datasvc.getDataSource().subscribe((res: any) => {
            this.allDS = res['Result'];
        });
        //  this.datasvc.getAllAttribute().subscribe((res: any) => {
        //      debugger;
        //      this.superSix = res['Result'].filter(obj  =>  obj.attribute_id>1 && obj.attribute_id < 8);
        //      //this.superSix = res['Result'];
        //  });

        this.datasvc.getDropdownData().subscribe((res: any) => {
            this.dropDown = res.CTGridDropdown;
            this.addRowCT = res.ConversionTranslation;
            this.columnSelected = this.dropDown[0].id;
        })
        this.showNdcSuperSixData(2);
    }

    showNdcSuperSixData(attributeId: number) {
        this.data_source_name = "";
        this.ds_value = "";
        this.user = "";
        this.ct_filter = "";

        this.attributeId = attributeId;
        switch (attributeId) {
            case 3:
                this.activeTab = 'brand_name';
                break;
            case 4:
                this.activeTab = 'strength';
                break;
            case 5:
                this.activeTab = 'dosage_form';
                break;
            case 6:
                this.activeTab = 'rx_otc_ind';
                break;
            case 7:
                this.activeTab = 'route_of_administration';
                break;
            case 8:
                this.activeTab = 'br_generic_indicator';
                break;
            case 9:
                this.activeTab = 'therapeutic_class';
                break;
            case 10:
                this.activeTab = 'manufacturer_name';
                break;
            case 11:
                this.activeTab = 'package_description';
                break;
            case 12:
                this.activeTab = 'package_size';
                break;
            case 14:
                this.activeTab = 'package_unit_dose';
                break;
            case 16:
                this.activeTab = 'repackager_ind';
                break;
            case 17:
                this.activeTab = 'sd_md';
                break;
            case 18:
                this.activeTab = 'tee_code';
                break;
            case 19:
                this.activeTab = 'inner_outer_package_indicator';
                break;
            default:
                this.activeTab = 'generic_name';
        }
        this.conversionSvc.getConversionTranslation(this.activeTab).subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
            this.masterNdcSuperSixData = ndcSuperSix['Result'];
            this.ndcSuperSixData = ndcSuperSix['Result'];
            this.ndcSuperSixDataFilter = ndcSuperSix['Result']; // user updated data to be stored
        });

    }

    showcalender() {
        // $('#addDate').created_datepicker({
        //     format: 'mm/dd/yyyy',
        //     autoclose: true
        // }).on('change', (event: any) => {
        //     this.new_created_date = event.target.value;
        // });
    }
    sort() {
        //this.isDesc = !this.isDesc;
        this.column = this.columnSelected.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    filterCT($event, ctValue) {
        if ($event.target.checked) {
            this.ct_filter = ctValue;
        }
        this.filterNdcSuperSixData();
    }

    filterNdcSuperSixData(): void {
        // this.ndcSuperSixData = this.masterNdcSuperSixData.filter(obj  =>  obj.super_six_name == this.activeTab);

        if (this.data_source_name || this.ds_value || this.user || this.ct_filter) {
            this.ndcSuperSixDataFilter = this.ndcSuperSixData.filter(item =>
                ((this.data_source_name) ? (item.data_source_name.toLowerCase().indexOf(this.data_source_name.toLowerCase()) > -1) : 1)
                &&
                ((this.ds_value) ? (item.ds_value.toLowerCase().indexOf(this.ds_value.toLowerCase()) > -1) : 1)
                &&
                ((this.user) ? (item.modified_by.toLowerCase().indexOf(this.user.toLowerCase()) > -1) : 1)
                &&
                ((this.ct_filter) ? (item.map_type.toLowerCase().indexOf(this.ct_filter.toLowerCase()) > -1) : 1)
            );
        }
        else {
            this.ndcSuperSixDataFilter = this.masterNdcSuperSixData;
        }
    }

    clear() {
        this.data_source_name = "";
        this.ds_value = "";
        this.user = "";
        this.ct_filter = "";
        this.ndcSuperSixDataFilter = this.masterNdcSuperSixData;
    }

    checkAll(event) {
        if (event == true) {
            for (let data of this.ndcSuperSixDataFilter) {
                data.is_selected = true;
            }
        }
        else {
            for (let data of this.ndcSuperSixDataFilter) {
                data.is_selected = false;
            }
        }
    }

    addRow() {
        this.addSuperSix.data_source_id = undefined;
        this.addSuperSix.ds_value ="";
        this.addSuperSix.rj_value ="";
        this.addSuperSix.map_type ="";
        this.isAddRow = true;
        this.isEditRow = false;
    }

    deleteRow() {
        var convTranId = [];
        for (let i = 0; i < this.ndcSuperSixDataFilter.length; i++) {
            if (this.ndcSuperSixDataFilter[i]['is_selected'] == true) {
                convTranId.push(this.ndcSuperSixDataFilter[i].ds_rj_id);
            }
        }
        if (convTranId.length > 0) {
            this.conversionSvc.deleteConversionTranslation(convTranId).subscribe((res: JSON) => {
                debugger;
                if (res['Result'].toLowerCase() == 'success') {
                    this.showNdcSuperSixData(this.attributeId);
                } else {
                    toastr.error("failed to delete /n internal sever error");
                }
            });
        } else {
            toastr.error("You must select atleast 1 row to delete");
        }
    }

    edit(Id) {
        this.isAddRow = false;
        this.isEditRow = true;
        this.editRowId = Id;
        this.editIds.push(Id);
    }

    saveNdcSuperSixData() {
        debugger;
        var updatedSuperSix: IDS_RJ_MAP[] = [];
        this.editIds.forEach(element => {
            var modifiedSuperSixTC: IDS_RJ_MAP = {} as IDS_RJ_MAP;
            modifiedSuperSixTC = this.ndcSuperSixDataFilter.filter(obj => obj.ds_rj_id == element)[0];
            modifiedSuperSixTC.attribute_id = this.attributeId;
            modifiedSuperSixTC.modified_by = this.logInUser.user_name;
            delete modifiedSuperSixTC.data_source_name;
            delete modifiedSuperSixTC.modified_date;
            updatedSuperSix.push(modifiedSuperSixTC);
        });

        if (this.isAddRow == true) {
            if (this.addSuperSix.data_source_id && this.addSuperSix.ds_value && this.addSuperSix.rj_value && this.addSuperSix.map_type) {
                this.addSuperSix.ds_rj_id = 0;
                this.addSuperSix.attribute_id = this.attributeId;
                this.addSuperSix.modified_by = this.logInUser.user_name;

                updatedSuperSix.push(this.addSuperSix);
            }
            else if (this.addSuperSix.data_source_id && this.addSuperSix.ds_value && this.addSuperSix.map_type.toLowerCase() == 'c') {
                this.addSuperSix.ds_rj_id = 0;
                this.addSuperSix.attribute_id = this.attributeId;
                this.addSuperSix.modified_by = this.logInUser.user_name;

                updatedSuperSix.push(this.addSuperSix);
            }
            else{
                toastr.error("Please enter all the fields");
            }
        }

        var count = 0;
        if (updatedSuperSix.length > 0) {
            updatedSuperSix.forEach(superSix => {
                this.conversionSvc.saveConversionTranslation(superSix).subscribe((res: JSON) => {
                    count++;
                    if (res['Result'].toLowerCase() == 'success') {
                        if (count == updatedSuperSix.length) {
                            this.showNdcSuperSixData(this.attributeId);
                        }
                    } else {
                        toastr.error("failed to delete /n internal sever error");
                    }
                });
            });
        }

        this.isAddRow = false;
        this.isEditRow = false;
    }

    cancel() {
        this.showNdcSuperSixData(this.attributeId);
        this.isAddRow = false;
        this.isEditRow = false;
        this.showRowSelectedError = false;
    }
}


        // this.conversionSvc.getNdcSuperSixData().subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
        //     this.masterNdcSuperSixData = ndcSuperSix;
        //     this.ndcSuperSixData = ndcSuperSix;
        //     this.ndcSuperSixDataFilter = ndcSuperSix; // user updated data to be stored
        //     this.filterSuperSixTab('generic_name');

        // //     this.masterNdcSuperSixData = new Array();
        // //     ndcGenericName.forEach((obj) => {
        // //         this.masterNdcSuperSixData.push(Object.assign({}, obj));
        // //     })
        // });


        // filterSuperSixTab(superSixName: string) {

        //     this.data_source_name = "";
        //     this.ds_value = "";
        //     this.user = "";
        //     this.activeTab = superSixName;
        //     this.ndcSuperSixDataFilter = this.masterNdcSuperSixData.filter(obj  =>  obj.super_six_name == superSixName);
        // }