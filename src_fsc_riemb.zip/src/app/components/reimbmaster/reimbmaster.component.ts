import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';

import { GlobalService } from "./../../services/shared/global.service";
import { IUSER_MASTER, IREIMB_CODE } from '../../shared/interfaces/entities.interface';
import { ReimbMasterService } from '../../services/reimbmaster.service';
import { DataService } from '../../services/data.service';
import { DropDown } from '../../shared/common';
import { ModalComponent } from '../shared/modalpopup.component';

import { AutocompleteComponent } from '../shared/autocomplete.component';

declare var $: any;

@Component({
  selector: 'app-reimbmaster',
  templateUrl: './reimbmaster.component.html',
  providers: [ReimbMasterService, DataService]
})
export class ReimbMasterComponent implements OnInit, AfterViewInit {

  user: IUSER_MASTER;
  actionCodeDropDown: DropDown[];
  reimbCodeData: IREIMB_CODE[];
  NewReimbCode: any;
  reimbCodeChangesData: any;
  reimbCodeNoteData: any;
  reimbCodeDataFilter: IREIMB_CODE[];
  clearFieldReimbCodeDataFilter: IREIMB_CODE[];
  newReimbCodeData: IREIMB_CODE = {} as IREIMB_CODE;
  isSearch: boolean = false;
  reimbCodeSearch: string = "";
  reimbDescriptionSearch: string = "";
  ndcSearch: string = "";
  searchResult: any;
  isAddCodeChangeRow: boolean = false;
  isAddUserNotesRow: boolean = false;
  showTabs: boolean = true;
  reimbCodeSuggestions: string[] = new Array();
  reimbCodeSearchResult: any[] = new Array();
  reimCodeSelected: string;

  ndcSuggestions: string[] = new Array();
  ndcSearchResult: any[] = new Array();
  ndcSelected: string;
  disableSave:boolean=true;

  @ViewChild('modalReimbCodeList') modalReimbCodeList: ModalComponent;

  @ViewChild(AutocompleteComponent) ndcauto: AutocompleteComponent;

  constructor(private _globalSvc: GlobalService,
    private reimbMasterSvc: ReimbMasterService<IREIMB_CODE>,
    private dataSvc: DataService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSvc.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {
    this.ndcSuggestions = [];
    //this.showReimbCodedata();
    this.setNewReimbCode();
    this.showTabs = false;
    this.isAddCodeChangeRow = false;
    this.isAddUserNotesRow = false;
    
  }

  ngAfterViewInit() {
    $('#EffectiveDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
     
      if(this.showTabs)
      this.NewReimbCode['ori_code_eff_date'] = event.target.value;
      else
      this.reimbCodeData['ori_code_eff_date'] = event.target.value;
    });

    $('#TerminalDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      
      if(this.showTabs)
      this.NewReimbCode['term_date'] = event.target.value;
      else
      this.reimbCodeData['term_date'] = event.target.value;
    });

    $('#ActionDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.NewReimbCode['chg_eff_date'] = event.target.value;
    });
  }

  setNewReimbCode() {
    this.NewReimbCode = {
      "hcpc_code": "",
      "ori_code_eff_date": "",
      "term_date": "",
      "is_admin_code": "",
      "is_noc_code": "",
      "cms_desc": "",
      "rj_addl_desc": "",
      "action_cd": "",
      "chg_eff_date": "",
      "note_description": "",
      "created_by": "",
      "created_date": new Date()
    }
  }

  search() {
    this.isAddCodeChangeRow = false;
    this.isAddUserNotesRow = false;
    this.isSearch = true;
    this.showTabs = false;
    debugger;
    var hcpc_code = this.reimbCodeSearch.trim();
    var hcpc_desc = this.reimbDescriptionSearch.trim();

    this.ndcSearch = this.ndcSelected;
    if (this.reimbCodeSearch.trim() == '' && this.reimbDescriptionSearch.trim() == '') {
      toastr.error("Please enter Reimb Code or Description");
      return;
    }
    else {
      this.reimbMasterSvc.getDistinctCodeWithDesc(hcpc_code, hcpc_desc).subscribe((res: any) => {
        this.searchResult = res;
        if (this.searchResult.length > 0) {
          this.modalReimbCodeList.show();
          this.disableSave=false;
        }
        else {
          toastr.error("Record not found");
        }
      });
    }
  }

  getReimbByCode(hcpc_code, hcpc_desc): any {
    this.showTabs = false;
    debugger;
    this.reimbMasterSvc.getReimbCode(hcpc_code, hcpc_desc).subscribe((res: any) => {
      debugger;
      this.reimbCodeData = res;
    });

    this.reimbMasterSvc.getReimbCodeChange(hcpc_code, hcpc_desc).subscribe((res: any) => {
      this.reimbCodeChangesData = res;
    });

    this.reimbMasterSvc.getReimbCodeNotes(hcpc_code).subscribe((res: any) => {
      this.reimbCodeNoteData = res;
    });

    this.modalReimbCodeList.hide();
    this.ngAfterViewInit();
  }

  onSelectionChange(codeType, entry) {
    debugger;
    if (codeType == 'adminCode') {
      this.NewReimbCode.is_admin_code = entry;
    }
    else if (codeType == 'nocCode') {
      this.NewReimbCode.is_noc_code = entry;
    }
  }

  addNewReimbCode() {
    var newReimCode=this.reimbCodeSearch.trim();
    this.cancel();
    this.showTabs = true;      
    this.NewReimbCode['hcpc_code'] =newReimCode;
    //this.isAddUserNotesRow = true;
    //this.isAddCodeChangeRow=true;   
    this.disableSave=false;
      
  }

  addCodeChangeRow() {
    this.isAddCodeChangeRow = true;
    this.dataSvc.getDropdownData().subscribe((res: any) => {
      this.actionCodeDropDown = res.ActionCodeDropDown;
    })
  }

  addUserNotesRow() {
    this.isAddUserNotesRow = true;
  }

  save() {    

 if(this.showTabs){
  if((this.NewReimbCode['hcpc_code'] == undefined || this.NewReimbCode['hcpc_code'] =="") || ((this.NewReimbCode['ori_code_eff_date'] == undefined || this.NewReimbCode['ori_code_eff_date'] =="")) || ((this.NewReimbCode['term_date'] == undefined || this.NewReimbCode['term_date'] ==""))
  ||(this.NewReimbCode['is_admin_code'] == undefined || this.NewReimbCode['is_admin_code'] == "")||
  (this.NewReimbCode['is_noc_code'] == undefined || this.NewReimbCode['is_noc_code'] == "")){
    toastr.warning("Enter Reim Code ,Effective date , Termination date,Admin code and NOC code");
    return;
 } 
 }
 else{  
    if((this.reimbCodeData[0]['hcpc_code'] == undefined || this.reimbCodeData[0]['hcpc_code'] =="") || ((this.reimbCodeData[0]['ori_code_eff_date'] == undefined || this.reimbCodeData[0]['ori_code_eff_date'] =="")) || ((this.reimbCodeData[0]['term_date'] == undefined || this.reimbCodeData[0]['term_date'] ==""))){
      toastr.warning("Reim Code ,Effective date and Termination date cant be blank");
      return;
   }
 }


 
    if ((this.NewReimbCode['cms_desc'] == undefined || this.NewReimbCode['cms_desc'] == "") ||
        ((this.NewReimbCode['rj_addl_desc'] == undefined || this.NewReimbCode['rj_addl_desc'] == "")) ||
        ((this.NewReimbCode['action_cd'] == undefined || this.NewReimbCode['action_cd'] == "")) ||
        ((this.NewReimbCode['chg_eff_date'] == undefined || this.NewReimbCode['chg_eff_date'] == "")) //||
        // ((this.NewReimbCode['strength'] == undefined || this.NewReimbCode['strength'] == "")) ||
        // ((this.NewReimbCode['strength_uom'] == undefined || this.NewReimbCode['strength_uom'] == ""))
      ){

        toastr.warning("Please use Add Row option tp enter code changes related details");
        return;
 
}


 
  
   if(this.NewReimbCode['note_description'] == undefined || this.NewReimbCode['note_description'] ==""){
     toastr.warning("Please use Add Row option to Enter Notes in Notes table");
     return;
  
}
    
    for (var prop in this.NewReimbCode) {
      if (this.NewReimbCode[prop] == undefined) { this.NewReimbCode[prop] = "" }
    }

    var saveData = {
      "rc_id": this.showTabs == false ? this.reimbCodeData[0]['rc_id'] : 0,
      "hcpc_code": this.showTabs == false ? this.reimbCodeData[0]['hcpc_code'] : this.NewReimbCode['hcpc_code'],
      "ori_code_eff_date": this.showTabs == false ? this.reimbCodeData[0]['ori_code_eff_date'] : this.NewReimbCode['ori_code_eff_date'],
      "term_date": this.showTabs == false ? this.reimbCodeData[0]['term_date'] : this.NewReimbCode['term_date'],
      "is_admin_code": this.showTabs == false ? this.reimbCodeData[0]['is_admin_code'] : this.NewReimbCode['is_admin_code'],
      "is_noc_code": this.showTabs == false ? this.reimbCodeData[0]['is_noc_code'] : this.NewReimbCode['is_noc_code'],

      "code_change_details": [{
        "hcpc_desc_chg_id": 0,
        "rc_id": this.showTabs == false ? this.reimbCodeData[0]['rc_id'] : 0,
        "cms_desc": this.NewReimbCode['cms_desc'],
        "rj_addl_desc": this.NewReimbCode['rj_addl_desc'],
        "action_cd": this.NewReimbCode['action_cd'].substr(0, 5),
        "chg_eff_date": this.NewReimbCode['chg_eff_date']
      }],

      "notes": [{
        "hcpc_notes_id": 0,
        "note_description": this.NewReimbCode['note_description'],
        "created_by": this.user['user_name'],
        "created_date": new Date()
      }]
    }

    this.reimbMasterSvc.SaveReimbCode(saveData).subscribe((res: any) => {
      if (res['Result'] != null || res['Result'] == "Success") {
          this.NewReimbCode['cms_desc'] = "";
          this.NewReimbCode['rj_addl_desc'] ="";
          this.NewReimbCode['action_cd']="";
          this.NewReimbCode['chg_eff_date']="";
          this.NewReimbCode['note_description']="";
          toastr.success("Reimb Master Data saved successfully");
          if(this.showTabs)
          this.getReimbByCode(this.reimbCodeData[0]['hcpc_code'], "");
          else
          this.getReimbByCode(this.NewReimbCode['hcpc_code'], "");
          this.cancel();
      }
    });
    this.showTabs = false;
    
  }
  
  cancel() {
    
    this.isAddUserNotesRow = false;
    this.isAddCodeChangeRow = false;
    this.reimbCodeNoteData=[];
    this.reimbCodeChangesData=[];
    this.reimbCodeData=[];
    this.reimbDescriptionSearch="";
    this.reimbCodeSearch="";
    this.NewReimbCode=[];     
    this.disableSave=true;
  }

  reimCodeSearchKey(event) {
    console.log(this.reimbCodeSuggestions);
    if (event == "" || event.length < 3) {
      return;
    }
    var suggestion = []
    //this.reimbCodeSearchResult = [{ "rc_id": 1, "hcpc_code": "J900", "hcpc_status": "Active" }, { "rc_id": 2, "hcpc_code": "J901", "hcpc_status": null }, { "rc_id": 4, "hcpc_code": "J907", "hcpc_status": null }, { "rc_id": 60, "hcpc_code": "J9051", "hcpc_status": null }];

    this.reimbCodeSuggestions.forEach(function (obj) {
      // var isExit = obj.startsWith(event);
      var isExit = obj['hcpc_code'].startsWith(event);
      if (isExit == true) {
        suggestion.push(obj['hcpc_code']);
      }
    });

    this.reimbCodeSuggestions = suggestion;

    if (this.reimbCodeSuggestions.length == 0) { //call service
      this.reimbMasterSvc.getDistinctHcpcCode(event.trim()).subscribe((res: any) => {
        debugger;
        this.reimbCodeSearchResult = res['Result']
        if (this.reimbCodeSearchResult.length != 0) {
          suggestion = [];
          this.reimbCodeSearchResult.forEach(function (obj) {
            suggestion.push(obj.ndc);
          });
          debugger;
          this.reimbCodeSuggestions = suggestion;
        } else {
          toastr.info("Record Not Found");
          //return;
        }
      });
    }
    //alert('patent: '+ event);
  }

  ndcSearchKey(event) {
    console.log(this.ndcSuggestions);
    this.ndcSuggestions = this.ndcSuggestions.filter(function (el) {
      debugger;
      return el.toLowerCase().indexOf(event.toLowerCase()) > -1
    });
    if (this.ndcSuggestions.length == 0) { //call service
      this.dataSvc.getDistinctNDC(event.trim()).subscribe((res: any) => {
        debugger;
        this.ndcSearchResult = res['Result']
        if (this.ndcSearchResult.length != 0) {
          var suggestion = [];
          this.ndcSearchResult.forEach(function (obj) {
            suggestion.push(obj.ndc);
          });
          debugger;
          this.ndcSuggestions = suggestion;
        } else {
          toastr.info("Record Not Found");
          //return;
        }
      });
    }
    //alert('patent: '+ event);
  }
}
