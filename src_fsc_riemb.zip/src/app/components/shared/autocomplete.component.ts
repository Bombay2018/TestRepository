import {Component, ElementRef, EventEmitter, Output, Input } from '@angular/core';

@Component({
    selector: 'autocomplete',
    host: {
        '(document:click)': 'handleClick($event)',
    },
    template: `
        <div class="row">
            <div>
            <input type="text" class="form-control" [(ngModel)]=query (keyup)=IsSuggestionsAvailable()>
                <ul class="ui-autocomplete list-group" style="position: absolute;top: 30px;left: 6px;cursor: default;z-index: 1;width:100%">
                    <li class="list-group-item" *ngFor="let item of filteredList" >
                        <a (click)="select(item)">{{item}}</a>
                    </li>
                </ul>
            </div>
        </div>
        `
})

export class AutocompleteComponent {
    @Output() selectedValue : EventEmitter<any> = new EventEmitter();
    @Output() searchKey = new EventEmitter<any>();
    @Input() suggestions : string[] = new Array();
    public query = ''; //hold the string enter by the user
    public filteredList = [];  //to store the suggestions being displayed by the component, its value will constantly change as the user enter on the input
    
    public elementRef;
 
    constructor(myElement: ElementRef) {
        this.elementRef = myElement;
    }

    IsSuggestionsAvailable(){
        this.searchKey.emit(this.query);
        if(this.suggestions.length>0){
            this.filter();
        }
    }

    //the filter() function uses the query variable to filter the data, then it stores the result in the filteredList.
    filter() {
        if (this.query !== "" && this.suggestions!=undefined){
            this.filteredList = this.suggestions.filter(function(el){
                if(el!=undefined)
                return el.toLowerCase().indexOf(this.query.toLowerCase()) > -1;
            }.bind(this));
        }else{
            this.filteredList = [];
        }
        console.log(this.filteredList);
    }
    
    //assigning the selected item to the query variable in order to make it appear on the input, and to make the suggestions list disappear and removing everything from the filteredList.
    select(item){
        //(on_user_has_logged_in)="userNow = $event"
        this.selectedValue.emit(item);
        this.query = item;
        this.filteredList = [];
    }

    handleClick(event){
        var clickedComponent = event.target;
        var inside = false;
        do {
            if (clickedComponent === this.elementRef.nativeElement) {
                inside = true;
            }
           clickedComponent = clickedComponent.parentNode;
        } while (clickedComponent);
         if(!inside){
             this.filteredList = [];
         }
     }
}