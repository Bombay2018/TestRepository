import { Component } from '@angular/core';
import { ContextMenuService } from './../../services/shared/contextmenu.service';

@Component({
  selector: 'context-menu-holder',
  styles: [
    '.container{width:150px;background-color:#eee}',
    'a.disabled, a.disabled:visited {pointer-events: none; cursor: default; color: gray;'
  ],
  host: {
    '(document:click)': 'clickedOutside()',
  },
  template:
  `  <div [ngStyle]="mainMenuPosition" class="container" >
      <ul class="dropdown-menu link" style="display:block;">
         <li *ngFor="let link of links">
          <!--<input type="checkbox" (click)="link.subject.next(link.id)">{{link.title}}-->
          <a [class.disabled]="!link.enable" (click)="link.subject.next(link.id)">{{link.title}}
          </a>
        </li>
      </ul>
  </div>`
})
export class ContextMenuHolderComponent {

  links = [];
  isShown = false;
  private mouseLocation: { left: number, top: number } = { left: 0, top: 0 };

  constructor(private _contextMenuService: ContextMenuService) {
    _contextMenuService.show.subscribe(e => this.showMenu(e.event, e.obj));
  }

  get mainMenuPosition() {
    return {
      'position': 'fixed',
      'display': this.isShown ? 'block' : 'none',
      left: this.mouseLocation.left + 'px',
      top: this.mouseLocation.top + 'px',
    };
  }

  get subMenuPosition() {
    return {
      'position': 'fixed',
      'display': this.isShown ? 'block' : 'none',
      left: this.mouseLocation.left + 'px',
      top: this.mouseLocation.top + 'px',
    };
  }

  clickedOutside() {
    this.isShown = false
  }

  showMenu(event, links) {
    this.isShown = true;
    this.links = links;
    this.mouseLocation = {
      left: event.clientX,
      top: event.clientY
    }
  }
}