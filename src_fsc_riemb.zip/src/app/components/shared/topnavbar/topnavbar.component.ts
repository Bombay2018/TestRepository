import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { UserService } from '../../../services/user.service';
import { GlobalService } from '../../../services/shared/global.service';
import { IUSER_MASTER } from '../../../shared/interfaces/entities.interface';

@Component({
  selector: 'navbar',
  templateUrl: './topnavbar.component.html'
})
export class TopNavbarComponent implements OnInit {
  public showNavBar: boolean;
  username: string;
  constructor(private _userSev: UserService<IUSER_MASTER>, private _globalSev: GlobalService) {
    this._globalSev.setNavBar.subscribe((mode: boolean) => {
      this.showNavBar = mode;
    });
  }

  ngOnInit() {
    this._globalSev.currentUser.subscribe(name => this.username = name);
  }

}
