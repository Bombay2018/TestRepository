import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
//import {Observer} from 'rxjs/Observer';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { IUSER_MASTER } from './../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class DataService{

    _baseUrl: string = '';
    private _headers: any;

    constructor(private http: Http,
        private configsvc: ConfigService) {
        this._baseUrl = configsvc.getApiURI();
        this._headers = configsvc.getHTTPHeader();
    }

    //searchfor: HCPC=>1; NDC=>2
    globalSearch(code: string, searchfor: number) {
        let data = {
            "code": code,
            "searchfor": searchfor
        }

        return this.http
            .post(this._baseUrl + 'globalsearch', data, { headers: this._headers })
            .map((res: Response) => {
                return res.json();
            });
    }

    getMockData(): Observable<IUSER_MASTER[]> {
        return this.http.get("app/shared/mockdata/user.json")
        .map(resp => resp.json() as IUSER_MASTER[]);
    };

    getDropdownData(): Observable<any> {
        return this.http
        .get("app/shared/mockdata/mockDropdown.json")
        .map(resp => resp.json());
    };

    //Use this when service is ready
    // getDropdownData(): Observable<any> {
    //     return this.http
    //     .get(this._baseUrl+"workQueueName")
    //     .map(resp => resp.json());
    // };

    // getListNdc(ndcCode:string) {
    //     this.repository.getByCode('http://localhost:79/services/DistinctNdc?ndc=', ndcCode)
    //         .subscribe((ndc: INDC_ATTRIBUTES) => {
    //             user => this.ndc;
    //         });http://localhost:79/services/retrieveAllAttributeDetails
    // }
    getAllAttribute() {
        return this.http
        .get(this._baseUrl+"retrieveAllAttributeDetails")
        .map(resp => resp.json());
    }

    getDataSource() {
        return this.http
        .get(this._baseUrl+"retrieveAllDataSourceDetails")
        .map(resp => resp.json());
    }

    getDistinctNDC(ndc:string) {
        return this.http
        .get(this._baseUrl+"DistinctNdc?ndc="+ndc)
        .map(resp => resp.json());
    }
//http://localhost:79/services/retrieveAllAttributeDetails
    getWorkQueueName() {
        return this.http
        .get(this._baseUrl+"WorkQueueName")
        .map(resp => resp.json().Result);
    }

    getUserByQueueId(queueId:number) {
        return this.http
        .get(this._baseUrl+"retrieveAllUsers?queue_id="+queueId)
        .map(resp => resp.json().Result);
    }

    lockWorkQueueNdc(objData:any) {
        return this.http
            .post(this._baseUrl+ 'LockWorkQueueByUser',objData)
            .map(resp => resp.json());
    }
}

