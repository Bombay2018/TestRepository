import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { Subject } from 'rxjs/Rx';

@Injectable()
export class ConfigService {

    _apiURI: string;
    _header: any;

    constructor() {
        //For developers
        this._apiURI = 'http://54.205.212.130:9000/services/';
        //this._apiURI ='http://192.168.133.118:9000/services/';

        //For Dev Build (QA Database Pointing)
        //this._apiURI = 'http://54.205.212.130:9090/services/';

        //For UAT build (UAT Database Pointing)
        //this._apiURI = 'http://34.229.76.126:9091/services/';

        //For developers-Old
        // this._apiURI = 'http://192.168.133.92:79/services/';
    }

    getApiURI() {
        return this._apiURI;
    }

    getApiHost() {
        return this._apiURI.replace('api/', '');
    }

    getHTTPHeader() {
        this._header = new Headers({
           // 'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization',
            //'Access-Control-Allow-Origin': '*',
           // 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Content-Type': 'application/json'
        });

        return this._header;

    }

    getcontexMenu(){
      return [{ id: 3, title: 'Overrides Values', enable: false, subject: new Subject() },
        { id: 4, title: 'Change Review', enable: false, subject: new Subject()}]
       // { id: 5, title: 'Overrides Values/Change Review', enable: false, subject: new Subject()}]
    }
}