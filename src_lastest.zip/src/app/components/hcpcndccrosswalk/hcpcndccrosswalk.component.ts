import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { GlobalService } from "./../../services/shared/global.service";
import { HCPCNDCService } from "./../../services/hcpcndc.service";
import { DataService } from '../../services/data.service';
import { Repository } from '../../repository/implement/repository.service';
import { IUSER_MASTER, IHCPC_SUPER_SIX_COMBINATION, INDC_ATTRIBUTES, IADMIN_CODE, IHCPC_PRICING, IHCPC_MASTER } from '../../shared/interfaces/entities.interface';
import { DropDown } from '../../shared/common';
import { ModalComponent } from '../shared/modalpopup.component';

declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'app-hcpcndccrosswalk',
    templateUrl: './hcpcndccrosswalk.component.html',
    providers: [HCPCNDCService, DataService, Repository]
})
export class HcpcNdcCrosswalkComponent implements OnInit, AfterViewInit {
    user: IUSER_MASTER;
    calcPriceDropDown: DropDown[];
    sortDropDown: DropDown[];
    reasonNoteDropDown: DropDown[];
    workQueueTypeDropDown: DropDown[];
    workQueueDropDown: DropDown[];
    userDropDown: any;
    ruleFailureDropDown: any;
    hcpcSuperSixData: IHCPC_SUPER_SIX_COMBINATION[];
    hcpcSuperSixFilterData: IHCPC_SUPER_SIX_COMBINATION[];
    hcpcNdcData: INDC_ATTRIBUTES[];
    adminCodeData: IADMIN_CODE[];
    addAdminCode: IADMIN_CODE[] = {} as IADMIN_CODE[];
    hcpcPriceData: IHCPC_PRICING[];
    addHcpcSuperSix: IHCPC_SUPER_SIX_COMBINATION[] = {} as IHCPC_SUPER_SIX_COMBINATION[];
    hcpcSearchData: IHCPC_MASTER[];
    hcpcSearchFilterData: IHCPC_MASTER[];
    otherInfo: Object;
    newAdminCode: boolean = false;
    genericName: string;
    brandName: string;
    strength: string;
    roa: string;
    DoseForm: string;
    calcPrice: string;
    rxOtc: string;
    pendingTask: boolean;
    columnSelected: Object = {};
    column: string = 'generic_name';
    direction: number;
    isDesc: boolean;
    isAddRow: boolean = false;
    isSearch: boolean = false;
    isShowNDCDetails: boolean = false;
    hcpcRuleFailure: any[] = new Array();

    search = {
        hcpcSearch: '',
        hcpcDesc: '',
        ndcSearch: '',
    }


    @ViewChild('modalHCPCSearchList') modalHCPCSearchList: ModalComponent;

    constructor(
        private _globalSev: GlobalService,
        private hcpcndcService: HCPCNDCService<IADMIN_CODE>,
        private datasvc: DataService) {
        this.user = JSON.parse(localStorage.getItem('currentUser'));
        this._globalSev.showNavBar(true, this.user.user_name);
    }

    ngOnInit() {
        this.showHCPCSuperSixData();
        this.showRuleFailure();
        this.showAdminCodeData();
        this.showHcpcPrice();
        this.showHCPCSearchData();
        this.datasvc.getDropdownData().subscribe((res: any) => {
            this.calcPriceDropDown = res.CalcPriceDropDown;
            this.calcPrice = this.calcPriceDropDown[0].id;
            this.sortDropDown = res.HcpcNdcSortDropdown;
            this.columnSelected = this.sortDropDown[0].id;
            this.reasonNoteDropDown = res.HcpcNdcReasonCode;
            this.otherInfo['reason_notes'] = this.reasonNoteDropDown[0].id;
            this.ruleFailureDropDown = res.mockRuleFailureUpdate;
            this.otherInfo['rule_failure'] = this.ruleFailureDropDown[0].Id;
            this.workQueueTypeDropDown = res.mockWorkQueueType;
            this.userDropDown = res.mockUser;
        });

        this.datasvc.getWorkQueueName().subscribe((res: any) => {
            this.workQueueDropDown = res;
        });

        this.otherInfo = {
            reason_notes: "",
            attribute_status: "",
            follow_up_date: "",
            reason_code: "",
            work_queue: 0,
            work_queue_type: 0,
            route_user_id: 0,
            routing_notes: '',
            publish_note: '',
            reason_attribute_id: ''
        }
    }
    //attrubutStatus
    ngAfterViewInit() {
        $('.date').datepicker({
            format: 'mm/dd/yyyy',
            startDate: new Date(),
            autoclose: true
        }).on('change', (event: any) => {
            this.otherInfo['follow_up_date'] = event.target.value;
        });
    }

    showHCPCSearchData() {
        this.hcpcndcService.getHCPCSearchData().subscribe((searchData: IHCPC_MASTER[]) => {
            this.hcpcSearchData = searchData;
        });
    }
    showHCPCSuperSixData() {
        this.hcpcndcService.getHCPCSuperSix().subscribe((superSix: IHCPC_SUPER_SIX_COMBINATION) => {
            this.hcpcSuperSixData = superSix['Result'];
            this.hcpcSuperSixFilterData = superSix['Result'];
        });
    }

    showRuleFailure() {
        this.hcpcndcService.getHCPCRuleFailure().subscribe((ndcrulefailure) => {
            this.hcpcRuleFailure = ndcrulefailure;
        });
    }

    showHcpcNdcData(data) {
        debugger;
        this.hcpcndcService.getHcpcNdc().subscribe((ndc: INDC_ATTRIBUTES) => {
            if (this.isShowNDCDetails == false) {
                this.hcpcNdcData = ndc['Result'];
            }
            data.isShowNDCDetails = !data.isShowNDCDetails;
        });
    }

    showHcpcPrice() {
        this.hcpcndcService.getHcpcPrice().subscribe((price: IHCPC_PRICING[]) => {
            this.hcpcPriceData = price;
        });
    }

    showAdminCodeData() {
        this.hcpcndcService.getHCPCAdminCodes().subscribe((adminCode: IADMIN_CODE) => {
            this.adminCodeData = adminCode['Result'];
        });
    }

    searchHCPC() {
        this.isSearch = true;

        if (this.search['hcpcSearch'].trim() == '' && this.search['hcpcDesc'].trim() == '' && this.search['ndcSearch'].trim() == '') {
            toastr.error("Please enter HCPC Code or HCPC Description or NDC for search");
            return;
        } else {
            this.modalHCPCSearchList.show();
        }
    }

    getHCPCByCode(hcpc): any {
        if (this.search['hcpcSearch'] != undefined || this.search['hcpcDesc'] != '' || this.search['ndcSearch'] != '') {
            this.hcpcSearchFilterData = this.hcpcSearchData.filter(obj => (obj.hcpc == hcpc));
            this.modalHCPCSearchList.hide();
        }
    }

    addRow() {
        this.isAddRow = true;
    }

    sort(columnSelected) {
        this.column = this.columnSelected.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    filterPendingTask($event) {
        this.pendingTask = $event.target.checked;
        this.filterHCPCSuperSix();
    }

    filterRxOtc($event, rxotcValue) {
        if ($event.target.checked) {
            this.rxOtc = rxotcValue;
        }
        this.filterHCPCSuperSix();
    }

    filterHCPCSuperSix(): void {
        if (this.genericName || this.brandName || this.strength || this.roa || this.DoseForm || this.calcPrice || this.rxOtc || this.pendingTask) {
            this.hcpcSuperSixFilterData = this.hcpcSuperSixData.filter
                (item =>
                    ((this.genericName) ? (item.generic_name.toLowerCase().indexOf(this.genericName.toLowerCase()) > -1) : 1)
                    &&
                    ((this.brandName) ? (item.brand_name.toLowerCase().indexOf(this.brandName.toLowerCase()) > -1) : 1)
                    &&
                    ((this.strength) ? (item.strength.toLowerCase().indexOf(this.strength.toLowerCase()) > -1) : 1)
                    &&
                    ((this.roa) ? (item.route_of_administration.toLowerCase().indexOf(this.roa.toLowerCase()) > -1) : 1)
                    &&
                    ((this.DoseForm) ? (item.dosage_form.toLowerCase().indexOf(this.DoseForm.toLowerCase()) > -1) : 1)
                    &&
                    ((this.calcPrice) ? (item.calc_price.toLowerCase().indexOf(this.calcPrice.toLowerCase()) > -1) : 1)
                    &&
                    ((this.rxOtc) ? (item.rx_otc_ind.toLowerCase().indexOf(this.rxOtc.toLowerCase()) > -1) : 1)
                    &&
                    ((this.pendingTask) ? item.is_active == true : 1)
                );
        }
        else {
            this.hcpcSuperSixFilterData = this.hcpcSuperSixData;
        }
    }

    clear() {
        this.genericName = "";
        this.brandName = "";
        this.strength = "";
        this.roa = "";
        this.DoseForm = "";
        this.rxOtc = "";
        this.calcPrice = this.calcPriceDropDown[0].id;
        this.hcpcSuperSixFilterData = this.hcpcSuperSixData;
    }


    addAdminCodeRow() {
        this.newAdminCode = true;
    }

    deleteAdminCodeRow() {
        this.newAdminCode = false;
        var arrLenght = this.adminCodeData.length - 1;
        for (let i = arrLenght; i >= 0; i--) {
            if (this.adminCodeData[i]['is_selected'] == true) {
                var index = this.adminCodeData.indexOf(this.adminCodeData[i]);
                this.adminCodeData.splice(index, 1);
            }
        }
    }

    saveAdminCodeRow() {
        this.newAdminCode = false;
        var maxId = Math.max.apply(Math, this.adminCodeData.map(function (o) { return o.id; }));
        this.adminCodeData.push({
            id: maxId + 1,
            admin_code: this.addAdminCode['admin_code'],
            admin_code_description: this.addAdminCode['admin_code_description'],
            is_selected: false
        });
    }

    cancel() {
        this.isAddRow = false;
    }
}
