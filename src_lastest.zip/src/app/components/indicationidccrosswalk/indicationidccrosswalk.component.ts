import { Component, OnInit } from '@angular/core';

import { IUSER_MASTER } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";

@Component({
  selector: 'app-indicationidccrosswalk',
  templateUrl: './indicationidccrosswalk.component.html'
})
export class IndicationIdcCrosswalkComponent implements OnInit {

  user: IUSER_MASTER;

  constructor(private _globalSev: GlobalService) 
  {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }


  ngOnInit() {
  }

}
