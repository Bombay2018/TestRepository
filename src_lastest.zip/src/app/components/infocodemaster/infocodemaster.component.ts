import { Component, OnInit, ViewChild } from '@angular/core';

import { GlobalService } from "./../../services/shared/global.service";
import { InfoCodeService } from '../../services/infocode.service';
import { IUSER_MASTER, IINFO_CODE } from '../../shared/interfaces/entities.interface';
import { ModalComponent } from '../shared/modalpopup.component';

@Component({
  selector: 'app-infocodemaster',
  templateUrl: './infocodemaster.component.html',
  providers: [InfoCodeService]
})
export class InfoCodeMasterComponent implements OnInit {

  user: IUSER_MASTER;
  infoCodeData: IINFO_CODE[];
  infoCodeFilterData: IINFO_CODE[];
  infoCodeSearch: string = "";
  info_code: string = "";
  info_note: string = "";
  isSearch: boolean = false;

  @ViewChild('modalInfoCodeList') modalInfoCodeList: ModalComponent;

  constructor(private _globalSev: GlobalService, private infoCodeService: InfoCodeService<IINFO_CODE>) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {
    this.showInfoCodedata();
  }

  showInfoCodedata() {
    this.infoCodeService.getInfoCode().subscribe((infoCode: IINFO_CODE[]) => {
      this.infoCodeData = infoCode;
    });
  }

  search() {
    this.isSearch = true;
    if (this.infoCodeSearch.trim() == '') {
      toastr.error("Please enter Info Code");
      return;
    } else {
      this.modalInfoCodeList.show();
    }
  }

  addInfoCode() {
    this.isSearch = false;
    this.info_code = this.infoCodeSearch;
  }

  getInfoByCode(code: string): any {
    this.infoCodeFilterData = this.infoCodeData.filter(obj  =>  obj.info_code == code);
    this.modalInfoCodeList.hide();
  }

  saveInfoCode() {
    var maxId = Math.max.apply(Math, this.infoCodeData.map(function (o) { return o.id; }));
    if (this.info_code && this.info_note) {
      this.infoCodeData.push({
        id: maxId + 1,
        info_code: this.info_code,
        info_note: this.info_note
      });
      toastr.success("saved successfully");
    }
    else if (this.isSearch == false && (this.info_code == "" || this.info_note == "")) {
      toastr.warning("None of the field should be empty");
    }

    console.log(this.infoCodeData);
    this.info_code = "";
    this.info_note = "";
  }

  cancelInfoCode() {
    this.isSearch = false;
    this.infoCodeSearch = "";
  }
}

