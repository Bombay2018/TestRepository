/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import {GlobalService} from "./../../services/shared/global.service";
import {IUSER_MASTER} from './../../shared/interfaces/entities.interface';
import {UserService} from './../../services/user.service';

import { INDC_ATTRIBUTES_STATUS } from '../../shared/interfaces/entities.interface';


@Component({
  moduleId: module.id,
  selector: 'app-login',
  templateUrl: './login.component.html',
  providers:[UserService]
})


export class LoginComponent implements OnInit {

  public user:IUSER_MASTER = {user_name:'', password:''} as IUSER_MASTER;
  attrubutStatus: INDC_ATTRIBUTES_STATUS = {} as INDC_ATTRIBUTES_STATUS;

  constructor(
    private _routes:Router, 
    private _userSev:UserService<IUSER_MASTER>,
    private _globalSev:GlobalService) { 
      
  }

  ngOnInit() {  
    this._globalSev.showNavBar(false, '');
     this._userSev.logout();
  }

  doLogin(){  
      this._userSev.getUser(this.user).subscribe(
      resdata => this.isValidUser(resdata as IUSER_MASTER)
     );
  }

  isValidUser(user:IUSER_MASTER){
    debugger;
    this.user=user;
    if(this.user!= undefined && this.user.user_id != undefined){
      this._userSev.isAuthenicated=true;
      user.password='';
      this._globalSev.user=user;
      localStorage.setItem('currentUser', JSON.stringify(user));
      this._globalSev.showNavBar(true, user.user_name);
      this._routes.navigate(['/home']);
    }else{
      toastr.error("Invalid userId or password");
      localStorage.setItem('currentUser', '');
      this._routes.navigate(['/login']);
    }
  }

}
