import { Component, OnInit, ViewChild } from '@angular/core';

import { GlobalService } from "./../../services/shared/global.service";
import { NDCPartBvsDService } from '../../services/NDCPartBvsD.service';
import { IUSER_MASTER, IBD_SPEC, IPART_BVSD_SUPER_SIX_MAP } from '../../shared/interfaces/entities.interface';
import { ModalComponent } from '../shared/modalpopup.component';
import { DataService } from '../../services/data.service';
import { DropDown } from '../../shared/common';

@Component({
  selector: 'app-ndcbdcrosswalk',
  templateUrl: './ndcbdcrosswalk.component.html',
  providers: [NDCPartBvsDService, DataService]
})
export class NdcBdCrosswalkComponent implements OnInit {

  user: IUSER_MASTER;
  mockNarativeTypeData: IBD_SPEC[];
  bvsdNDCDeatilsDataList: IPART_BVSD_SUPER_SIX_MAP[];
  masterbvsdDataList: IPART_BVSD_SUPER_SIX_MAP[];
  bvsdDataListFilter: IPART_BVSD_SUPER_SIX_MAP[];
  addSuperSix: IPART_BVSD_SUPER_SIX_MAP = {} as IPART_BVSD_SUPER_SIX_MAP;
  narrativesNameSearch: string = "";
  genericNameSearch: string = "";
  ndcSearch: string = "";
  brandNameSearch: string = "";
  isAddRow: boolean = false;
  isEditRow: boolean = false;
  bvsdName: any;
  ROAName: any;
  DFName: any;
  RXOTCName: any;
  IsShowNDCDetails: boolean = false;
  direction: number;
  isDesc: boolean = false;
  column: string = 'narratives_name';
  columnSelected: any;

  sortDropDown: DropDown[];
  partBvsDData: IPART_BVSD_SUPER_SIX_MAP[];
  bvsDDropdown: DropDown[];
  dosageFormDropdown: DropDown[];
  ROADropdown: DropDown[];
  rxOTCDropdown: DropDown[];
  NDC: string;
  brand_name: string;
  generic_name: string;
  strength: string;
  dosage_form: string;
  route_of_administration: string;

  @ViewChild('modalBvsDNameList') modalBvsDNameList: ModalComponent;
  @ViewChild('modalGenericNameList') modalGenericNameList: ModalComponent;
  @ViewChild('modalBrandNameList') modalBrandNameList: ModalComponent;
  @ViewChild('modalNDCCodeList') modalNDCCodeList: ModalComponent;

  constructor(private _globalSev: GlobalService,
    private NDCPartBvsDsvc: NDCPartBvsDService<IBD_SPEC>, private datasvc: DataService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {

    // this.NDCPartBvsDsvc.getNarativeTypeData().subscribe((res: IBD_SPEC[]) => {
    //   this.mockNarativeTypeData = res['Result'];            
    // })
    this.showbvsdCodedata();
    this.NDCPartBvsDsvc.getbvsdDataList("bvsDPartName").subscribe((bvsdSuperSix: IPART_BVSD_SUPER_SIX_MAP) => {
      //console.log(bvsdSuperSix);
      this.bvsdDataListFilter = bvsdSuperSix['bvsdDataList'];
      this.masterbvsdDataList = bvsdSuperSix['bvsdDataList']; // user updated data to be stored
    });


    this.datasvc.getDropdownData().subscribe((res: any) => {

      //Populate Sort Drodown
      this.sortDropDown = res.bvsDSortDropdown;
      this.columnSelected = this.sortDropDown[0].id;

      //Populate Narative Drodown
      this.mockNarativeTypeData = res.narativeDropdown;

      //Add new Row Drodown
      this.bvsDDropdown = res.bvsDDropdown;
      this.dosageFormDropdown = res.dosageFormDropdown;
      this.ROADropdown = res.ROADropdown;
      this.rxOTCDropdown = res.rxOTCDropdown;
    })
  }


  showbvsdCodedata() {
    this.NDCPartBvsDsvc.getpartBvsDData().subscribe((reimbCode: IPART_BVSD_SUPER_SIX_MAP[]) => {
      this.partBvsDData = reimbCode;
      //this.reimbCodeDataFilter = reimbCode;
      //console.log(this.reimbCodeData);
    });
  }

  clear() {
    this.generic_name = "";
    this.brand_name = "";
    this.strength = "";
    this.route_of_administration = "";
    this.dosage_form = "";


  }

  search() {

    if (this.narrativesNameSearch.trim() == '' && this.genericNameSearch.trim() == '' && this.ndcSearch.trim() == '' && this.brandNameSearch.trim() == '') {
      toastr.error("Please enter BvsD Name or Generic Name or NDC or Brand Name ");
      return;
    } else if (this.narrativesNameSearch.trim() != '') {
      this.modalBvsDNameList.show();
    }
    else if (this.genericNameSearch.trim() != '') {
      this.modalGenericNameList.show();
    }
    else if (this.ndcSearch.trim() != '') {
      this.modalNDCCodeList.show();
    }
    else if (this.brandNameSearch.trim() != '') {
      this.modalBrandNameList.show();
    }
  }

  sort() {
    this.column = this.columnSelected.toString();
    this.direction = this.isDesc == false ? 1 : -1;
  }

  addRow() {
    this.isAddRow = true;
    this.isEditRow = false;
  }

  showNDCDetails(data) {
    this.NDCPartBvsDsvc.getbvsdDataList("ndcNumber").subscribe((bvsdSuperSix: IPART_BVSD_SUPER_SIX_MAP) => {
      if (this.IsShowNDCDetails == false) {
        this.bvsdNDCDeatilsDataList = bvsdSuperSix['ndcDetails'];
      }

      data.IsShowNDCDetails = !data.IsShowNDCDetails;

    });
  }
  cancel() {

    this.isAddRow = false;
    //this.isEditRow = false;
    // this.showRowSelectedError = false;

  }

  filterbvdSuperSixData(): void {
    debugger;
    // this.ndcSuperSixData = this.masterNdcSuperSixData.filter(obj  =>  obj.super_six_name == this.activeTab);

    if (this.brand_name || this.generic_name || this.strength || this.dosage_form || this.route_of_administration) {
      this.bvsdDataListFilter = this.bvsdDataListFilter.filter(item =>
        ((this.brand_name) ? (item.brand_name.toLowerCase().indexOf(this.brand_name.toLowerCase()) > -1) : 1)
        &&
        ((this.generic_name) ? (item.generic_name.toLowerCase().indexOf(this.generic_name.toLowerCase()) > -1) : 1)
        &&
        ((this.strength) ? (item.strength.toLowerCase().indexOf(this.strength.toLowerCase()) > -1) : 1)
        &&
        ((this.dosage_form) ? (item.dosage_form.toLowerCase().indexOf(this.dosage_form.toLowerCase()) > -1) : 1)
        &&
        ((this.route_of_administration) ? (item.dosage_form.toLowerCase().indexOf(this.route_of_administration.toLowerCase()) > -1) : 1)
      );
    }
    else {
      this.bvsdDataListFilter = this.masterbvsdDataList;
    }
  }
}
