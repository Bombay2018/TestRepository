/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, HostListener, Renderer } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs/Rx';

import { ConfigService } from '../../services/shared/config.service';
import { NDCFailureGridHead, NDCFailureMessage, WorkQueueType, DataSources } from '../../services/shared/config.const';
import { INDC_ATTRIBUTES, INDC_ATTRIBUTES_STATUS, INDC_PRICE_HISTORY, IUSER_MASTER, IDS_RJ_MAP, IWORKQUEUE_MAPPING } from '../../shared/interfaces/entities.interface';
import { GlobalService } from '../../services/shared/global.service';
import { DataService } from '../../services/data.service';
import { NDCService } from '../../services/ndc.service';
import { PriceHistoryService } from '../../services/pricehistory.service';
import { ConversionService } from '../../services/conversion.service';

import { DropDown } from '../../shared/common';

import { ModalComponent } from '../shared/modalpopup.component';
//import { OrderBy } from './../../pipes/orderby.pipe';

import { attributeChangeOption } from '../../services/shared/enum';

declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'app-ndcfailure-readOnly',
  templateUrl: './ndcFailureReadOnly.component.html',
  providers: [NDCService, DataService, PriceHistoryService, ConversionService]
})
export class NDCFailureReadOnlyComponent implements OnInit, AfterViewInit {

  user: IUSER_MASTER;
  mockRuleFailureUpdate: any;
  mockWorkQueue: DropDown[];
  reasonCodeDropDown: DropDown[];
  attributeNameDropDown: any;
  workQueueType: any;
  mockUser: any;

  viewMode: boolean = false;
  ndcSearchResult: any[] = new Array();
  ndcSearchCode: string = '';
  ndcNumber: string = '';
  ndcWtId: number = 0;
  //prescribinginformation: Object;
  ndcDSAttributes: any;
  ndcSDDLAttributesBackup: any;
  ndcSDDLAttributes: INDC_ATTRIBUTES;
  ndcDiscrepancyAttributes: any;
  ndcChangedAttr: Object;
  ndcOtherDetails: Object;
  ndcRuleFailure: any[] = new Array();
  attrubutStatus: INDC_ATTRIBUTES_STATUS = {} as INDC_ATTRIBUTES_STATUS;

  msView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  fdbView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  rjView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  gsView: INDC_ATTRIBUTES[] = [] as INDC_ATTRIBUTES[];
  msshow: boolean = true;
  fdbshow: boolean = true;
  rjshow: boolean = true;
  gsShow: boolean = true;

  conversionTranslate: any; //IDS_RJ_MAP = {} as IDS_RJ_MAP;
  selectedSuperSix: string = '';
  statusProp: string = '';

  newNDC: boolean = false;
  isNewNDC: boolean = false;
  priceHistoryshow: boolean = false;
  activePricing: string;
  ndcAWPWACHistoryBackup: INDC_PRICE_HISTORY[] = [] as INDC_PRICE_HISTORY[];
  ndcAWPWACHistory: INDC_PRICE_HISTORY[] = [] as INDC_PRICE_HISTORY[];

  isAddNDC: boolean = false;
  options: string[];
  //attrCnangeOptions : typeof attributeChangeOption = attributeChangeOption;
  datasources: any;
  pricespecification: any;

  contexMenu;
  message;
  gridhead: any;

  @ViewChild('modalNDCList') modalNDCList: ModalComponent;
  @ViewChild('modalPublish') modalNPublish: ModalComponent;
  @ViewChild('fdbTab') div: ElementRef;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private configsvc: ConfigService,
    private elementRef: ElementRef,
    private ndcSvc: NDCService<INDC_ATTRIBUTES>,
    private dataSvc: DataService,
    private pricehistorySvc: PriceHistoryService<INDC_PRICE_HISTORY>,
    private conversionSvc: ConversionService<IDS_RJ_MAP>,
    private _globalSev: GlobalService) {
      this.user = JSON.parse(localStorage.getItem('currentUser'));
      this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {
    this.isAddNDC = false;
    this.ndcNumber = this.route.snapshot.params['workqueue'];
    this.gridhead = NDCFailureGridHead;
    this.getNDCByCode(this.ndcNumber);
    this.message = NDCFailureMessage;
    this.contexMenu = this.configsvc.getcontexMenu();
    this.contexMenu.forEach(cm => cm.subject.subscribe(val => this.setStatus(val)));

    this.dataSvc.getDropdownData().subscribe((res: any) => {
      this.mockRuleFailureUpdate = res.mockRuleFailureUpdate;
      this.workQueueType = WorkQueueType;
      this.reasonCodeDropDown = res.HcpcNdcReasonCode;
    })
    this.dataSvc.getAllAttribute().subscribe((res: any) => {
      this.attributeNameDropDown = res['Result'];
    });
    this.dataSvc.getWorkQueueName().subscribe((res: any) => {
      this.mockWorkQueue = res;
    });
    this.dataSvc.getDataSource().subscribe((res: any) => {
      this.datasources = res['Result'];
    });
    this.setndcOtherDetails();
  }

  ngAfterViewInit() {
    $('#nextDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.ndcOtherDetails['followUp_date'] = event.target.value;
    });

    $('#piDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    }).on('change', (event: any) => {
      this.ndcOtherDetails['pi_StatusDate'] = event.target.value;
    });

  }

  search() {
    if (this.ndcSearchCode.trim() == '') {
      toastr.error("Please enter NDC Code");
      return;
    } else {
      //this.modalNDCList.show();
      // if (this.ndcSearchCode.trim().length > 3) {
      this.dataSvc.getDistinctNDC(this.ndcSearchCode.trim()).subscribe((res: any) => {
        this.ndcSearchResult = res['Result'];
        if (this.ndcSearchResult.length == 0) {
          toastr.info("Record Not Found");
          return;
        }

        this.modalNDCList.show();
      });
      //}
    }
  }

  getNDCByCode(code: string): any {
    this.ndcNumber = code;

    if (this.ndcSearchResult.length > 0) {
      this.ndcWtId = this.ndcSearchResult.filter(obj => obj.ndc == code)[0]['wt_id'];
    }

    if (code != undefined) {
      this.ndcSvc.getNDCByNDC(code).subscribe((ndcattributes: INDC_ATTRIBUTES[]) => {
        this.ndcDSAttributes = ndcattributes;
        this.ndcSDDLAttributes = ndcattributes.filter(obj => obj.data_source_id == 6)[0];
        this.InitStatus();
        debugger;
        var statusProps = Object.getOwnPropertyNames(this.attrubutStatus);
        statusProps.forEach(prop => {
          this.ndcSDDLAttributes[prop] = 0
        });
        this.ndcSDDLAttributesBackup = Object.assign({}, this.ndcSDDLAttributes);
        this.ndcWtId = this.ndcSDDLAttributes.wt_id;

        this.ndcSvc.getNDCRuleFailure(code).subscribe((ndcrulefailure) => {
          this.ndcRuleFailure = ndcrulefailure;
          if (this.ndcRuleFailure.length > 0) {
            this.ndcSvc.getDiscrepancyAttributes(this.ndcWtId).subscribe((workqueitems: IWORKQUEUE_MAPPING[]) => {
              this.ndcDiscrepancyAttributes = workqueitems;
              if (this.ndcDiscrepancyAttributes.length > 0) {
                this.dataSvc.getUserByQueueId(this.ndcDiscrepancyAttributes[0].queue_id).subscribe((res: any) => {
                  this.mockUser = res;
                })
              }

              //check ndcRuleFailure to change status and create link
              var self = this;
              var ths = Array.prototype.slice.call(document.getElementById("grid").getElementsByTagName("th"));
              this.ndcRuleFailure.forEach(function (obj) {
                var status = obj['attribute_name'];
                self.ndcSDDLAttributes[status.toLowerCase() + '_status'] = 2;
                self.ndcSDDLAttributesBackup[status.toLowerCase() + '_status'] = 2;

                var link = document.createElement("a");
                link.setAttribute('href', "javascript:void(0)");
                link.innerHTML = self.gridhead[status.toLowerCase()];
                ths.forEach((th) => {
                  if (th.innerHTML.trim() == link.innerHTML.trim()) {
                    link.addEventListener("click", self.showCTpopup.bind(self));
                    th.innerHTML = '';
                    th.appendChild(link);
                  }
                });
              })
            });
          }
          var prop = status.slice(0, -7);
          if (prop.trim().length > 0) {
            if (this.ndcSDDLAttributesBackup[prop] != event) {
              debugger;
              this.ndcSDDLAttributes[status] = 1;
            } else {
              this.ndcSDDLAttributes[status] = this.ndcSDDLAttributesBackup[status];
            }
          }
        });

        this.ndcSvc.getNDCPrescribingInformation(this.ndcWtId).subscribe((ndcprescribinginformation) => {
          if (ndcprescribinginformation != null) {
            this.ndcOtherDetails['pi_link'] = ndcprescribinginformation['pi_link'];
            this.ndcOtherDetails['pi_status_date'] = ndcprescribinginformation['pi_status_date'];
          }
        });

        this.ndcSvc.getNDCPriceSpecification().subscribe((pricespecification) => {
          console.log(pricespecification);
          this.pricespecification = pricespecification;
        });
      });
    }
  }

  modelChange(status, event) {
    var prop = status.slice(0, -7);
    if (status != '') {
      if (this.ndcSDDLAttributesBackup[prop] != event) {
        debugger;
        this.ndcSDDLAttributes[status] = 1;
      } else {
        this.ndcSDDLAttributes[status] = this.ndcSDDLAttributesBackup[status];
      }
    }
  }

  showhide(ds: number) {
    if (this.isNewNDC == false) {
      switch (ds) {
        case 2:
          this.fdbshow = !this.fdbshow;
          if (this.fdbView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((fdbView: INDC_ATTRIBUTES[]) => {
              debugger;
              this.fdbView = fdbView;
            })
          }
          //this.fdbView = this.fdbshow == true ? this.ndcDSAttributes.DataSource.FDB : this.ndcDSAttributes.DataSource.FDB.slice(0, 1);
          break;
        case 4:
          this.gsShow = !this.gsShow;
          if (this.gsView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((gsView: INDC_ATTRIBUTES[]) => {
              debugger;
              this.gsView = gsView;
            })
          }
          // this.gsView = this.gsShow == true ? this.ndcDSAttributes.DataSource.GS : this.ndcDSAttributes.DataSource.GS.slice(0, 1);
          break;
        case 6:
          this.rjshow = !this.rjshow;
          if (this.rjView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((rjView: INDC_ATTRIBUTES[]) => {
              debugger;
              this.rjView = rjView;
            })
          }
          break;
        case 7:
          this.msshow = !this.msshow;
          if (this.msView.length == 0) {
            this.ndcSvc.getNDCHistory(this.ndcNumber, ds).subscribe((msView: INDC_ATTRIBUTES[]) => {
              debugger;
              this.msView = msView;
            })
          }
          break;
      }
    }
  }

  showCTpopup(e) {
    this.selectedSuperSix = e.srcElement.innerHTML;
    var key = Object.keys(NDCFailureGridHead).find(key => NDCFailureGridHead[key] === e.srcElement.innerHTML);
    this.conversionSvc.getConversionTranslation(key).subscribe((ndcSuperSix: IDS_RJ_MAP[]) => {
      this.conversionTranslate = ndcSuperSix['Result'];
      var x = document.getElementById("CTPopup");
      x.style.position = "relative";
      x.style.left = '550.5px';
      x.style.top = '-1926px';
      x.style.display = 'block';
    });
  };

  closeCTpopup() {
    var x = document.getElementById("CTPopup");
    x.style.display = 'none';
  }

  showhistory(ds, data_source_id, attribute_name) {
    debugger;
    this.activePricing = attribute_name;
    this.ndcAWPWACHistory = this.ndcAWPWACHistoryBackup.filter(obj => obj.data_source_id === data_source_id && obj['attribute_name'] === attribute_name);

    if (this.ndcAWPWACHistory.length == 0) {
      this.pricehistorySvc.getPriceHistory(this.ndcNumber, attribute_name).subscribe((pricehistory: INDC_PRICE_HISTORY[]) => {
        pricehistory.forEach((obj) => {
          this.ndcAWPWACHistoryBackup.push(obj);
        })
        this.ndcAWPWACHistory = this.ndcAWPWACHistoryBackup.filter(obj => obj.data_source_id === data_source_id && obj['attribute_name'] === attribute_name);
        this.priceHistoryshow = true;
        var dsTab = document.getElementById(ds);
        console.log(dsTab);
      })
    }


    // if (document.getElementById(ds) == null) {
    //   setTimeout(function () { document.getElementById(ds).click(); }, 1000);
    // } else {
    //   document.getElementById(ds).click();
    // }
  }

  contexMenuClick(prop) {
    this.statusProp = prop;
  }

  setndcOtherDetails() {
    this.ndcOtherDetails = {
      reason_notes: "",
      reason_code: "",
      pi_link: "",
      pi_status_date: new Date(),
      price_spec_id: 0,
      price_spec_notes: '',
      follow_up_date: "",
      work_queue: 0,
      work_queue_type: 0,
      route_user_id: 0,
      routing_notes: '',
      req_to_publish_note: '',
      reason_attribute_id:''
    }
  }

  setStatus(id) {
    var prop = this.statusProp.slice(0, -7);
    //var maxId: number = Math.max.apply(Math, this.ndcDSAttributes.DataSource.RJ.map(function (o) { return o.Id; }))
    var updatedData = Object.assign({}, this.ndcSDDLAttributes);
    if (updatedData[prop] === this.ndcSDDLAttributesBackup[prop]) {
      toastr.error('Status not allowed to <br> change on old value');
      return;
    }

    // switch case not required directly assin id
    switch (id) {
      case 0: //Failure Resolved
        this.ndcSDDLAttributes[this.statusProp] = 0;
        this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        break;
      case 1: //Follow-Up
        //this.ndcSDDLAttributes[this.statusProp] = 1;
        break;
      case 2: //Further Routing
        //this.ndcSDDLAttributes[this.statusProp] = 2;
        break;
      case 3: //override value
        this.ndcSDDLAttributes[this.statusProp] = 3;
        if (this.ndcSDDLAttributesBackup[status] == undefined) {
          this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        }
        break;
      case 4: //Change Review
        this.ndcSDDLAttributes[this.statusProp] = 4;
        if (this.ndcSDDLAttributesBackup[status] == undefined) {
          this.ndcSDDLAttributesBackup[this.statusProp] = 0;
        }
        break;
      default:
        toastr.info('Invalid selection');
        break;
    }
    this.statusProp = '';
  }

  addNDC() {
    this.isAddNDC = true;
    if (this.newNDC == false) {
      //var maxId: number = Math.max.apply(Math, this.ndcSDDLAttributes.map(function (o) { return o.Id; }))
      //var objNewNDC = { "Id": maxId + 1, "Generic_Name": "", "Generic_NameStatus": 0, "Brand_Name": "", "Brand_NameStatus": 0, "Strenth": "", "StrenthStatus": 0, "RoA": "", "RoAStatus": 0, "DF": "", "DFStatus": 0, "Rx_OTC_Ind": "", "Rx_OTC_IndStatus": 0, "AWPPrice": "", "AWPPriceStatus": 0, "WACPrice": "", "WACPriceStatus": 0, "Br_Generic_Indicator": "", "Br_Generic_IndicatorStatus": 0, "Package_Size": "", "Package_SizeStatus": 0, "Package_Size_UoM": "", "Package_Size_UoMStatus": 0, "Package_Description": "", "Package_DescriptionStatus": 0, "Package_Unit_Dose": "", "Package_Unit_DoseStatus": 0, "Package_Quantity": "", "Package_QuantityStatus": 0, "Repackager_Ind": "", "Repackager_IndStatus": 0, "SD_MD": "", "SD_MDStatus": 0, "Tee_Code": "", "Tee_CodeStatus": 0, "IO_Pkg_Ind": "", "IO_Pkg_IndStatus": 0, "Manufacturer_Name": "", "Manufacturer_NameStatus": 0, "CMS_Rebet": "", "CMS_RebetStatus": 0, "Date": "", "DateStatus": 0, "Reason": "", "ReasonStatus": 0 };    //this.msView=new Array();
      //this.ndcSDDLAttributes.unshift(objNewNDC);
      this.newNDC = true;
      //this.showhide("RJ");
    } else {
      toastr.error("Add Multiple NDC Not Allow");
    }
  }

  save() {
    debugger;
    var errorList = [];
    this.isAddNDC = false;

    //valiadation for attributes value canot be blank
    var props = Object.getOwnPropertyNames(this.gridhead);
    props.forEach(prop => {
      if (this.ndcSDDLAttributes[prop] == "") {
        errorList.push(this.gridhead[prop] + '<br/>');
      }
    });


    // if (this.ndcSDDLAttributes['followupDate'] == "" && (this.ndcSDDLAttributes['FurtherRouting']['UserId'] == "" && this.ndcSDDLAttributes['FurtherRouting']['WorkQueueId'] == "" && this.ndcSDDLAttributes['FurtherRouting']['WorkQueueTypeId'] == "" && this.ndcSDDLAttributes['FurtherRouting']['Notes'] == "")) {
    //   errorList.push("Any of Follow up or Further Routing is to be field"+ '<br/>');
    // }
    // if ((this.ndcSDDLAttributes['Prescribe']['Link'] == "" && this.ndcSDDLAttributes['Prescribe']['Notes'] == "") && (this.ndcSDDLAttributes['PriceSpec']['SpecificationId'] == "" && this.ndcSDDLAttributes['PriceSpec']['Notes'] == "")) {
    //   errorList.push("PI and Price Spec/Drug Monograph should not be empty"+ '<br/>');
    // }

    if (errorList.length > 0) {
      errorList.splice(0, 0, 'Following are the error(s):<br/>')
      toastr.error(errorList.toString().replace(",", ""));
      return;
    }

    if (this.newNDC = true) {
      // var objNewNDC = { "Id": 0, "Generic_Name": "", "Generic_NameStatus": 0, "Brand_Name": "", "Brand_NameStatus": 0, "Strenth": "", "StrenthStatus": 0, "RoA": "", "RoAStatus": 0, "DF": "", "DFStatus": 0, "Rx_OTC_Ind": "", "Rx_OTC_IndStatus": 0, "AWPPrice": "", "AWPPriceStatus": 0, "WACPrice": "", "WACPriceStatus": 0, "Br_Generic_Indicator": "", "Br_Generic_IndicatorStatus": 0, "Package_Size": "", "Package_SizeStatus": 0, "Package_Size_UoM": "", "Package_Size_UoMStatus": 0, "Package_Description": "", "Package_DescriptionStatus": 0, "Package_Unit_Dose": "", "Package_Unit_DoseStatus": 0, "Package_Quantity": "", "Package_QuantityStatus": 0, "Repackager_Ind": "", "Repackager_IndStatus": 0, "SD_MD": "", "SD_MDStatus": 0, "Tee_Code": "", "Tee_CodeStatus": 0, "IO_Pkg_Ind": "", "IO_Pkg_IndStatus": 0, "Manufacturer_Name": "", "Manufacturer_NameStatus": 0, "CMS_Rebet": "", "CMS_RebetStatus": 0, "Date": "", "DateStatus": 0, "Reason": "", "ReasonStatus": 0 };    //this.msView=new Array();
    }

    if (this.ndcSDDLAttributes != undefined) {
      this.getChangedAttr(this.ndcSDDLAttributesBackup, this.ndcSDDLAttributes);

      // for (var prop in this.ndcChangedAttr) {
      //   if (this.ndcChangedAttr.hasOwnProperty(prop)) {
      //     errorList.push(this.message[prop] + '<br/>');
      //   }
      // }

      var workqueues = [];
      var rule_failures = [];

      // work_queue: 0,
      // work_queue_type: 0,
      // route_user_id: 0,
      // routing_notes: '',
      // req_to_publish_note: ''

      var savedata = {
        "wt_id": this.ndcWtId,
        "pi_link": this.ndcOtherDetails['pi_link'],
        "pi_status_date": this.ndcOtherDetails['pi_status_date'],
        "price_spec_id": this.ndcOtherDetails['price_spec_id'],
        "price_spec_notes": this.ndcOtherDetails['price_spec_notes'],
        "follow_up_date": this.ndcOtherDetails['follow_up_date'],
        "wq_list": {
          "ndc": this.ndcNumber,
          "wt_id": this.ndcWtId,
          "user_id": this.ndcOtherDetails['route_user_id'],
          "wq_notes": this.ndcOtherDetails['reason_notes'],
          "reason_code": this.ndcOtherDetails['reason_code'],
          "queue_id": this.ndcOtherDetails['work_queue'],
          "routing_notes": this.ndcOtherDetails['routing_notes'],
          "stage_id": this._globalSev.workqueuetype,
          "reason_attribute_id":'',
          "workqueues": workqueues,
          "rule_failures": rule_failures
        }
      }

      for (var prop in this.ndcChangedAttr) {
        var workqueue = {
          "workqueue_id": "0",
          "attribute_id": "0",
          "attribute_name": "",
          "attribute_value": "0",
          //"attribute_status": "0" attribute_name
        };

        var attr = this.attributeNameDropDown.filter(obj => obj['attribute_name'] == prop);
        var wt_item;

        if (attr.length > 0) {
          workqueue.workqueue_id = "0";
          workqueue.attribute_id = attr[0]['attribute_id'];
          workqueue.attribute_name = attr[0]['attribute_name'];
          workqueue.attribute_value = this.ndcChangedAttr[prop];
          //workqueue.attribute_status"= this.ndcChangedAttr[prop+'_status'];
          workqueues.push(workqueue);
        }
      }
    } else {
      toastr.error("Any atteibutes updates not made");
      return;
    }

    this.ndcRuleFailure.forEach(existing => {
      var attrRF = workqueues.filter(obj => obj['attribute_name'] == existing['attribute_name']);
      if (attrRF.length > 0) {
        var ndcworkqueueitem = this.ndcDiscrepancyAttributes.filter(obj => obj['attribute_name'] == existing['attribute_name']);
        // attrRF['workqueue_id'] = ndcworkqueueitem[0]['workqueue_id'];
        workqueues.filter(obj => obj['attribute_name'] == existing['attribute_name'])[0]['workqueue_id'] = ndcworkqueueitem[0]['workqueue_id'];
        debugger;
        attrRF[0]['attribute_status'] = existing['attribute_status'];
        rule_failures.push(attrRF);
        //workqueues.filter(obj => obj['attribute_name'] == existing['attribute_name']).splice(1);
        workqueues=workqueues.filter(obj => obj['workqueue_id'] ==0);
        
      }
    });

    this.ndcSvc.saveNDCResolution(savedata).subscribe((ndcData: INDC_ATTRIBUTES[]) => {
      if(ndcData['Result'] != null || ndcData['Result'] == "Success"){
        // call ReleaseWorkQueue service
        toastr.success("NDC Resolution Page Data Saved Successfully")
      }
    });

    this.newNDC = false;
    this.setndcOtherDetails();
  }

  savePublish() {
    if (this.ndcOtherDetails['req_to_publish_note'] == '') {
      toastr.error("publish Note cannot be empty");
    } else {
      this.modalNPublish.hide()
    }
  }

  selectedtributeChangeOption(value: string) {
    console.log(attributeChangeOption[value]);
  }
  cancel() {
      this.router.navigate(['home']);
  }
  getChangedAttr(newObj, oldObj): Object {
    this.ndcChangedAttr = {};
    // Create arrays of property names
    var newProps = Object.getOwnPropertyNames(newObj);
    var oldProps = Object.getOwnPropertyNames(oldObj);
    delete newObj[""];
    delete oldObj[""];

    // If number of properties are different
    if (newProps.length != oldProps.length) {
      return this.ndcChangedAttr;
    }

    for (var i = 0; i < newProps.length; i++) {
      var propName = newProps[i];
      // Those property values are not equal
      if (newObj[propName] !== oldObj[propName]) {
        this.ndcChangedAttr[propName] = oldObj[propName];
      }
    }

    var Props = Object.getOwnPropertyNames(this.ndcChangedAttr);
    for (var loop = Props.length - 1; loop >= 0; loop--) {
      var statusProp = Props[loop] + 'Status';
      if (this.ndcChangedAttr[statusProp] != undefined) {
        delete this.ndcChangedAttr[Props[loop]];
        delete this.ndcChangedAttr[statusProp];
      }
    }

    return this.ndcChangedAttr;
  }

  InitStatus() {
    this.attrubutStatus = {
      awp_status: 0,
      br_generic_indicator_status: 0,
      brand_name_status: 0,
      dosage_form_status: 0,
      generic_name_status: 0,
      inner_outer_package_indicator_status: 0,
      manufacturer_name_status: 0,
      ndc_status_date_status: 0,
      ndc_status_status: 0,
      package_description_status: 0,
      package_quantit_status: 0,
      package_size_status: 0,
      package_size_umo_status: 0,
      package_unit_dose_status: 0,
      repackager_ind_status: 0,
      route_of_administration_status: 0,
      rx_otc_ind_status: 0,
      sd_md_status: 0,
      strength_status: 0,
      tee_code_status: 0,
      wac_status: 0
    };
  }
  sortByDescending(arrObj: any) {
    arrObj.sort(function (val1, val2) {
      if (val1.Id > val2.Id) {
        return -1;
      } else if (val1.Id < val2.Id) {
        return 1;
      } else {
        return 0;
      }
    });
  }


}

