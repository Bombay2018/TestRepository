import { Component, OnInit, ViewChild } from '@angular/core';

import { IUSER_MASTER, IPRICE_SPEC } from '../../shared/interfaces/entities.interface';
import { GlobalService } from "./../../services/shared/global.service";
import { PriceSpecService } from '../../services/pricespec.service';
import { ModalComponent } from '../shared/modalpopup.component';

@Component({
  selector: 'app-prisespecmaster',
  templateUrl: './prisespecmaster.component.html',
  providers: [PriceSpecService]
})
export class PriseSpecMasterComponent implements OnInit {

  user: IUSER_MASTER;
  priceSpecData : IPRICE_SPEC[];
  priceSpecFilterData : IPRICE_SPEC[];
  priceSpecSearch: string ="";  
  price_spec_name :string ="";
  price_spec_upload : string ="";
  price_spec_note : string ="";
  isSearch : boolean = false;

  
  @ViewChild('modalPriceSpecList') modalPriceSpecList: ModalComponent;

  constructor(private infoCodeService: PriceSpecService<IPRICE_SPEC>,private _globalSev: GlobalService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this._globalSev.showNavBar(true, this.user.user_name);
  }

  ngOnInit() {
      this.showPriceSpec();
      console.log(this.priceSpecData);
  }

  showPriceSpec()
  {
    this.infoCodeService.getPriceSpec().subscribe((priceSpec : IPRICE_SPEC[]) => {
      this.priceSpecData = priceSpec;
    });
  }

  search() {
    this.isSearch = true;
    if (this.priceSpecSearch.trim() == '') {
      toastr.error("Please enter Price Specification Name");
      return;
    } else {
       this.modalPriceSpecList.show();
    }
  }

  getPriceSpecByName(psName: string): any {    
    this.priceSpecFilterData= this.priceSpecData.filter(obj => obj.price_spec_name == psName);
    this.modalPriceSpecList.hide();
  }

  addPriceSpec()
  {
    this.isSearch = false;
    this.price_spec_name = this.priceSpecSearch;
  }

  savePriceSpec()
  {
    var maxId = Math.max.apply(Math, this.priceSpecData.map(function (o) { return o.id; }));
    if(this.price_spec_name  && this.price_spec_note /* && this.price_spec_upload */)
      {
        this.priceSpecData.push({
            id :maxId+1,
            price_spec_name : this.price_spec_name,
            price_spec_upload : "",                 //this.price_spec_upload,
            price_spec_note : this.price_spec_note
        });
        toastr.success("saved successfully");
      }
      else if(this.isSearch == false && (this.price_spec_name ==""  || this.price_spec_note /*|| this.price_spec_upload == ""*/)){
        toastr.warning("None of the field should be empty");
      }

      console.log(this.priceSpecData);
      this.price_spec_name ="";
      this.price_spec_upload = "";
      this.price_spec_note ="";
  }

  cancelInfoCode()
  {
    this.isSearch = false;
    this.priceSpecSearch ="";
  }

}
