import { Directive, ElementRef, Input, AfterViewInit, HostListener } from '@angular/core';

@Directive({
  selector: '[charallowed]'
})
export class AllowSpecificCharDirective {
  @Input() charallowed: any[];
  @Input() ngModel;

  constructor() { 
  }

  @HostListener('keydown', ['$event']) onKeyDown(event) {
    var keyCode = [];
    console.log(this.ngModel);
    
    this.charallowed.forEach(el => {
      if(isNaN(el)==true){
        keyCode.push(el.toUpperCase());
      }else{
        keyCode.push(el);
      }
    });
    keyCode.push(8,46,37,39);
    var allow=[8,37,39,46]
    if(allow.indexOf(event.keyCode)>=0){
      return true;
    }
   
    if (keyCode.indexOf(String.fromCharCode(event.keyCode)) == -1){
      event.preventDefault();
    }
  }
}