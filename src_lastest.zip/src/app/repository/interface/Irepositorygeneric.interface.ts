import { Observable } from 'rxjs/Observable';

import {IRepository} from './Irepository.interface';

export interface IRepositoryGeneric<TEntity> extends IRepository {
    getAll(action:string): Observable<TEntity[]>;
    getById(action:string, id: number): Observable<TEntity>;
    add(action:string, entity: TEntity): Observable<TEntity>;
    update(action:string, entity: TEntity): Observable<boolean>;
    delete(action:string, id: number):Observable<boolean>;
}