import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IBD_SPEC,IPART_BVSD_SUPER_SIX_MAP } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class NDCPartBvsDService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public NDCPartBvsD: IBD_SPEC;

    constructor(private http: Http, private configSvc: ConfigService,) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }
    
    getpartBvsDData():Observable<IPART_BVSD_SUPER_SIX_MAP[]> {
        return this.http.get("app/shared/mockdata/mockReimbSearchResult.json")
        .map(resp => resp.json() as IPART_BVSD_SUPER_SIX_MAP[])
 
    }
    
    // getNarativeTypeData(): Observable<IBD_SPEC[]> {
    //     return this.http
    //     .get("app/shared/mockdata/mockNarativeType.json")
    //     .map(resp => resp.json() as IBD_SPEC[]
    //     )};

       
    // getbvsDNameDataSource(): Observable<any> {
    //     return this.http
    //     .get("app/shared/mockdata/mockbvsDDataNameDropdown.json")
    //     .map(resp => resp.json());
    // };

    //Calling Mock data to load the bvsD Part
    getbvsdDataList(bvsDPartName: string): Observable<IPART_BVSD_SUPER_SIX_MAP> {
        return this.http
        .get("app/shared/mockdata/mockbvsdDataList.json")
        .map(
            resp => resp.json() as IPART_BVSD_SUPER_SIX_MAP
        );
    }

    //original call to service (Require four parameter)
    // getbvsdDataList(bvsDPartName: string): Observable<IPART_BVSD_SUPER_SIX_MAP[]> {
    //     debugger;
    //     return this.http
    //         .get(this._baseUrl + 'ConversionTranslationMappingData?attributeName=' + code)
    //         .map(
    //         resp => resp.json()
    //         );
    // }
  

}
