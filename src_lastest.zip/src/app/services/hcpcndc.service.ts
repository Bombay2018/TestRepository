import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IHCPC_SUPER_SIX_COMBINATION ,INDC_ATTRIBUTES, IADMIN_CODE,IHCPC_PRICING, IHCPC_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class HCPCNDCService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public hcpcSuperSix: IHCPC_SUPER_SIX_COMBINATION;

    constructor(
        private http: Http,
        private configSvc: ConfigService,
        private repository: Repository<IHCPC_SUPER_SIX_COMBINATION> ) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getHCPCSearchData(): Observable<IHCPC_MASTER[]> {
        return this.http
            .get("app/shared/mockdata/mockHCPC_SearchResult.json")
            .map(resp => resp.json() as IHCPC_MASTER[]);
    }
    getHCPCAdminCodes(): Observable<IADMIN_CODE> {
        return this.http
            .get("app/shared/mockdata/mockadmincodes.json")
            .map(resp => resp.json() as IADMIN_CODE);
    }

    getHCPCSuperSix(): Observable<IHCPC_SUPER_SIX_COMBINATION> {
        return this.http
            .get("app/shared/mockdata/mockHCPC_SuperSixData.json")
            .map(resp => resp.json() as IHCPC_SUPER_SIX_COMBINATION);
    }
    
    getHCPCRuleFailure(){
        return this.http
            .get("app/shared/mockdata/mockHCPC_SuperSixData.json")
            .map(resp => resp.json().Rule_Failure);
    }

    getHcpcNdc(): Observable<INDC_ATTRIBUTES> {
        return this.http
            .get("app/shared/mockdata/mockHCPC_NdcData.json")
            .map(resp => resp.json() as INDC_ATTRIBUTES);
    }

     getHcpcPrice(): Observable<IHCPC_PRICING[]> {
        return this.http
            .get("app/shared/mockdata/mockHCPC_PriceData.json")
            .map(resp => resp.json() as IHCPC_PRICING[]);
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}