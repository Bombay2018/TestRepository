import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { INDC_PRICE_HISTORY } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class PriceHistoryService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public priceHistory: INDC_PRICE_HISTORY;

    constructor(private http: Http, private configSvr: ConfigService, private repository: Repository<INDC_PRICE_HISTORY>, ) {
        this._baseUrl = configSvr.getApiURI();
        this._headers = configSvr.getHTTPHeader;
    }

    // getPriceHistory():Observable<INDC_PRICE_HISTORY> {
    //     return this.http
    //     .get('app/shared/mockdata/mockPriceHistory.json')
    //     .map(resp => resp.json() as INDC_PRICE_HISTORY)
    //     .catch(this.handleError);
    // }
    getPriceHistory(ndc: string,  attributeName: string): Observable<INDC_PRICE_HISTORY[]> {
        return  this.http
            .get(this._baseUrl + "PricingHistoryForAllDataSource?ndc=" + ndc  +  "&attributeName="  +  attributeName)
            .map(resp  =>  <INDC_PRICE_HISTORY[]>resp.json().Result)
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}