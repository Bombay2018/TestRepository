import { Injectable } from '@angular/core';
import {Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { GlobalService } from './../../services/shared/global.service';
//import { UserService } from './../user.service';
//import { IUser } from './../../shared/interfaces/entities.interface'

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private _globalSvc:GlobalService){  
  }
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot,): boolean {
       if (localStorage.getItem('currentUser') || this._globalSvc.user!=null) {
            // logged in so return true
            return true;
        }
        // not logged in so redirect to login page with the return url
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
        return false;
  }
}
