import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import {IUSER_MASTER} from '../../shared/interfaces/entities.interface';
import { UserService } from './../user.service';

import { LoggerService } from './logger.service';

//import * as StackTrace from 'stacktrace-js';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

    constructor(private injector: Injector, private logger: LoggerService, private UserSvc:UserService<IUSER_MASTER>) { }

    handleError(error) {
      debugger;
    //const loggingService = this.injector.get(LoggingService);
    const location = this.injector.get(LocationStrategy);
    const message = error.message ? error.message : error.toString();
    const url = location instanceof PathLocationStrategy ? location : '';
    this.logger.error(error.message, this);

    console.log('Error Location: ' +location);
    console.log('Error message: ' +message);
    console.log('Error url: ' +url);
    
   // get the stack trace, lets grab the last 10 stacks only
    /*StackTrace.fromError(error).then(stackframes => {
      const stackString = stackframes
        .splice(0, 20)
        .map(function(sf) {
          return sf.toString();
        }).join('\n');
    // log on the server
        alert('error');
        //loggingService.log({ message, url, stack: stackString });
        });*/
        alert(error+'=>'+message);
        this.UserSvc.logout();
        throw error;
  }
  
}