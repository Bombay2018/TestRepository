import { Injectable } from '@angular/core';

// @Injectable()
// export class workqueue{
//     ImpactedElement : string;    
// }

export class DropDown {
    id: string;
    value: string;
};
