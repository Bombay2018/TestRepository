import { BrowserModule } from '@angular/platform-browser';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { HttpModule } from '@angular/http';
import { NgModule, ErrorHandler } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { routing } from './app.routes';

import { ContextMenuDirective } from './directives/contextmenu.directive';
import { AllowNumberDirective } from './directives/allownumber.directive';
import { NDCValidatorDirective } from './directives/NDCValidator.directive';
import { AllowSpecificCharDirective } from './directives/allowspecificchar.directive';
import { DiscripancyStatusDirective } from './directives/discrepancystatus.dierctive';
import { DraggableDirective} from './directives/draggable.directive';

import { dropdownSortBy } from './pipes/dropdownsortby.pipe';
import { ObjectFilter } from './pipes/objectfilter.pipe';
import { OrderBy } from './pipes/orderby.pipe';
import { SafeHTMLPipe } from './pipes/safehtmltag.pipe';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { NDCFailureComponent } from './components/ndcfailure/ndcfailure.component';
import { NdcconversionmappingComponent } from './components/ndcconversionmapping/ndcconversionmapping.component';
import { HcpcNdcCrosswalkComponent } from './components/hcpcndccrosswalk/hcpcndccrosswalk.component';
import { IndicationIdcCrosswalkComponent } from './components/indicationidccrosswalk/indicationidccrosswalk.component';
import { InfoCodeMasterComponent } from './components/infocodemaster/infocodemaster.component';
import { NarrativeMasterComponent } from './components/narrativemaster/narrativemaster.component';
import { UploadMasterComponent } from './components/uploadmaster/uploadmaster.component';
import { PIMasterComponent } from './components/pimaster/pimaster.component';
import { PriseSpecMasterComponent } from './components/prisespecmaster/prisespecmaster.component';
import { ReimbMasterComponent } from './components/reimbmaster/reimbmaster.component';
import { NdcBdCrosswalkComponent } from './components/ndcbdcrosswalk/ndcbdcrosswalk.component';
import { HcpcInfoCodeCrosswalkComponent } from './components/hcpcinfocodecrosswalk/hcpcinfocodecrosswalk.component';
import { IndicationAdminCrosswalkComponent } from './components/indicationadmincrosswalk/indicationadmincrosswalk.component';
import { IndicationMinMaxCrosswalkComponent } from './components/indicationminmaxcrosswalk/indicationminmaxcrosswalk.component';

import { TopNavbarComponent } from './components/shared/topnavbar/topnavbar.component';
import { ContextMenuHolderComponent } from './components/shared/contextmenuholder.component';
import { ModalComponent } from './components/shared/modalpopup.component';
import { ConfirmationComponent } from './components/shared/confirmation/confirmation.component';
//import { AutocompleteComponent } from './components/shared/autocomplete.component';


import { AuthGuard } from './services/shared/auth.guard';
import { LoggerService } from './services/shared/logger.service';

import { ConfigService } from './services/shared/config.service';
import { GlobalEventsManager } from './services/shared/globaleventsmanager.service';
import { GlobalErrorHandler } from './services/shared/exceptionhandler.service';
import { ContextMenuService } from './services/shared/contextmenu.service';
import { ConfirmationService } from "./services/shared/confirmation.service";

import { UserService } from './services/user.service';
import { DataService } from './services/data.service';
import { workqueue, DropDown } from './shared/common';

import { IRepositoryGeneric } from './repository/interface/Irepositorygeneric.interface';
import {Repository} from './repository/implement/repository.service';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NDCFailureComponent,
    NdcconversionmappingComponent,
    HcpcNdcCrosswalkComponent,
    IndicationIdcCrosswalkComponent,
    InfoCodeMasterComponent,
    NarrativeMasterComponent,
    UploadMasterComponent,
    PIMasterComponent,
    PriseSpecMasterComponent,
    NdcBdCrosswalkComponent,
    HcpcInfoCodeCrosswalkComponent,
    
    TopNavbarComponent,
    ContextMenuHolderComponent,
    ModalComponent,
    ConfirmationComponent,
   // AutocompleteComponent,
    

    dropdownSortBy,
    OrderBy,
    ObjectFilter,
    SafeHTMLPipe,

    ContextMenuDirective,
    AllowNumberDirective,
    NDCValidatorDirective,
    AllowSpecificCharDirective,
    DiscripancyStatusDirective,
    DraggableDirective,
    ReimbMasterComponent,
    IndicationAdminCrosswalkComponent,
    IndicationMinMaxCrosswalkComponent
  ],
  imports: [
    BrowserModule, HttpModule, FormsModule, routing
  ],

  providers: [AuthGuard,
    DataService,
    workqueue,
    UserService,
    ConfigService,
    GlobalEventsManager,
    Repository,
    ContextMenuService,
    ConfirmationService,
    LoggerService,
  {		
      provide: ErrorHandler,		
      useClass: GlobalErrorHandler		
    },
    {
      provide: LocationStrategy, 
      useClass: HashLocationStrategy
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }