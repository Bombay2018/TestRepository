/// <reference path="../shared/toastr.d.ts" />
import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, Directive } from '@angular/core';
import { Router } from '@angular/router';

import { GlobalEventsManager } from "./../../services/shared/globaleventsmanager.service";
import { HomeService } from "./../../services/home.service";
import { DataService } from '../../services/data.service';
import { Repository } from '../../repository/implement/repository.service';
import { IUSER_MASTER, IWorkQueue, IFOLLOWUP_MASTER } from '../../shared/interfaces/entities.interface';
import { workqueue, DropDown } from '../../shared/common';
import { ConfirmationService } from "../../services/shared/confirmation.service";

declare var $: any;


@Component({
    moduleId: module.id,
    selector: 'app-home',
    templateUrl: './home.component.html',
    providers: [HomeService, DataService, Repository, ConfirmationService]
})

export class HomeComponent implements AfterViewInit {
    user: IUSER_MASTER;
    isDesc: boolean = false;
    column: string = 'ImpactedElement';
    direction: number;
    selectedColumn: Object = {};
    dropDown: DropDown[];
    workqueuedata: IWorkQueue[];
    workqueuedataFilter: IWorkQueue[];
    calendarFollowUp: IFOLLOWUP_MASTER[];
    calendarFollowUpFilter: IFOLLOWUP_MASTER[];
    calendarFollowUpHighlight: IFOLLOWUP_MASTER[];
    el: HTMLElement;
    todayDate: any;
    differenceInDate: any;
    differenceInMonth: any;
    differenceInYear: any;
    ImpactedElement: string;
    RuleFailure: string;
    AttributeFailed: string;
    Status: string;
    statusFilter: string;
    switchResult: any;
    newfollowup: IFOLLOWUP_MASTER = {} as IFOLLOWUP_MASTER;

    seldate: Date;

    @ViewChild('taskDate') div: ElementRef;

    constructor(
        private homeSvc: HomeService<IWorkQueue>,
        private dataSvc: DataService,
        private workqueue: workqueue,
        private router: Router,
        private elementRef: ElementRef,
        private _globalEventsManagerSev: GlobalEventsManager,
        private _confirmationSev: ConfirmationService) {

        this._globalEventsManagerSev.showNavBar.emit(true);
        this.user = JSON.parse(localStorage.getItem('currentUser'));
        toastr.options = { positionClass: 'toast-top-center' };
    }

    ngOnInit() {
        this.todayDate = new Date().getDate();
        this.showWorkQueueData();
        this.showFollowup();
        this.dataSvc.getDropdownData().subscribe((res: any) => {
            this.dropDown = res.HomeGridDropdown;
            this.selectedColumn = this.dropDown[0].id;
        })
    }

    showWorkQueueData() {
        this.homeSvc.getWorkqueue(this.user.user_id).subscribe((WorkQueue: IWorkQueue[]) => {
            if(WorkQueue['Result'] != null){
            WorkQueue['Result'].sort(function (a, b) { return (a.DateAdded > b.DateAdded) ? 1 : ((b.DateAdded > a.DateAdded) ? -1 : 0); } );
            this.workqueuedata = WorkQueue['Result'];
            this.workqueuedataFilter = WorkQueue['Result'];
            }
        });
    }

    showFollowup() {
        debugger;
        var retrievedcalendarFollow = localStorage.getItem('calendarFollowUpKey');
        var parsedretrievedcalendarFollow = JSON.parse(retrievedcalendarFollow);
        if (parsedretrievedcalendarFollow == undefined ||parsedretrievedcalendarFollow.length==0 ) {
            this.homeSvc.getCalendarFollowUp(this.user.user_id).subscribe((calendarData: IFOLLOWUP_MASTER[]) => {
                this.calendarFollowUp = calendarData['result'];
                this.calendarFollowUp = this.calendarFollowUp.filter(obj => (new Date(obj.follow_up_date)).getDate() == (new Date()).getDate());
                this.calendarFollowUpFilter = calendarData['result'];
                localStorage.setItem('calendarFollowUpKey', JSON.stringify(this.calendarFollowUp));
            });
        }
        else {
            this.calendarFollowUp = parsedretrievedcalendarFollow.filter(obj => (new Date(obj.follow_up_date)).getDate() == (new Date()).getDate());
        }
    }

    ngAfterViewInit() {
        $('.date').datepicker({
            format: 'mm/dd/yyyy',
            startDate: new Date(),
            autoclose: true
        }).on('change', (event: any) => {
            this.newfollowup.follow_up_date = event.target.value;
        });

        $('.inlineDate div').datepicker({
            multidate: false,
            multidateSeparator: ",",
            todayHighlight: true,
            beforeShowDay: function (date) {
                var i: number;
                this.homeSvc.getCalendarFollowUp(this.user.user_id).subscribe((calendarData: IFOLLOWUP_MASTER[]) => {
                    this.calendarFollowUpHighlight = calendarData['result'];
                    localStorage.setItem('calendarFollowUpHighlightKey', JSON.stringify(this.calendarFollowUpHighlight));

                    for (i = 0; i < this.calendarFollowUpHighlight.length; i++) {
                        if (date.getMonth() == (new Date(this.calendarFollowUpHighlight[i].follow_up_date)).getMonth()) {
                            if (date.getDate() == (new Date(this.calendarFollowUpHighlight[i].follow_up_date)).getDate()) {
                                if (date.getDate() < (new Date()).getDate())
                                    $(".datepicker td:contains(" + date.getDate() + ")").addClass('danger');
                                else if (date.getDate() >= (new Date()).getDate())
                                    $(".datepicker td:contains(" + date.getDate() + ")").removeClass('today').addClass('primary');
                            }
                        }
                    }
                });
            }.bind(this), //.apply(this),               
        }).on("changeDate", function (e) {
            debugger;
            this.seldate = new Date(e.date)
            var retrievedcalendarFollow11 = localStorage.getItem('calendarFollowUpKey');
            var parsedretrievedcalendarFollow11 = JSON.parse(retrievedcalendarFollow11);
            if (parsedretrievedcalendarFollow11 == undefined ||parsedretrievedcalendarFollow11.length==0 ) {
                this.homeSvc.getCalendarFollowUp(this.user.user_id).subscribe((calendarData: IFOLLOWUP_MASTER[]) => {
                    this.calendarFollowUp = calendarData['result'];
                    this.calendarFollowUp = this.calendarFollowUp.filter(obj => (new Date(obj.follow_up_date)).getDate() == (this.seldate).getDate());
                });
            }
            else {
                this.calendarFollowUp = parsedretrievedcalendarFollow11.filter(obj => (new Date(obj.follow_up_date)).getDate() == (this.seldate).getDate());
            }

        }.bind(this));
    }

    getDateDifference(DateAdded): boolean {
        this.differenceInDate = new Date().getDate() - new Date(DateAdded).getDate();
        this.differenceInMonth = new Date().getMonth() - new Date(DateAdded).getMonth();
        this.differenceInYear = new Date().getFullYear() - new Date(DateAdded).getFullYear();
        if (this.differenceInDate >= 30 || this.differenceInMonth > 1 || this.differenceInMonth == 1 && this.differenceInDate >= 30 || this.differenceInYear >= 1) {
            return true;
        }
        return false;
    }

    showNDCdetail(ImpactedElement: workqueue, RuleFailure: string) {
        this.workqueue = ImpactedElement;
        if (RuleFailure == "NDC") {
            this.router.navigate(['/ndcfailure', this.workqueue]);
        }
        else if (RuleFailure == "HCPC") {
            this.router.navigate(['/hcpcndccrosswalk']);
        }
    }

    sort(selectedColumn) {
        this.column = this.selectedColumn.toString();
        this.direction = this.isDesc == false ? 1 : -1;
    }

    filterStatus($event, statusValue) {
        if ($event.target.checked) {
            this.statusFilter = statusValue;
        }
        this.filterWorkQueueData();
    }

    filterWorkQueueData(): void {
        if (this.ImpactedElement || this.RuleFailure || this.AttributeFailed || this.Status || this.statusFilter) {
            this.workqueuedataFilter = this.workqueuedata.filter
                (item =>
                    ((this.RuleFailure) ? (item.Rule_Failure.toLowerCase().indexOf(this.RuleFailure.toLowerCase()) > -1) : 1)
                    &&
                    ((this.ImpactedElement) ? (item.Impacted_Element.indexOf(this.ImpactedElement.toLowerCase()) > -1) : 1)
                    &&
                    ((this.AttributeFailed) ? (item.Attribute_Failed.toLowerCase().indexOf(this.AttributeFailed.toLowerCase()) > -1) : 1)
                    &&
                    ((this.Status) ? (item.Status.toLowerCase().indexOf(this.Status.toLowerCase()) > -1) : 1)
                    &&
                    ((this.statusFilter) ? (item.Status.toLowerCase().indexOf(this.statusFilter.toLowerCase()) > -1) : 1)
                );
        }
        else {
            this.workqueuedataFilter = this.workqueuedata;
        }
    }

    clear() {
        this.ImpactedElement = "";
        this.RuleFailure = "";
        this.AttributeFailed = "";
        this.Status = "";
        this.workqueuedataFilter = this.workqueuedata;
    }

    parseDate(dateString: string): Date {
        if (dateString) {
            return new Date(dateString);
        } else {
            return null;
        }
    }

    saveFollowUp() {
        if (this.newfollowup.ndc && this.newfollowup.hcpc && this.newfollowup.drug_name &&
            this.newfollowup.follow_up_date && this.newfollowup.notes) {
            this.newfollowup.user_id = this.user.user_id;
            // newfollowup.is_ndc_followup=false;
            this.homeSvc.saveFollowUp(this.newfollowup).subscribe(
                resdata => this.showFollowup()
            );
        }
        else {
            toastr.warning("None of the field should be empty while adding follow-up");
        }
    }

    deleteFollowUpTask(followUpId) {
        this.homeSvc.deleteFollowUp(followUpId).subscribe(
            resdata  =>  this.showFollowup()
        );
    }
}