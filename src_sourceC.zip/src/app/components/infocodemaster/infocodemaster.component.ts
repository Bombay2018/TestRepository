import { Component, OnInit, ViewChild } from '@angular/core';
import {GlobalEventsManager} from "./../../services/shared/globaleventsmanager.service";
import { InfoCodeService } from '../../services/infocode.service';
import { IINFO_CODE } from '../../shared/interfaces/entities.interface';
import { ModalComponent } from '../shared/modalpopup.component';

@Component({
  selector: 'app-infocodemaster',
  templateUrl: './infocodemaster.component.html',
  providers: [InfoCodeService]
})
export class InfoCodeMasterComponent implements OnInit {

  infoCodeData : IINFO_CODE[];
  infoCodeFilterData : IINFO_CODE[];
  infoCodeSearch: string ="";  
  info_code : string ="";
  info_note : string ="";
  isSearch : boolean = false;
  infoCodeReturn:string="";
  IsCallFromModal:boolean=false;

  @ViewChild('modalInfoCodeList') modalInfoCodeList: ModalComponent;

  constructor(private infoCodeService: InfoCodeService<IINFO_CODE>,
              private _globalEventsManagerSev: GlobalEventsManager) 
  {
    this._globalEventsManagerSev.showNavBar.emit(true);
  }

  ngOnInit() {
      
  }

  showInfoCodedata() {
        // this.infoCodeService.getInfoCode(this.infoCodeSearch).subscribe((infoCode: IINFO_CODE[]) => {
        //     this.infoCodeData = infoCode['Result'];
        // });
        this.infoCodeFilterData =[];
        this.infoCodeService.getInfoCode(this.infoCodeSearch).subscribe((infoCode: IINFO_CODE[]) => {
          this.infoCodeData = infoCode['Result'];
          if(this.infoCodeData!=null && this.infoCodeData.length>1){
            this.IsCallFromModal=true;
          this.modalInfoCodeList.show();
          }
          else if(this.infoCodeData!=null && this.infoCodeData.length==0){
          toastr.warning("No record found for info code" + " " + this.infoCodeSearch);
          this.infoCodeSearch="";
          }
          else{
          this.IsCallFromModal=false;
          this.getInfoByCode(this.infoCodeData[0].info_code);
          }
        });
    }

  search() {
    this.isSearch = true;
    if (this.infoCodeSearch.trim() == '') {
      toastr.error("Please enter Valid Info Code");
      return;
    } else {
       this.showInfoCodedata();
       
    }
  }
  
  addInfoCode()
  {
    this.isSearch = false;  
    this.infoCodeSearch="";
       
  }

  //With Mock data
  // getInfoByCode(code: string): any {    
  //   this.infoCodeFilterData= this.infoCodeData.filter(obj => obj.info_code == code);
  //   this.modalInfoCodeList.hide();
  // }

  //With Service data
  getInfoByCode(code: string): any {    
    this.infoCodeService.getInfoByCode(code).subscribe((infoCode: IINFO_CODE[]) => {
       this.infoCodeFilterData = infoCode['Result'];   
    });
    if(this.IsCallFromModal==true)
    this.modalInfoCodeList.hide();
  }

  saveInfoCode()
  {
    //var maxId = Math.max.apply(Math, this.infoCodeData.map(function (o) { return o.id; }));
    this.infoCodeData=[];
    if(this.isSearch == false && (this.info_code =="" || this.info_note == "")){
      toastr.warning("None of the field should be empty");
    }
    else if(this.info_code && this.info_note)
      {
        // this.infoCodeData.push({
        //     id :maxId+1,
        //     info_code : this.info_code,
        //     info_note : this.info_note
       
        // });       
        
        this.infoCodeData.push({
          info_code_id :null,
          info_code : this.info_code,
          note_description : this.info_note
      });  
    }
    else if (this.isSearch == true){
      
      this.infoCodeData.push({
        info_code_id :this.infoCodeFilterData[0].info_code_id,
        info_code : this.infoCodeFilterData[0].info_code,
        note_description : this.infoCodeFilterData[0].note_description
    });  
    }
    
    this.infoCodeService.saveInfoCode(this.infoCodeData).subscribe((infoCode: IINFO_CODE[]) => {
      this.infoCodeReturn = infoCode['Result']; 
      if (this.infoCodeReturn=="success")
      toastr.success("Info code saved successfully");
    else
    {
      toastr.error("Error while saving Info Code");
      //console.log(this.infoCodeData);
      this.info_code ="";
      this.info_note ="";
      this.infoCodeFilterData=[];
  }     
    });    
  }

  cancelInfoCode()
  {
    this.isSearch = false;
    this.infoCodeSearch ="";
    this.infoCodeFilterData=[];
    this.infoCodeData=[];
  }
}

