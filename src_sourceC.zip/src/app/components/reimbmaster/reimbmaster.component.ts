import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { GlobalEventsManager } from "./../../services/shared/globaleventsmanager.service";
import { IREIMB_CODE } from '../../shared/interfaces/entities.interface';
import { ReimbMasterService } from '../../services/reimbmaster.service';
import { DataService } from '../../services/data.service';
import { DropDown } from '../../shared/common';
import { ModalComponent } from '../shared/modalpopup.component';

declare var $: any;

@Component({
  selector: 'app-reimbmaster',
  templateUrl: './reimbmaster.component.html',
  providers: [ReimbMasterService, DataService]
})
export class ReimbMasterComponent implements OnInit, AfterViewInit {

  actionCodeDropDown: DropDown[];
  reimbCodeData: IREIMB_CODE[];
  reimbCodeDataFilter: IREIMB_CODE[];
  clearFieldReimbCodeDataFilter : IREIMB_CODE[];
  newReimbCodeData: IREIMB_CODE = {} as IREIMB_CODE;
  isSearch: boolean = false;
  reimbCodeSearch: string = "";
  reimbDescriptionSearch: string = "";
  ndcSearch: string = "";
  isAddCodeChangeRow: boolean = false;
  isAddUserNotesRow: boolean = false;
  showTabs: boolean = true;

  @ViewChild('modalReimbCodeList') modalReimbCodeList: ModalComponent;
  @ViewChild('modalReimbDescriptionList') modalReimbDescriptionList: ModalComponent;
  @ViewChild('modalNdcList') modalNdcList: ModalComponent;

  constructor(private _globalEventsManagerSev: GlobalEventsManager,
    private reimbMasterService: ReimbMasterService<IREIMB_CODE>,
    private datasvc: DataService, ) {
    this._globalEventsManagerSev.showNavBar.emit(true);
  }

  ngOnInit() {
    this.showReimbCodedata();
    this.datasvc.getDropdownData().subscribe((res: any) => {
      this.actionCodeDropDown = res.ActionCodeDropDown;
    })
  }

  ngAfterViewInit() {
    $('#EffectiveDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    });

    $('#TerminalDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    });

    $('#ActionDate').datepicker({
      format: 'mm/dd/yyyy',
      startDate: new Date(),
      autoclose: true
    });
    //   .on('change', (event: any) => {
    //     this. = event.target.value;
    // });
  }

  showReimbCodedata() {
    this.reimbMasterService.getReimbCode().subscribe((reimbCode: IREIMB_CODE[]) => {
      this.reimbCodeData = reimbCode;
      //this.reimbCodeDataFilter = reimbCode;
      console.log(this.reimbCodeData);
    });
  }

  search() {
    this.isSearch = true;
    this.showTabs = false;
    if (this.reimbCodeSearch.trim() == '' && this.reimbDescriptionSearch.trim() == '' && this.ndcSearch.trim() == '') {
      toastr.error("Please enter Reimb Code or Description or NDC ");
      return;
    } else if (this.reimbCodeSearch.trim() != '') {
      this.modalReimbCodeList.show();
    }
    else if (this.reimbDescriptionSearch.trim() != '') {
      this.modalReimbDescriptionList.show();
    }
    else if (this.ndcSearch.trim() != '') {
      this.modalNdcList.show();
    }
  }

  getReimbByCode(code: any): any {
    if (this.reimbCodeSearch.trim() != '') {
      this.reimbCodeDataFilter = this.reimbCodeData.filter(obj  =>  obj.reimb_code == code);
      this.modalReimbCodeList.hide();
    }
    else if (this.reimbDescriptionSearch.trim() != '') {
      this.reimbCodeDataFilter = this.reimbCodeData.filter(obj  =>  obj.reimb_code_description == code);
      this.modalReimbDescriptionList.hide();
    }
    else if (this.ndcSearch.trim() != '') {
      this.reimbCodeDataFilter = this.reimbCodeData.filter(obj  =>  obj.ndc == code);
      this.modalNdcList.hide();
    }
    this.ngAfterViewInit();
  }

  onSelectionChange(codeType,entry)
  {
    debugger;
    if(codeType=='adminCode'){
        this.newReimbCodeData.is_admin_code = entry;
      }
      else if(codeType=='nocCode'){
          this.newReimbCodeData.is_noc_code = entry;
      }
  }

  addNewReimbCode() {
    this.showTabs = true;
    this.reimbCodeDataFilter = this.clearFieldReimbCodeDataFilter;
  }

  addCodeChangeRow() {
    this.isAddCodeChangeRow = true;
  }

  addUserNotesRow() {
    this.isAddUserNotesRow = true;
  }

  save() {

  }

  cancel() {
    this.isAddUserNotesRow = false;
    this.isAddCodeChangeRow = false;
  }
}
