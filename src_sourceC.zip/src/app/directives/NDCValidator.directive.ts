import { Directive, HostListener, Input } from '@angular/core';


@Directive({
  selector: '[validNDC]'
})
export class NDCValidatorDirective {

  constructor() { }

  @Input() ngModel;
  @HostListener('keydown', ['$event']) onKeyDown(event) {
    console.log(event);
    var keyCode = [8, 9, 36, 35, 37, 39, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 109, 110, 173, 189];
    if (keyCode.indexOf(event.which) == -1) {
      return false;
    }

    if (event.which == 8 || event.which == 37 || event.which == 39 || event.which == 46) {
      return true;
    }

    var input = String.fromCharCode(event.which);
    var len = this.ngModel.length + 1;

    switch (true) {
      case (len == 6 || len == 11):
        if (event.which == 189) {
          return true;//!!/-/.test(input);
        }
        return false;
      case (len < 14):
        return !!/[0-9]/.test(input);
      default:
        return false;
    }
  }
}