import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { IUSER_MASTER, IWorkQueue, IFOLLOWUP_MASTER, INDC_ATTRIBUTES } from './../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class HomeService<T>{

    _baseUrl: string = '';
    private _headers: any;

    constructor(private http: Http,
        private configsvc: ConfigService) {
        this._baseUrl = configsvc.getApiURI();
        this._headers = configsvc.getHTTPHeader();
    }

    //searchfor: HCPC=>1; NDC=>2
    globalSearch(code: string, searchfor: number): Observable<INDC_ATTRIBUTES[]> {
        let data = {
            "code": code,
            "searchfor": searchfor
        }

        return this.http
            .post(this._baseUrl + 'globalsearch', data, { headers: this._headers })
            .map((res: Response) => {
                return <INDC_ATTRIBUTES[]>res.json();
            });
    }

    getWorkqueue(userId: number) {
        return this.http
            .get(this._baseUrl + `retrieveWorkQueueDetails?user_id=` + userId)
            .map(
            resp => resp.json()
            );
    }

    getCalendarFollowUp(userId: number): Observable<IFOLLOWUP_MASTER[]> {
        return this.http
            .get(this._baseUrl + `followUpTaskDetails?user_id=` + userId)
            .map((resp: Response) => {
                return resp.json();
            });
    }

    saveFollowUp(followup: IFOLLOWUP_MASTER): Observable<IFOLLOWUP_MASTER> {
        let options = new RequestOptions({ headers: this._headers });
        let body = followup;
        return this.http
            .post(this._baseUrl + 'addfollowUpTask', body, options)
            .map((resp: Response) => {
                console.log(resp);
                return resp.json();
            });
    }

    deleteFollowUp(followup: number): Observable<IFOLLOWUP_MASTER> {
        let options = new RequestOptions({ headers: this._headers });
        let body = {"follow_up_id":followup};
        return this.http
            .post(this._baseUrl + 'deleteFollowUP', body, options)
            .map((resp: Response) => {
                console.log(resp);
                return resp.json();
            });
    }

}

