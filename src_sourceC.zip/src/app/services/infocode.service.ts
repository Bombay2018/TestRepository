//getHTTPHeader
import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { IINFO_CODE } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class InfoCodeService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public infoCode: IINFO_CODE;

    constructor(private http: Http,
         private configSvc: ConfigService, 
         private repository: Repository<IINFO_CODE> ) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }
    //With Mock Data
    // getInfoCode(): Observable<IINFO_CODE[]> {
    //     return this.http.get("app/shared/mockdata/mockINFOSearchResult.json")
    //                     .map(resp => resp.json() as IINFO_CODE[])
    //                     .catch(this.handleError);
    // }

    //With service Data
    getInfoCode(ndcCode: string): Observable<IINFO_CODE[]> {
        return this.http
        .get(this._baseUrl+ 'DistinctInfoCodes?infoCode='+ndcCode)
        .map((res: Response) => {
            //console.log(res.json().Result[0])
            return <IINFO_CODE[]>res.json()
            //.catch(this.handleError);
    });
}

getInfoByCode(ndcCode: string): Observable<IINFO_CODE[]> {
    return this.http
    .get(this._baseUrl+ 'InfoCodeDetails?infoCode='+ndcCode)
    .map((res: Response) => {
        //console.log(res.json().Result[0])
        return <IINFO_CODE[]>res.json()
        //.catch(this.handleError);
});
}

saveInfoCode(saveInfoCode: IINFO_CODE[]) {
    let body = saveInfoCode[0];
    let options = new RequestOptions({ headers: this._headers });
    return this.http
        .post(this._baseUrl + 'SaveInfoCodeDetails', body, options)
        .map(resp => resp.json());

}  
    
    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}