//getHTTPHeader
import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { INDC_ATTRIBUTES } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';
import { Repository } from './../repository/implement/repository.service';

@Injectable()
export class NDCService<T>{
    private _baseUrl: string = '';
    private _headers: any;

    public ndc: INDC_ATTRIBUTES;

    constructor(private http: Http, private configSvc: ConfigService, private repository: Repository<INDC_ATTRIBUTES>, ) {
        this._baseUrl = configSvc.getApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    getListNdc(ndcCode:string) {
        this.repository.getByCode('http://localhost:79/services/DistinctNdc?ndc=', ndcCode)
            .subscribe((ndc: INDC_ATTRIBUTES) => {
                user => this.ndc;
            });
    }

    getNDCByNDC(ndcCode: string): Observable<INDC_ATTRIBUTES[]> {
        return this.http
            .get(this._baseUrl+ 'NdcAttributeDetailsWithDataSource?ndc='+ndcCode)
            .map((res: Response) => {
                console.log(res.json().Result[0])
                return <INDC_ATTRIBUTES[]>res.json().Result[0];
            });
    }

    // getNDCByNDC2(ndcCode: string): Observable<INDC_ATTRIBUTES> {
    //     return this.http
    //     .get(this._baseUrl+'NdcAttributeDetailsWithDataSource?ndc='+ndcCode)
    //         .subscribe((ndc: INDC_ATTRIBUTES) => {
    //             ndc => this.ndc as INDC_ATTRIBUTES;
    //         });
    // }


    getNdcByCode(ndcCode: string) {
        this.repository.getByCode('app/shared/mockdata/mockNDCMaster.json', ndcCode)
            .subscribe((ndc: INDC_ATTRIBUTES) => {
                user => this.ndc;
            });
    }
    // getNdcFailureByCode(ndc:string) {
    //     return this.http
    //     .get(this._baseUrl+"RuleFailureDetails?ndc="+ndc)
    //     .map(resp => resp.json());
    // }

    getMockNdcFailureByCode(): Observable<INDC_ATTRIBUTES[]> {
        return this.http
            .get("app/shared/mockdata/mockdataNDCFailure.json")
            .map(resp => resp.json() as INDC_ATTRIBUTES[]);
    }

    getMockNdc(): Observable<INDC_ATTRIBUTES[]> {
        return this.http
            .get("app/shared/mockdata/mockNDCMaster.json")
            .map(resp => resp.json() as INDC_ATTRIBUTES[]);
    }

   
}