export const NDCFailureGridHead = {
    "generic_name": "Generic Name",
    "brand_name": "Brand Name",
    "strength": "Strength",
    "route_of_administration": "RoA",
    "dosage_form": "DF",
    "rx_otc_ind": "Rx",
    "awp_price": "AWP Pr",
    "wac_price": "WAC Pr",
    "ndc_status":"Status",
    "ndc_status_date":"Status Date",
    "br_generic_indicator": "B/G Ind",
    "package_size": "PKG Size",
    "package_size_umo": "PKG Size UoM",
    "package_description": "PKG Desc",
    "package_unit_dose": "PKG Unit Dose",
    "package_quantity": "PKG QTY",
    "repackager_ind": "Re PKG Ind",
    "sd_md": "SD/MD",
    "tee_code": "Tee Code",
    "inner_outer_package_indicator": "Inner Package",
    "manufacturer_name": "MfG Name",
    "cms_rebate": "CMS Rebate",
    "date": "Date",
    "notes_reason": "Notes Reason"
}


export const NDCFailureMessage={
      "Generic_Name": "Generic Name", "Generic_NameStatus": "Generic Name Status",
      "Brand_Name": "Brand Name", "Brand_NameStatus": "Brand Name Status",
      "Strenth": "Strenth", "StrenthStatus": "Strenth Status",
      "RoA": "RoA", "RoAStatus": "RoA Status",
      "DF": "DF", "DFStatus": "DF Status",
      "Rx_OTC_Ind": "Rx", "Rx_OTC_IndStatus": "Rx Status",
      "AWPPrice": "AWP Pr", "AWPPriceStatus": "AWP Pr Status",
      "WACPrice": "WAC Pr", "WACPriceStatus": "WAC Pr. Status",
      "Br_Generic_Indicator": "B/G Ind", "Br_Generic_IndicatorStatus": "B/G Ind Status",
      "Package_Size": "PKG Size", "Package_SizeStatus": "PKG Size Status",
      "Package_Size_UoM": "PKG Size UoM", "Package_Size_UoMStatus": "PKG Size UoM Status",
      "Package_Description": "PKG Desc", "Package_DescriptionStatus": "PKG Desc Status",
      "Package_Unit_Dose": "PKG Unit Dose", "Package_Unit_DoseStatus": "PKG Unit Dose Status",
      "Package_Quantity": "PKG QTY", "Package_QuantityStatus": "PKG QTY Status",
      "Repackager_Ind": "Re-PKG Ind", "Repackager_IndStatus": "Re-PKG Ind",
      "SD_MD": "Dose/Multi Dose Ind", "SD_MDStatus": "Dose/Multi Dose Ind Status",
      "Tee_Code": "Tee Code", "Tee_CodeStatus": "Tee Code Status",
      "IO_Pkg_Ind": "I/O PKG Ind", "IO_Pkg_IndStatus": "I/O PKG Ind Status",
      "Manufacturer_Name": "Mfg Name", "Manufacturer_NameStatus": "Mfg Name Status",
      "CMS Rebate": "CMS Rebate", "CMS_RebetStatus": "CMS Rebate Status",
      "Date": "Date", "DateStatus": "DateStatus",
      "Reason": "Notes/Reason", "ReasonStatus": "Notes/Reason"
    }

    